import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import Hyosan3DGame from '../../components/games/hyosan-memories-3d/Hyosan3DGame.client';
import './styles.css';

const root = document.getElementById('root');
if (!root) throw new Error('Hyosan showcase root is missing');

createRoot(root).render(
  <StrictMode>
    <Hyosan3DGame />
  </StrictMode>,
);
