import { fileURLToPath } from 'node:url';
import { resolve } from 'node:path';
import { defineConfig } from 'vite';

const showcaseRoot = fileURLToPath(new URL('.', import.meta.url));
const repositoryRoot = resolve(showcaseRoot, '../..');

export default defineConfig({
  root: showcaseRoot,
  publicDir: false,
  resolve: {
    alias: {
      '@': repositoryRoot,
    },
  },
  define: {
    'process.env.NODE_ENV': JSON.stringify('production'),
    'process.env.NEXT_PUBLIC_HYOSAN_TEST_DRIVER': JSON.stringify(''),
  },
  build: {
    outDir: resolve(repositoryRoot, 'output/hyosan-showcase/site'),
    emptyOutDir: true,
    sourcemap: false,
    rollupOptions: {
      input: resolve(showcaseRoot, 'index.html'),
    },
  },
});
