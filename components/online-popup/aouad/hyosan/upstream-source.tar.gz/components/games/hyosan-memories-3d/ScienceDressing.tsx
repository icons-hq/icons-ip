'use client';

import { useMemo } from 'react';
import { useGLTF } from '@react-three/drei';
import { Mesh } from 'three';

/** Static detail inside existing furniture; the loader cache owns shared resources. */
export function ScienceDressing() {
  const gltf = useGLTF('/api/dev/hyosan-3d/science-dressing.glb');
  const scene = useMemo(() => {
    const clone = gltf.scene.clone(true);
    clone.traverse(node => {
      if (!(node instanceof Mesh)) return;
      node.castShadow = !node.name.endsWith('_glass') && !node.name.endsWith('_resin') && !node.name.startsWith('floor-paper');
      node.receiveShadow = true;
    });
    return clone;
  }, [gltf]);
  return <primitive object={scene} dispose={null} />;
}
