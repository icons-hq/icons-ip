'use client';

import { useEffect, useRef } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { Color, HalfFloatType, Line, Material, Mesh, Points, Vector2, WebGLRenderTarget, type Object3D, type WebGLRenderer, type Scene, type Camera } from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { GTAOPass } from 'three/addons/postprocessing/GTAOPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { SMAAPass } from 'three/addons/postprocessing/SMAAPass.js';
import type { Hyosan3DDiagnostics } from './diagnostics';

class SchoolGTAOPass extends GTAOPass {
  private readonly excludedMaterial = Object.assign(new Material(), { visible: false });

  override render(...args: Parameters<GTAOPass['render']>) {
    const hidden: Object3D[] = [];
    const replaced: { mesh: Mesh; materials: Material[] }[] = [];
    const renderer = args[0]; const { shadowMap } = renderer;
    const { autoUpdate, needsUpdate } = shadowMap;
    const originalOverride = this.scene.overrideMaterial;
    const originalAutoClear = renderer.autoClear;
    const originalTarget = renderer.getRenderTarget();
    const originalColor = renderer.getClearColor(new Color());
    const originalAlpha = renderer.getClearAlpha();
    try {
      // RenderPass already owns this frame's shadows. An explicit dirty request
      // must survive AO for the next beauty pass, rather than be consumed here.
      shadowMap.autoUpdate = false; shadowMap.needsUpdate = false;
      // GTAOPass replaces every mesh material with opaque normals. Keep the
      // beauty pass intact, but do not restore walls that the player can see through.
      this.scene.traverse((node) => {
        if (!node.visible) return;
        // Own Three's existing line/point exclusion too, so a failed normal
        // render cannot leave its private visibility cache half-restored.
        if (node instanceof Line || node instanceof Points || 'isLine2' in node && node.isLine2 === true) {
          hidden.push(node); node.visible = false; return;
        }
        if (!(node instanceof Mesh)) return;
        const materials = Array.isArray(node.material) ? node.material : [node.material];
        const excluded = materials.map((material) => material.opacity < 1 || !material.depthWrite);
        if (excluded.every(Boolean)) {
          hidden.push(node); node.visible = false;
        } else if (excluded.some(Boolean)) {
          // Three checks original group-material visibility before its normal
          // override. Substitute only those slots; shared materials stay untouched.
          replaced.push({ mesh: node, materials });
          node.material = materials.map((material, index) => excluded[index] ? this.excludedMaterial : material);
        }
      });
      super.render(...args);
    } finally {
      for (const node of hidden) node.visible = true;
      for (const { mesh, materials } of replaced) mesh.material = materials;
      shadowMap.autoUpdate = autoUpdate; shadowMap.needsUpdate = needsUpdate;
      this.scene.overrideMaterial = originalOverride;
      renderer.autoClear = originalAutoClear;
      renderer.setClearColor(originalColor, originalAlpha);
      renderer.setRenderTarget(originalTarget);
    }
  }

  override dispose() {
    this.excludedMaterial.dispose();
    super.dispose();
  }
}

function createLightingPipeline(gl: WebGLRenderer, scene: Scene, camera: Camera) {
  const target = new WebGLRenderTarget(1, 1, { type: HalfFloatType, samples: 4 });
  const composer = new EffectComposer(gl, target);
  composer.setPixelRatio(1);
  const render = new RenderPass(scene, camera);
  const ao = new SchoolGTAOPass(scene, camera);
  ao.blendIntensity = .75;
  ao.updateGtaoMaterial({ radius: .48, thickness: .65, samples: 8, distanceFallOff: 1, scale: 1 });
  ao.updatePdMaterial({ samples: 8, rings: 2, radius: 5 });
  const output = new OutputPass();
  const antialias = new SMAAPass();
  // Three 0.185 SMAA consumes linear color, including AO, before tone mapping.
  composer.addPass(render); composer.addPass(ao); composer.addPass(antialias); composer.addPass(output);
  const autoReset = gl.info.autoReset;
  gl.info.autoReset = false;
  return { composer, ao, dispose() {
    render.dispose(); ao.dispose(); antialias.dispose(); output.dispose(); composer.dispose();
    // Three 0.185.1 GTAOPass.dispose omits these two owned shader materials.
    ao.gtaoMaterial.dispose(); ao.blendMaterial.dispose();
    gl.info.autoReset = autoReset;
  } };
}

/** Contact occlusion at reduced resolution; the playfield retains full-resolution color. */
export function LightingPass({ diagnostics }: { diagnostics: Hyosan3DDiagnostics }) {
  const { gl, scene, camera, size, viewport } = useThree();
  const runtime = useRef<ReturnType<typeof createLightingPipeline> | null>(null);
  useEffect(() => {
    const pipeline = createLightingPipeline(gl, scene, camera);
    runtime.current = pipeline;
    return () => {
      runtime.current = null;
      pipeline.dispose();
      diagnostics.recordBuffers(null);
    };
  }, [camera, diagnostics, gl, scene]);
  useEffect(() => {
    const current = runtime.current;
    if (!current) return;
    const bufferSize = gl.getDrawingBufferSize(new Vector2());
    current.composer.setSize(bufferSize.x, bufferSize.y);
    // Color follows physical pixels; AO deliberately retains its CSS-pixel budget.
    current.ao.setSize(Math.ceil(size.width * .6), Math.ceil(size.height * .6));
    diagnostics.recordBuffers({ color: current.composer.readBuffer, ao: current.ao.gtaoRenderTarget });
  }, [camera, diagnostics, gl, scene, size.width, size.height, viewport.dpr]);
  useFrame((_state, dt) => {
    gl.info.reset();
    if (runtime.current) runtime.current.composer.render(dt);
    else gl.render(scene, camera);
  }, 1);
  return null;
}
