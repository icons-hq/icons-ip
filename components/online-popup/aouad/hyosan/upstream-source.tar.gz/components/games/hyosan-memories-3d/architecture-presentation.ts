import { Box3, Mesh, Raycaster, Vector3, type Material, type Object3D } from 'three';
import layout from '@/docs/games/hyosan-memories-3d/world-layout.json';
import type { Hyosan3DEnemy, Hyosan3DPlayer } from '@/lib/games/hyosan-memories-3d/types';

/** Open individual wall/window or doorway assemblies masking a nearby actor. */
export function createArchitecturePresentation(scene: Object3D) {
  const raycaster = new Raycaster();
  const direction = new Vector3();
  const side = new Vector3();
  const origin = new Vector3();
  const hit = new Vector3();
  scene.updateMatrixWorld(true);
  const doorways = layout.doors.filter(door => !/^(library|staffroom|gym|rooftop)-/.test(door.id)).map(door => {
    const object = scene.getObjectByName(`doorway-${door.id}`);
    if (!object) throw new Error(`Missing school doorway ${door.id}`);
    return object;
  });
  const walls = scene.children.filter(object => object.name.startsWith('wall-visibility-'));
  const assemblies = [...doorways, ...walls].map(object => {
    const materials = new Map<Material, Material>();
    const meshes: Mesh[] = [];
    const shadows = new Map<Mesh, boolean>();
    object.traverse(node => {
      if (!(node instanceof Mesh)) return;
      meshes.push(node);
      shadows.set(node, node.castShadow);
      const copy = (source: Material) => {
        let material = materials.get(source);
        if (!material) { material = source.clone(); material.transparent = true; materials.set(source, material); }
        return material;
      };
      node.material = Array.isArray(node.material) ? node.material.map(copy) : copy(node.material);
    });
    // The kitchen has several reflective frame/glass surfaces on one sightline.
    // A normal wall's fade accumulates into a bright band across the actor there.
    const actorOpacityLimit = object.name.startsWith('wall-visibility-s2-kitchen-') ? .025 : .12;
    return { object, meshes, materials, shadows, actorOpacityLimit, box: new Box3().setFromObject(object) };
  });
  raycaster.far = 12;
  let disposed = false;
  return {
    update(player: Readonly<Hyosan3DPlayer>, cameraDirection: Vector3, enemies: readonly Hyosan3DEnemy[] = [],
      equipmentOccluders?: ReadonlySet<Object3D>) {
      if (disposed) return;
      direction.copy(cameraDirection).normalize();
      side.set(-direction.z, 0, direction.x).normalize();
      for (const frame of assemblies) {
        const blocks = (x: number, y: number, z: number, offset = 0) => {
          // Cast from the camera side. Reverse rays miss one-sided faces that
          // the actual camera renders; a body-width probe also catches feet
          // beside the central line of sight.
          origin.set(x, y, z).addScaledVector(side, offset).addScaledVector(direction, -raycaster.far);
          raycaster.set(origin, direction);
          if (!raycaster.ray.intersectBox(frame.box, hit) || hit.distanceTo(origin) > raycaster.far) return false;
          // A box around an open arch also covers its empty passage. The final
          // triangles decide visibility, including the sign and its lettering.
          return raycaster.intersectObjects(frame.meshes, false).length > 0;
        };
        const obscured = [.2, .65, 1.15, 1.65].some(height => [-.28, 0, .28]
          .some(offset => blocks(player.x, player.y + height, player.z, offset)))
          || enemies.some(enemy => enemy.hp > 0 && !enemy.dormant && enemy.currentLayerId === player.currentLayerId
            && Math.hypot(enemy.x - player.x, enemy.z - player.z) <= 4
            && [.2, .65, 1.5].some(height => [-.28, 0, .28]
              .some(offset => blocks(enemy.x, enemy.y + height, enemy.z, offset))));
        const equipmentObscured = equipmentOccluders?.has(frame.object) ?? false;
        const fadeMaterial = (material: Material) => obscured || equipmentObscured && material.name === 'cafeteria_kitchen_plaster';
        for (const [source, material] of frame.materials) {
          const faded = fadeMaterial(source);
          material.opacity = faded ? Math.min(obscured ? frame.actorOpacityLimit : .12, source.opacity) : source.opacity;
          material.depthWrite = !faded && source.depthWrite;
        }
        for (const mesh of frame.meshes) {
          const materials = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
          mesh.castShadow = !materials.every(fadeMaterial) && frame.shadows.get(mesh)!;
        }
      }
    },
    dispose() {
      if (disposed) return;
      disposed = true;
      for (const frame of assemblies) for (const material of frame.materials.values()) material.dispose();
    },
  };
}
