'use client';

import { HYOSAN_REUNION } from '@/lib/games/hyosan-memories-3d/ending';
import { areaBoss, hyosan3DRoomLabel } from './school-presentation';

import { useId, useMemo, useState, type Ref } from 'react';
import layout from '@/docs/games/hyosan-memories-3d/world-layout.json';
import { HYOSAN_ALL_ROOMS, type Hyosan3DArea, type Hyosan3DSnapshot } from '@/lib/games/hyosan-memories-3d/types';
import { hyosan3DAreaForRoom, hyosan3DRoomAt, hyosan3DRoomForFloor } from '@/lib/games/hyosan-memories-3d/rooms';
import { createHyosanElevatedRouteGeometry } from '@/lib/games/hyosan-memories-3d/elevated-routes';
import { createHyosanSupportGeometry, type HyosanSupportPoint } from '@/lib/games/hyosan-memories-3d/support-geometry';
import { HYOSAN_MAIN_LAYER } from '@/lib/games/hyosan-memories-3d/combat-layers';
import { createHyosanNavigationEntrances } from '@/lib/games/hyosan-memories-3d/navigation-entrances';
import { createHyosanNavigationFlights } from '@/lib/games/hyosan-memories-3d/navigation-flights';
import type { HyosanNavigationTarget } from '@/lib/games/hyosan-memories-3d/navigation-target';
import styles from './NavigationMap.module.css';

type GroundPoint = HyosanSupportPoint;
interface PlanRect extends GroundPoint { width: number; depth: number; rotation?: number; elevation?: number }
interface MapFloor extends PlanRect { id: string; label: string; room: ReturnType<typeof hyosan3DRoomForFloor>; points: string }
interface MapGoal extends HyosanNavigationTarget { label: string; kind: 'door' | 'upgrade' | 'boss' | 'memory'; room: string }
const AREAS: { id: Hyosan3DArea; label: string }[] = [
  { id: 'science', label: '과학동' }, { id: 'cafeteria', label: '보건실·급식실' },
  { id: 'classroom', label: '2학년 교실' }, { id: 'broadcast', label: '방송동' },
  { id: 'library', label: '도서관' }, { id: 'staffroom', label: '교무실' }, { id: 'gymnasium', label: '체육관' },
  { id: 'rooftop', label: '옥상' },
];
// Stable within a region, independent of discovery order and save-array order.
const ROOM_NUMBERS = Object.fromEntries(AREAS.flatMap((area) => HYOSAN_ALL_ROOMS
  .filter((room) => hyosan3DAreaForRoom(room) === area.id).map((room, index) => [room, index + 1])));

const CAMERA_COS = 20 / 25;
const CAMERA_SIN = 15 / 25;
const CAMERA_GROUND_HEIGHT = 24 / Math.hypot(24, 25);
const project = ({ x, z, y = 0 }: GroundPoint) => ({ x: x * CAMERA_COS - z * CAMERA_SIN,
  y: (x * CAMERA_SIN + z * CAMERA_COS) * CAMERA_GROUND_HEIGHT - y * 25 / Math.hypot(24, 25) });
const contains = (rect: PlanRect, point: GroundPoint) => Math.abs(point.x - rect.x) <= rect.width / 2 + .01
  && Math.abs(point.z - rect.z) <= rect.depth / 2 + .01;
function corners(rect: PlanRect) {
  const rotation = rect.rotation ?? 0;
  return [[-1, -1], [1, -1], [1, 1], [-1, 1]].map(([sx, sz]) => {
    const dx = sx * rect.width / 2;
    const dz = sz * rect.depth / 2;
    return project({ x: rect.x + dx * Math.cos(rotation) + dz * Math.sin(rotation), y: rect.elevation ?? rect.y ?? 0,
      z: rect.z - dx * Math.sin(rotation) + dz * Math.cos(rotation) });
  });
}
const polygon = (rect: PlanRect) => corners(rect).map(({ x, y }) => `${x},${y}`).join(' ');
function mapFrame(points: readonly { x: number; y: number }[], surface: 'mini' | 'full') {
  if (!points.length) return { viewBox: '0 0 1 1', unit: .08 };
  const left = Math.min(...points.map((point) => point.x));
  const top = Math.min(...points.map((point) => point.y));
  const width = Math.max(...points.map((point) => point.x)) - left;
  const height = Math.max(...points.map((point) => point.y)) - top;
  const margin = Math.max(width, height) * .08;
  return { viewBox: `${left - margin} ${top - margin} ${width + margin * 2} ${height + margin * 2}`,
    unit: Math.max(width, height) / (surface === 'full' ? 75 : 36) };
}
const floors: MapFloor[] = layout.floors.map((floor) => ({ ...floor, room: hyosan3DRoomForFloor(floor), points: polygon(floor) }));
const walls = layout.walls.map((wall) => ({ ...wall, points: polygon(wall) }));
const elevated = createHyosanElevatedRouteGeometry(layout);
const supports = createHyosanSupportGeometry(layout);
// A stair-only room still needs a discovered floor silhouette and legend entry.
// Its actual tread geometry provides both; never invent a flat connecting slab.
const mapFloors: MapFloor[] = [...floors, ...supports.stairs.filter((stair) => !floors.some((floor) => floor.room === stair.roomId))
  .flatMap((stair) => stair.treads.map((tread) => ({ ...tread, id: tread.surfaceId, y: tread.height,
    label: '상승 계단', room: hyosan3DRoomForFloor(tread), points: polygon({ ...tread, y: tread.height }) })))];
const supportRamps = supports.ramps.map((ramp) => ({ ...ramp, points: [[-1, -1], [1, -1], [1, 1], [-1, 1]].map(([sx, sz]) => {
  const x = ramp.x + sx * ramp.width / 2; const z = ramp.z + sz * ramp.depth / 2;
  const point = project({ x, z, y: ramp.height + (x - ramp.x) * ramp.slopeX + (z - ramp.z) * ramp.slopeZ });
  return `${point.x},${point.y}`;
}).join(' ') }));
function roomAt(point: GroundPoint) {
  const sample = supports.sample(point);
  const surface = sample && supports.surfaces.find((candidate) => candidate.surfaceId === sample.surfaceId);
  return surface && hyosan3DRoomForFloor({ id: surface.surfaceId, roomId: surface.roomId }) || hyosan3DRoomAt(point, layout.floors);
}
const ramps = elevated.ramps.map((ramp) => ({ ...ramp, points: [[-1, -1], [1, -1], [1, 1], [-1, 1]].map(([sx, sz]) => {
  const x = ramp.x + sx * ramp.width / 2; const z = ramp.z + sz * ramp.depth / 2;
  const point = project({ x, z, y: elevated.sample({ x, z })!.height });
  return `${point.x},${point.y}`;
}).join(' ') }));
const footprint = (prop: typeof layout.props[number]) => layout.propFootprints[prop.kind as keyof typeof layout.propFootprints];
const entrances = createHyosanNavigationEntrances(layout);
const flights = createHyosanNavigationFlights(layout);
const doors = layout.doors.map((door) => {
  const alongX = door.axis === 'x';
  return { ...door, rooms: entrances.entrances.find((entrance) => entrance.id === door.id)!.rooms,
    from: project({ ...door, x: door.x - (alongX ? door.width / 2 : 0), z: door.z - (alongX ? 0 : door.width / 2) }),
    to: project({ ...door, x: door.x + (alongX ? door.width / 2 : 0), z: door.z + (alongX ? 0 : door.width / 2) }) };
});
const byDoorId = (id: string) => doors.find((door) => door.id === id)!;
interface Connection extends GroundPoint { id: string; label: string; rooms: readonly string[];
  stair?: typeof supports.stairs[number]; ramp?: typeof supports.ramps[number] }
const connections: Connection[] = [...entrances.entrances, ...supports.stairs.map((stair) => ({ ...stair.start, id: stair.id, stair,
  label: '계단', rooms: [stair.fromFloorId, stair.toFloorId].map((id) => floors.find((floor) => floor.id === id)!.room!) })),
...supports.ramps.map((ramp) => ({ ...ramp.start, id: ramp.id, ramp, label: '경사로',
  rooms: [ramp.fromFloorId, ramp.toFloorId].map((id) => floors.find((floor) => floor.id === id)!.room!) }))];
const slopeLabel = (ramp: boolean, upward: boolean) => `${ramp ? '경사로를' : '계단을'} 따라 ${upward ? '위로' : '아래로'}`;

/** A directional boundary needs a target beyond its line, so arriving within
 * .18 m still crosses it. Radius goals and interaction handles remain exact.
 * The canonical boundary, including terminal metadata, is never moved. */
function passageGoal(boundary: GroundPoint & { axis: string; forward: number }, label: string, room: string): MapGoal {
  const axis = boundary.axis === 'x' ? 'x' : 'z';
  return { ...boundary, [axis]: boundary[axis] + boundary.forward * .3, label, kind: 'door', room };
}

function objectiveGoal(snapshot: Readonly<Hyosan3DSnapshot>): MapGoal {
  const nextArea = snapshot.ending?.nextArea;
  const nextProgress = nextArea && snapshot.schoolState?.[nextArea];
  if (snapshot.progress.objective === 'return_memory' && nextArea && nextProgress && nextProgress.objective !== 'return_memory') {
    return objectiveGoal({ ...snapshot, area: nextArea, progress: nextProgress, ending: undefined });
  }
  if (snapshot.progress.objective === 'return_campfire') return { ...HYOSAN_REUNION.approach, label: '모닥불 앞으로', kind: 'memory', room: 'rooftop-memorial' };
  if (snapshot.progress.objective === 'return_science') return { ...layout.science.origin, label: '과학실의 감염 흔적', kind: 'memory', room: 'science-lab' };
  if (snapshot.progress.objective === 'reach_classroom') return { ...layout.classroom.spawn, label: '2학년 교실 복도', kind: 'door', room: 'classroom-west' };
  // The spawn is on the guidance seam itself. Finish inside the next area,
  // beyond its .3 m hysteresis and the map's arrival tolerance.
  if (snapshot.progress.objective === 'reach_broadcast') return { ...layout.broadcast.spawn,
    x: Math.max(layout.broadcast.spawn.x, layout.broadcast.entrySeam.x + .8), label: '방송동 입구', kind: 'door', room: 'broadcast-entry' };
  if (snapshot.progress.objective === 'reach_library') return { ...layout.library.spawn, label: '도서관 입구', kind: 'door', room: 'library-entry' };
  if (snapshot.progress.objective === 'reach_staffroom') return { ...layout.staffroom.spawn, label: '교무실 입구', kind: 'door', room: 'staffroom-entry' };
  if (snapshot.progress.objective === 'reach_gym') return { ...layout.gymnasium.spawn, label: '체육관 전실', kind: 'door', room: 'gym-entry' };
  if (snapshot.progress.objective === 'ascend_rooftop') return { ...byDoorId('rooftop-main-threshold'), label: '옥상 출입구', kind: 'door', room: 'rooftop-threshold' };
  if (snapshot.area === 'rooftop') {
    if (snapshot.progress.objective === 'collect_echo') return { ...layout.rooftop.echo, label: '옥상의 기억 회수', kind: 'memory', room: 'rooftop-memorial' };
    if (snapshot.progress.objective === 'reach_exit' || snapshot.progress.areaResolved) return passageGoal(layout.rooftop.exit, '모닥불 자리 북쪽 끝', 'rooftop-memorial');
    const boss = areaBoss(snapshot) ?? layout.rooftop.boss;
    return { ...boss, label: snapshot.progress.objective === 'defeat_boss' ? '옥상의 귀남' : '열린 옥상 살피기', kind: 'boss', room: roomAt(boss) };
  }
  if (snapshot.area === 'gymnasium') {
    if (snapshot.progress.objective === 'explore_gym') return { ...byDoorId('gym-court-west'), label: '체육관 코트 살피기', kind: 'door', room: 'gym-court' };
    if (snapshot.progress.echoCollected) return passageGoal(layout.gymnasium.exit, '동쪽 로비 끝으로', 'gym-exit');
    if (snapshot.progress.escapeResolved) return { ...layout.gymnasium.echo, label: '탈출의 기억 회수', kind: 'memory', room: 'gym-exit' };
    if (!snapshot.progress.escapeCartCleared) return { ...layout.gymnasium.exitCart.interactPoint, label: '출구 카트 밀기', kind: 'door', room: 'gym-cartlane' };
    return passageGoal(layout.gymnasium.escape, '열린 통로로 탈출하기', 'gym-exit');
  }
  if (snapshot.area === 'staffroom') {
    if (snapshot.progress.objective === 'explore_staffroom') return { ...layout.staffroom.checkpoint, label: '방화 통로 살피기', kind: 'door', room: 'staffroom-firebreak' };
    if (snapshot.progress.objective === 'inspect_records' || snapshot.progress.objective === 'defeat_boss')
      return { ...layout.staffroom.echo, label: '기록석의 파손된 휴대전화', kind: 'memory', room: 'staffroom-records' };
    if (snapshot.progress.objective === 'collect_echo') return { ...layout.staffroom.echo, label: '교무실의 기억 회수', kind: 'memory', room: 'staffroom-records' };
    return passageGoal(layout.staffroom.exit, '휴게실 비상 출입부', 'staffroom-breakroom');
  }
  if (snapshot.area === 'library') {
    if (snapshot.progress.objective === 'explore_library') return { ...layout.library.checkpoint, label: '서가 아래 교차로 살피기', kind: 'door', room: 'library-crossing' };
    if (snapshot.progress.objective === 'climb_shelves') return { ...layout.library.boss, label: '서가 위 길 살피기', kind: 'door', room: 'library-crown' };
    if (snapshot.progress.objective === 'defeat_boss') {
      const boss = areaBoss(snapshot) ?? layout.library.boss;
      return { ...boss, label: '서가 위의 귀남', kind: 'boss', room: roomAt(boss) };
    }
    if (snapshot.progress.objective === 'collect_echo') return { ...layout.library.echo, label: '도서관의 기억 회수', kind: 'memory', room: 'library-crown' };
    return passageGoal(layout.library.exit, '정리실 동쪽 출구', 'library-workroom');
  }
  if (snapshot.area === 'broadcast') {
    if (snapshot.progress.objective === 'inspect_broadcast') return { ...layout.broadcast.console, label: '방송 흔적 조사', kind: 'memory', room: 'broadcast-control' };
    if (snapshot.progress.objective === 'secure_hose') return { ...layout.broadcast.hose.interactPoint, label: '소방호스 고정', kind: 'door', room: 'broadcast-upper' };
    if (snapshot.progress.objective === 'descend_stairs') return { ...layout.broadcast.boss, label: '하층 복도로', kind: 'door', room: 'broadcast-lower' };
    if (snapshot.progress.objective === 'defeat_boss') {
      const boss = areaBoss(snapshot) ?? layout.broadcast.boss;
      return { ...boss, label: '홍대원', kind: 'boss', room: roomAt(boss) };
    }
    if (snapshot.progress.objective === 'collect_echo') return { ...layout.broadcast.echo, label: '방송동의 기억 회수', kind: 'memory', room: 'broadcast-lower' };
    return passageGoal(layout.broadcast.exit, '하층 복도 동쪽 끝', 'broadcast-lower');
  }
  if (snapshot.area === 'classroom') {
    if (snapshot.progress.objective === 'defeat_boss' || snapshot.progress.objective === 'explore_classroom'
      && snapshot.progress.discoveredRooms.includes('classroom-2-5')) {
      const boss = areaBoss(snapshot) ?? layout.classroom.boss;
      return { ...boss, label: '교실 복도의 위협', kind: 'boss', room: roomAt(boss) };
    }
    if (snapshot.progress.objective === 'collect_echo') return { ...layout.classroom.echo, label: '교실의 기억 회수', kind: 'memory', room: 'classroom-2-5' };
    if (snapshot.progress.objective === 'reach_exit' || snapshot.progress.areaResolved) return { ...layout.classroom.exit, label: '동쪽 복도 북쪽 끝', kind: 'door', room: 'classroom-east' };
    return { ...layout.classroom.origin, label: '교실 안쪽으로', kind: 'door', room: 'classroom-2-5' };
  }
  if (snapshot.area === 'science') {
    if (snapshot.progress.objective === 'inspect_lab') return { ...layout.science.origin, label: '감염 흔적 조사', kind: 'memory', room: 'science-lab' };
    if (snapshot.progress.objective === 'defeat_boss') {
      const boss = areaBoss(snapshot) ?? layout.science.boss;
      return { ...boss, label: '첫 감염자', kind: 'boss', room: roomAt(boss) };
    }
    if (snapshot.progress.objective === 'collect_echo') return { ...layout.science.echo, label: '첫 기억 회수', kind: 'memory', room: 'science-lab' };
    return { ...byDoorId('science-infirmary-entry'), label: '보건실로', kind: 'door', room: 'infirmary' };
  }
  if (snapshot.progress.bossApproaching) {
    const threat = areaBoss(snapshot);
    const nurse = threat && threat.hp > 0 && !threat.dormant ? threat : undefined;
    return { ...(nurse ?? byDoorId(layout.adventure.inflow.thresholdId)),
      label: '북서쪽 통로의 위협', kind: nurse ? 'boss' : 'door', room: nurse ? roomAt(nurse) : 'cafeteria' };
  }
  switch (snapshot.progress.objective) {
    case 'find_upgrade': return { ...layout.upgrade, label: '양궁 장비', kind: 'upgrade', room: 'corridor' };
    case 'reach_cafeteria': return snapshot.progress.room === 'cafeteria'
      ? { x: Math.max(layout.adventure.incident.minX + .5, Math.min(layout.adventure.incident.maxX - .5, snapshot.player.x)),
        z: Math.max(layout.adventure.incident.minZ + .5, Math.min(layout.adventure.incident.maxZ - .5, snapshot.player.z)),
        label: '급식실 안쪽으로', kind: 'door', room: 'cafeteria' }
      : { ...byDoorId('cafeteria-entry'), label: '급식실 입구', kind: 'door', room: 'cafeteria' };
    case 'explore_cafeteria': return { x: (layout.adventure.bossBoundary.minX + layout.adventure.bossBoundary.maxX) / 2,
      z: (layout.adventure.bossBoundary.minZ + layout.adventure.bossBoundary.maxZ) / 2,
      label: '급식실 중앙 살피기', kind: 'door', room: 'cafeteria' };
    case 'defeat_boss': {
      const boss = areaBoss(snapshot) ?? layout.boss;
      return { ...boss, label: '급식실의 위협', kind: 'boss', room: roomAt(boss) };
    }
    case 'collect_echo': return { ...layout.adventure.echo, label: '남겨진 기억 회수', kind: 'memory', room: 'cafeteria' };
    default: return { ...byDoorId('next-area'), label: '급식실 출구', kind: 'door', room: 'cafeteria' };
  }
}

/** Door topology selects the next entrance; this map never invents a straight travel path. */
export function getHyosan3DMapGoal(snapshot: Readonly<Hyosan3DSnapshot>): MapGoal | null {
  if (snapshot.progress.awaitingFirstShot) return null;
  if (snapshot.progress.objective === 'explore_school' || snapshot.progress.objective === 'completed') return null;
  const known = new Set<string>(snapshot.progress.discoveredRooms);
  const from = snapshot.progress.room;
  if (!known.has(from)) return null;
  const goal = objectiveGoal(snapshot);
  const classroom = snapshot.area === 'classroom' ? snapshot.progress : snapshot.schoolState?.classroom;
  const science = snapshot.area === 'science' ? snapshot.progress : snapshot.schoolState?.science;
  const cafeteria = snapshot.area === 'cafeteria' ? snapshot.progress : snapshot.schoolState?.cafeteria;
  const currentSupport = supports.sample(snapshot.player);
  const currentFlight = connections.find((connection) => connection.stair?.id === currentSupport?.stairId && currentSupport?.stairId
    || connection.ramp?.id === currentSupport?.rampId && currentSupport?.rampId);
  const flightGoal = (connection: Connection, exit: 'start' | 'end'): MapGoal | null => {
    const crossing = flights.crossing(connection.id, exit);
    if (!crossing) return null;
    return { ...crossing.to, flight: { id: connection.id, exit }, room: from, kind: 'door',
      label: slopeLabel(!!connection.ramp, crossing.edge.y > crossing.from.y) };
  };
  if (currentFlight && flights.crossing(currentFlight.id, 'end')?.onFlight(supports.sample(goal))) {
    // A moving objective can occupy this same flight. Its room belongs to a
    // landing, so room topology alone would send every pursuit to that end.
    const slope = currentFlight.stair ?? currentFlight.ramp!;
    const along = (goal.x - snapshot.player.x) * (slope.end.x - slope.start.x)
      + (goal.z - snapshot.player.z) * (slope.end.z - slope.start.z);
    return Math.abs(along) < 1e-8 ? goal : flightGoal(currentFlight, along > 0 ? 'end' : 'start');
  }
  if (currentFlight && !currentFlight.rooms.includes(from)) {
    // The rooftop flights have an ascent room distinct from both landings.
    // Select the landing connected to the objective without crossing this
    // same flight again; do not send a mid-stair player through empty space.
    const seen = new Set<string>([currentFlight.rooms[1]]);
    const queue = [...seen];
    for (let index = 0; index < queue.length; index++) {
      for (const connection of connections) {
        if (connection.id === currentFlight.id || connection.rooms.length !== 2 || !connection.rooms.includes(queue[index])) continue;
        for (const room of connection.rooms) if (!seen.has(room)) { seen.add(room); queue.push(room); }
      }
    }
    return flightGoal(currentFlight, seen.has(goal.room) ? 'end' : 'start');
  }
  const finishCurrentFlight = () => flightGoal(currentFlight!, currentFlight!.rooms[0] === from ? 'start' : 'end');
  if (from === goal.room && known.has(goal.room)) return currentFlight ? finishCurrentFlight() : goal;
  const broadcast = snapshot.area === 'broadcast' ? snapshot.progress : snapshot.schoolState?.broadcast;
  const library = snapshot.area === 'library' ? snapshot.progress : snapshot.schoolState?.library;
  const staffroom = snapshot.area === 'staffroom' ? snapshot.progress : snapshot.schoolState?.staffroom;
  const gymnasium = snapshot.area === 'gymnasium' ? snapshot.progress : snapshot.schoolState?.gymnasium;
  const rooftop = snapshot.area === 'rooftop' ? snapshot.progress : snapshot.schoolState?.rooftop;
  const queue: { room: string; route: Connection[] }[] = [{ room: from, route: [] }];
  const seen = new Set<string>([from]);
  for (let index = 0; index < queue.length; index += 1) {
    const entry = queue[index];
    for (const door of connections) {
      if (!door.rooms.some((room) => room === entry.room) || door.rooms.length !== 2) continue;
      // The south-side latch can be opened at the door. From the cafeteria,
      // the closed door must never direct a player through its solid collider.
      if (door.id === 'service-shortcut' && !cafeteria?.shortcutOpened && entry.room !== 'service-gallery') continue;
      if (door.id === 'science-prep-shortcut-frame' && !science?.shortcutOpened && entry.room !== 'science-prep') continue;
      if (door.id === 'classroom-shortcut-frame' && !classroom?.shortcutOpened && entry.room !== 'classroom-east') continue;
      if (door.id === 'classroom-front-door' && !classroom?.barricadeReleased && entry.room !== 'classroom-west') continue;
      if (door.id === 'broadcast-annex-gate-frame' && !broadcast?.shortcutOpened && entry.room !== 'broadcast-upper') continue;
      if (door.id === 'staffroom-firebreak-shortcut-frame' && !staffroom?.shortcutOpened && entry.room !== 'staffroom-records') continue;
      if (door.id === 'gym-equipment-shortcut-frame' && !gymnasium?.shortcutOpened && entry.room !== 'gym-equipment') continue;
      if (door.id === 'rooftop-service-frame' && !rooftop?.shortcutOpened && entry.room !== 'rooftop-service') continue;
      // When northern papers are igniting, use the authored dry southern loop.
      if (door.id === 'staffroom-records-north' && snapshot.fires?.some((fire) => (fire.id === 'staffroom-paper-desks' || fire.id === 'staffroom-paper-records')
        && (fire.phase === 'warning' || fire.phase === 'burning'))) continue;
      if (door.id === 'library-service-gate-frame' && !library?.shortcutOpened && entry.room !== 'library-workroom') continue;
      const next = door.rooms.find((room) => room !== entry.room)!;
      if (seen.has(next)) continue;
      const route = [...entry.route, door];
      if (next === goal.room) {
        const first = route[0];
        // A flight shares its room ID with a landing. Finish the flight before
        // pointing across that landing to another stair or doorway.
        if (currentFlight && first.id !== currentFlight.id) return finishCurrentFlight();
        if (first.stair || first.ramp) {
          const slope = first.stair ?? first.ramp!;
          const descending = first.rooms[0] === from;
          const entrance = descending ? slope.start : slope.end;
          const leaving = descending ? slope.end : slope.start;
          const onStair = currentFlight?.id === first.id;
          const atEntrance = Math.hypot(snapshot.player.x - entrance.x, snapshot.player.z - entrance.z) < .7;
          if (onStair || atEntrance) return flightGoal(first, descending ? 'end' : 'start');
          return { ...entrance, room: from, kind: 'door',
            label: slopeLabel(!!first.ramp, leaving.y > entrance.y) };
        }
        if (first.id === 'broadcast-annex-gate-frame' && !broadcast?.shortcutOpened) return {
          ...layout.broadcast.shortcut.interactPoint, room: from, kind: 'door', label: '부속실 빗장 열기' };
        if (first.id === 'classroom-front-door' && !classroom?.barricadeReleased) return {
          ...layout.classroom.barricade.interactPoint, room: from, kind: 'door', label: '책상 바리케이드 밀기' };
        if (first.id === 'classroom-shortcut-frame' && !classroom?.shortcutOpened) return {
          ...layout.classroom.shortcut.interactPoint, room: from, kind: 'door', label: '북쪽 빗장 열기' };
        if (first.id === 'staffroom-firebreak-shortcut-frame' && !staffroom?.shortcutOpened) return {
          ...layout.staffroom.shortcut.interactPoint, room: from, kind: 'door', label: '카트를 밀어 방화 통로 열기' };
        if (first.id === 'gym-equipment-shortcut-frame' && !gymnasium?.shortcutOpened) return {
          ...layout.gymnasium.shortcut.interactPoint, room: from, kind: 'door', label: '장비실 빗장 열기' };
        if (first.id === 'rooftop-service-frame' && !rooftop?.shortcutOpened) return {
          ...layout.rooftop.shortcut.interactPoint, room: from, kind: 'door', label: '설비실 빗장 열기' };
        if (first.id === 'gym-exit-neck-out' && !gymnasium?.escapeCartCleared) return {
          ...layout.gymnasium.exitCart.interactPoint, room: from, kind: 'door', label: '출구 카트 밀기' };
        if (first.id === 'library-service-gate-frame' && !library?.shortcutOpened) return {
          ...layout.library.shortcut.interactPoint, room: from, kind: 'door', label: '정리실 빗장 열기' };
        if (first.id === 'science-prep-shortcut-frame' && !science?.shortcutOpened) return {
          x: first.x, y: first.y, z: first.z - 1.1, room: from, kind: 'door', label: '준비실 빗장 열기' };
        if (first.id === 'service-shortcut' && !cafeteria?.shortcutOpened) return {
          x: first.x, y: first.y, z: first.z, room: from, kind: 'door', label: '지름길 빗장 열기' };
        const crossing = entrances.crossing(first.id, from);
        if (!crossing) return null;
        // The automatic glass leaves still block the crossing on first approach.
        // This near-side point is inside their trigger radius and stays walkable.
        if (first.id === 'cafeteria-entry' && (cafeteria?.entranceOpen ?? 0) < 1) return {
          ...crossing.from, room: from, kind: 'door', label: '급식실 유리문 앞으로' };
        const nextFloor = mapFloors.find((floor) => floor.id === crossing.toRoom) ?? mapFloors.find((floor) => floor.room === crossing.toRoom);
        const roomLabel = hyosan3DRoomLabel(crossing.toRoom, nextFloor?.label ?? first.label);
        const syllable = roomLabel.charCodeAt(roomLabel.length - 1) - 0xac00;
        const particle = syllable >= 0 && syllable <= 11171 && syllable % 28 !== 0 && syllable % 28 !== 8 ? '으로' : '로';
        return { ...crossing.to, room: from, kind: 'door', entrance: { id: first.id, fromRoom: from },
          label: `${roomLabel}${particle} 이동` };
      }
      seen.add(next); queue.push({ room: next, route });
    }
  }
  return null;
}

interface NavigationMapProps {
  snapshot: Readonly<Hyosan3DSnapshot>;
  surface?: 'mini' | 'full';
  onExpand?: () => void;
  expandRef?: Ref<HTMLButtonElement>;
  route?: readonly GroundPoint[];
  routeVisible?: boolean;
  onToggleRoute?: () => void;
}

export function NavigationMap({ snapshot, surface = 'mini', onExpand, expandRef, route, routeVisible = true, onToggleRoute }: NavigationMapProps) {
  const id = useId().replaceAll(':', '');
  const [view, setView] = useState<'region' | 'school'>('region');
  const scope = surface === 'full' ? view : 'region';
  // Guidance may change just before a doorway; frame the physically occupied
  // region so the player never disappears while walking across that seam.
  const currentArea = hyosan3DAreaForRoom(snapshot.progress.room);
  const revealedKey = snapshot.progress.discoveredRooms.join('|');
  const goal = getHyosan3DMapGoal(snapshot);
  const destination = goal ? project(goal) : null;
  const plan = useMemo(() => {
    const revealed = mapFloors.filter((floor) => floor.room && revealedKey.split('|').includes(floor.room));
    const known = revealed.filter((floor) => scope === 'school' || hyosan3DAreaForRoom(floor.room!) === currentArea);
    const context = scope === 'school' ? [] : doors.flatMap((door) => {
      if (!door.rooms.some((room) => hyosan3DAreaForRoom(room) === currentArea)
        || !door.rooms.some((room) => hyosan3DAreaForRoom(room) !== currentArea)) return [];
      return revealed.filter((floor) => door.rooms.includes(floor.room!) && hyosan3DAreaForRoom(floor.room!) !== currentArea)
        .flatMap((floor) => {
          // Include only the real, discovered floor at the neighboring door;
          // adding its entire long corridor would shrink this regional map.
          const minX = Math.max(floor.x - floor.width / 2, door.x - 3);
          const maxX = Math.min(floor.x + floor.width / 2, door.x + 3);
          const minZ = Math.max(floor.z - floor.depth / 2, door.z - 3);
          const maxZ = Math.min(floor.z + floor.depth / 2, door.z + 3);
          if (maxX <= minX || maxZ <= minZ) return [];
          const fragment = { ...floor, id: `${floor.id}:${door.id}`, x: (minX + maxX) / 2, z: (minZ + maxZ) / 2,
            width: maxX - minX, depth: maxZ - minZ };
          return [{ ...fragment, points: polygon(fragment) }];
        });
    });
    const rooms = HYOSAN_ALL_ROOMS.flatMap((room) => {
      const pieces = known.filter((floor) => floor.room === room);
      return pieces.length ? [{ id: room, pieces, labelFloor: pieces.find((floor) => floor.id === room) ?? pieces[0] }] : [];
    });
    const knownStairs = supports.stairs.filter((stair) => known.some((floor) => floor.room === stair.roomId));
    const knownRamps = supportRamps.filter((ramp) => known.some((floor) => floor.room === ramp.roomId));
    const points = [...known.flatMap(corners), ...context.flatMap(corners), ...knownStairs.flatMap((stair) => stair.treads.flatMap((tread) => corners({ ...tread, y: tread.height }))),
      ...knownRamps.flatMap((ramp) => ramp.points.split(' ').map((point) => { const [x, y] = point.split(',').map(Number); return { x, y }; }))];
    return { known, context, rooms, points };
  }, [revealedKey, scope, currentArea]);
  // Frame the selected entrance/flight without revealing its destination room.
  // Keep the expensive discovered geometry cached independently of guidance.
  const framePoints = [...plan.points];
  if (scope === 'region' && goal) {
    framePoints.push(project(goal));
    const flight = goal.flight && flights.crossing(goal.flight.id, goal.flight.exit);
    if (flight) framePoints.push(project(flight.from), project(flight.edge));
  }
  const frame = mapFrame(framePoints, surface);
  const player = project(snapshot.player);
  const forward = project({ x: Math.sin(snapshot.player.yaw), z: Math.cos(snapshot.player.yaw) });
  const heading = Math.atan2(forward.y, forward.x) * 180 / Math.PI + 90;
  const unit = frame.unit;
  const routePoints = surface === 'full' && scope === 'region' && routeVisible && route && route.length > 1
    ? route.map((point) => { const projected = project(point); return `${projected.x},${projected.y}`; }).join(' ') : null;
  const knownDoors = doors.filter((door) => door.rooms.some((room) => plan.rooms.some((known) => known.id === room))
    && (!door.rooms.includes('library-archive') || plan.rooms.some((room) => room.id === 'library-archive')));
  const furniture = new Map(snapshot.furniture.map((pose) => [pose.id, pose]));
  const cutthrough = layout.adventure.incidentShortcut;
  const cutthroughFrom = project(cutthrough.from);
  const cutthroughTo = project(cutthrough.to);
  const science = snapshot.area === 'science' ? snapshot.progress : snapshot.schoolState?.science;
  const cafeteria = snapshot.area === 'cafeteria' ? snapshot.progress : snapshot.schoolState?.cafeteria;
  const classroom = snapshot.area === 'classroom' ? snapshot.progress : snapshot.schoolState?.classroom;
  const broadcast = snapshot.area === 'broadcast' ? snapshot.progress : snapshot.schoolState?.broadcast;
  const library = snapshot.area === 'library' ? snapshot.progress : snapshot.schoolState?.library;
  const staffroom = snapshot.area === 'staffroom' ? snapshot.progress : snapshot.schoolState?.staffroom;
  const gymnasium = snapshot.area === 'gymnasium' ? snapshot.progress : snapshot.schoolState?.gymnasium;
  const knownStairs = supports.stairs.filter((stair) => plan.rooms.some((room) => room.id === stair.roomId));
  const rooftop = snapshot.area === 'rooftop' ? snapshot.progress : snapshot.schoolState?.rooftop;
  const knownRamps = supportRamps.filter((ramp) => plan.rooms.some((room) => room.id === ramp.roomId));
  const currentLayer = snapshot.player.currentLayerId ?? HYOSAN_MAIN_LAYER;
  // Some landings precede their combat-layer portal. Display the physical
  // floor without changing which enemies can attack across that portal.
  const currentHeight = supports.sample(snapshot.player)?.height ?? snapshot.player.y;
  // A projection clip alone lets an undiscovered upper wall or shelf appear on
  // a discovered lower floor. Filter by the actual authored support as well.
  const visibleObject = (object: PlanRect) => {
    const directlyUnder = supports.candidates(object).filter((support) => Math.abs((object.y ?? 0) - support.height) < .21);
    const candidates = directlyUnder.length ? directlyUnder : supports.surfaces.filter((support) => {
      const y = support.height + (object.x - support.x) * support.slopeX + (object.z - support.z) * support.slopeZ;
      return Math.abs((object.y ?? 0) - y) < .21 && Math.abs(object.x - support.x) <= (object.width + support.width) / 2 + .01
        && Math.abs(object.z - support.z) <= (object.depth + support.depth) / 2 + .01;
    });
    return candidates.some((support) => {
      const surface = supports.surfaces.find((candidate) => candidate.surfaceId === support.surfaceId)!;
      const room = hyosan3DRoomForFloor({ id: surface.surfaceId, roomId: surface.roomId });
      return room && plan.rooms.some((known) => known.id === room);
    });
  };
  const knownProps = scope === 'region' ? layout.props.flatMap((prop) => {
    const pose = { ...prop, ...furniture.get(prop.id), ...footprint(prop) };
    return visibleObject(pose) ? [{ id: prop.id, points: polygon(pose) }] : [];
  }) : [];
  const planFire = (snapshot.fires ?? []).flatMap((fire) => {
    const zone = layout.staffroom.fire.zones.find((zone) => zone.id === fire.id);
    return zone && (fire.phase === 'warning' || fire.phase === 'burning')
      && plan.rooms.some((room) => room.id === roomAt({ ...zone.visualPoint, y: zone.y })) ? [{ zone, phase: fire.phase }] : [];
  });
  const knownWalls = scope === 'region' ? walls.filter(visibleObject) : [];
  const layerLabel = currentArea === 'library' ? snapshot.progress.room === 'library-crown' ? '서가 위' : '서가 아래'
    : currentArea === 'rooftop' ? ['rooftop-foot', 'rooftop-ascent', 'rooftop-landing'].includes(snapshot.progress.room) ? '옥상 계단' : '옥상 층'
    : currentArea === 'gymnasium' ? currentLayer === 'gym-gallery' ? '관람석 위층' : '코트 아래층'
    : currentArea === 'broadcast' ? currentLayer === 'broadcast-lower' ? '하층' : '상층' : null;
  const knownAreas = AREAS.flatMap((area, index) => {
    const pieces = plan.known.filter((floor) => hyosan3DAreaForRoom(floor.room!) === area.id);
    if (!pieces.length) return [];
    const bounds = pieces.flatMap(corners);
    const point = { x: (Math.min(...bounds.map((p) => p.x)) + Math.max(...bounds.map((p) => p.x))) / 2,
      y: (Math.min(...bounds.map((p) => p.y)) + Math.max(...bounds.map((p) => p.y))) / 2 };
    return [{ ...area, number: index + 1, point }];
  });
  const landmarks = [
    { ...layout.science.checkpoint, label: '기억 지점', kind: 'anchor', active: science?.anchorReached },
    ...(!snapshot.progress.upgraded ? [{ ...layout.science.upgrade, label: '양궁 장비', kind: 'supply', active: false }] : []),
    { ...layout.adventure.checkpoint, label: '기억 지점', kind: 'anchor', active: cafeteria?.anchorReached },
    ...(!snapshot.progress.upgraded ? [{ ...layout.upgrade, label: '양궁 장비', kind: 'supply', active: false }] : []),
    ...(!snapshot.progress.supplyCollected ? [{ ...layout.adventure.supply, label: '활 보급품', kind: 'supply', active: false }] : []),
    { ...layout.classroom.checkpoint, label: '기억 지점', kind: 'anchor', active: classroom?.anchorReached },
    ...(!classroom?.piercingCollected ? [{ ...layout.classroom.upgrade, label: '관통 화살 장비', kind: 'supply', active: false }] : []),
    { ...layout.broadcast.checkpoint, label: '계단참 기억 지점', kind: 'anchor', active: broadcast?.anchorReached },
    ...(!broadcast?.supplyTaken ? [{ ...layout.broadcast.supply, label: '구급품', kind: 'supply', active: false }] : []),
    { ...layout.library.checkpoint, label: '교차로 기억 지점', kind: 'anchor', active: library?.anchorReached },
    ...(!library?.stringReinforced ? [{ ...layout.library.upgrade, label: '시위 보강', kind: 'supply', active: false }] : []),
    { ...layout.gymnasium.checkpoint, label: '장비실 기억 지점', kind: 'anchor', active: gymnasium?.anchorReached },
    ...(!gymnasium?.supplyTaken ? [{ ...layout.gymnasium.supply, label: '장비실 구급품', kind: 'supply', active: false }] : []),
    { ...layout.staffroom.checkpoint, label: '방화 통로 기억 지점', kind: 'anchor', active: staffroom?.anchorReached },
    ...(!staffroom?.tipReinforced ? [{ ...layout.staffroom.upgrade, label: '관통 촉 보강', kind: 'supply', active: false }] : []),
    { ...layout.rooftop.checkpoint, label: '대피참 기억 지점', kind: 'anchor', active: rooftop?.anchorReached },
    ...(!rooftop?.supplyTaken ? [{ ...layout.rooftop.supply, label: '설비실 구급품', kind: 'supply', active: false }] : []),
  ].filter((point) => plan.known.some((floor) => contains(floor, point) && Math.abs((('y' in point ? point.y : 0) ?? 0) - (floor.y ?? 0)) < .2));

  const roomLabels = (() => {
    const occupied = [player, ...(destination ? [destination] : []), ...landmarks.map(project)];
    const prepared = plan.rooms.map((room) => ({ room,
      candidates: room.pieces.flatMap((floor) => [[0, -.25], [.25, .25], [-.25, .25], [0, 0]].map(([x, z]) =>
        project({ ...floor, x: floor.x + floor.width * x, z: floor.z + floor.depth * z }))) }));
    // Give small, single-piece rooms a position before long stair/corridor rooms
    // that have many alternatives. Keep the legend in authored room order.
    const positions = new Map<string, { x: number; y: number }>();
    for (const { room, candidates } of prepared.sort((a, b) => a.candidates.length - b.candidates.length)) {
      const clearance = (point: { x: number; y: number }) => Math.min(...occupied.map((other) => Math.hypot(point.x - other.x, point.y - other.y)));
      candidates.sort((a, b) => clearance(b) - clearance(a));
      const point = candidates[0]; occupied.push(point);
      positions.set(room.id, point);
    }
    return plan.rooms.map((room) => ({ ...room, point: positions.get(room.id)!, number: ROOM_NUMBERS[room.id] }));
  })();
  const freeExploration = snapshot.progress.objective === 'explore_school';
  return <section className={styles.map} data-surface={surface} data-scope={scope} aria-label="발견한 구역 지도">
    {surface === 'mini' ? <button ref={expandRef} type="button" className={styles.toggle} aria-label="지도 크게 보기" onClick={onExpand}>
      <svg viewBox="0 0 18 18" aria-hidden="true"><path d="m2 4 4-2 6 2 4-2v12l-4 2-6-2-4 2Zm4-2v12m6-10v12" /></svg>
      <span>{layerLabel ? `${layerLabel} 지도` : '주변 지도'}</span><kbd>M</kbd>
    </button> : null}
    {surface === 'full' ? <>
      <div className={styles.scopeControls} role="group" aria-label="지도 표시 범위">
        <button type="button" aria-label="현재 지역 보기" aria-pressed={scope === 'region'} onClick={() => setView('region')}>현재 지역</button>
        <button type="button" aria-label="학교 전체 보기" aria-pressed={scope === 'school'} onClick={() => setView('school')}>학교 전체</button>
        {onToggleRoute ? <button type="button" aria-label="길 안내 표시" aria-pressed={routeVisible} onClick={onToggleRoute}>길 안내 {routeVisible ? '켬' : '끔'}</button> : null}
      </div>
      <p className={styles.scopeCaption}>{scope === 'school' ? '지금까지 발견한 학교' : AREAS.find((area) => area.id === currentArea)?.label}
        {scope === 'region' && layerLabel ? <span>{layerLabel}</span> : null}
      </p>
    </> : null}
    <div className={styles.plan}>
      <svg className={styles.drawing} viewBox={frame.viewBox} role="img"
        aria-label={`${plan.rooms.map((room) => hyosan3DRoomLabel(room.id, room.labelFloor.label)).join(', ')}. 화살표는 내 위치와 향함. 목표: ${goal?.label ?? '주변 살피기'}`}>
        <defs><clipPath id={`${id}-floor`}>{[...plan.known, ...plan.context].map((floor) => <polygon key={floor.id} points={floor.points} />)}
          {knownStairs.flatMap((stair) => stair.treads.map((tread) => <polygon key={tread.id} points={polygon({ ...tread, y: tread.height })} />))}
          {knownRamps.map((ramp) => <polygon key={ramp.id} points={ramp.points} />)}
        </clipPath></defs>
        {plan.context.map((floor) => <polygon key={floor.id} points={floor.points} className={styles.connectionFloor}
          data-connection-room={floor.room}><title>{`${AREAS.find((area) => area.id === hyosan3DAreaForRoom(floor.room!))?.label} 연결`}</title></polygon>)}
        {plan.rooms.map((room) => <g key={room.id} data-room={room.id}>
          {room.pieces.map((floor) => <polygon key={floor.id} points={floor.points} className={styles.floor} data-floor={floor.id}
            data-height={'y' in floor ? floor.y : 0} data-layer-current={currentArea === 'library' || currentArea === 'rooftop'
              ? Math.abs((floor.y ?? 0) - currentHeight) < .2
              : ('currentLayerId' in floor ? floor.currentLayerId : HYOSAN_MAIN_LAYER) === currentLayer}
            data-current={snapshot.progress.room === room.id} />)}
        </g>)}
        {knownStairs.map((stair) => <g key={stair.id} className={styles.stair} data-stair={stair.id} data-layer-current={stair.currentLayerId === currentLayer}>
          <title>{`${stair.start.y}m → ${stair.end.y}m 계단 · 오르내리기`}</title>
          {stair.treads.map((tread) => <polygon key={tread.id} data-tread={tread.id} points={polygon({ ...tread, y: tread.height })} />)}
        </g>)}
        {knownRamps.map((ramp) => <g key={ramp.id} className={styles.supportRamp} data-support-ramp={ramp.id}
          data-layer-current={ramp.currentLayerId === currentLayer}>
          <title>{`${ramp.start.y < ramp.end.y ? '서쪽 오름' : '동쪽 내림'} 경사로 · 양방향 이동`}</title>
          <polygon points={ramp.points} />
          <line x1={project(ramp.start).x} y1={project(ramp.start).y} x2={project(ramp.end).x} y2={project(ramp.end).y} />
        </g>)}
        <g clipPath={`url(#${id}-floor)`}>
          {scope === 'region' ? planFire.map(({ zone, phase }) => <polygon key={zone.id} data-fire={zone.id} data-phase={phase}
            points={zone.polygon.map((p) => { const q = project({ ...p, y: zone.y }); return `${q.x},${q.y}`; }).join(' ')}
            fill={phase === 'warning' ? '#cfa767' : '#a65532'} fillOpacity={.35} stroke={phase === 'warning' ? '#e3c58d' : '#e9a069'}
            strokeWidth={unit * .3} strokeDasharray={phase === 'warning' ? `${unit} ${unit * .6}` : undefined}>
            <title>{phase === 'warning' ? '종이에 불씨가 번지는 중' : '불타는 바닥'}</title></polygon>) : null}
          {knownProps.map((prop) => <polygon key={prop.id} data-prop={prop.id} points={prop.points} className={styles.prop} />)}
          {elevated.routes.filter((route) => plan.rooms.some((room) => room.id === route.roomId)).map((route) => <g key={route.id}
            data-elevated-route={route.id} className={styles.raisedRoute}>
            <title>{`${route.label} · 양쪽 경사로로 이동`}</title>
            {ramps.filter((ramp) => ramp.routeId === route.id).map((ramp) => <polygon key={ramp.id} points={ramp.points} data-ramp={ramp.id} />)}
            <polygon points={polygon({ ...route.deck, elevation: route.deck.height })} data-deck={route.id} />
          </g>)}
          {knownWalls.map((wall) => <polygon key={wall.id} data-wall={wall.id} points={wall.points} className={styles.wall} />)}
          {knownDoors.map((door) => <line key={door.id} x1={door.from.x} y1={door.from.y} x2={door.to.x} y2={door.to.y}
            data-door={door.id} data-axis={door.axis} data-closed={door.id === 'service-shortcut' && !cafeteria?.shortcutOpened
              || door.id === 'cafeteria-entry' && (cafeteria?.entranceOpen ?? 0) < 1
              || door.id === 'science-prep-shortcut-frame' && !science?.shortcutOpened
              || door.id === 'classroom-front-door' && !classroom?.barricadeReleased
              || door.id === 'classroom-shortcut-frame' && !classroom?.shortcutOpened
              || door.id === 'broadcast-annex-gate-frame' && !broadcast?.shortcutOpened
              || door.id === 'library-service-gate-frame' && !library?.shortcutOpened
              || door.id === 'staffroom-firebreak-shortcut-frame' && !staffroom?.shortcutOpened
              || door.id === 'gym-equipment-shortcut-frame' && !gymnasium?.shortcutOpened
              || door.id === 'rooftop-service-frame' && !rooftop?.shortcutOpened
              || door.id === 'gym-exit-neck-out' && !gymnasium?.escapeCartCleared}
            className={styles.door} strokeWidth={unit * .5} />)}
          {cafeteria?.incidentShortcutOpened ? <line data-shortcut={cutthrough.id}
            x1={cutthroughFrom.x} y1={cutthroughFrom.y} x2={cutthroughTo.x} y2={cutthroughTo.y}
            className={styles.door} strokeWidth={unit * .35}><title>열린 북쪽 지름길</title></line> : null}
        </g>
        {/* The runtime checks this whole line, including the short entrance into
            an unseen room. Clipping it to discovered floors hides the crossing. */}
        {routePoints ? <g className={styles.route} aria-label="다음 목표로 가는 길">
          <polyline points={routePoints} className={styles.routeUnderlay} vectorEffect="non-scaling-stroke" />
          <polyline data-navigation-route points={routePoints} vectorEffect="non-scaling-stroke" />
        </g> : null}
        {surface === 'full' && scope === 'region' ? roomLabels.map((room) => <g key={room.id}
          data-room-label={room.id} transform={`translate(${room.point.x} ${room.point.y})`}>
          <title>{hyosan3DRoomLabel(room.id, room.labelFloor.label)}</title>
          <circle className={styles.numberBackdrop} r={unit * 3} />
          <text className={styles.roomNumber} fontSize={unit * 5.2} dy=".35em" aria-hidden="true">{room.number}</text>
        </g>) : null}
        {surface === 'full' && scope === 'school' ? knownAreas.map((area) => <g key={area.id}
          data-area-label={area.id} transform={`translate(${area.point.x} ${area.point.y})`}>
          <title>{area.label}</title><circle className={styles.numberBackdrop} r={unit * 3.4} />
          <text className={styles.roomNumber} fontSize={unit * 5.2} dy=".35em" aria-hidden="true">{area.number}</text>
        </g>) : null}
        {scope === 'region' ? landmarks.map((landmark) => {
          const point = project(landmark);
          return <g key={`${landmark.kind}-${landmark.x}-${landmark.z}`} transform={`translate(${point.x} ${point.y})`} className={styles.landmark} data-landmark={landmark.kind} data-active={landmark.active}>
            <title>{landmark.label}</title>
            <circle r={unit * .85} strokeWidth={unit * .25} />
          </g>;
        }) : null}
        {plan.known.length ? <>
          {destination && goal ? <g transform={`translate(${destination.x} ${destination.y})`} className={styles.goal} data-kind={goal.kind} data-goal-x={goal.x} data-goal-z={goal.z} data-goal-y={goal.y ?? 0}>
            <circle r={unit * 1.55} className={styles.goalHalo} />
            <path d={`M0 ${-unit} ${unit} 0 0 ${unit} ${-unit} 0Z`} strokeWidth={unit * .2} />
          </g> : null}
          <g transform={`translate(${player.x} ${player.y}) rotate(${heading})`} className={styles.player} data-elevation={snapshot.player.y}>
            <circle r={unit * 1.6} className={styles.playerHalo} />
            <path d={`M0 ${-unit * 1.45} ${unit} ${unit} 0 ${unit * .58} ${-unit} ${unit}Z`} strokeWidth={unit * .25} />
          </g>
        </> : null}
      </svg>
      <span className={styles.destination}><i aria-hidden="true" />{goal?.label ?? (snapshot.progress.awaitingFirstShot ? '움직이며 활을 익혀보세요' : freeExploration ? '열린 길을 자유롭게 둘러보세요' : '주변을 살펴보세요')}</span>
    </div>
    {surface === 'full' ? <>
      <div className={styles.legend}><span>△ 내 위치</span>{goal ? <span>◇ 다음 목표</span> : null}
        {routePoints ? <span>┅ 가는 길</span> : null}
        {scope === 'region' ? <><span>○ 기억·보급</span><span>━ 열린 문</span><span>┄ 닫힌 문</span>
          {planFire.length ? <span>▧ 불씨·불타는 바닥</span> : null}
          {knownStairs.length ? <span>▤ 계단 · 상층/하층</span> : null}
          {knownRamps.length ? <span>▱ 경사로 · 서가 위/아래</span> : null}
          {plan.rooms.some((room) => room.id === 'cafeteria') ? <span>▧ 식탁 위 경로</span> : null}</> : null}</div>
      <ul className={styles.roomNames} aria-label={scope === 'region' ? '지도 구역 이름' : '학교 지역 이름'}>
        {scope === 'region' ? roomLabels.map((room) => <li key={room.id} data-room-name={room.id} data-current={room.id === snapshot.progress.room}>
          <span aria-hidden="true">{room.number}</span>{hyosan3DRoomLabel(room.id, room.labelFloor.label)}</li>)
          : knownAreas.map((area) => <li key={area.id} data-current={area.id === currentArea}><span aria-hidden="true">{area.number}</span>{area.label}</li>)}
      </ul>
    </> : null}
  </section>;
}

export default NavigationMap;
