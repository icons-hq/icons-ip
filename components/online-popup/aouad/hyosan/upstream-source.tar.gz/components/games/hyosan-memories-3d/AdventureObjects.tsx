'use client';
import { cafeteriaPresentation } from './school-presentation';

import { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import layout from '@/docs/games/hyosan-memories-3d/world-layout.json';
import type { Hyosan3DPlayRuntime } from '@/lib/games/hyosan-memories-3d/types';
import { HYOSAN_INCIDENT_WATER } from '@/lib/games/hyosan-memories-3d/incident-water';
import { CafeteriaEntrance } from './CafeteriaEntrance';

const adventure = layout.adventure;
const random = (index: number) => {
  const value = Math.sin(index * 127.1 + 311.7) * 43758.5453;
  return value - Math.floor(value);
};

/** A modest physical case: its contents disappear after the interaction. */
export function BowCase({ supply = false }: { supply?: boolean }) {
  return <group>
    <mesh castShadow receiveShadow><boxGeometry args={[.70, .16, .36]} /><meshStandardMaterial color={supply ? '#56604b' : '#342d22'} roughness={.82} /></mesh>
    <mesh position={[0, .085, 0]}><boxGeometry args={[.09, .018, .37]} /><meshStandardMaterial color="#c4ad73" roughness={.55} metalness={.3} /></mesh>
    {[-.18, .18].map((x) => <mesh key={x} position={[x, .11, 0]} rotation={[Math.PI / 2, 0, 0]}>
      <cylinderGeometry args={[.014, .014, .48, 6]} /><meshStandardMaterial color="#cbb88a" roughness={.6} />
    </mesh>)}
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -.069, 0]}>
      <ringGeometry args={[.48, .505, 40]} /><meshBasicMaterial color="#cfb77e" transparent opacity={.65} depthWrite={false} />
    </mesh>
  </group>;
}

/** Fixed authored positions; every visible state comes from the simulation. */
export function AdventureObjects({ simulation }: { simulation: Hyosan3DPlayRuntime }) {
  const supply = useRef<THREE.Group>(null);
  const gate = useRef<THREE.Group>(null);
  const echo = useRef<THREE.Group>(null);
  const echoRing = useRef<THREE.Mesh>(null);
  const phoneLight = useRef<THREE.Mesh>(null);
  const incident = useRef<THREE.Group>(null);
  const rain = useRef<THREE.LineSegments>(null);
  const waterPools = useRef(new Map<string, THREE.Group>());
  const ripples = useRef(new Map<number, THREE.Mesh>());
  const drops = useMemo(() => new Float32Array(90 * 6), []);
  const puddles = useMemo(() => HYOSAN_INCIDENT_WATER.map((patch) => {
    const shape = new THREE.Shape();
    patch.points.forEach((point, index) => {
      // The floor rotation maps Shape Y to -Z; the shared vertices are local XZ.
      if (index === 0) shape.moveTo(point.x, -point.z); else shape.lineTo(point.x, -point.z);
    });
    shape.closePath();
    return { ...patch, shape, edge: new Float32Array(patch.points.flatMap((point) => [point.x, 0, point.z])) };
  }), []);

  useFrame(() => {
    const snapshot = simulation.read();
    const progress = cafeteriaPresentation(snapshot);
    if (supply.current) supply.current.visible = !progress.supplyCollected;
    // Fold the shutter under its overhead header. No visible metal remains at
    // character or arrow height once the simulation removes the closed collider.
    if (gate.current) {
      gate.current.position.y = progress.shortcutOpened ? 2.46 : adventure.shortcut.height / 2;
      gate.current.scale.y = progress.shortcutOpened ? .06 : 1;
    }
    if (echo.current) echo.current.visible = progress.bossDefeated && !progress.echoCollected;
    if (echoRing.current) echoRing.current.scale.setScalar(1 + Math.sin(snapshot.time * 2.5) * .045);
    if (phoneLight.current) {
      const material = phoneLight.current.material as THREE.MeshBasicMaterial;
      material.opacity = progress.anchorReached ? .65 : .26 + Math.sin(snapshot.time * 2) * .08;
    }
    if (incident.current) incident.current.visible = progress.incidentTriggered;
    waterPools.current.forEach((pool, id) => { pool.visible = progress.activeWaterIds.includes(id); });
    if (progress.incidentTriggered) ripples.current.forEach((ripple, index) => {
      const phase = (snapshot.time * .60 + index * .29) % 1;
      ripple.scale.setScalar(.35 + phase * .7);
      (ripple.material as THREE.MeshBasicMaterial).opacity = .15 * (1 - phase);
    });
    if (rain.current && progress.incidentTriggered) {
      const attribute = rain.current.geometry.getAttribute('position') as THREE.BufferAttribute;
      for (let index = 0; index < 90; index++) {
        const head = index % 6;
        const x = 6 + (head % 3) * 6 + (random(index * 3) - .5) * 2.6;
        const z = (head < 3 ? -1 : 5.8) + (random(index * 3 + 1) - .5) * 2.4;
        const y = 3.05 - ((snapshot.time * 2.8 + random(index * 3 + 2) * 3) % 3);
        attribute.setXYZ(index * 2, x, y, z);
        attribute.setXYZ(index * 2 + 1, x + .025, y - .12, z + .01);
      }
      attribute.needsUpdate = true;
    }
  });

  return <>
    <CafeteriaEntrance simulation={simulation} />
    <group ref={supply} position={[adventure.supply.x, .095, adventure.supply.z]}><BowCase supply /></group>
    <group position={[adventure.checkpoint.x, .038, adventure.checkpoint.z]}>
      <mesh castShadow rotation={[0, -.3, 0]}><boxGeometry args={[.095, .026, .19]} /><meshStandardMaterial color="#202927" roughness={.42} /></mesh>
      <mesh position={[0, .015, 0]} rotation={[-Math.PI / 2, 0, -.3]}><planeGeometry args={[.077, .157]} /><meshBasicMaterial color="#afd5ca" /></mesh>
      <mesh ref={phoneLight} rotation={[-Math.PI / 2, 0, 0]} position={[0, -.013, 0]}>
        <ringGeometry args={[.36, .40, 40]} /><meshBasicMaterial color="#b8d6c6" transparent opacity={.5} depthWrite={false} />
      </mesh>
    </group>
    <group ref={gate} position={[adventure.shortcut.x, adventure.shortcut.height / 2, adventure.shortcut.z]}>
      <mesh castShadow receiveShadow><boxGeometry args={[adventure.shortcut.width, adventure.shortcut.height, adventure.shortcut.depth]} /><meshStandardMaterial color="#586257" roughness={.66} metalness={.2} /></mesh>
      {[-.40, .40].map((y) => <mesh key={y} position={[0, y, .09]}><boxGeometry args={[2.76, .045, .045]} /><meshStandardMaterial color="#879086" roughness={.48} metalness={.4} /></mesh>)}
      <mesh position={[1.11, .14, .12]}><boxGeometry args={[.19, .06, .08]} /><meshStandardMaterial color="#baad7b" metalness={.6} roughness={.4} /></mesh>
    </group>
    <group ref={echo} visible={false} position={[adventure.echo.x, .034, adventure.echo.z]}>
      <mesh receiveShadow rotation={[0, .3, 0]}><boxGeometry args={[.21, .012, .29]} /><meshStandardMaterial color="#e7dfc8" roughness={.78} /></mesh>
      <mesh position={[0, .009, -.024]} rotation={[-Math.PI / 2, 0, .3]}><planeGeometry args={[.17, .19]} /><meshStandardMaterial color="#647a72" roughness={.95} /></mesh>
      <mesh ref={echoRing} rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[.55, .59, 48]} /><meshBasicMaterial color="#edd39b" transparent opacity={.8} depthWrite={false} />
      </mesh>
    </group>
    <group ref={incident} visible={false}>
      {puddles.map((patch, index) => <group key={patch.id} name={patch.id} position={[patch.x, .013, patch.z]}
        visible={simulation.read().progress.activeWaterIds.includes(patch.id)}
        ref={(object) => { if (object) waterPools.current.set(patch.id, object); else waterPools.current.delete(patch.id); }}>
        <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <shapeGeometry args={[patch.shape]} />
          <meshStandardMaterial color="#243c32" transparent opacity={.20} roughness={.6} metalness={0} envMapIntensity={.1} depthWrite={false} />
        </mesh>
        <lineLoop position={[0, .002, 0]}>
          <bufferGeometry><bufferAttribute attach="attributes-position" args={[patch.edge, 3]} /></bufferGeometry>
          <lineBasicMaterial color="#6b8981" transparent opacity={.10} depthWrite={false} />
        </lineLoop>
        {[0, 1].map((drop) => <mesh key={drop}
          ref={(object) => { const key = index * 2 + drop; if (object) ripples.current.set(key, object); else ripples.current.delete(key); }}
          rotation={[-Math.PI / 2, 0, 0]} position={[drop === 0 ? -.26 : .26, .004, drop === 0 ? -.04 : .04]}>
          <ringGeometry args={[.22, .228, 36]} /><meshBasicMaterial color="#9fbeb2" transparent opacity={.1} depthWrite={false} />
        </mesh>)}
      </group>)}
      <lineSegments ref={rain} frustumCulled={false}>
        <bufferGeometry><bufferAttribute attach="attributes-position" args={[drops, 3]} /></bufferGeometry>
        <lineBasicMaterial color="#c8ded7" transparent opacity={.22} depthWrite={false} />
      </lineSegments>
    </group>
  </>;
}
