import type { Hyosan3DSnapshot } from '@/lib/games/hyosan-memories-3d/types';

/** Room IDs own stable UI names while each physical floor keeps its authored label. */
export function hyosan3DRoomLabel(room: string, authoredLabel: string): string {
  return room === 'library-crown' ? '서가 위 통로' : authoredLabel;
}

/** Area objectives select their own boss from the school-wide combat roster. */
export function areaBoss(state: Readonly<Hyosan3DSnapshot>) {
  return state.enemies.find((enemy) => enemy.kind === 'boss'
    && (enemy.ownerArea ?? (enemy.profile === 'gwinam-halfbie' ? 'rooftop' : enemy.profile === 'eunji' ? 'staffroom' : enemy.profile === 'hyunju' ? 'science' : enemy.profile === 'jingu' ? 'classroom' : enemy.profile === 'gwinam-human' ? 'library' : enemy.profile === 'daewon' ? 'broadcast' : 'cafeteria'))
      === (state.area ?? 'cafeteria'));
}
/** Event flags belong to their own environment throughout connected exploration. */
export function cafeteriaPresentation(state: Readonly<Hyosan3DSnapshot>): Hyosan3DSnapshot['progress'] {
  return state.schoolState?.cafeteria ?? (!state.area || state.area === 'cafeteria' ? state.progress : { ...state.progress,
    bossDefeated: false, echoCollected: false, anchorReached: false, incidentTriggered: false, shortcutOpened: false,
    entranceOpen: 0, activeWaterIds: [], inWater: false, incidentShortcutOpened: false });
}
