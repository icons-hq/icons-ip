export const HYOSAN_CAMPAIGN_WRITER_LOCK_NAME = 'hyosan-memories:3d-campaign-writer';

export interface HyosanCampaignLockManager {
  request(name: string, options: Readonly<{ mode: 'exclusive'; ifAvailable: true }>,
    callback: (lock: unknown | null) => Promise<void>): Promise<void>;
}
export interface HyosanCampaignWriterLease {
  readonly status: 'acquired';
  readonly active: boolean;
  release(): void;
}
export type HyosanCampaignWriterLeaseResult = HyosanCampaignWriterLease
  | { readonly status: 'contended' | 'unavailable' };

/** One open 3D campaign owns this origin's save, including its paused menus.
 * No waiting, forced takeover, or unsafe localStorage lock fallback. */
export function acquireHyosanCampaignWriterLease(manager: HyosanCampaignLockManager | null | undefined): Promise<HyosanCampaignWriterLeaseResult> {
  if (!manager) return Promise.resolve({ status: 'unavailable' });
  return new Promise(resolve => {
    let settled = false;
    let active = false;
    let releaseLock: (() => void) | undefined;
    const settle = (result: HyosanCampaignWriterLeaseResult) => {
      if (settled) return;
      settled = true; resolve(result);
    };
    const release = () => { active = false; releaseLock?.(); };
    const failed = () => { release(); settle({ status: 'unavailable' }); };
    try {
      void manager.request(HYOSAN_CAMPAIGN_WRITER_LOCK_NAME, { mode: 'exclusive', ifAvailable: true }, async lock => {
        if (settled) return;
        if (lock === null) { settle({ status: 'contended' }); return; }
        active = true;
        const released = new Promise<void>(done => { releaseLock = done; });
        settle({ status: 'acquired', get active() { return active; }, release });
        await released;
      }).then(failed, failed);
    } catch { failed(); }
  });
}
