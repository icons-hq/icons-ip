import type { Hyosan3DInput, Hyosan3DSnapshot } from '@/lib/games/hyosan-memories-3d/types';

interface RenderStatistics {
  manual: boolean;
  drawCalls: number;
  triangles: number;
  frameMs: number;
  rawFrameMs: number;
  simulationMs: number;
  geometries: number;
  textures: number;
  colorBufferWidth: number;
  colorBufferHeight: number;
  aoBufferWidth: number;
  aoBufferHeight: number;
}
type Projector = (x: number, y: number, z: number) => { x: number; y: number };

/** Imperative frame instrumentation, kept outside React render state. */
export class Hyosan3DDiagnostics {
  private stats: RenderStatistics = { manual: false, drawCalls: 0, triangles: 0, frameMs: 0, rawFrameMs: 0, simulationMs: 0, geometries: 0, textures: 0,
    colorBufferWidth: 0, colorBufferHeight: 0, aoBufferWidth: 0, aoBufferHeight: 0 };
  private projector: Projector | null = null;
  setManual(manual: boolean) { this.stats.manual = manual; }
  isManual() { return this.stats.manual; }
  read() { return { ...this.stats }; }
  recordSimulation(ms: number) { this.stats.simulationMs = ms; }
  recordBuffers(buffers: { color: { width: number; height: number }; ao: { width: number; height: number } } | null) {
    this.stats.colorBufferWidth = buffers?.color.width ?? 0; this.stats.colorBufferHeight = buffers?.color.height ?? 0;
    this.stats.aoBufferWidth = buffers?.ao.width ?? 0; this.stats.aoBufferHeight = buffers?.ao.height ?? 0;
  }
  recordFrame(drawCalls: number, triangles: number, delta: number, memory: { geometries: number; textures: number }) {
    this.stats.drawCalls = drawCalls; this.stats.triangles = triangles;
    this.stats.frameMs += (delta * 1000 - this.stats.frameMs) * .05;
    this.stats.rawFrameMs = delta * 1000;
    this.stats.geometries = memory.geometries; this.stats.textures = memory.textures;
  }
  setProject(projector: Projector | null) { this.projector = projector; }
  project(x: number, y: number, z: number) { return this.projector?.(x, y, z) ?? null; }
}

declare global {
  interface Window {
    __HYOSAN_3D_QA__?: {
      read: () => Readonly<Hyosan3DSnapshot>;
      manual: (enabled: boolean) => void;
      advance: (frames: readonly Hyosan3DInput[]) => Readonly<Hyosan3DSnapshot>;
      rendering: () => RenderStatistics;
      project: (x: number, y: number, z: number) => { x: number; y: number } | null;
    };
  }
}
