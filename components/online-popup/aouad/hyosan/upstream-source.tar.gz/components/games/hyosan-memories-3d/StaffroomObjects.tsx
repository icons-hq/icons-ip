'use client';
import { useEffect, useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import layout from '@/docs/games/hyosan-memories-3d/world-layout.json';
import type { Hyosan3DPlayRuntime } from '@/lib/games/hyosan-memories-3d/types';
import { createStaffroomFlameMaterial } from './staffroom-flame';

const plan = layout.staffroom;
/** The visible boundary uses the exact damage polygon; furniture flames have their own authored height. */
export function StaffroomObjects({ simulation }: { simulation: Hyosan3DPlayRuntime }) {
  const fires = useRef<THREE.Group>(null); const tip = useRef<THREE.Group>(null);
  const echo = useRef<THREE.Group>(null); const keepsake = useRef<THREE.Group>(null);
  const geometry = useMemo(() => plan.fire.zones.map((zone, index) => {
    const shape = new THREE.Shape(zone.polygon.map((p) => new THREE.Vector2(p.x, -p.z)));
    const edges: number[] = [];
    for (let i = 0; i < zone.polygon.length; i++) {
      const a = zone.polygon[i], b = zone.polygon[(i + 1) % zone.polygon.length];
      const length = Math.hypot(b.x - a.x, b.z - a.z);
      const nx = -(b.z - a.z) / length * .028, nz = (b.x - a.x) / length * .028;
      const vertices = [[a.x + nx, a.z + nz], [a.x - nx, a.z - nz], [b.x + nx, b.z + nz], [b.x - nx, b.z - nz]];
      for (const corner of [0, 2, 1, 1, 2, 3]) edges.push(vertices[corner][0], zone.y + .03, vertices[corner][1]);
    }
    const outline = new THREE.BufferGeometry();
    outline.setAttribute('position', new THREE.Float32BufferAttribute(edges, 3));
    return { fill: new THREE.ShapeGeometry(shape), outline, flame: createStaffroomFlameMaterial(index) };
  }), []);
  const mount = useMemo(() => {
    let leases = 0, disposed = false;
    return () => {
      leases++;
      return () => {
        leases--;
        // Preserve the compiled shader through Strict Mode's immediate replay.
        queueMicrotask(() => {
          if (leases || disposed) return;
          disposed = true;
          for (const item of geometry) { item.fill.dispose(); item.outline.dispose(); item.flame.dispose(); }
        });
      };
    };
  }, [geometry]);
  useEffect(mount, [mount]);
  useFrame(({ camera }) => {
    const state = simulation.read(); const progress = state.area === 'staffroom' ? state.progress : state.schoolState?.staffroom;
    if (tip.current) tip.current.visible = Boolean(progress?.discoveredRooms.includes('staffroom-copy') && !progress.tipReinforced);
    if (echo.current) echo.current.visible = Boolean(progress && !progress.areaResolved && progress.bossDefeated && !progress.echoCollected);
    if (keepsake.current) keepsake.current.visible = state.progress.room === 'staffroom-breakroom' && !progress?.keepsakeFound;
    fires.current?.children.forEach((group, index) => {
      const phase = state.fires?.find((fire) => fire.id === plan.fire.zones[index].id)?.phase ?? 'unlit';
      group.visible = phase !== 'unlit';
      const warning = phase === 'warning'; const burning = phase === 'burning'; const embers = phase === 'embers';
      const fill = group.children[0] as THREE.Mesh<THREE.ShapeGeometry, THREE.MeshBasicMaterial>;
      fill.material.color.set(warning ? '#df9a42' : burning ? '#d77436' : '#242321');
      fill.material.opacity = warning ? .18 + Math.sin(state.time * 5) * .035 : burning ? .17 : .2;
      const outline = group.children[1] as THREE.Mesh<THREE.BufferGeometry, THREE.MeshBasicMaterial>;
      outline.visible = warning || burning; outline.material.color.set(warning ? '#ffd59a' : '#fbb773');
      const flameGroup = group.children[2]; flameGroup.visible = burning || embers;
      const flame = flameGroup.children[0];
      flame.scale.y = burning ? 1 : .18;
      flame.position.y = burning ? .57 : .1;
      flame.rotation.y = Math.atan2(camera.position.x - plan.fire.zones[index].visualPoint.x,
        camera.position.z - plan.fire.zones[index].visualPoint.z);
      geometry[index].flame.uniforms.time.value = state.time;
      geometry[index].flame.uniforms.intensity.value = burning ? 1 : .45;
      (flameGroup.children[1] as THREE.PointLight).intensity = burning ? 1.3 + Math.sin(state.time * 11) * .2 : .15;
    });
  });
  return <group>
    <group ref={fires}>{plan.fire.zones.map((zone, index) => <group key={zone.id} visible={false} name={`staffroom-fire-${zone.id}`}>
      <mesh geometry={geometry[index].fill} rotation={[-Math.PI / 2, 0, 0]} position={[0, zone.y + .022, 0]}>
        <meshBasicMaterial transparent depthWrite={false} toneMapped={false} />
      </mesh>
      <mesh geometry={geometry[index].outline}><meshBasicMaterial transparent opacity={.9} depthWrite={false} side={THREE.DoubleSide} toneMapped={false} /></mesh>
      <group position={[zone.visualPoint.x, zone.visualPoint.y, zone.visualPoint.z]} visible={false}>
        <mesh material={geometry[index].flame} position={[0, .57, 0]}><planeGeometry args={[1.7, 1.2]} /></mesh>
        <pointLight color="#e99a55" intensity={0} distance={3.2} decay={2} />
      </group>
    </group>)}</group>
    <group ref={tip} visible={false} position={[plan.upgrade.x, plan.upgrade.y + .05, plan.upgrade.z]}>
      <mesh rotation={[Math.PI / 2, 0, 0]}><coneGeometry args={[.055, .25, 4]} /><meshStandardMaterial color="#c7c2a8" metalness={.55} roughness={.45} /></mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]}><ringGeometry args={[.36, .39, 36]} /><meshBasicMaterial color="#e4c88e" transparent opacity={.65} depthWrite={false} /></mesh>
    </group>
    <group position={[plan.checkpoint.x, plan.checkpoint.y + .04, plan.checkpoint.z]}>
      <mesh><boxGeometry args={[.17, .035, .28]} /><meshStandardMaterial color="#313e3d" roughness={.55} /></mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]}><ringGeometry args={[.38, .405, 40]} /><meshBasicMaterial color="#a8d9b8" transparent opacity={.65} depthWrite={false} /></mesh>
    </group>
    <group ref={keepsake} visible={false} position={[plan.hidden.x, plan.hidden.y + .035, plan.hidden.z]}>
      <mesh><boxGeometry args={[.16, .014, .22]} /><meshStandardMaterial color="#c5b996" roughness={.95} /></mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]}><ringGeometry args={[.3, .33, 36]} /><meshBasicMaterial color="#e4c88e" transparent opacity={.65} depthWrite={false} /></mesh>
    </group>
    <group ref={echo} visible={false} position={[plan.echo.x, plan.echo.y + .045, plan.echo.z]}>
      <mesh><boxGeometry args={[.17, .045, .27]} /><meshStandardMaterial color="#777e74" roughness={.7} /></mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]}><ringGeometry args={[.5, .54, 40]} /><meshBasicMaterial color="#f0d0a0" transparent opacity={.8} depthWrite={false} /></mesh>
    </group>
  </group>;
}
