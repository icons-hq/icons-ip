import { Box3, Frustum, Matrix4, Mesh, Raycaster, Vector3, type Camera, type Object3D } from 'three';
import layout from '@/docs/games/hyosan-memories-3d/world-layout.json';

const BAY_MARKERS = [{ id: 'north', count: 5 }, { id: 'south', count: 4 }] as const;
const SHELLS = ['north-back', 'north-return', 'south-return'] as const;
const EMPTY: ReadonlySet<Object3D> = new Set();
const RAY_LENGTH = 12;
interface ServingKitchenVisibility { update(camera: Camera): ReadonlySet<Object3D>; dispose(): void }

/** Native static markers describe equipment worth seeing, never combat actors.
 * Recreate with the scene when the asset or static root transforms change.
 * This controller reads geometry/materials and owns no GPU resources. */
export function createServingKitchenVisibility(scene: Object3D): ServingKitchenVisibility {
  scene.updateMatrixWorld(true);
  const equipment = BAY_MARKERS.map(bay => scene.getObjectByName(`wall-visibility-s2-kitchen-${bay.id}-equipment`));
  if (equipment.every(object => !object)) return { update: () => EMPTY, dispose() {} };
  if (equipment.some(object => !object)) throw new Error('Incomplete native serving-kitchen equipment');
  const bays = BAY_MARKERS.map((bay, index) => {
    const object = equipment[index]!;
    const bounds = new Box3().setFromObject(object, true);
    if (bounds.isEmpty()) throw new Error(`Missing serving-kitchen geometry ${bay.id}`);
    const markerBounds = bounds.clone().expandByScalar(.0001);
    const targets = Array.from({ length: bay.count }, (_, markerIndex) => {
      const name = `s2-kitchen-visibility-${bay.id}-${markerIndex}`;
      const marker = object.getObjectByName(name);
      if (!marker) throw new Error(`Missing native kitchen visibility marker ${name}`);
      const point = marker.getWorldPosition(new Vector3());
      if (![point.x, point.y, point.z].every(Number.isFinite) || !markerBounds.containsPoint(point)) {
        throw new Error(`Kitchen visibility marker exceeds its equipment geometry ${name}`);
      }
      return point;
    });
    return { bounds, targets, blockers: new Set<Object3D>() };
  });
  const candidates = [...SHELLS.map(id => `wall-visibility-s2-kitchen-${id}`), layout.classroom.connectorCutawayNode].map(name => {
    const object = scene.getObjectByName(name);
    if (!object) throw new Error(`Missing kitchen visibility occluder ${name}`);
    const meshes: Mesh[] = []; const bounds = new Box3();
    object.traverse(node => {
      if (!(node instanceof Mesh)) return;
      const materials = Array.isArray(node.material) ? node.material : [node.material];
      if (name !== layout.classroom.connectorCutawayNode && !materials.every(material => material.name === 'cafeteria_kitchen_plaster')) return;
      meshes.push(node); bounds.expandByObject(node, true);
    });
    if (!meshes.length) throw new Error(`Missing separate opaque kitchen upper mesh ${name}`);
    return { object, meshes, bounds };
  });
  const raycaster = new Raycaster(); raycaster.far = RAY_LENGTH - .0001;
  const origin = new Vector3(); const entry = new Vector3(); const direction = new Vector3();
  const frustum = new Frustum(); const projection = new Matrix4();
  let cachedDirection: Vector3 | null = null; let disposed = false;
  return {
    update(camera: Camera): ReadonlySet<Object3D> {
      if (disposed) return EMPTY;
      camera.updateMatrixWorld(); camera.getWorldDirection(direction).normalize();
      if (!cachedDirection || cachedDirection.distanceToSquared(direction) > 1e-14) {
        cachedDirection ??= new Vector3(); cachedDirection.copy(direction);
        for (const bay of bays) {
          bay.blockers.clear();
          for (const target of bay.targets) {
            origin.copy(target).addScaledVector(direction, -RAY_LENGTH); raycaster.set(origin, direction);
            for (const candidate of candidates) {
              if (bay.blockers.has(candidate.object)) continue;
              if (!candidate.bounds.containsPoint(origin) && (!raycaster.ray.intersectBox(candidate.bounds, entry)
                || entry.distanceTo(origin) > raycaster.far)) continue;
              // Keep every foreground blocker; opening the nearest shell alone
              // would leave a second opaque classroom wall over the equipment.
              if (raycaster.intersectObjects(candidate.meshes, false).length) bay.blockers.add(candidate.object);
            }
          }
        }
      }
      // Orthographic translation/zoom changes visibility, not the static rays.
      frustum.setFromProjectionMatrix(projection.multiplyMatrices(camera.projectionMatrix, camera.matrixWorldInverse));
      const visible = new Set<Object3D>();
      for (const bay of bays) if (frustum.intersectsBox(bay.bounds)) for (const object of bay.blockers) visible.add(object);
      return visible;
    },
    dispose() { disposed = true; for (const bay of bays) bay.blockers.clear(); },
  };
}
