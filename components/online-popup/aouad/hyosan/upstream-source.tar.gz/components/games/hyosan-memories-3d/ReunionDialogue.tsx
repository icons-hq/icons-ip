'use client';

import { useEffect, useId, useRef } from 'react';
import { HYOSAN_REUNION_PAGES } from '@/lib/games/hyosan-memories-3d/ending';
import type { Hyosan3DEnding } from '@/lib/games/hyosan-memories-3d/types';
import styles from './Hyosan3D.module.css';

export function ReunionDialogue({ ending, onAdvance, onPause }: {
  ending: Readonly<Hyosan3DEnding>;
  onAdvance: (action: 'next' | 'skip') => void;
  onPause: () => void;
}) {
  const panel = useRef<HTMLDivElement>(null);
  const id = useId();
  const returning = ending.phase === 'returning';
  const page = HYOSAN_REUNION_PAGES[ending.page];
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    panel.current?.focus();
    return () => { if (previous?.isConnected) previous.focus(); };
  }, []);
  return <div className={styles.reunionBackdrop}>
    <div ref={panel} className={styles.reunion} role="dialog" aria-modal="true" aria-labelledby={`${id}-title`}
      aria-describedby={`${id}-text`} tabIndex={-1} data-reunion-phase={ending.phase}
      onKeyDown={(event) => {
        if (event.key !== 'Tab') return;
        const buttons = [...event.currentTarget.querySelectorAll<HTMLButtonElement>('button:not(:disabled)')];
        const first = buttons[0]; const last = buttons.at(-1);
        if (event.shiftKey && (document.activeElement === first || document.activeElement === panel.current)) {
          event.preventDefault(); last?.focus();
        } else if (!event.shiftKey && (document.activeElement === last || document.activeElement === panel.current)) {
          event.preventDefault(); first?.focus();
        }
      }}>
      <span className={styles.menuEyebrow}>{returning ? '여덟 개의 기억 너머' : `${page.speaker} · ${ending.page + 1} / ${HYOSAN_REUNION_PAGES.length}`}</span>
      <div aria-live="polite" aria-atomic="true">
        <h1 id={`${id}-title`}>{returning ? '다시, 옥상' : page.title}</h1>
        <p id={`${id}-text`}>{returning ? '기억 속 학교가 잠잠해지고, 모닥불이 밤을 밝힙니다.' : page.text}</p>
      </div>
      <div className={styles.reunionActions}>
        {!returning && <button type="button" className={styles.primaryButton} disabled={ending.time < .25} onClick={() => onAdvance('next')}>
          {ending.page === HYOSAN_REUNION_PAGES.length - 1 ? '기억을 간직하고 · 학교 둘러보기' : '다음 이야기'}
        </button>}
        {!returning && ending.page < HYOSAN_REUNION_PAGES.length - 1 && <button type="button" className={styles.secondaryButton} disabled={ending.time < .25} onClick={() => onAdvance('skip')}>이야기 건너뛰기</button>}
        <button type="button" className={styles.secondaryButton} onClick={onPause}>잠시 멈추기 <small>Esc</small></button>
      </div>
    </div>
  </div>;
}
