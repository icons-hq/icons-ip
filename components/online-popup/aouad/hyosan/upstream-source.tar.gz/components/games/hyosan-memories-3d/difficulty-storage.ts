import { isHyosanDifficulty, type HyosanDifficulty } from '@/lib/games/hyosan-memories-3d/difficulty';

export const HYOSAN_DIFFICULTY_KEY = 'hyosan-memories-difficulty-v1';

/** Preferences never modify or migrate the player's durable campaign record. */
export function createHyosanDifficultyStorage(access: () => Pick<Storage, 'getItem' | 'setItem'>) {
  return {
    load(hasProgress: boolean): HyosanDifficulty {
      const fallback = hasProgress ? 'standard' : 'relaxed';
      try {
        const value = access().getItem(HYOSAN_DIFFICULTY_KEY);
        return isHyosanDifficulty(value) ? value : fallback;
      } catch { return fallback; }
    },
    write(value: HyosanDifficulty): boolean {
      if (!isHyosanDifficulty(value)) return false;
      try { access().setItem(HYOSAN_DIFFICULTY_KEY, value); return true; }
      catch { return false; }
    },
  };
}
