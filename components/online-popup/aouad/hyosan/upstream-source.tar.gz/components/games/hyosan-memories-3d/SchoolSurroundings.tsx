'use client';

import { useMemo } from 'react';
import { useGLTF } from '@react-three/drei';
import { Mesh } from 'three';

/** Authored, noninteractive scenery; the shared GLB cache owns its resources. */
export function SchoolSurroundings() {
  const gltf = useGLTF('/api/dev/hyosan-3d/school-surroundings.glb');
  const scene = useMemo(() => {
    const clone = gltf.scene.clone(true);
    clone.traverse((node) => {
      if (!(node instanceof Mesh)) return;
      node.castShadow = !node.name.startsWith('apron-') && !node.name.startsWith('roof-finish');
      node.receiveShadow = true;
    });
    return clone;
  }, [gltf]);
  return <primitive object={scene} dispose={null} />;
}
