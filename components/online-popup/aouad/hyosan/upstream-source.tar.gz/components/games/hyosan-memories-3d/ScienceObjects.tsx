'use client';
import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import type { Group, Mesh, MeshBasicMaterial } from 'three';
import layout from '@/docs/games/hyosan-memories-3d/world-layout.json';
import type { Hyosan3DPlayRuntime } from '@/lib/games/hyosan-memories-3d/types';
import { BowCase } from './AdventureObjects';
const science = layout.science;
/** Physical landmarks at the exact interaction coordinates; no screen-space fake exit. */
export function ScienceObjects({ simulation }: { simulation: Hyosan3DPlayRuntime }) {
  const root = useRef<Group>(null); const kit = useRef<Group>(null); const echo = useRef<Group>(null); const origin = useRef<Mesh>(null);
  useFrame(() => {
    const state = simulation.read();
    if (root.current) root.current.visible = state.area === 'science';
    if (kit.current) kit.current.visible = !state.progress.upgraded;
    if (echo.current) echo.current.visible = !state.progress.areaResolved && state.progress.bossDefeated && !state.progress.echoCollected;
    if (origin.current) {
      origin.current.visible = !state.progress.originInspected && !state.progress.awaitingFirstShot;
      (origin.current.material as MeshBasicMaterial).opacity = .45 + Math.sin(state.time * 2) * .15;
    }
  });
  return <group ref={root} visible={simulation.read().area === 'science'}>
    <group ref={kit} position={[science.upgrade.x, .095, science.upgrade.z]}><BowCase /></group>
    <group position={[science.checkpoint.x, .026, science.checkpoint.z]}>
      <mesh castShadow><boxGeometry args={[.26, .04, .18]} /><meshStandardMaterial color="#9caa95" roughness={.8} /></mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]}><ringGeometry args={[.38, .405, 40]} /><meshBasicMaterial color="#a8d9b8" transparent opacity={.65} depthWrite={false} /></mesh>
    </group>
    <mesh ref={origin} position={[science.origin.x, .026, science.origin.z]} rotation={[-Math.PI / 2, 0, 0]}>
      <ringGeometry args={[.42, .46, 40]} /><meshBasicMaterial color="#e4c88e" transparent opacity={.5} depthWrite={false} />
    </mesh>
    <group ref={echo} visible={false} position={[science.echo.x, .035, science.echo.z]}>
      <mesh castShadow><boxGeometry args={[.3, .035, .23]} /><meshStandardMaterial color="#d7c598" roughness={.9} /></mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]}><ringGeometry args={[.52, .56, 48]} /><meshBasicMaterial color="#f0d0a0" transparent opacity={.8} depthWrite={false} /></mesh>
    </group>
  </group>;
}
