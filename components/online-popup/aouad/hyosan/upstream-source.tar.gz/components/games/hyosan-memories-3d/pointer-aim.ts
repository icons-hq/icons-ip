import { Plane, Ray, Vector3 } from 'three';
import { HYOSAN_BOW_HEIGHT } from '@/lib/games/hyosan-memories-3d/bow-projectiles';
import { sameHyosanCombatLayer, type HyosanLayerPoint } from '@/lib/games/hyosan-memories-3d/combat-layers';

interface Point extends HyosanLayerPoint { x: number; y: number; z: number }
interface Body extends Point { hp: number; kind: 'student' | 'boss'; dormant?: boolean }

/** Pick the body under the pointer; the simulation still owns projectile occlusion. */
export function resolveHyosanPointerAim(ray: Ray, player: Point, enemies: readonly Body[]): Point {
  let picked: Body | undefined;
  let nearest = Infinity;
  const lower = new Vector3(); const upper = new Vector3(); const hit = new Vector3();
  for (const enemy of enemies) {
    if (enemy.hp <= 0 || enemy.dormant || !sameHyosanCombatLayer(player, enemy)) continue;
    const radius = enemy.kind === 'boss' ? .5 : .32;
    lower.set(enemy.x, enemy.y + radius, enemy.z);
    upper.copy(lower).y += 1.1;
    if (ray.distanceSqToSegment(lower, upper, hit) > radius * radius) continue;
    const distance = hit.distanceToSquared(ray.origin);
    if (distance < nearest) { nearest = distance; picked = enemy; }
  }
  if (picked) return { x: picked.x - player.x, y: picked.y - player.y, z: picked.z - player.z };
  // An empty-space shot stays level with the archer. Picking an actual body
  // above/below supplies its height instead of projecting it behind the body.
  const target = ray.intersectPlane(new Plane(new Vector3(0, 1, 0), -player.y - HYOSAN_BOW_HEIGHT), hit);
  return target ? { x: target.x - player.x, y: 0, z: target.z - player.z } : { x: 0, y: 0, z: 0 };
}
