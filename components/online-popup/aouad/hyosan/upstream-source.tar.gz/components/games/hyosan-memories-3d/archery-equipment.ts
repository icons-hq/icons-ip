import { BufferGeometry, Float32BufferAttribute, Line, LineBasicMaterial, Group, Mesh, Object3D, Vector3 } from 'three';

interface RecurveContract {
  tips: [number[], number[]]; drawnTips: [number[], number[]]; drawDistance: number; braceZ: number;
}

/** Own the moving string; the GLB retains ownership of limb morph geometry. */
export function createHyosanArcheryEquipment(bow: Object3D) {
  const contract: RecurveContract = bow.userData.archery ?? {
    tips: [[0, .583, -.199], [0, -.583, -.199]],
    drawnTips: [[0, .583, -.199], [0, -.583, -.199]], drawDistance: .22, braceZ: -.199,
  };
  const rest = contract.tips.map(point => new Vector3().fromArray(point));
  const drawn = contract.drawnTips.map(point => new Vector3().fromArray(point));
  const geometry = new BufferGeometry().setAttribute('position', new Float32BufferAttribute(9, 3));
  const material = new LineBasicMaterial({ color: '#d3d7cc' });
  const string = new Line(geometry, material);
  string.name = 'hyosan-runtime-bow-string';
  const original = bow.getObjectByName('hyosan_bow_string');
  if (original) original.visible = false;
  bow.add(string);
  const limbs: { mesh: Mesh; index: number }[] = [];
  bow.traverse(node => {
    if (node instanceof Mesh && node.morphTargetDictionary?.Draw !== undefined) {
      limbs.push({ mesh: node, index: node.morphTargetDictionary.Draw });
    }
  });
  const attachments = [2, 3, 4].map(level => ({ level, object: bow.getObjectByName(`hyosan_bow_upgrade_${level}`) }));
  const point = new Vector3();
  const updateDraw = (amount: number) => {
    const draw = Math.max(0, Math.min(1, amount));
    const position = geometry.getAttribute('position');
    for (const [index, vertex] of [0, 2].entries()) {
      point.copy(rest[index]).lerp(drawn[index], draw);
      position.setXYZ(vertex, point.x, point.y, point.z);
    }
    position.setXYZ(1, 0, 0, contract.braceZ - draw * contract.drawDistance);
    position.needsUpdate = true;
    geometry.computeBoundingSphere();
    for (const { mesh, index } of limbs) mesh.morphTargetInfluences![index] = draw;
  };
  const updateLevel = (level: number) => {
    for (const attachment of attachments) if (attachment.object) attachment.object.visible = level >= attachment.level;
  };
  updateDraw(0); updateLevel(1);
  return { string, material, drawDistance: contract.drawDistance, braceZ: contract.braceZ, updateDraw, updateLevel,
    dispose: () => geometry.dispose() };
}

/** The simulation point is the arrow tip. GLB geometry/materials stay loader-owned. */
export function createHyosanFlightArrow(student: Object3D) {
  const source = student.getObjectByName('hyosan_nocked_arrow');
  if (!source) throw new Error('Missing nocked school arrow');
  const arrow = source.clone(true);
  arrow.position.set(0, 0, -(source.userData.arrowLength ?? .72));
  arrow.quaternion.identity();
  arrow.scale.setScalar(1);
  arrow.visible = true;
  const flight = new Group();
  flight.name = 'hyosan-flight-arrow';
  flight.add(arrow);
  return flight;
}
