'use client';
import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import layout from '@/docs/games/hyosan-memories-3d/world-layout.json';
import type { Hyosan3DPlayRuntime } from '@/lib/games/hyosan-memories-3d/types';

const plan = layout.gymnasium;
const point = (value: { x: number; y: number; z: number }, height = .04): [number, number, number] => [value.x, value.y + height, value.z];
function Ring({ color, radius = .38 }: { color: string; radius?: number }) {
  return <mesh rotation={[-Math.PI / 2, 0, 0]}><ringGeometry args={[radius, radius + .035, 36]} />
    <meshBasicMaterial color={color} transparent opacity={.75} depthWrite={false} /></mesh>;
}

/** Small floor cues follow discovered objects and physics-accepted cart handles. */
export function GymnasiumObjects({ simulation }: { simulation: Hyosan3DPlayRuntime }) {
  const anchor = useRef<THREE.Group>(null), supply = useRef<THREE.Group>(null), record = useRef<THREE.Group>(null);
  const echo = useRef<THREE.Group>(null), cart = useRef<THREE.Group>(null);
  useFrame(() => {
    const state = simulation.read(); const progress = state.area === 'gymnasium' ? state.progress : state.schoolState?.gymnasium;
    const equipmentKnown = progress?.discoveredRooms.includes('gym-equipment') ?? false;
    if (anchor.current) anchor.current.visible = equipmentKnown;
    if (supply.current) supply.current.visible = equipmentKnown && !progress?.supplyTaken;
    if (record.current) record.current.visible = state.progress.room === 'gym-equipment' && !progress?.keepsakeFound;
    if (echo.current) echo.current.visible = Boolean(progress?.escapeResolved && !progress.areaResolved && !progress.echoCollected);
    if (cart.current) {
      cart.current.visible = state.interaction === 'exit-cart' || state.interaction === 'cover-cart';
      const cover = state.furniture.find((item) => item.id === plan.coverCart.id);
      const handle = state.interaction === 'cover-cart' && cover ? { x: cover.x + plan.coverCart.interactOffset.x,
        y: cover.y ?? -3, z: cover.z + plan.coverCart.interactOffset.z } : plan.exitCart.interactPoint;
      cart.current.position.set(...point(handle));
    }
  });
  return <group>
    <group ref={anchor} visible={false} position={point(plan.checkpoint)}><Ring color="#a8d9b8" radius={.65} />
      <mesh><boxGeometry args={[.16, .035, .25]} /><meshStandardMaterial color="#536d65" roughness={.8} /></mesh></group>
    <group ref={supply} visible={false} position={point(plan.supply, .12)}>
      <mesh><boxGeometry args={[.32, .2, .24]} /><meshStandardMaterial color="#e1dcca" roughness={.85} /></mesh>
      <mesh position={[0, .105, 0]}><boxGeometry args={[.17, .009, .04]} /><meshStandardMaterial color="#8e4941" /></mesh>
      <mesh position={[0, .105, 0]}><boxGeometry args={[.04, .009, .15]} /><meshStandardMaterial color="#8e4941" /></mesh>
      <group position={[0, -.08, 0]}><Ring color="#afd5bb" /></group>
    </group>
    <group ref={record} visible={false} position={point(plan.hidden)}>
      <mesh><boxGeometry args={[.2, .014, .28]} /><meshStandardMaterial color="#c9bc9a" roughness={.95} /></mesh>
      <Ring color="#dcc28b" radius={.3} />
    </group>
    <group ref={echo} visible={false} position={point(plan.echo)}>
      <mesh><boxGeometry args={[.19, .035, .28]} /><meshStandardMaterial color="#636a63" roughness={.7} /></mesh>
      <Ring color="#efd29f" radius={.5} />
    </group>
    <group ref={cart} visible={false}><Ring color="#f0cf8a" radius={.48} /></group>
  </group>;
}
