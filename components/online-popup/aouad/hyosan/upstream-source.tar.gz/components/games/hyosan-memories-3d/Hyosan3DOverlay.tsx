'use client';

import { reunionPlaying } from '@/lib/games/hyosan-memories-3d/ending';
import { ReunionDialogue } from './ReunionDialogue';
import { StoryCutscene } from './StoryCutscene';
import { areaBoss, hyosan3DRoomLabel } from './school-presentation';

import { useCallback, useEffect, useId, useRef, type PointerEvent as ReactPointerEvent, type ReactNode } from 'react';
import layout from '@/docs/games/hyosan-memories-3d/world-layout.json';
import { HYOSAN_ALL_ROOMS, type Hyosan3DSnapshot } from '@/lib/games/hyosan-memories-3d/types';
import type { Hyosan3DInputController } from './input';
import styles from './Hyosan3D.module.css';
import { NavigationMap } from './NavigationMap';
import { hyosan3DRoomAt, hyosan3DRoomForFloor } from '@/lib/games/hyosan-memories-3d/rooms';
import { HYOSAN_STAFFROOM_FIRE } from '@/lib/games/hyosan-memories-3d/staffroom-fire';
import type { GroundPoint } from '@/lib/games/hyosan-memories-3d/physics';
import type { HyosanDifficulty } from '@/lib/games/hyosan-memories-3d/difficulty';

interface Hyosan3DOverlayProps {
  readonly snapshot: Readonly<Hyosan3DSnapshot> | null;
  readonly started: boolean;
  readonly temporary?: boolean;
  readonly onAdvanceStory?: (action: 'next' | 'skip') => void;
  readonly onAdvanceEnding?: (action: 'next' | 'skip') => void;
  readonly onStart: () => void;
  readonly onPause: () => void;
  readonly onRestart: () => void;
  readonly input: Hyosan3DInputController;
  readonly muted: boolean;
  readonly onToggleSound: () => void;
  readonly hasSave: boolean;
  readonly saveUnavailable: boolean;
  readonly saveNotice: string | null;
  readonly mapOpen: boolean;
  readonly onToggleMap: () => void;
  readonly mapRoute?: readonly GroundPoint[];
  readonly routeVisible?: boolean;
  readonly onToggleRoute?: () => void;
  readonly onChangeDifficulty?: (difficulty: HyosanDifficulty) => void;
  readonly difficultyUnavailable?: boolean;
}

const ROOMS = Object.fromEntries(HYOSAN_ALL_ROOMS.map((room) => {
  const authoredLabel = (layout.floors.find((floor) => floor.id === room)
    ?? layout.floors.find((floor) => hyosan3DRoomForFloor(floor) === room))?.label
    ?? (room === 'rooftop-ascent' ? '옥상으로 오르는 계단' : room);
  return [room, hyosan3DRoomLabel(room, authoredLabel)];
}));
const BOW_LEVELS = { 1: 'I', 2: 'II', 3: 'III', 4: 'IV' } as const;
const ROOFTOP_BOSS_HINTS = { stalk: null, 'rush-windup': '돌진 방향이 정해졌습니다 · 옆으로 피하세요', rush: '돌진선 옆으로 벗어나세요',
  'sweep-windup': '팔을 듭니다 · 한 걸음 물러나세요', sweep: '팔이 닿지 않는 곳으로 물러나세요',
  recovery: '자세를 고칩니다 · 활을 쏠 틈입니다', resolve: '다시 일어섭니다 · 다음 돌진에 대비하세요' } as const;
const INTERACTIONS = { campfire: '모닥불 곁으로', 'cover-cart': '엄폐 카트 한 칸 밀기', 'exit-cart': '출구 카트 밀기', origin: '감염 흔적 조사', upgrade: '양궁 장비로 강화', supply: '보급품으로 강화', shortcut: '지름길 빗장 열기', echo: '남겨진 기억 회수', barricade: '책상 바리케이드 밀기', hose: '소방호스 고정', bowstring: '시위 보강 · 화살 속도 증가', arrowtip: '화살촉 보강 · 관통 +1', keepsake: '낡은 책갈피 챙기기' } as const;
const STAFFROOM_BOSS_HINTS = { idle: null, pursuit: null, investigate: null, return: null,
  notice: '시선을 끌었습니다 · 거리를 벌리세요', 'grab-windup': '붙잡으려 합니다 · 옆으로 피하세요', grab: '뻗는 팔에서 벗어나세요',
  recovery: '자세를 고칩니다 · 활을 쏠 틈입니다', 'ignite-windup': '종이에 불을 붙입니다 · 표시에서 벗어나세요', 'ignite-recovery': '불길을 피해 활을 쏘세요' } as const;
const LIBRARY_BOSS_HINTS = { stalk: null, sidestep: '옆으로 움직입니다 · 거리를 유지하세요', 'thrust-windup': '앞으로 찌릅니다 · 옆으로 피하세요', thrust: '찌르는 방향에서 벗어나세요', 'check-windup': '왼팔을 듭니다 · 한 걸음 물러나세요', check: '팔이 닿지 않는 곳으로 물러나세요', recovery: '자세를 고칩니다 · 활을 쏠 틈입니다' } as const;
const BROADCAST_BOSS_HINTS = { limp: null, 'grab-windup': '붙잡기 전에 거리를 벌리세요', grab: '팔이 뻗는 방향을 피하세요',
  recovery: '활을 쏠 틈입니다', trip: '발이 걸렸습니다 · 계단 아래에서 물러나세요', slide: '미끄러지는 방향에서 물러나세요', brace: '다시 일어납니다 · 거리를 확보하세요' } as const;
const CLASSROOM_BOSS_HINTS = { brace: '몸을 낮춥니다 · 옆으로 피할 준비', rush: '옆으로 피하세요',
  impact: '부딪힌 자리에서 물러나세요', stagger: '균형이 무너졌습니다 · 활을 쏠 틈입니다', recovery: '활을 쏠 틈입니다' } as const;
const BOSS_HINTS = {
  idle: null, tremor: '옆으로 피할 준비', charge: '옆으로 피하세요',
  'sweep-windup': '거리를 벌리세요', sweep: '거리를 벌리세요', recovery: '활을 쏠 틈입니다',
} as const;
const OBJECTIVES = {
  return_memory: '아직 남은 기억이 있습니다 · 지도에 표시된 길로 돌아가세요',
  return_campfire: '여덟 기억을 되찾았습니다 · 옥상 모닥불 앞으로 돌아가세요',
  ascend_rooftop: '두 계단을 따라 옥상 출입실로 올라가세요',
  explore_rooftop: '설비 사이의 열린 길을 살피세요',
  reach_gym: '휴게실 동쪽 문을 지나 체육관으로 이동하세요',
  explore_gym: '전실을 돌아 코트로 들어가 탈출로를 살피세요',
  escape_gym: '동쪽 출구 카트를 밀어 길을 열고 빠져나가세요',
  inspect_lab: '실험대 옆 우리에서 감염 흔적을 조사하세요',
  return_science: '서쪽 과학실로 돌아가 첫 기억을 찾으세요',
  explore_school: '기억을 되찾았습니다 · 놓친 길과 장비를 살펴보세요',
  find_upgrade: '복도에서 양궁 장비를 찾으세요',
  reach_cafeteria: '복도 끝 급식실 입구를 찾으세요',
  explore_cafeteria: '급식실 중앙에서 소리의 흔적을 살피세요',
  reach_classroom: '동쪽 연결 복도를 따라 교실로 이동하세요',
  explore_classroom: '막힌 앞문을 밀거나 남쪽 복도로 돌아 교실을 살피세요',
  reach_library: '하층 복도 동쪽 문으로 도서관에 들어가세요',
  explore_library: '열람실을 지나 서가 사이의 길을 살피세요',
  climb_shelves: '서쪽 경사로를 따라 서가 위 통로로 올라가세요',
  reach_staffroom: '도서관 동쪽 문을 지나 교무실로 이동하세요',
  explore_staffroom: '학년 업무석과 남쪽 방화구획 통로를 살피세요',
  inspect_records: '학년 업무석 동쪽의 교무 기록석을 살피세요',
  reach_broadcast: '동쪽 복도 끝에서 방송동으로 이동하세요',
  inspect_broadcast: '방송 조정실의 조작대에서 남겨진 흔적을 조사하세요',
  secure_hose: '상층 계단참에서 소방호스를 고정하세요',
  descend_stairs: '두 계단을 따라 하층 복도로 내려가세요',
  defeat_boss: '전조를 피하며 급식실의 위협을 물리치세요',
  collect_echo: '남겨진 기억 가까이에서 E로 회수하세요',
  reach_exit: '배식대 사이 출구로 이동하세요',
  completed: '급식실을 통과했습니다',
} as const;

function objectiveLabel(snapshot: Readonly<Hyosan3DSnapshot>) {
  if (snapshot.progress.awaitingFirstShot) return '첫 화살을 쏴보세요';
  if (snapshot.progress.objective === 'return_memory' && snapshot.ending?.nextArea) {
    const names = { science: '과학실', cafeteria: '보건실·급식실', classroom: '2학년 교실', broadcast: '방송동', library: '도서관', staffroom: '교무실', gymnasium: '체육관', rooftop: '옥상' };
    return `${names[snapshot.ending.nextArea]}의 기억이 남았습니다 · 지도의 입구 표시를 따라가세요`;
  }
  if (snapshot.ending?.phase === 'complete') return '여덟 기억을 간직했습니다 · 학교를 자유롭게 둘러보세요';
  if (snapshot.area === 'rooftop') {
    if (snapshot.progress.objective === 'defeat_boss') return '돌진을 옆으로 피하고, 귀남이 멈추면 활을 쏘세요';
    if (snapshot.progress.objective === 'reach_exit') return '모닥불 자리 북쪽 끝으로 이동하세요';
    if (snapshot.progress.objective === 'completed') return '옥상에 남겨진 기억을 되찾았습니다';
  }
  if (snapshot.area === 'gymnasium') {
    if (snapshot.progress.objective === 'escape_gym' && snapshot.progress.escapeCartCleared) return '열린 동쪽 통로로 빠져나가세요';
    if (snapshot.progress.objective === 'reach_exit') return '기억을 챙겨 동쪽 로비 끝으로 이동하세요';
    if (snapshot.progress.objective === 'completed') return '체육관을 빠져나왔습니다';
  }
  if (snapshot.area === 'staffroom') {
    if (snapshot.progress.objective === 'inspect_records' && snapshot.progress.shortcutOpened) return '열린 방화구획 통로를 지나 교무 기록석을 살피세요';
    if (snapshot.progress.objective === 'defeat_boss') return '불길을 피해 움직이고, 붙잡기 뒤 빈틈에 활을 쏘세요';
    if (snapshot.progress.objective === 'reach_exit') return '직원 휴게실 동쪽 끝으로 이동하세요';
    if (snapshot.progress.objective === 'completed') return '교무실의 기억을 되찾았습니다';
  }
  if (snapshot.area === 'library') {
    if (snapshot.progress.objective === 'climb_shelves' && snapshot.progress.room === 'library-crown') return '서가 위 통로를 따라 중앙의 위협을 살피세요';
    if (snapshot.progress.objective === 'defeat_boss') return '귀남의 찌르기를 피하고, 자세를 고칠 때 활을 쏘세요';
    if (snapshot.progress.objective === 'reach_exit') return '동쪽 경사로로 내려가 정리실 끝까지 이동하세요';
    if (snapshot.progress.objective === 'completed') return '도서관에 남겨진 기억을 되찾았습니다';
  }
  if (snapshot.area === 'broadcast') {
    if (snapshot.progress.objective === 'defeat_boss') return '붙잡기를 피하고, 계단 아래의 위협을 물리치세요';
    if (snapshot.progress.objective === 'reach_exit') return '하층 복도 동쪽 끝으로 이동하세요';
    if (snapshot.progress.objective === 'completed') return '방송동에 남겨진 기억을 되찾았습니다';
  }
  if (snapshot.area === 'classroom') {
    if (snapshot.progress.objective === 'explore_classroom' && snapshot.progress.discoveredRooms.includes('classroom-2-5')) return '교실 뒷문을 지나 동쪽 복도를 살피세요';
    if (snapshot.progress.objective === 'defeat_boss') return '돌진을 옆으로 피하고, 교실 복도의 위협을 물리치세요';
    if (snapshot.progress.objective === 'reach_exit') return '동쪽 복도를 따라 북쪽 끝으로 이동하세요';
    if (snapshot.progress.objective === 'completed') return '교실에 남겨진 기억을 되찾았습니다';
  }
  if (snapshot.area === 'science') {
    if (snapshot.progress.objective === 'defeat_boss') return '물기 전조를 피하고, 첫 감염자를 물리치세요';
    if (snapshot.progress.objective === 'reach_exit') return '동쪽 연결 복도를 따라 보건실로 이동하세요';
  }
  if (snapshot.progress.bossApproaching) return '북서쪽 통로에서 다가오는 위협에 대비하세요';
  if (snapshot.progress.objective === 'reach_cafeteria') {
    if (snapshot.progress.room === 'corridor') return snapshot.progress.entranceOpen < 1
      ? '급식실 유리문 가까이로 다가가세요' : '열린 유리문으로 급식실에 들어가세요';
    if (snapshot.progress.room === 'cafeteria') return '문 안쪽으로 들어가 급식실을 살피세요';
    if (snapshot.progress.room === 'sheltered-passage') return '보급실을 지나 급식실로 연결되는 길을 찾으세요';
    if (snapshot.progress.room === 'supply-room') return '보급실 동쪽 문으로 배식실 옆 통로를 찾으세요';
    if (snapshot.progress.room === 'service-gallery') return snapshot.progress.shortcutOpened
      ? '열린 남문으로 급식실에 들어가세요' : '남문 가까이에서 E로 빗장을 여세요';
  }
  return OBJECTIVES[snapshot.progress.objective];
}

function nearbyFireWarning(snapshot: Readonly<Hyosan3DSnapshot>) {
  if (snapshot.area !== 'staffroom') return false;
  return snapshot.fires?.some((fire) => {
    if (fire.phase !== 'warning') return false;
    const zone = layout.staffroom.fire.zones.find((candidate) => candidate.id === fire.id);
    return zone && snapshot.player.currentLayerId === zone.layerId
      && Math.abs(snapshot.player.y - zone.y) <= HYOSAN_STAFFROOM_FIRE.feetTolerance
      && Math.hypot(snapshot.player.x - zone.visualPoint.x, snapshot.player.z - zone.visualPoint.z) <= 6
      && snapshot.progress.discoveredRooms.includes(hyosan3DRoomAt(zone.visualPoint, layout.floors));
  }) ?? false;
}

function interactionLabel(snapshot: Readonly<Hyosan3DSnapshot>) {
  if (!snapshot.interaction) return null;
  if (snapshot.interaction === 'campfire' && snapshot.ending?.phase === 'complete') return '남라와의 재회 다시 보기';
  if (snapshot.area === 'staffroom' && snapshot.interaction === 'keepsake') return '남겨진 메모 챙기기';
  if (snapshot.area === 'staffroom' && snapshot.interaction === 'shortcut') return '방화구획 카트 밀기';
  if (snapshot.area === 'broadcast' && snapshot.interaction === 'origin') return '방송 흔적 조사';
  if ((snapshot.area === 'broadcast' || snapshot.area === 'gymnasium' || snapshot.area === 'rooftop') && snapshot.interaction === 'supply') return '구급품 사용 · 체력 +2';
  if (snapshot.area === 'rooftop' && snapshot.interaction === 'keepsake') return '생존자가 남긴 쪽지 챙기기';
  if (snapshot.area === 'gymnasium' && snapshot.interaction === 'keepsake') return '훈련 기록 챙기기';
  return INTERACTIONS[snapshot.interaction];
}

function placeLabel(snapshot: Readonly<Hyosan3DSnapshot>) {
  const room = ROOMS[snapshot.progress.room];
  const level = snapshot.area === 'library' ? snapshot.player.y > -1 ? '서가 위' : '서가 아래'
    : snapshot.area === 'broadcast' ? snapshot.player.currentLayerId === 'broadcast-lower' ? '하층' : '상층' : null;
  if (!level) return room;
  return `${level} · ${room.startsWith(`${level} `) ? room.slice(level.length + 1) : room}`;
}

function BowIcon() {
  return <svg viewBox="0 0 28 28" fill="none" aria-hidden="true"><path d="M9 3c15 6 15 16 0 22M9 3v22M4 14h20m-4-4 4 4-4 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" /></svg>;
}

function Joystick({ input }: { input: Hyosan3DInputController }) {
  const pointer = useRef<number | null>(null);
  const knob = useRef<HTMLSpanElement>(null);
  const clear = useCallback(() => {
    pointer.current = null;
    input.setMovement(0, 0);
    if (knob.current) knob.current.style.transform = 'translate(0px, 0px)';
  }, [input]);
  const move = (event: ReactPointerEvent<HTMLDivElement>) => {
    if (event.pointerId !== pointer.current) return;
    const bounds = event.currentTarget.getBoundingClientRect();
    const radius = bounds.width * 0.32;
    const dx = event.clientX - bounds.left - bounds.width / 2;
    const dy = event.clientY - bounds.top - bounds.height / 2;
    const distance = Math.hypot(dx, dy);
    const scale = Math.min(1, radius / Math.max(1, distance));
    const x = distance < radius * 0.1 ? 0 : dx * scale;
    const y = distance < radius * 0.1 ? 0 : dy * scale;
    input.setMovement(x / radius, y / radius);
    if (knob.current) knob.current.style.transform = `translate(${x}px, ${y}px)`;
  };
  const release = (event: ReactPointerEvent<HTMLDivElement>) => {
    if (event.pointerId === pointer.current) clear();
  };
  useEffect(() => {
    const visibility = () => { if (document.visibilityState === 'hidden') clear(); };
    window.addEventListener('blur', clear);
    document.addEventListener('visibilitychange', visibility);
    return () => {
      window.removeEventListener('blur', clear);
      document.removeEventListener('visibilitychange', visibility);
      clear();
    };
  }, [clear]);
  return <div className={styles.joystick} role="group" aria-label="이동 조이스틱" data-control="joystick"
    onPointerDown={(event) => {
      if (event.button !== 0 || pointer.current !== null) return;
      event.preventDefault();
      pointer.current = event.pointerId;
      event.currentTarget.setPointerCapture(event.pointerId);
      move(event);
    }} onPointerMove={move} onPointerUp={release} onPointerCancel={release} onLostPointerCapture={release}>
    <span className={styles.joystickAxis} aria-hidden="true" />
    <span ref={knob} className={styles.joystickKnob} aria-hidden="true" />
  </div>;
}

function FireButton({ input }: { input: Hyosan3DInputController }) {
  const pointer = useRef<number | null>(null);
  const clear = useCallback(() => { pointer.current = null; input.setAttackHeld(false); }, [input]);
  const release = (event: ReactPointerEvent<HTMLButtonElement>) => {
    if (event.pointerId === pointer.current) clear();
  };
  useEffect(() => {
    const visibility = () => { if (document.visibilityState === 'hidden') clear(); };
    window.addEventListener('blur', clear);
    document.addEventListener('visibilitychange', visibility);
    return () => {
      window.removeEventListener('blur', clear);
      document.removeEventListener('visibilitychange', visibility);
      clear();
    };
  }, [clear]);
  return <button type="button" className={styles.fireButton} aria-label="활 사격, 누르고 있으면 연사" data-action="fire"
    onPointerDown={(event) => {
      if (event.button !== 0 || pointer.current !== null) return;
      event.preventDefault();
      pointer.current = event.pointerId;
      event.currentTarget.setPointerCapture(event.pointerId);
      input.setAttackHeld(true);
    }} onPointerUp={release} onPointerCancel={release} onLostPointerCapture={release}
    onClick={(event) => { if (event.detail === 0) { input.setAttackHeld(true); input.setAttackHeld(false); } }}>
    <BowIcon /><span>사격</span>
  </button>;
}

function Menu({ title, children, overview, wide = false, restoreFocus }: { title: string; children: ReactNode; overview?: ReactNode; wide?: boolean; restoreFocus?: () => void }) {
  const panel = useRef<HTMLDivElement>(null);
  const titleId = useId();
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    const first = panel.current?.querySelector<HTMLButtonElement>('button[data-menu-primary]:not(:disabled)')
      ?? panel.current?.querySelector<HTMLButtonElement>('button:not(:disabled)');
    (first ?? panel.current)?.focus();
    return () => {
      if (restoreFocus) restoreFocus();
      else if (previous?.isConnected) previous.focus();
    };
  }, [restoreFocus]);
  return <div className={styles.menuBackdrop}>
    <div ref={panel} className={styles.menu} data-wide={wide} data-setup={Boolean(overview)} role="dialog" aria-modal="true" aria-labelledby={titleId} tabIndex={-1}
      onKeyDown={(event) => {
        if (event.key !== 'Tab') return;
        const buttons = [...event.currentTarget.querySelectorAll<HTMLButtonElement>('button:not(:disabled)')];
        const first = buttons[0];
        const last = buttons.at(-1);
        if (!first) { event.preventDefault(); return; }
        if (event.shiftKey && (document.activeElement === first || document.activeElement === panel.current)) {
          event.preventDefault(); last?.focus();
        } else if (!event.shiftKey && (document.activeElement === last || document.activeElement === panel.current)) {
          event.preventDefault(); first.focus();
        }
      }}>
      {overview ? <>
        <div className={styles.menuOverview}>
          <span className={styles.menuEyebrow}>효산의 기억</span>
          <h1 id={titleId}>{title}</h1>
          {overview}
        </div>
        <div className={styles.menuActions}>{children}</div>
      </> : <>
        <span className={styles.menuEyebrow}>효산의 기억</span>
        <h1 id={titleId}>{title}</h1>
        {children}
      </>}
    </div>
  </div>;
}

export type HyosanCampaignGuardReason = 'contended' | 'unsupported' | 'read-failed' | 'conflict' | 'suspended' | 'reset-failed';

const CAMPAIGN_GUARD_COPY: Record<HyosanCampaignGuardReason, { title: string; description: string; retry: string }> = {
  contended: { title: '다른 탭에 탐험이 열려 있습니다', description: '다른 탭을 닫고 다시 확인해 주세요.', retry: '다시 확인' },
  unsupported: { title: '탐험을 시작할 수 없습니다', description: '브라우저를 업데이트하고 다시 시도해 주세요.', retry: '다시 시도' },
  'read-failed': { title: '저장된 기억을 읽지 못했습니다', description: '기억을 다시 읽거나 저장 없이 탐험을 시작할 수 있습니다.', retry: '다시 시도' },
  conflict: { title: '다른 곳에서 기억이 바뀌었습니다', description: '최신 기억을 불러오세요.', retry: '최신 기억 불러오기' },
  suspended: { title: '마지막 기억에서 이어갑니다', description: '최신 기억을 불러오세요.', retry: '최신 기억 불러오기' },
  'reset-failed': { title: '기억을 지우지 못했습니다', description: '마지막 기억을 불러오세요.', retry: '마지막 기억 불러오기' },
};

export function HyosanCampaignGuard({ reason, onRetry, onTemporary }: {
  readonly reason: HyosanCampaignGuardReason;
  readonly onRetry: () => void;
  readonly onTemporary?: () => void;
}) {
  const copy = CAMPAIGN_GUARD_COPY[reason];
  const temporary = reason === 'read-failed' && onTemporary;
  return <div className={styles.overlay} data-hyosan-campaign-guard={reason}><Menu title={copy.title}>
    <p className={styles.intro}>{copy.description}</p>
    {reason === 'read-failed' ? <p className={styles.restartNote}>저장 없이 탐험하면 이 탭을 닫을 때 이번 진행이 사라집니다.</p> : null}
    <button type="button" data-menu-primary className={styles.primaryButton} onClick={onRetry}>{copy.retry}</button>
    {temporary ? <button type="button" className={styles.secondaryButton} onClick={onTemporary}>저장 없이 탐험</button> : null}
  </Menu></div>;
}

function DifficultyChoice({ value, onChange, unavailable }: { value: HyosanDifficulty; onChange: (difficulty: HyosanDifficulty) => void; unavailable?: boolean }) {
  const hintId = useId();
  return <fieldset className={styles.difficulty} aria-describedby={hintId}>
    <legend>전투 난이도</legend>
    <div className={styles.difficultyOptions}>
      <button type="button" aria-pressed={value === 'relaxed'} onClick={() => onChange('relaxed')}>여유롭게</button>
      <button type="button" aria-pressed={value === 'standard'} onClick={() => onChange('standard')}>기본</button>
    </div>
    <p id={hintId}>{value === 'relaxed' ? '피격 후 보호가 길고, 5초간 피해를 피하면 체력이 조금씩 회복됩니다.' : '피격 후 보호가 짧고, 자동 회복 없이 전투합니다.'}</p>
    <small>{unavailable ? '설정을 저장하지 못해 이번 플레이에만 적용됩니다.' : '언제든 변경할 수 있고 기억과 강화는 유지됩니다.'}</small>
  </fieldset>;
}

export function Hyosan3DOverlay({ snapshot, started, temporary = false, onStart, onAdvanceEnding, onAdvanceStory, onPause, onRestart, input, muted, onToggleSound, hasSave, saveUnavailable, saveNotice, mapOpen, onToggleMap, mapRoute, routeVisible, onToggleRoute, onChangeDifficulty, difficultyUnavailable }: Hyosan3DOverlayProps) {
  const mapTrigger = useRef<HTMLButtonElement>(null);
  const mapOpenedWithShortcut = useRef(false);
  const restoreMapFocus = useCallback(() => {
    if (mapOpenedWithShortcut.current) input.focusGame();
    else mapTrigger.current?.focus();
  }, [input]);
  const toggleMapFromButton = () => {
    if (!mapOpen) mapOpenedWithShortcut.current = false;
    onToggleMap();
  };
  const loaded = snapshot !== null;
  const paused = Boolean(snapshot?.paused && !snapshot.transitioning);
  const completed = Boolean(snapshot?.progress.completed && !snapshot.transitioning);
  const defeated = snapshot ? snapshot.player.hp <= 0 : false;
  const inReunion = reunionPlaying(snapshot?.ending);
  const inStory = Boolean(snapshot?.story);
  const playable = !inStory && !inReunion && loaded && started && !paused && !mapOpen && !completed && !defeated;
  const pause = useCallback(() => { input.reset(); onPause(); }, [input, onPause]);
  useEffect(() => { if (!playable) input.reset(); }, [input, playable]);
  useEffect(() => {
    if (!loaded || !started || completed || defeated) return;
    const key = (event: KeyboardEvent) => {
      if (event.repeat || event.altKey || event.ctrlKey || event.metaKey) return;
      const target = event.target as HTMLElement | null;
      if (target?.closest('input, textarea, select, [contenteditable="true"]')) return;
      if (event.key.toLowerCase() === 'm' && !inReunion && !inStory) {
        event.preventDefault(); input.reset();
        if (!mapOpen) mapOpenedWithShortcut.current = true;
        onToggleMap();
      }
      else if (event.key === 'Escape') { event.preventDefault(); if (mapOpen) onToggleMap(); else pause(); }
    };
    window.addEventListener('keydown', key);
    return () => window.removeEventListener('keydown', key);
  }, [completed, defeated, inReunion, inStory, input, loaded, mapOpen, onToggleMap, pause, started]);
  const restart = () => { input.reset(); onRestart(); };
  const areaThreat = snapshot ? areaBoss(snapshot) : undefined;
  const boss = snapshot?.progress.objective === 'defeat_boss' && areaThreat && areaThreat.hp > 0 && !areaThreat.dormant
    ? areaThreat : null;
  const bossHint = playable && boss?.profile === 'hyunju' ? boss.scienceBeat === 'bite-windup' ? '뒤로 물러나세요' : boss.scienceBeat === 'recovery' ? '활을 쏠 틈입니다' : boss.scienceBeat === 'notice' ? '시선을 끌었습니다 · 거리를 벌리세요' : null
    : playable && boss?.rooftopBeat ? ROOFTOP_BOSS_HINTS[boss.rooftopBeat]
    : playable && boss?.staffroomBeat ? STAFFROOM_BOSS_HINTS[boss.staffroomBeat]
    : playable && boss?.libraryBeat ? LIBRARY_BOSS_HINTS[boss.libraryBeat]
    : playable && boss?.broadcastBeat ? BROADCAST_BOSS_HINTS[boss.broadcastBeat]
      : playable && boss?.classroomBeat ? CLASSROOM_BOSS_HINTS[boss.classroomBeat]
      : playable && boss?.comboBeat ? BOSS_HINTS[boss.comboBeat] : null;
  const imminentGrab = boss?.staffroomBeat === 'grab-windup' || boss?.staffroomBeat === 'grab';
  const fireHint = playable && snapshot.progress.inFire ? '불길에서 벗어나세요'
    : playable && !imminentGrab && nearbyFireWarning(snapshot) ? '불이 번질 자리입니다 · 표시 밖으로 피하세요' : null;
  const guidance = fireHint ?? bossHint;

  return <div className={styles.overlay} data-hyosan-3d-state={!loaded ? 'loading' : !started ? 'start' : completed ? 'completed' : defeated ? 'defeated' : mapOpen ? 'map' : paused ? 'paused' : inStory ? 'story' : inReunion ? 'reunion' : 'playing'}>
    {started && snapshot && !inStory && !inReunion ? <>
      <div className={styles.objective} data-boss-guidance-active={Boolean(guidance)}>
        <span className={styles.place}>{placeLabel(snapshot)}</span>
        <p className={styles.objectiveAction}>{objectiveLabel(snapshot)}</p>
        {snapshot.progress.awaitingFirstShot ? <div className={styles.practiceHint}>
          <span className={styles.practiceKeyboard}>WASD로 이동 · J / Space로 사격</span>
          <span className={styles.practiceTouch}>왼쪽 패드로 이동 · 오른쪽 버튼으로 사격</span>
          <span>첫 사격 뒤 과학실의 위협이 움직입니다</span>
        </div> : null}
        {playable && snapshot.progress.keepsakeFound && !snapshot.progress.keepsakeSecured ? <span className={styles.saveNotice} role="status">{snapshot.area === 'staffroom' ? '메모' : snapshot.area === 'gymnasium' ? '훈련 기록' : snapshot.area === 'rooftop' ? '쪽지' : '책갈피'}를 챙겼습니다 · 기억 지점으로 가져오세요</span> : null}
        {saveNotice ? <span className={styles.saveNotice} role="status">{saveNotice}</span> : null}
        {playable && snapshot.progress.inWater && snapshot.progress.activeWaterIds.length > 0 ? <span className={styles.waterHint} role="status">젖은 바닥 · 이동 느려짐</span> : null}
        {boss ? <div className={styles.bossHealth} role="progressbar" aria-label={snapshot.area === 'staffroom' ? '민은지' : snapshot.area === 'library' || snapshot.area === 'rooftop' ? '윤귀남' : snapshot.area === 'broadcast' ? '홍대원' : snapshot.area === 'science' ? '첫 감염자' : snapshot.area === 'classroom' ? '강진구' : '급식실의 위협'} aria-valuemin={0} aria-valuemax={boss.maxHp} aria-valuenow={boss.hp}><span style={{ width: `${boss.hp / boss.maxHp * 100}%` }} /></div> : null}
        {guidance ? <p className={styles.bossHint} data-combat-guidance={fireHint ? 'fire' : 'boss'} role={fireHint ? 'status' : undefined}
          data-boss-hint={fireHint ? undefined : boss?.rooftopBeat ?? boss?.staffroomBeat ?? boss?.libraryBeat ?? boss?.broadcastBeat ?? boss?.classroomBeat ?? boss?.comboBeat}>{guidance}</p> : null}
      </div>
      <div className={styles.vitals}>
        <div className={styles.health} role="progressbar" aria-label="체력" aria-valuemin={0} aria-valuemax={snapshot.player.maxHp} aria-valuenow={snapshot.player.hp}>
          <div className={styles.healthPips} aria-hidden="true">{Array.from({ length: snapshot.player.maxHp }, (_, index) => <span key={index} data-filled={index < snapshot.player.hp} />)}</div>
          <span>{snapshot.player.hp}<small> / {snapshot.player.maxHp}</small></span>
        </div>
        {playable && snapshot.difficulty === 'relaxed' && snapshot.player.hp < snapshot.player.maxHp
          && snapshot.recoveryIn != null && Number.isFinite(snapshot.recoveryIn)
          ? <span className={styles.recoveryHint} data-combat-recovery>피해를 피하면 회복 · {Math.ceil(snapshot.recoveryIn)}초</span> : null}
        <div className={styles.weapon} data-upgraded={snapshot.bow.level > 1}><BowIcon /><span>양궁부 활</span><b aria-label={`활 ${snapshot.bow.level}단계`}>{BOW_LEVELS[snapshot.bow.level]}</b></div>
        <div className={styles.weaponStats}><span>위력 {snapshot.bow.damage}</span><span>{snapshot.bow.interval.toFixed(2)}초 / 발</span>{snapshot.bow.penetration ? <span aria-label={snapshot.progress.tipReinforced ? `화살촉 보강 · 추가 관통 ${snapshot.bow.penetration}명` : undefined}>관통 +{snapshot.bow.penetration}</span> : null}{snapshot.bow.projectileSpeed ? <span>시위 보강</span> : null}</div>
      </div>
    </> : null}
    {playable ? <>
      <NavigationMap snapshot={snapshot} onExpand={toggleMapFromButton} expandRef={mapTrigger} />
      <button type="button" className={styles.pauseButton} onClick={pause} aria-label="일시정지"><span aria-hidden="true">Ⅱ</span></button>
      <div className={styles.desktopHint}><span>WASD 이동</span><span>J / Space 자동 조준</span><span>마우스 조준 사격</span><span>Shift 대시</span><span>M 지도</span></div>
      <div className={styles.touchControls}>
        <Joystick input={input} />
        <button type="button" className={styles.dashButton} data-action="dash" aria-label="대시"
          onPointerDown={(event) => { if (event.button === 0) { event.preventDefault(); input.pressDash(); } }}
          onClick={(event) => { if (event.detail === 0) input.pressDash(); }}><span aria-hidden="true">↗</span><small>대시</small></button>
        <FireButton input={input} />
      </div>
      {snapshot.interaction ? <button type="button" className={styles.interaction} data-action="interact"
        onPointerDown={(event) => { if (event.button === 0) { event.preventDefault(); input.pressInteract(); } }}
        onClick={(event) => { if (event.detail === 0) input.pressInteract(); }}><kbd>E</kbd> {interactionLabel(snapshot)}</button> : null}
    </> : null}
    {!started || !loaded ? <Menu key={loaded ? 'start' : 'loading'} title={'활을 들고,\n길을 여세요.'} overview={<>
      <p className={styles.intro}>{hasSave ? '남겨 둔 기억에서 탐험을 이어갑니다.' : '과학실에서 시작된 흔적을 따라, 학교에 남겨진 기억을 찾으세요.'}</p>
      <ol className={styles.steps}>
        <li><b>이동</b><span>WASD / 방향키 · 왼쪽 조이스틱</span></li>
        <li><b>누르고 사격</b><span>J / Space 자동 조준 · 마우스 위치 조준</span></li>
        <li><b>길을 열고 강화</b><span>장비·보급품·빗장 가까이에서 E · M 지도</span></li>
      </ol>
      {loaded ? <p className={styles.restartNote}>{temporary ? '이번 탐험은 저장되지 않습니다. 이 탭을 닫으면 진행이 사라집니다.' : saveUnavailable ? '기억을 저장하지 못했습니다. 탐험은 계속할 수 있지만 이 탭을 닫으면 마지막 저장 이후 진행이 사라질 수 있습니다.' : '복도의 기억 지점을 지나면 자동으로 기록됩니다. 쓰러져도 강화와 열린 길은 남습니다.'}</p> : null}
    </>}>
      {loaded && onChangeDifficulty ? <DifficultyChoice value={snapshot.difficulty ?? 'standard'} onChange={onChangeDifficulty} unavailable={difficultyUnavailable} /> : null}
      <button type="button" data-menu-primary className={styles.primaryButton} disabled={!loaded} onClick={() => { input.reset(); onStart(); }}>{loaded ? hasSave ? snapshot.progress.anchorReached ? '기억 지점에서 이어하기' : '탐험 이어하기' : '탐험 시작' : '학교를 불러오는 중…'}</button>
      <div className={styles.menuSecondary}>
      {loaded ? <button type="button" className={styles.secondaryButton} aria-pressed={muted} onClick={onToggleSound}>{muted ? '소리 켜기' : '소리 끄기'}</button> : null}
      {loaded && hasSave ? <button type="button" className={styles.secondaryButton} onClick={restart}>처음부터 시작</button> : null}
      </div>
      {loaded && hasSave ? <p className={styles.restartNote}>처음부터 시작하면 저장한 기억과 활 강화가 지워집니다.</p> : null}
      {!loaded ? <p className={styles.loading} role="status">공간과 인물을 준비하고 있습니다.</p> : null}
    </Menu> : completed ? <Menu key="completed" title={`${snapshot?.area === 'staffroom' ? '교무실' : snapshot?.area === 'library' ? '도서관' : snapshot?.area === 'broadcast' ? '방송동' : snapshot?.area === 'classroom' ? '교실' : snapshot?.area === 'science' ? '과학실' : '급식실'}의 기억을 되찾았습니다`}>
      <p className={styles.intro}>남겨진 기억을 회수하고 출구에 도달했습니다.</p>
      <button type="button" className={styles.primaryButton} onClick={restart}>처음부터 시작</button>
      <p className={styles.restartNote}>{temporary ? '이 화면의 탐험을 처음부터 시작합니다.' : '처음부터 시작하면 저장한 기억과 활 강화가 지워집니다.'}</p>
    </Menu> : mapOpen && snapshot ? <Menu key="map" title="지나온 길" wide restoreFocus={restoreMapFocus}>
      <p className={styles.mapObjective}>{objectiveLabel(snapshot)}</p>
      <NavigationMap snapshot={snapshot} surface="full" route={mapRoute} routeVisible={routeVisible} onToggleRoute={onToggleRoute} />
      <button type="button" className={styles.primaryButton} onClick={onToggleMap}>지도 닫기 <small>M / Esc</small></button>
    </Menu> : paused ? <Menu key="paused" title="잠시 숨을 고르세요" overview={<>
      {onChangeDifficulty ? <DifficultyChoice value={snapshot.difficulty ?? 'standard'} onChange={onChangeDifficulty} unavailable={difficultyUnavailable} /> : null}
      <p className={styles.restartNote}>{temporary ? '이번 탐험은 저장되지 않습니다. 이 탭을 닫으면 진행이 사라집니다.' : saveUnavailable ? '기억을 저장하지 못했습니다. 탐험은 계속할 수 있지만 이 탭을 닫으면 마지막 저장 이후 진행이 사라질 수 있습니다.' : snapshot?.progress.anchorReached ? snapshot.area === 'rooftop' ? '쓰러지면 옥상 중간 대피참의 기억 지점으로 돌아갑니다.' : snapshot.area === 'gymnasium' ? '쓰러지면 체육 장비실의 기억 지점으로 돌아갑니다.' : snapshot.area === 'staffroom' ? '쓰러지면 방화구획 통로의 기억 지점으로 돌아갑니다.' : snapshot.area === 'broadcast' ? '쓰러지면 계단참의 기억 지점으로 돌아갑니다.' : '쓰러지면 복도 쉼터의 기억 지점으로 돌아갑니다.' : '복도의 기억 지점을 지나면 자동으로 기록됩니다.'}</p>
    </>}>
      <button type="button" data-menu-primary className={styles.primaryButton} onClick={pause}>계속하기</button>
      <button type="button" className={styles.secondaryButton} aria-pressed={muted} onClick={onToggleSound}>{muted ? '소리 켜기' : '소리 끄기'}</button>
      {!inStory && !inReunion && <button type="button" className={styles.secondaryButton} onClick={toggleMapFromButton}>지도 살펴보기</button>}
      <button type="button" className={styles.secondaryButton} onClick={restart}>처음부터 시작</button>
      <p className={styles.restartNote}>{temporary ? '이 화면의 탐험을 처음부터 시작합니다.' : '처음부터 시작하면 저장한 기억과 활 강화가 지워집니다.'}</p>
    </Menu> : inStory && snapshot?.story ? <StoryCutscene key={snapshot.story.id} story={snapshot.story} onAdvance={(action) => { input.reset(); onAdvanceStory?.(action); }} onPause={pause} /> : inReunion && snapshot?.ending ? <ReunionDialogue ending={snapshot.ending} onAdvance={(action) => { input.reset(); onAdvanceEnding?.(action); }} onPause={pause} /> : defeated ? <div className={styles.defeat} role="status"><strong>잠시 기억이 흐려집니다</strong><span>{snapshot?.progress.anchorReached ? snapshot.area === 'rooftop' ? '옥상 중간 대피참에 남긴 기억으로 돌아갑니다.' : snapshot.area === 'gymnasium' ? '체육 장비실에 남긴 기억으로 돌아갑니다.' : snapshot.area === 'staffroom' ? '방화구획 통로에 남긴 기억으로 돌아갑니다.' : snapshot.area === 'broadcast' ? '계단참에 남긴 기억으로 돌아갑니다.' : '복도 쉼터에 남긴 기억으로 돌아갑니다.' : snapshot?.area === 'rooftop' ? '체육관 옆 옥상 계단 입구에서 다시 일어납니다.' : snapshot?.area === 'gymnasium' ? '체육관 전실에서 다시 일어납니다.' : snapshot?.area === 'staffroom' ? '교무실 앞에서 다시 일어납니다.' : snapshot?.area === 'broadcast' ? '방송동 입구에서 다시 일어납니다.' : snapshot?.area === 'science' ? '과학실에서 다시 일어납니다.' : snapshot?.area === 'classroom' ? '교실 앞에서 다시 일어납니다.' : '보건실에서 다시 일어납니다.'}</span><span>활 강화와 발견한 길은 남아 있습니다.</span></div> : null}
  </div>;
}
