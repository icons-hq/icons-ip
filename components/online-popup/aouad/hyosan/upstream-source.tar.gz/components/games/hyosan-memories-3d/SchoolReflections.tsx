'use client';

import { useLayoutEffect } from 'react';
import { useThree } from '@react-three/fiber';
import { InstancedMesh, PMREMGenerator, type Scene, type WebGLRenderer, type WebGLRenderTarget } from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';

function installSchoolReflections(gl: WebGLRenderer, scene: Scene) {
  const previousEnvironment = scene.environment;
  const previousIntensity = scene.environmentIntensity;
  const previousTarget = gl.getRenderTarget();
  const previousCubeFace = gl.getActiveCubeFace();
  const previousMipmap = gl.getActiveMipmapLevel();
  const previousXrEnabled = gl.xr.enabled;
  const previousAutoClear = gl.autoClear;
  const previousToneMapping = gl.toneMapping;
  const room = new RoomEnvironment();
  const generator = new PMREMGenerator(gl);
  let target: WebGLRenderTarget;
  try {
    target = generator.fromScene(room, .04, .1, 100, { size: 128 });
  } catch (error) {
    console.warn('School reflection generation failed; keeping the existing environment.', error);
    return;
  } finally {
    // Three restores these only after a successful fromScene render.
    gl.setRenderTarget(previousTarget, previousCubeFace, previousMipmap);
    gl.xr.enabled = previousXrEnabled;
    gl.autoClear = previousAutoClear;
    gl.toneMapping = previousToneMapping;
    // RoomEnvironment.dispose owns the shared geometry/materials but omits
    // InstancedMesh's instance buffers in Three 0.185.1.
    room.traverse((node) => { if (node instanceof InstancedMesh) node.dispose(); });
    room.dispose();
    generator.dispose();
  }
  scene.environment = target.texture;
  scene.environmentIntensity = .06;
  return () => {
    scene.environment = previousEnvironment;
    scene.environmentIntensity = previousIntensity;
    target.dispose();
  };
}

/** A local indoor reflection source, installed before the scene's passive shader preparation. */
export function SchoolReflections() {
  const { gl, scene } = useThree();
  useLayoutEffect(() => installSchoolReflections(gl, scene), [gl, scene]);
  return null;
}
