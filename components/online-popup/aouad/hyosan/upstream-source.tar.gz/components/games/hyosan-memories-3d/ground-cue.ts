import { BufferAttribute, BufferGeometry, Matrix4, Mesh, RingGeometry, Vector3 } from 'three';
import layout from '@/docs/games/hyosan-memories-3d/world-layout.json';
import { createHyosanSupportGeometry, type HyosanSupportPoint } from '@/lib/games/hyosan-memories-3d/support-geometry';

const surfaces = createHyosanSupportGeometry(layout);
const rest = new WeakMap<BufferGeometry, {
  positions: Float32Array; indices: Uint32Array; worldPositions: Float64Array; supported: Uint8Array;
}>();
const coneAngles = new WeakMap<RingGeometry, number>();
const maxSlopeSquared = Math.tan(Math.PI * 35 / 180) ** 2;
const point = new Vector3();
const inverse = new Matrix4();
export const hyosanGroundCueHeight = (position: HyosanSupportPoint) => (surfaces.sample(position)?.height ?? position.y ?? 0) + .04;
export const hyosanGroundNormal = (position: HyosanSupportPoint) => {
  const sample = surfaces.sample(position);
  return new Vector3(-(sample?.slopeX ?? 0), 1, -(sample?.slopeZ ?? 0)).normalize();
};

/** Keep R3F's geometry ownership stable when a boss switches between two cone widths. */
export function setHyosanGroundCueAngle(mesh: Mesh<RingGeometry>, halfAngle: number) {
  const geometry = mesh.geometry; const params = geometry.parameters;
  if (Math.abs((coneAngles.get(geometry) ?? params.thetaLength / 2) - halfAngle) < 1e-6) return;
  const previous = rest.get(geometry);
  if (previous) {
    geometry.index!.array.set(previous.indices);
    geometry.index!.needsUpdate = true;
    geometry.setDrawRange(0, previous.indices.length);
  }
  coneAngles.set(geometry, halfAngle);
  const start = -Math.PI / 2 - halfAngle; const length = 2 * halfAngle;
  const position = geometry.getAttribute('position');
  for (let ring = 0; ring <= params.phiSegments; ring++) {
    const radius = params.innerRadius + (params.outerRadius - params.innerRadius) * ring / params.phiSegments;
    for (let segment = 0; segment <= params.thetaSegments; segment++) {
      const angle = start + length * segment / params.thetaSegments;
      position.setXYZ(ring * (params.thetaSegments + 1) + segment, radius * Math.cos(angle), radius * Math.sin(angle), 0);
    }
  }
  position.needsUpdate = true;
  rest.delete(geometry);
}

/** Telegraph vertices follow the same deck and ramps as the collision surface. */
export function conformHyosanGroundCue(mesh: Mesh, currentLayerId?: string) {
  const position = mesh.geometry.getAttribute('position');
  let original = rest.get(mesh.geometry);
  if (!original) {
    if (!mesh.geometry.index) mesh.geometry.setIndex(new BufferAttribute(
      Uint32Array.from({ length: position.count }, (_, index) => index), 1));
    original = { positions: new Float32Array(position.array), indices: new Uint32Array(mesh.geometry.index!.array),
      worldPositions: new Float64Array(position.count * 3), supported: new Uint8Array(position.count) };
    rest.set(mesh.geometry, original);
  }
  mesh.updateWorldMatrix(true, false);
  inverse.copy(mesh.matrixWorld).invert();
  for (let index = 0; index < position.count; index++) {
    point.fromArray(original.positions, index * 3);
    point.applyMatrix4(mesh.matrixWorld);
    const support = surfaces.sample({ x: point.x, y: point.y, z: point.z, currentLayerId });
    original.supported[index] = support ? 1 : 0;
    point.y = (support?.height ?? point.y) + .04;
    point.toArray(original.worldPositions, index * 3);
    point.applyMatrix4(inverse);
    position.setXYZ(index, point.x, point.y, point.z);
  }
  const { indices, worldPositions } = original;
  const rendered = mesh.geometry.index!;
  let count = 0;
  for (let index = 0; index < indices.length; index += 3) {
    if (!original.supported[indices[index]] || !original.supported[indices[index + 1]] || !original.supported[indices[index + 2]]) continue;
    const a = indices[index] * 3; const b = indices[index + 1] * 3; const c = indices[index + 2] * 3;
    const abX = worldPositions[b] - worldPositions[a]; const acX = worldPositions[c] - worldPositions[a];
    const abY = worldPositions[b + 1] - worldPositions[a + 1]; const acY = worldPositions[c + 1] - worldPositions[a + 1];
    const abZ = worldPositions[b + 2] - worldPositions[a + 2]; const acZ = worldPositions[c + 2] - worldPositions[a + 2];
    const nx = abY * acZ - abZ * acY; const ny = abZ * acX - abX * acZ; const nz = abX * acY - abY * acX;
    // Preserve climbable slopes, but never stretch a warning down a cliff.
    // Rebuild from cached source indices so previously omitted faces return.
    if (nx * nx + nz * nz > ny * ny * maxSlopeSquared + 1e-16) continue;
    rendered.setX(count++, indices[index]);
    rendered.setX(count++, indices[index + 1]);
    rendered.setX(count++, indices[index + 2]);
  }
  mesh.geometry.setDrawRange(0, count);
  rendered.needsUpdate = true;
  position.needsUpdate = true;
  // The deformed warning can cross the source plane's zero-height bounds.
  mesh.frustumCulled = false;
}
