import { Mesh, type Material, type Object3D } from 'three';
import layout from '@/docs/games/hyosan-memories-3d/world-layout.json';
import type { Hyosan3DSnapshot } from '@/lib/games/hyosan-memories-3d/types';

/** Decorative bodies never enter the simulation, targeting or collision lists. */
export function createGalleryPresentation(object: Object3D) {
  const source = layout.adventure.inflow;
  const gallery = layout.floors.find(({ id }) => id === source.galleryFloorId)!;
  const required = (name: string) => {
    const node = object.getObjectByName(name);
    if (!node) throw new Error(`Missing Hyosan gallery assembly ${name}`);
    return node;
  };
  const canopy = required(source.canopy.id);
  const upperWalls = source.cutawayWallIds.map((id) => required(`${id}-upper`));
  const cutawayMaterials = new Map<Material, Material>();
  for (const wall of upperWalls) wall.traverse((node) => {
    if (!(node instanceof Mesh)) return;
    const copy = (material: Material) => {
      let clone = cutawayMaterials.get(material);
      if (!clone) {
        clone = material.clone();
        // Keep the shader mode ready before play; only opacity/depth state
        // changes on entry. Other school walls retain their own materials.
        clone.transparent = true;
        cutawayMaterials.set(material, clone);
      }
      return clone;
    };
    node.material = Array.isArray(node.material) ? node.material.map(copy) : copy(node.material);
  });
  const crowd = source.pressureStrip.decorativeCrowd.map(({ id, yaw }, index) => {
    const node = required(`crowd-pressure-${id}`);
    node.traverse((child) => { if (child instanceof Mesh) child.castShadow = false; });
    return { node, index, x: node.position.x, z: node.position.z, yaw };
  });
  object.traverse((node) => {
    if (!(node instanceof Mesh)) return;
    const materials = Array.isArray(node.material) ? node.material : [node.material];
    if (!materials.some((material) => material.name === 'arrival_fixed_glass')) return;
    node.castShadow = false;
    node.receiveShadow = false;
    for (const material of materials) {
      material.transparent = true;
      material.opacity = .24;
      material.depthWrite = false;
    }
  });
  let lastTime = -1;
  let incidentStart: number | null = null;
  let motionTime = 0;
  let disposed = false;
  return {
    update(snapshot: Hyosan3DSnapshot) {
      if (disposed) return;
      const cutaway = Math.abs(snapshot.player.x - gallery.x) <= gallery.width / 2
        && Math.abs(snapshot.player.z - gallery.z) <= gallery.depth / 2;
      canopy.visible = !cutaway;
      for (const material of cutawayMaterials.values()) {
        material.opacity = cutaway ? .16 : 1;
        material.depthWrite = !cutaway;
      }
      for (const wall of upperWalls) wall.traverse((node) => {
        if (node instanceof Mesh) node.castShadow = !cutaway;
      });
      if (snapshot.time < lastTime || !snapshot.progress.incidentTriggered) {
        incidentStart = null;
        motionTime = 0;
      }
      if (snapshot.progress.incidentTriggered) {
        incidentStart ??= snapshot.time;
        if (!snapshot.progress.bossDefeated && !snapshot.paused) motionTime = snapshot.time - incidentStart;
      }
      const moving = incidentStart !== null;
      for (const { node, index, x, z, yaw } of crowd) {
        const wave = moving ? Math.sin(motionTime * 2.4 + index * .73) : 0;
        node.position.x = x + wave * .018;
        node.position.z = z + wave * .008;
        node.rotation.set(0, yaw + wave * .025, 0);
      }
      lastTime = snapshot.time;
    },
    dispose() {
      if (disposed) return;
      disposed = true;
      for (const material of cutawayMaterials.values()) material.dispose();
    },
  };
}
