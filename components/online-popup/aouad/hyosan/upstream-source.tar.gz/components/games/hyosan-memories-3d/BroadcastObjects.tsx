'use client';
import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import type { Group, Mesh } from 'three';
import layout from '@/docs/games/hyosan-memories-3d/world-layout.json';
import type { Hyosan3DPlayRuntime } from '@/lib/games/hyosan-memories-3d/types';

const plan = layout.broadcast;
/** Interaction objects sit on the same upper, middle and lower surfaces as play. */
export function BroadcastObjects({ simulation }: { simulation: Hyosan3DPlayRuntime }) {
  const supply = useRef<Group>(null); const echo = useRef<Group>(null);
  const consoleCue = useRef<Mesh>(null); const hoseCue = useRef<Mesh>(null);
  useFrame(() => {
    const state = simulation.read();
    const progress = state.area === 'broadcast' ? state.progress : state.schoolState?.broadcast;
    if (supply.current) supply.current.visible = !progress?.supplyTaken;
    if (echo.current) echo.current.visible = Boolean(progress && !progress.areaResolved && progress.bossDefeated && !progress.echoCollected);
    if (consoleCue.current) consoleCue.current.visible = state.area === 'broadcast' && !progress?.consoleInspected;
    if (hoseCue.current) hoseCue.current.visible = state.area === 'broadcast' && !progress?.hoseSecured;
  });
  return <group>
    <group ref={supply} position={[plan.supply.x, plan.supply.y + .12, plan.supply.z]}>
      <mesh castShadow><boxGeometry args={[.42, .2, .3]} /><meshStandardMaterial color="#d5d9ce" roughness={.7} /></mesh>
      <mesh position={[0, .105, 0]}><boxGeometry args={[.06, .012, .19]} /><meshStandardMaterial color="#3e7561" /></mesh>
      <mesh position={[0, .106, 0]}><boxGeometry args={[.18, .012, .06]} /><meshStandardMaterial color="#3e7561" /></mesh>
    </group>
    <group position={[plan.checkpoint.x, plan.checkpoint.y + .035, plan.checkpoint.z]}>
      <mesh castShadow><boxGeometry args={[.26, .045, .18]} /><meshStandardMaterial color="#9caa95" roughness={.8} /></mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]}><ringGeometry args={[.38, .405, 40]} /><meshBasicMaterial color="#a8d9b8" transparent opacity={.65} depthWrite={false} /></mesh>
    </group>
    <mesh ref={consoleCue} visible={false} position={[plan.console.x, plan.console.y + .03, plan.console.z]} rotation={[-Math.PI / 2, 0, 0]}>
      <ringGeometry args={[.33, .36, 40]} /><meshBasicMaterial color="#e4c88e" transparent opacity={.55} depthWrite={false} />
    </mesh>
    <mesh ref={hoseCue} visible={false} position={[plan.hose.interactPoint.x, plan.hose.interactPoint.y + .03, plan.hose.interactPoint.z]} rotation={[-Math.PI / 2, 0, 0]}>
      <ringGeometry args={[.38, .42, 40]} /><meshBasicMaterial color="#e4c88e" transparent opacity={.55} depthWrite={false} />
    </mesh>
    <group ref={echo} visible={false} position={[plan.echo.x, plan.echo.y + .04, plan.echo.z]}>
      <mesh castShadow><boxGeometry args={[.24, .05, .16]} /><meshStandardMaterial color="#bdab84" roughness={.9} /></mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]}><ringGeometry args={[.52, .56, 48]} /><meshBasicMaterial color="#f0d0a0" transparent opacity={.8} depthWrite={false} /></mesh>
    </group>
  </group>;
}
