import { Vector3, type DirectionalLight } from 'three';

const offset = new Vector3(-8, 18, -13);
const right = new Vector3(0, 1, 0).cross(offset).normalize();
const up = offset.clone().normalize().cross(right);

/** Keep static school geometry on the same shadow texels as the camera follows. */
export function positionSchoolSun(light: DirectionalLight, center: Vector3) {
  const { camera, mapSize } = light.shadow;
  const width = (camera.right - camera.left) / camera.zoom / mapSize.x;
  const height = (camera.top - camera.bottom) / camera.zoom / mapSize.y;
  const x = center.dot(right); const y = center.dot(up);
  const dx = Math.round(x / width) * width - x;
  const dy = Math.round(y / height) * height - y;
  light.target.position.copy(center).addScaledVector(right, dx).addScaledVector(up, dy);
  light.position.copy(light.target.position).add(offset);
  light.target.updateMatrixWorld();
}
