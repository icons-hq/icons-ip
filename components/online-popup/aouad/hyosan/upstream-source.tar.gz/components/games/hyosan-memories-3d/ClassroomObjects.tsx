'use client';
import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import type { Group, Mesh } from 'three';
import layout from '@/docs/games/hyosan-memories-3d/world-layout.json';
import type { Hyosan3DPlayRuntime } from '@/lib/games/hyosan-memories-3d/types';
import { BowCase } from './AdventureObjects';

const plan = layout.classroom;
/** Landmarks share the simulation's actual approach points and durable progress. */
export function ClassroomObjects({ simulation }: { simulation: Hyosan3DPlayRuntime }) {
  const kit = useRef<Group>(null); const echo = useRef<Group>(null); const push = useRef<Mesh>(null);
  useFrame(() => {
    const state = simulation.read();
    const progress = state.area === 'classroom' ? state.progress : state.schoolState?.classroom;
    if (kit.current) kit.current.visible = !progress?.piercingCollected;
    if (echo.current) echo.current.visible = Boolean(progress && !progress.areaResolved && progress.bossDefeated && !progress.echoCollected);
    if (push.current) push.current.visible = state.area === 'classroom' && !progress?.barricadeReleased;
  });
  return <group>
    <group ref={kit} position={[plan.upgrade.x, .095, plan.upgrade.z]}><BowCase /></group>
    <group position={[plan.checkpoint.x, .026, plan.checkpoint.z]}>
      <mesh castShadow><boxGeometry args={[.26, .04, .18]} /><meshStandardMaterial color="#9caa95" roughness={.8} /></mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]}><ringGeometry args={[.38, .405, 40]} /><meshBasicMaterial color="#a8d9b8" transparent opacity={.65} depthWrite={false} /></mesh>
    </group>
    <mesh ref={push} visible={false} position={[plan.barricade.interactPoint.x, .026, plan.barricade.interactPoint.z]} rotation={[-Math.PI / 2, 0, 0]}>
      <ringGeometry args={[.38, .42, 40]} /><meshBasicMaterial color="#e4c88e" transparent opacity={.55} depthWrite={false} />
    </mesh>
    <group ref={echo} visible={false} position={[plan.echo.x, .035, plan.echo.z]}>
      <mesh castShadow><boxGeometry args={[.3, .035, .23]} /><meshStandardMaterial color="#d7c598" roughness={.9} /></mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]}><ringGeometry args={[.52, .56, 48]} /><meshBasicMaterial color="#f0d0a0" transparent opacity={.8} depthWrite={false} /></mesh>
    </group>
  </group>;
}
