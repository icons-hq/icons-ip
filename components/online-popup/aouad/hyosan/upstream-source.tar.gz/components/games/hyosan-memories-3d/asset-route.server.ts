import 'server-only';
import { readFile, stat } from 'node:fs/promises';
import path from 'node:path';
import { promisify } from 'node:util';
import { brotliCompress, constants, gzip } from 'node:zlib';

const compressBrotli = promisify(brotliCompress);
const compressGzip = promisify(gzip);

type Encoding = 'br' | 'gzip' | 'identity';

/** Explicit exclusions override wildcard preferences (RFC 9110 §12.5.3). */
function preferredEncoding(header: string | null): Encoding | null {
  const weights = new Map<string, number>();
  for (const entry of (header ?? '').split(',')) {
    const [name, ...parameters] = entry.toLowerCase().trim().split(/\s*;\s*/);
    const quality = parameters.find((parameter) => parameter.startsWith('q='))?.slice(2) ?? '1';
    const weight = /^(?:0(?:\.\d{0,3})?|1(?:\.0{0,3})?)$/.test(quality) ? Number(quality) : 0;
    weights.set(name, Math.max(weights.get(name) ?? 0, weight));
  }
  const choices: Encoding[] = ['br', 'gzip', 'identity'];
  const quality = (encoding: Encoding) => weights.get(encoding) ?? (encoding === 'identity' ? 0 : weights.get('*') ?? 0);
  choices.sort((a, b) => quality(b) - quality(a));
  if (quality(choices[0]) > 0) return choices[0];
  // Identity needs no opt-in, except when explicitly rejected or covered by *;q=0.
  return (weights.get('identity') ?? (weights.get('*') === 0 ? 0 : 1)) > 0 ? 'identity' : null;
}

const cacheLimit = 32 * 1024 * 1024;
type CachedAsset = { version: string; bytes: number; result: Promise<Uint8Array<ArrayBuffer>> };
const compressedAssets = new Map<string, CachedAsset>();
let cachedBytes = 0;

function evict(key: string) {
  cachedBytes -= compressedAssets.get(key)?.bytes ?? 0;
  compressedAssets.delete(key);
}

async function encodedAsset(file: string, encoding: Exclude<Encoding, 'identity'>) {
  const source = await stat(file, { bigint: true });
  const version = `${source.ino}:${source.size}:${source.mtimeNs}:${source.ctimeNs}`;
  const key = `${file}:${encoding}`;
  const cached = compressedAssets.get(key);
  if (cached?.version === version) {
    compressedAssets.delete(key);
    compressedAssets.set(key, cached);
    return cached.result;
  }
  evict(key);
  const result = readFile(file).then((bytes) => encoding === 'br'
    ? compressBrotli(bytes, { params: { [constants.BROTLI_PARAM_QUALITY]: 6 } })
    : compressGzip(bytes));
  const entry: CachedAsset = { version, bytes: 0, result };
  compressedAssets.set(key, entry);
  try {
    const bytes = await result;
    // A newer file version may have replaced this pending compression already.
    if (compressedAssets.get(key) === entry) {
      entry.bytes = bytes.byteLength;
      cachedBytes += entry.bytes;
      while (cachedBytes > cacheLimit) evict(compressedAssets.keys().next().value!);
    }
    return bytes;
  } catch (error) {
    if (compressedAssets.get(key) === entry) evict(key);
    throw error;
  }
}

const assets = {
  'hyosan-opening.webp': 'story/hyosan-opening.webp',
  'hyosan-music-memory.webp': 'story/hyosan-music-memory.webp',
  'school-environment.glb': 'environment/s2-serving-kitchen/school-environment.glb',
  'school-surroundings.glb': 'environment/surroundings/school-surroundings.glb',
  'science-dressing.glb': 'environment/science-dressing/science-dressing.glb',
  'namra.glb': 'character/hyosan-namra-reunion.glb',
  'student.glb': 'character/archery/hyosan-student.glb',
  'zombie.glb': 'character/tailoring/hyosan-student-zombie.glb',
  'eunji.glb': 'character/hyosan-eunji.glb',
  'hyunju.glb': 'character/hyosan-hyunju.glb',
  'jingu.glb': 'character/hyosan-jingu.glb',
  'gwinam-human.glb': 'character/hyosan-gwinam-human.glb',
  'gwinam-halfbie.glb': 'character/hyosan-gwinam-halfbie.glb',
  'daewon.glb': 'character/hyosan-daewon.glb',
  'nurse.glb': 'character/hyosan-nurse-boss.glb',
} as const;

/** This module is absent from the production import graph via next.config alias. */
export async function GET(request: Request, context: { params: Promise<{ asset: string }> }) {
  const { asset } = await context.params;
  if (!Object.hasOwn(assets, asset)) return new Response(null, { status: 404 });
  const headers = new Headers({ 'Content-Type': asset.endsWith('.webp') ? 'image/webp' : 'model/gltf-binary', 'Cache-Control': 'no-store', Vary: 'Accept-Encoding' });
  const encoding = preferredEncoding(request.headers.get('Accept-Encoding'));
  if (encoding === null) return new Response(null, { status: 406, headers });
  const file = path.join(process.cwd(), 'docs/games/hyosan-memories-3d/assets', assets[asset as keyof typeof assets]);
  if (encoding !== 'identity') {
    headers.set('Content-Encoding', encoding);
    const encoded = await encodedAsset(file, encoding);
    return new Response(encoded, { headers });
  }
  return new Response(await readFile(file), { headers });
}
