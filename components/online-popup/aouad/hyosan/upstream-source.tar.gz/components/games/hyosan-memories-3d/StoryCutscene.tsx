'use client';

import { useEffect, useId, useRef, useState } from 'react';
import { HYOSAN_STORIES } from '@/lib/games/hyosan-memories-3d/story';
import type { Hyosan3DStory } from '@/lib/games/hyosan-memories-3d/types';
import styles from './StoryCutscene.module.css';

export function StoryCutscene({ story, onAdvance, onPause }: {
  story: Readonly<Hyosan3DStory>; onAdvance: (action: 'next' | 'skip') => void; onPause: () => void;
}) {
  const panel = useRef<HTMLDivElement>(null);
  const id = useId();
  const [failed, setFailed] = useState(false);
  const scene = HYOSAN_STORIES[story.id]; const page = scene.pages[story.page];
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    panel.current?.focus();
    return () => { if (previous?.isConnected) previous.focus(); };
  }, []);
  return <div ref={panel} className={styles.scene} role="dialog" aria-modal="true" tabIndex={-1}
    aria-labelledby={`${id}-title`} aria-describedby={`${id}-text`} data-story={story.id}
    onKeyDown={(event) => {
      if (event.key !== 'Tab') return;
      const buttons = [...event.currentTarget.querySelectorAll<HTMLButtonElement>('button:not(:disabled)')];
      const first = buttons[0]; const last = buttons.at(-1);
      if (event.shiftKey && (document.activeElement === first || document.activeElement === panel.current)) {
        event.preventDefault(); last?.focus();
      } else if (!event.shiftKey && (document.activeElement === last || document.activeElement === panel.current)) {
        event.preventDefault(); first?.focus();
      }
    }}>
    <div className={styles.art}>
      {/* Local gated artwork is served directly; keep the exact reviewed pixels. */}
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={scene.image} alt={scene.alt} onError={() => setFailed(true)} />
      {failed && <span className={styles.unavailable} role="status">장면 이미지를 불러오지 못했습니다. 이야기는 계속 볼 수 있습니다.</span>}
      <div className={styles.topline}><span>효산의 기억</span><button type="button" onClick={onPause} aria-label="이야기 일시정지">Ⅱ <small>Esc</small></button></div>
    </div>
    <div className={styles.caption}>
      <div className={styles.copy} aria-live="polite" aria-atomic="true">
        <span className={styles.eyebrow}>{scene.label} <span>{story.page + 1} / {scene.pages.length}</span></span>
        <h1 id={`${id}-title`}>{page.title}</h1>
        <p id={`${id}-text`}>{page.text}</p>
      </div>
      <div className={styles.actions}>
        <button type="button" className={styles.next} disabled={story.time < .25} onClick={() => onAdvance('next')}>
          {story.page === scene.pages.length - 1 ? scene.finish : '다음 이야기'} <span aria-hidden="true">→</span>
        </button>
        {story.page < scene.pages.length - 1 && <button type="button" disabled={story.time < .25} onClick={() => onAdvance('skip')}>이야기 건너뛰기</button>}
      </div>
    </div>
  </div>;
}
