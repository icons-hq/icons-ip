import { Box3, Ray, Vector3 } from 'three';
import type { Hyosan3DEnemy, Hyosan3DPlayer } from '@/lib/games/hyosan-memories-3d/types';

const ray = new Ray();
const direction = new Vector3();
const origin = new Vector3();
const hit = new Vector3();
const padded = new Box3();
export interface LibraryCutaway {
  name: string;
  bounds: { minX: number; maxX: number; minZ: number; maxZ: number };
  box: Box3;
}

/** Open foreground geometry around the player's feet, body and nearby live threats. */
export function libraryCutawayVisible(group: LibraryCutaway, player: Readonly<Hyosan3DPlayer>, cameraDirection: Vector3,
  enemies: readonly Hyosan3DEnemy[] = []) {
  if (group.name === 'library-archive-roof') {
    const b = group.bounds;
    return player.y < -1.5 && player.x > b.minX && player.x < b.maxX && player.z > b.minZ && player.z < b.maxZ;
  }
  if (group.name === `library-ramp-${player.surfaceId}`) return false;
  // Keep the platform solid under actors walking on its upper face.
  if (group.box.max.y <= player.y + .12) return false;
  direction.copy(cameraDirection).negate().normalize();
  padded.copy(group.box).expandByScalar(.22);
  const occludes = (x: number, y: number, z: number) => {
    origin.set(x, y, z);
    ray.set(origin, direction);
    return ray.intersectBox(padded, hit) !== null && hit.distanceTo(origin) < 12;
  };
  if ([.12, .65, 1.5].some((height) => occludes(player.x, player.y + height, player.z))) return true;
  // A small walkable neighbourhood remains legible before moving into it.
  if ([[.85, 0], [-.85, 0], [0, .85], [0, -.85]].some(([x, z]) => occludes(player.x + x, player.y + .12, player.z + z))) return true;
  return enemies.some((enemy) => enemy.hp > 0 && !enemy.dormant && enemy.currentLayerId === player.currentLayerId
    && Math.hypot(enemy.x - player.x, enemy.z - player.z) <= 4
    && [.15, 1].some((height) => occludes(enemy.x, enemy.y + height, enemy.z)));
}
