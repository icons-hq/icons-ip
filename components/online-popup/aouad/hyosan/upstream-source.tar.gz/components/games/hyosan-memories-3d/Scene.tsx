'use client';
import { HYOSAN_REUNION, reunionPlaying } from '@/lib/games/hyosan-memories-3d/ending';
import { RooftopReunion } from './RooftopReunion';
import { cafeteriaPresentation } from './school-presentation';

import { useEffect, useMemo, useRef, type RefObject } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { useGLTF } from '@react-three/drei';
import * as THREE from 'three';
import layout from '@/docs/games/hyosan-memories-3d/world-layout.json';
import type { Hyosan3DPlayRuntime, Hyosan3DSnapshot } from '@/lib/games/hyosan-memories-3d/types';
import Hyosan3DActors from './Actors';
import { createHyosanFlightArrow } from './archery-equipment';
import type { Hyosan3DInputController } from './input';
import type { Hyosan3DDiagnostics } from './diagnostics';
import { LightingPass } from './LightingPass';
import { positionSchoolSun } from './school-sun';
import { SchoolReflections } from './SchoolReflections';
import { SchoolSurroundings } from './SchoolSurroundings';
import type { Hyosan3DAudio } from './audio';
import { ScienceObjects } from './ScienceObjects';
import { ScienceDressing } from './ScienceDressing';
import { ClassroomObjects } from './ClassroomObjects';
import { LibraryObjects } from './LibraryObjects';
import { StaffroomObjects } from './StaffroomObjects';
import { GymnasiumObjects } from './GymnasiumObjects';
import { RooftopObjects } from './RooftopObjects';
import { libraryCutawayVisible } from './library-cutaway';
import { BroadcastObjects } from './BroadcastObjects';
import { AdventureObjects, BowCase } from './AdventureObjects';
import { createGalleryPresentation } from './gallery-presentation';
import { createArchitecturePresentation } from './architecture-presentation';
import { createServingKitchenVisibility } from './serving-kitchen-visibility';
import { resolveHyosanPointerAim } from './pointer-aim';
import { conformHyosanGroundCue, setHyosanGroundCueAngle, hyosanGroundCueHeight, hyosanGroundNormal } from './ground-cue';
import { sameHyosanCombatLayer } from '@/lib/games/hyosan-memories-3d/combat-layers';
import { SchoolGround as RenderedSchoolGround } from './SchoolGround';

const CAMERA_OFFSET = new THREE.Vector3(15, 24, 20);
const AZIMUTH = Math.atan2(CAMERA_OFFSET.x, CAMERA_OFFSET.z);
const ASSET_ROOT = '/api/dev/hyosan-3d/';
const DAYLIGHT = { sky: .68, ambient: .08, sun: 1.75 };
const ARROW_TRAIL_POINTS = new Float32Array([0, 0, -1.05, 0, 0, -.18]);

function SchoolGround() {
  return <RenderedSchoolGround cameraOffset={CAMERA_OFFSET} />;
}

function sizeCamera(camera: THREE.Camera, width: number, height: number, scale = 1, blend = 1) {
  const orthographic = camera as THREE.OrthographicCamera;
  const worldWidth = width / height > 1.15 ? Math.min(28, 16 * width / height) : 13;
  orthographic.zoom = THREE.MathUtils.lerp(orthographic.zoom, width / worldWidth * scale, blend);
  orthographic.updateProjectionMatrix();
}

function isServingReflectionMaterial(material: THREE.Material): material is THREE.MeshStandardMaterial {
  return material instanceof THREE.MeshStandardMaterial
    && (material.name.startsWith('cafeteria_counter_') || material.name.startsWith('cafeteria_kitchen_'))
    && material.metalness > 0;
}

function collectServingReflectionMaterials(object: THREE.Object3D) {
  const result = new Set<THREE.MeshStandardMaterial>();
  object.traverse((node) => {
    if (!(node instanceof THREE.Mesh)) return;
    const nodeMaterials = Array.isArray(node.material) ? node.material : [node.material];
    for (const material of nodeMaterials) if (isServingReflectionMaterial(material)) result.add(material);
  });
  return result;
}

export function Environment({ simulation }: { simulation: Hyosan3DPlayRuntime }) {
  const gltf = useGLTF(`${ASSET_ROOT}school-environment.glb`);
  const environment = useMemo(() => {
    const clone = gltf.scene.clone(true);
    const materials = new Map<THREE.Material, THREE.Material>();
    clone.traverse((node) => {
      if (!(node instanceof THREE.Mesh)) return;
      const copy = (source: THREE.Material) => {
        let material = materials.get(source);
        if (!material) {
          material = source.clone();
          if (material instanceof THREE.MeshStandardMaterial && material.name === 'school_olive_tiles') material.roughness = .66;
          if (material instanceof THREE.MeshStandardMaterial && material.name === 'brushed_steel') material.roughness = .62;
          if (material instanceof THREE.MeshStandardMaterial && material.name === 'polished_chrome') material.roughness = .55;
          materials.set(source, material);
        }
        return material;
      };
      node.material = Array.isArray(node.material) ? node.material.map(copy) : copy(node.material);
      const nodeMaterials = Array.isArray(node.material) ? node.material : [node.material];
      const isKitchenGlass = nodeMaterials.some((material) => material.name === 'cafeteria_kitchen_glass');
      node.castShadow = !isKitchenGlass && !node.name.includes('window_daylight') && !node.name.includes('floor');
      node.receiveShadow = !isKitchenGlass;
    });
    const furniture = new Map([...layout.adventure.furniture, layout.science.shortcut, layout.classroom.shortcut, layout.classroom.barricade, layout.broadcast.shortcut, layout.broadcast.hose, layout.library.shortcut, layout.staffroom.shortcut,
      layout.gymnasium.shortcut, layout.gymnasium.coverCart, layout.gymnasium.exitCart, layout.rooftop.shortcut].map(({ id }) => {
      const node = clone.getObjectByName(`dynamic_prop_${id}`);
      if (!node) throw new Error(`Missing dynamic school furniture ${id}`);
      return [id, node] as const;
    }));
    const gallery = createGalleryPresentation(clone);
    const architecture = createArchitecturePresentation(clone);
    gallery.update({ ...simulation.read(), progress: cafeteriaPresentation(simulation.read()) });
    let leases = 0;
    let disposed = false;
    const cutawaySpecs: { name: string; bounds: { minX: number; maxX: number; minZ: number; maxZ: number };
      preserveStagingOcclusion?: boolean; hiddenInPlay?: boolean; preserveSurfacePrefix?: string }[] = [
      ...layout.rooftop.cutawayGroups.map((group) => ({ name: group.node, bounds: group.bounds, preserveSurfacePrefix: group.preserveSurfacePrefix })),
      { name: layout.rooftop.ceilingNode, bounds: { minX: 231.9, maxX: 238.1, minZ: 6, maxZ: 11.1 } },
      { name: layout.science.connectorCutawayNode, bounds: layout.science.connectorCutawayBounds },
      { name: layout.classroom.connectorCutawayNode, bounds: layout.classroom.connectorCutawayBounds },
      { name: layout.classroom.cameraCutawayNode, bounds: layout.classroom.cameraCutawayBounds },
      { name: layout.broadcast.cutawayNode, bounds: layout.broadcast.cutawayBounds },
      { name: layout.broadcast.ceilingNode, bounds: layout.broadcast.cutawayBounds },
      ...layout.staffroom.cutawayGroups.map((group) => ({ name: group.node, bounds: group.bounds })),
      ...layout.gymnasium.cutawayGroups.map((group) => ({ name: group.node, bounds: group.bounds, preserveStagingOcclusion: group.preserveStagingOcclusion })),
      ...layout.gymnasium.slabNodes.map((group) => ({ name: group.node, bounds: layout.gymnasium.subgradeCutout })),
      ...layout.stairs.filter((stair) => stair.id.startsWith('gym-')).map((stair) => ({ name: `${stair.id}-mesh`, bounds: layout.gymnasium.subgradeCutout })),
      { name: layout.gymnasium.ceilingNode, bounds: layout.gymnasium.subgradeCutout, hiddenInPlay: true },
      ...layout.library.cutawayGroups.map((group) => ({ name: group.node, bounds: group.bounds })),
      ...layout.supportRamps.map((ramp) => ({ name: `library-ramp-${ramp.id}`, bounds: {
        minX: Math.min(ramp.start.x, ramp.end.x) - (ramp.start.x === ramp.end.x ? ramp.width / 2 : 0),
        maxX: Math.max(ramp.start.x, ramp.end.x) + (ramp.start.x === ramp.end.x ? ramp.width / 2 : 0),
        minZ: Math.min(ramp.start.z, ramp.end.z) - (ramp.start.z === ramp.end.z ? ramp.width / 2 : 0),
        maxZ: Math.max(ramp.start.z, ramp.end.z) + (ramp.start.z === ramp.end.z ? ramp.width / 2 : 0),
      } })),
      ...layout.props.filter((prop) => prop.kind === 'library-archive-case').map((prop) => {
        const footprint = layout.propFootprints['library-archive-case'];
        const cosine = Math.abs(Math.cos(prop.rotation)); const sine = Math.abs(Math.sin(prop.rotation));
        const halfX = (footprint.width * cosine + footprint.depth * sine) / 2;
        const halfZ = (footprint.width * sine + footprint.depth * cosine) / 2;
        return { name: `library-occluder-${prop.id}`, bounds: {
          minX: prop.x - halfX, maxX: prop.x + halfX, minZ: prop.z - halfZ, maxZ: prop.z + halfZ,
        } };
      }),
    ];
    const cutaways = cutawaySpecs.map(({ name, bounds, preserveStagingOcclusion, hiddenInPlay, preserveSurfacePrefix }) => {
      const object = clone.getObjectByName(name);
      if (!object) throw new Error(`Missing school cutaway ${name}`);
      object.visible = !hiddenInPlay;
      const privateMaterials = new Map<THREE.Material, THREE.Material>();
      object.traverse((node) => {
        if (!(node instanceof THREE.Mesh)) return;
        const copy = (source: THREE.Material) => {
          let material = privateMaterials.get(source);
          if (!material) { material = source.clone(); material.transparent = true; privateMaterials.set(source, material); }
          return material;
        };
        node.material = Array.isArray(node.material) ? node.material.map(copy) : copy(node.material);
      });
      clone.updateMatrixWorld(true);
      return { name, object, bounds, preserveStagingOcclusion, hiddenInPlay, preserveSurfacePrefix, box: new THREE.Box3().setFromObject(object), materials: privateMaterials };
    });
    const kitchenVisibility = createServingKitchenVisibility(clone);
    // Architecture and cutaway controllers clone their own material instances.
    // Collect the final render tree after both have installed those clones so
    // kitchen walls and counters share the same reflection contract.
    const servingMetals = collectServingReflectionMaterials(clone);
    return { object: clone, materials, furniture, gallery, architecture, cutaways, kitchenVisibility,
      updateServingReflections(texture: THREE.Texture | null) {
        // The environment controller owns these private material clones.
        // Explicit envMap binding opts out of Scene.environmentIntensity.
        if (!texture) return;
        for (const material of servingMetals) {
          if (material.envMap === texture) continue;
          material.envMap = texture;
          material.envMapIntensity = .35;
          material.needsUpdate = true;
        }
      },
      mount() {
        leases++;
        let released = false;
        return () => {
          if (released) return;
          released = true;
          leases--;
          // Strict Mode replays effects against the same memoized scene. Its
          // synchronous remount keeps these materials and gallery controller
          // alive; only the final unmount releases them, exactly once.
          queueMicrotask(() => {
            if (leases || disposed) return;
            disposed = true;
            gallery.dispose();
            architecture.dispose();
            kitchenVisibility.dispose();
            for (const cutaway of cutaways) for (const material of cutaway.materials.values()) material.dispose();
            for (const material of materials.values()) material.dispose();
          });
        };
      },
    };
  }, [gltf, simulation]);
  useFrame(({ camera, scene }) => {
    environment.updateServingReflections(scene?.environment ?? null);
    const snapshot = simulation.read();
    const cameraDirection = camera.getWorldDirection(new THREE.Vector3());
    const poses = new Map(snapshot.furniture.map((pose) => [pose.id, pose]));
    for (const [id, node] of environment.furniture) {
      const pose = poses.get(id) ?? layout.props.find((prop) => prop.id === id)!;
      node.position.set(pose.x, 'y' in pose && typeof pose.y === 'number' ? pose.y : 0, pose.z);
      node.rotation.set(0, pose.rotation, 0);
    }
    environment.gallery.update({ ...snapshot, progress: cafeteriaPresentation(snapshot) });
    const equipmentOccluders = environment.kitchenVisibility.update(camera);
    environment.architecture.update(snapshot.player, cameraDirection, snapshot.enemies, equipmentOccluders);
    for (const region of environment.cutaways) {
      const bounds = region.bounds;
      const inside = snapshot.player.x >= bounds.minX && snapshot.player.x <= bounds.maxX
        && snapshot.player.z >= bounds.minZ && snapshot.player.z <= bounds.maxZ;
      const underfoot = region.preserveSurfacePrefix && snapshot.player.surfaceId?.startsWith(region.preserveSurfacePrefix);
      const cutaway = !underfoot && (!region.preserveStagingOcclusion || inside) &&
        (['library-', 'staffroom-', 'gym-', 'rooftop-'].some((prefix) => region.name.startsWith(prefix))
          ? libraryCutawayVisible(region, snapshot.player, cameraDirection, snapshot.enemies)
          : inside || libraryCutawayVisible(region, snapshot.player, cameraDirection, snapshot.enemies)
            || equipmentOccluders.has(region.object));
      for (const material of region.materials.values()) { material.opacity = cutaway ? .14 : 1; material.depthWrite = !cutaway; }
      region.object.traverse((node) => { if (node instanceof THREE.Mesh) node.castShadow = !cutaway; });
    }
  });
  useEffect(() => environment.mount(), [environment]);
  return <primitive object={environment.object} dispose={null} />;
}

function Projectiles({ simulation }: { simulation: Hyosan3DPlayRuntime }) {
  const student = useGLTF(`${ASSET_ROOT}student.glb`);
  const arrows = useMemo(() => Array.from({ length: 32 }, () => createHyosanFlightArrow(student.scene)), [student]);
  const group = useRef<THREE.Group>(null);
  const effects = useRef<THREE.Group>(null);
  const hitMaterial = useMemo(() => new THREE.MeshBasicMaterial({ color: '#eed8a0', transparent: true, opacity: .8 }), []);
  useFrame(() => {
    const snapshot = simulation.read();
    group.current?.children.forEach((arrow, index) => {
      const state = snapshot.arrows[index];
      arrow.visible = Boolean(state);
      if (!state) return;
      arrow.position.set(state.x, state.y, state.z);
      arrow.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), new THREE.Vector3(state.dx, state.dy, state.dz).normalize());
    });
    const impacts = snapshot.effects.filter((item) => item.kind === 'hit' || item.kind === 'impact');
    effects.current?.children.forEach((effect, index) => {
      const state = impacts[index];
      effect.visible = Boolean(state);
      if (!state) return;
      const age = (snapshot.time - state.startedAt) / state.duration;
      effect.position.set(state.x, state.y, state.z);
      effect.scale.setScalar(.04 + age * .17);
      effect.rotation.set(age * 3, age * 5, age);
    });
  });
  useEffect(() => () => hitMaterial.dispose(), [hitMaterial]);
  return <>
    <group ref={group}>{arrows.map((arrow, index) => <group key={index} visible={false}>
      <primitive object={arrow} dispose={null} />
      <lineSegments name="hyosan-arrow-flight-trail">
        <bufferGeometry><bufferAttribute attach="attributes-position" args={[ARROW_TRAIL_POINTS, 3]} /></bufferGeometry>
        <lineBasicMaterial color="#e3dcc2" transparent opacity={.48} depthWrite={false} toneMapped={false} />
      </lineSegments>
    </group>)}</group>
    <group ref={effects}>{Array.from({ length: 24 }, (_, index) => <mesh key={index} visible={false} material={hitMaterial}><octahedronGeometry args={[1, 0]} /></mesh>)}</group>
  </>;
}

function AttackCues({ simulation }: { simulation: Hyosan3DPlayRuntime }) {
  const ref = useRef<THREE.Group>(null);
  const roster = simulation.read().enemies;
  useFrame(() => {
    const snapshot = simulation.read();
    ref.current?.children.forEach((object, index) => {
      const enemy = snapshot.enemies[index];
      object.visible = Boolean(enemy && !enemy.dormant && enemy.hp > 0 && sameHyosanCombatLayer(snapshot.player, enemy)
        && (enemy.profile !== 'eunji' || enemy.staffroomBeat === 'grab-windup' || enemy.staffroomBeat === 'grab')
        && (enemy.attackPhase === 'windup' || enemy.attackPhase === 'strike'));
      if (!enemy) return;
      object.position.set(enemy.x, enemy.y + .04, enemy.z);
      object.rotation.y = enemy.yaw;
      const mesh = object.children[0] as THREE.Mesh<THREE.RingGeometry, THREE.MeshBasicMaterial>;
      const charge = object.children[1] as THREE.Group;
      const charging = enemy.attackStyle === 'charge';
      setHyosanGroundCueAngle(mesh, enemy.attackHalfAngle);
      mesh.visible = !charging;
      charge.visible = charging;
      object.scale.setScalar(1);
      mesh.scale.setScalar(enemy.attackRange);
      mesh.material.opacity = .15 + enemy.attackProgress * .45;
      if (object.visible && mesh.visible) conformHyosanGroundCue(mesh, enemy.currentLayerId);
      if (charging) {
        // Combo snapshots already carry the physically remaining charge reach.
        const range = enemy.comboBeat || enemy.classroomBeat || enemy.rooftopBeat ? enemy.attackRange
          : enemy.attackPhase === 'strike' ? .85 + (enemy.attackRange - .85) * (1 - enemy.attackProgress) : enemy.attackRange;
        const strip = charge.children[0] as THREE.Mesh<THREE.PlaneGeometry, THREE.MeshBasicMaterial>;
        strip.scale.y = range; strip.position.z = range / 2;
        strip.material.opacity = enemy.attackPhase === 'windup' ? .14 + enemy.attackProgress * .26 : .32;
        if (object.visible) conformHyosanGroundCue(strip, enemy.currentLayerId);
        charge.children[1].position.z = range;
        charge.children[1].position.y = 0;
        const tip = charge.children[1].getWorldPosition(new THREE.Vector3());
        tip.y = hyosanGroundCueHeight(tip) + .02;
        charge.children[1].position.copy(charge.worldToLocal(tip));
      }
    });
  });
  return <group ref={ref}>{roster.map((enemy) => <group key={enemy.id} visible={false}>
    <mesh rotation={[-Math.PI / 2, 0, 0]}><ringGeometry args={[0, 1, 40, 10, -Math.PI / 2 - enemy.attackHalfAngle, 2 * enemy.attackHalfAngle]} /><meshBasicMaterial color="#ec7f4d" transparent opacity={.4} depthWrite={false} side={THREE.DoubleSide} /></mesh>
    <group visible={false}>
      <mesh rotation={[-Math.PI / 2, 0, 0]}><planeGeometry args={[1.7, 1, 6, 24]} /><meshBasicMaterial color="#e68753" transparent opacity={.3} depthWrite={false} side={THREE.DoubleSide} /></mesh>
      <mesh rotation={[Math.PI / 2, 0, 0]} position={[0, .02, 5]}><coneGeometry args={[.28, .5, 3]} /><meshBasicMaterial color="#ffe3ac" transparent opacity={.8} depthWrite={false} /></mesh>
    </group>
  </group>)}</group>;
}

function PlayerMarker({ simulation }: { simulation: Hyosan3DPlayRuntime }) {
  const ref = useRef<THREE.Group>(null);
  const direction = useRef<THREE.Mesh>(null);
  useFrame(() => {
    const player = simulation.read().player;
    if (!ref.current) return;
    ref.current.position.set(player.x, player.y + .025, player.z);
    ref.current.visible = player.hp > 0;
    // The selection halo stays at the player's support level when it extends
    // past a ledge, rather than stretching down onto the floor below.
    ref.current.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), hyosanGroundNormal(player));
    if (direction.current) {
      direction.current.position.set(Math.sin(player.yaw) * .56, -Math.cos(player.yaw) * .56, .004);
      direction.current.rotation.z = Math.PI + player.yaw;
    }
  });
  return <group ref={ref} rotation={[-Math.PI / 2, 0, 0]}>
    <mesh renderOrder={2}><ringGeometry args={[.355, .46, 40]} /><meshBasicMaterial color="#172c28" transparent opacity={.85} depthWrite={false} /></mesh>
    <mesh position={[0, 0, .002]} renderOrder={3}><ringGeometry args={[.38, .435, 40]} /><meshBasicMaterial color="#edf0ca" transparent opacity={.9} depthWrite={false} /></mesh>
    <mesh ref={direction} renderOrder={3}><circleGeometry args={[.11, 3, Math.PI / 2]} /><meshBasicMaterial color="#edf0ca" transparent opacity={.95} depthWrite={false} /></mesh>
  </group>;
}

export function Hyosan3DScene({ simulation, input, onReady, onHud, diagnostics, audioRef, onFailure }: {
  simulation: Hyosan3DPlayRuntime;
  input: Hyosan3DInputController;
  onReady: () => void;
  onHud: (snapshot: Hyosan3DSnapshot) => void;
  diagnostics: Hyosan3DDiagnostics;
  audioRef: RefObject<Hyosan3DAudio | null>;
  onFailure: () => void;
}) {
  const { camera, size, gl, scene } = useThree();
  const center = useRef(new THREE.Vector3(simulation.read().player.x, simulation.read().player.y + .5, simulation.read().player.z));
  const sun = useRef<THREE.DirectionalLight>(null);
  const sky = useRef<THREE.HemisphereLight>(null);
  const ambient = useRef<THREE.AmbientLight>(null);
  const palette = useMemo(() => ({ day: new THREE.Color('#192b2c'), night: new THREE.Color('#0b1722'),
    dayFog: new THREE.Color('#243b3c'), nightFog: new THREE.Color('#122433'),
    daySun: new THREE.Color('#fff0d6'), moon: new THREE.Color('#b0cad9') }), []);
  const kit = useRef<THREE.Group>(null);
  const nextHudAt = useRef(0);
  const ray = useMemo(() => new THREE.Raycaster(), []);
  const pointer = useRef<THREE.Vector2 | null>(null);
  const reducedMotion = useRef(false);
  useEffect(() => {
    const query = window.matchMedia('(prefers-reduced-motion: reduce)');
    const update = () => { reducedMotion.current = query.matches; };
    update(); query.addEventListener('change', update);
    return () => query.removeEventListener('change', update);
  }, []);

  useEffect(() => {
    const detach = input.attach(window, gl.domElement);
    const onMove = (event: PointerEvent) => {
      if (event.pointerType === 'touch') return;
      const rect = gl.domElement.getBoundingClientRect();
      pointer.current = new THREE.Vector2((event.clientX - rect.left) / rect.width * 2 - 1, 1 - (event.clientY - rect.top) / rect.height * 2);
    };
    const onLeave = () => { pointer.current = null; input.clearAim(); };
    const onContextLost = (event: Event) => { event.preventDefault(); onFailure(); };
    gl.domElement.addEventListener('pointermove', onMove);
    gl.domElement.addEventListener('pointerdown', onMove);
    gl.domElement.addEventListener('pointerleave', onLeave);
    gl.domElement.addEventListener('webglcontextlost', onContextLost);
    return () => { detach(); gl.domElement.removeEventListener('pointermove', onMove); gl.domElement.removeEventListener('pointerdown', onMove); gl.domElement.removeEventListener('pointerleave', onLeave); gl.domElement.removeEventListener('webglcontextlost', onContextLost); };
  }, [gl, input, onFailure]);

  useEffect(() => {
    sizeCamera(camera, size.width, size.height, reunionPlaying(simulation.read().ending) ? 1.45 : 1);
  }, [camera, size.width, size.height, simulation]);
  useEffect(() => {
    // Compile hidden incident/attack materials before play, not on first contact.
    // Three's compile traversal includes hidden meshes without making them visible.
    // The synchronous preparation has no async material polling after a Strict
    // Mode cleanup disposes this mount's materials.
    try { gl.compile(scene, camera); onReady(); } catch { onFailure(); }
  }, [gl, scene, camera, onReady, onFailure]);

  useEffect(() => {
    diagnostics.setProject((x, y, z) => {
      const point = new THREE.Vector3(x, y, z).project(camera);
      return { x: (point.x + 1) * size.width / 2, y: (1 - point.y) * size.height / 2 };
    });
    return () => { diagnostics.setProject(null); };
  }, [camera, diagnostics, size]);

  useFrame((_state, delta) => {
    let snapshot = simulation.read();
    if (pointer.current) {
      ray.setFromCamera(pointer.current, camera);
      const aim = resolveHyosanPointerAim(ray.ray, snapshot.player, snapshot.enemies);
      input.setAimDirection(aim.x, aim.z, aim.y);
    }
    const simulationStart = performance.now();
    if (!diagnostics.isManual()) simulation.step(input.read(AZIMUTH), Math.min(delta, .1));
    diagnostics.recordSimulation(performance.now() - simulationStart);
    diagnostics.recordFrame(gl.info.render.calls, gl.info.render.triangles, delta, gl.info.memory);
    snapshot = simulation.read();
    audioRef.current?.update(snapshot);
    const ending = snapshot.ending;
    const night = ending?.phase === 'returning' ? Math.min(1, ending.time / HYOSAN_REUNION.returnDuration)
      : reunionPlaying(ending) || ending?.phase === 'complete' ? 1 : 0;
    if (scene.background instanceof THREE.Color) scene.background.copy(palette.day).lerp(palette.night, night);
    if (scene.fog) scene.fog.color.copy(palette.dayFog).lerp(palette.nightFog, night);
    if (sky.current) sky.current.intensity = THREE.MathUtils.lerp(DAYLIGHT.sky, .48, night);
    if (ambient.current) ambient.current.intensity = THREE.MathUtils.lerp(DAYLIGHT.ambient, .06, night);
    if (sun.current) { sun.current.intensity = THREE.MathUtils.lerp(DAYLIGHT.sun, .6, night); sun.current.color.copy(palette.daySun).lerp(palette.moon, night); }
    sizeCamera(camera, size.width, size.height, reunionPlaying(ending) ? 1.45 : 1, reducedMotion.current ? 1 : 1 - Math.exp(-delta * 5));
    const target = new THREE.Vector3(snapshot.player.x + 1.2, snapshot.player.y + .5, snapshot.player.z - .7);
    if (reunionPlaying(ending) && size.width / size.height > 1.15 && size.height < 520) {
      // Reserve the lower half for the dialogue on short landscape viewports.
      target.addScaledVector(new THREE.Vector3(0, 1, 0).applyQuaternion(camera.quaternion), -size.height * .24 / (camera as THREE.OrthographicCamera).zoom);
    }
    if (center.current.distanceToSquared(target) > 64 || reducedMotion.current && reunionPlaying(ending)) center.current.copy(target);
    else center.current.lerp(target, 1 - Math.exp(-delta * 6));
    camera.position.copy(center.current).add(CAMERA_OFFSET);
    camera.lookAt(center.current);
    if (sun.current) {
      // Preserve the daylight direction when the player descends to another floor.
      positionSchoolSun(sun.current, center.current);
    }
    if (kit.current) kit.current.visible = !snapshot.progress.upgraded;
    if (_state.clock.elapsedTime >= nextHudAt.current) {
      nextHudAt.current = _state.clock.elapsedTime + .08;
      onHud(snapshot);
    }
  }, -1);

  return <>
    <color attach="background" args={['#192b2c']} />
    <fog attach="fog" args={['#243b3c', 38, 80]} />
    <SchoolReflections />
    <hemisphereLight ref={sky} args={['#b3c9ce', '#343b32', DAYLIGHT.sky]} />
    <ambientLight ref={ambient} intensity={DAYLIGHT.ambient} />
    <directionalLight ref={sun} position={[-18, 18, -13]} intensity={DAYLIGHT.sun} color="#fff0d6" castShadow
      shadow-mapSize={[2048, 2048]} shadow-camera-left={-22} shadow-camera-right={22}
      shadow-camera-top={20} shadow-camera-bottom={-20} shadow-camera-near={.5} shadow-camera-far={70}
      shadow-bias={-.0001} shadow-normalBias={.035} shadow-radius={2} />
    <Environment simulation={simulation} />
    <SchoolGround />
    <SchoolSurroundings />
    <ScienceDressing />
    <Hyosan3DActors simulation={simulation} studentUrl={`${ASSET_ROOT}student.glb`} zombieUrl={`${ASSET_ROOT}zombie.glb`} nurseUrl={`${ASSET_ROOT}nurse.glb`} hyunjuUrl={`${ASSET_ROOT}hyunju.glb`} jinguUrl={`${ASSET_ROOT}jingu.glb`} daewonUrl={`${ASSET_ROOT}daewon.glb`} gwinamHumanUrl={`${ASSET_ROOT}gwinam-human.glb`} eunjiUrl={`${ASSET_ROOT}eunji.glb`} gwinamHalfbieUrl={`${ASSET_ROOT}gwinam-halfbie.glb`} />
    <Projectiles simulation={simulation} />
    <AttackCues simulation={simulation} />
    <PlayerMarker simulation={simulation} />
    <AdventureObjects simulation={simulation} />
    <ScienceObjects simulation={simulation} />
    <ClassroomObjects simulation={simulation} />
    <BroadcastObjects simulation={simulation} />
    <LibraryObjects simulation={simulation} />
    <StaffroomObjects simulation={simulation} />
    <GymnasiumObjects simulation={simulation} />
    <RooftopObjects simulation={simulation} />
    <RooftopReunion simulation={simulation} />
    <LightingPass diagnostics={diagnostics} />
    <group ref={kit} position={[layout.upgrade.x, .095, layout.upgrade.z]}><BowCase /></group>
  </>;
}
