import type { Hyosan3DEffect, Hyosan3DSnapshot } from '@/lib/games/hyosan-memories-3d/types';

export interface Hyosan3DAudio {
  /** Call directly from pointerdown/keydown, before awaiting any other work. */
  unlock(): Promise<boolean>;
  update(snapshot: Readonly<Hyosan3DSnapshot>): void;
  setMuted(muted: boolean): void;
  isMuted(): boolean;
  dispose(): void;
}

type Cue = Exclude<Hyosan3DEffect['kind'], 'respawn'>;
const durations: Record<Cue, number> = { shot: 0.23, hit: 0.14, impact: 0.13, hurt: 0.28, upgrade: 0.52, defeat: 0.18,
  door: 0.46, 'boss-warning': 0.40, 'boss-sweep': 0.31 };

/** Short physical-sounding one-shots: damped string, air, wood and soft body impact. */
export function renderHyosan3DCue(kind: Cue, sampleRate: number): Float32Array<ArrayBuffer> {
  const samples = new Float32Array(Math.ceil(durations[kind] * sampleRate));
  const string = new Float32Array(Math.round(sampleRate / 175));
  let seed = 17491;
  const noise = () => { seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0; return seed / 2147483648 - 1; };
  for (let i = 0; i < string.length; i += 1) string[i] = noise() * 0.6;
  let lowNoise = 0;
  for (let i = 0; i < samples.length; i += 1) {
    const t = i / sampleRate;
    const white = noise();
    lowNoise += (white - lowNoise) * 0.22;
    let value = 0;
    if (kind === 'shot') {
      const cursor = i % string.length;
      const pluck = string[cursor];
      string[cursor] = 0.494 * (pluck + string[(cursor + 1) % string.length]);
      const air = (white - lowNoise) * 0.055 * Math.sin(Math.min(1, t / 0.1) * Math.PI) * Math.exp(-t * 15);
      value = pluck * Math.exp(-t * 12) + Math.sin(2 * Math.PI * 132 * t) * 0.11 * Math.exp(-t * 38) + air;
    } else if (kind === 'upgrade') {
      for (const [index, frequency] of [440, 660, 880].entries()) {
        const age = t - index * 0.085;
        if (age >= 0) value += (Math.sin(2 * Math.PI * frequency * age) + 0.16 * Math.sin(2 * Math.PI * frequency * 2.01 * age))
          * 0.13 * Math.exp(-age * 13) * Math.min(1, age / 0.004);
      }
    } else if (kind === 'door') {
      // Light metal/glass fittings moving in their frame; no musical cue or voice.
      const movement = Math.sin(Math.PI * t / durations.door) ** 2;
      value = (white - lowNoise) * .10 * movement;
      for (const contact of [0, .12, .28]) {
        const age = t - contact;
        if (age >= 0) value += (Math.sin(2 * Math.PI * 570 * age) * .11
          + Math.sin(2 * Math.PI * 913 * age) * .065 + lowNoise * .25) * Math.exp(-age * 43);
      }
    } else if (kind === 'boss-warning') {
      const tremor = .35 + .65 * Math.sin(Math.PI * 14 * t) ** 2;
      value = (lowNoise * .78 + (white - lowNoise) * .12) * tremor
        * Math.sin(Math.PI * Math.min(1, t / durations['boss-warning'])) * Math.exp(-t * 2);
    } else if (kind === 'boss-sweep') {
      const air = Math.sin(Math.PI * t / durations['boss-sweep']) ** 1.5;
      value = ((white - lowNoise) * .32 + lowNoise * .58) * air;
    } else {
      const hard = kind === 'impact';
      const frequency = hard ? 235 : kind === 'hurt' ? 76 : 115;
      const decay = kind === 'hurt' ? 18 : hard ? 43 : 31;
      value = (lowNoise * (hard ? 1.15 : 0.8) + Math.sin(2 * Math.PI * frequency * t) * 0.24
        + (hard ? Math.sin(2 * Math.PI * 680 * t) * 0.13 : 0)) * Math.exp(-t * decay);
      if (kind === 'defeat') value *= 0.7;
    }
    const fade = Math.min(1, i / (sampleRate * 0.0015), (samples.length - i - 1) / (sampleRate * 0.008));
    samples[i] = Math.max(-0.8, Math.min(0.8, value * fade));
  }
  return samples;
}

/** Effects are consumed even while silent; unlock/resume never queues historical audio. */
export function createHyosan3DAudio(options: {
  muted?: boolean;
  contextFactory?: () => AudioContext | null;
} = {}): Hyosan3DAudio {
  let context: AudioContext | null = null;
  let master: GainNode | null = null;
  let muted = options.muted ?? false;
  let paused = false;
  let disposed = false;
  let lastTime: number | null = null;
  const heard = new Set<string>();
  const buffers = new Map<Cue, AudioBuffer>();
  const voices = new Set<{ source: AudioBufferSourceNode; gain: GainNode }>();
  const stopVoices = () => {
    for (const voice of voices) {
      voice.source.onended = null;
      voice.source.stop(); voice.source.disconnect(); voice.gain.disconnect();
    }
    voices.clear();
  };
  const updateVolume = () => {
    if (!master || !context) return;
    master.gain.cancelScheduledValues(context.currentTime);
    master.gain.setTargetAtTime(muted || paused ? 0 : 0.32, context.currentTime, 0.008);
  };
  const play = (effect: Hyosan3DEffect, snapshot: Readonly<Hyosan3DSnapshot>) => {
    if (!context || !master || effect.kind === 'respawn' || voices.size >= 12) return;
    let buffer = buffers.get(effect.kind);
    if (!buffer) {
      const samples = renderHyosan3DCue(effect.kind, context.sampleRate);
      buffer = context.createBuffer(1, samples.length, context.sampleRate);
      buffer.copyToChannel(samples, 0);
      buffers.set(effect.kind, buffer);
    }
    const source = context.createBufferSource();
    const gain = context.createGain();
    source.buffer = buffer;
    const variation = Number(effect.id.match(/\d+$/)?.[0] ?? 0) % 7;
    source.playbackRate.value = 0.97 + variation * 0.01;
    const distance = Math.hypot(effect.x - snapshot.player.x, effect.z - snapshot.player.z);
    gain.gain.value = 1 / (1 + distance * 0.12);
    source.connect(gain); gain.connect(master);
    const voice = { source, gain };
    voices.add(voice);
    source.onended = () => { voices.delete(voice); source.disconnect(); gain.disconnect(); };
    source.start(context.currentTime);
  };
  return {
    async unlock() {
      if (disposed) return false;
      try {
        if (!context) {
          context = options.contextFactory ? options.contextFactory()
            : typeof AudioContext === 'undefined' ? null : new AudioContext({ latencyHint: 'interactive' });
          if (!context) return false;
          master = context.createGain();
          master.gain.value = muted || paused ? 0 : 0.32;
          master.connect(context.destination);
        }
        if (context.state !== 'running') await context.resume();
        return !disposed && context.state === 'running';
      } catch { return false; }
    },
    update(snapshot) {
      if (disposed) return;
      if (lastTime !== null && snapshot.time < lastTime) { heard.clear(); stopVoices(); }
      lastTime = snapshot.time;
      const silent = Boolean(snapshot.paused || snapshot.story);
      if (silent !== paused) {
        paused = silent;
        if (paused) stopVoices();
        updateVolume();
      }
      for (const effect of snapshot.effects) {
        const key = `${effect.id}:${effect.kind}:${effect.startedAt}`;
        if (heard.has(key)) continue;
        heard.add(key);
        const age = snapshot.time - effect.startedAt;
        if (muted || paused || context?.state !== 'running' || age < 0 || age > 0.12) continue;
        play(effect, snapshot);
      }
    },
    setMuted(value) { if (!disposed) { muted = value; if (muted) stopVoices(); updateVolume(); } },
    isMuted() { return muted; },
    dispose() {
      if (disposed) return;
      disposed = true; stopVoices(); master?.disconnect();
      void context?.close().catch(() => undefined);
      buffers.clear(); heard.clear();
    },
  };
}
