'use client';
import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import type { Group } from 'three';
import layout from '@/docs/games/hyosan-memories-3d/world-layout.json';
import type { Hyosan3DPlayRuntime } from '@/lib/games/hyosan-memories-3d/types';

const plan = layout.rooftop;
const point = (value: { x: number; y: number; z: number }, height = .04): [number, number, number] => [value.x, value.y + height, value.z];
function Ring({ color, radius = .38 }: { color: string; radius?: number }) {
  return <mesh rotation={[-Math.PI / 2, 0, 0]}><ringGeometry args={[radius, radius + .035, 36]} />
    <meshBasicMaterial color={color} transparent opacity={.75} depthWrite={false} /></mesh>;
}

/** Revealed supplies and memory objects follow the same regional progress as the HUD. */
export function RooftopObjects({ simulation }: { simulation: Hyosan3DPlayRuntime }) {
  const anchor = useRef<Group>(null), supply = useRef<Group>(null), note = useRef<Group>(null);
  const echo = useRef<Group>(null), gate = useRef<Group>(null);
  useFrame(() => {
    const state = simulation.read(); const progress = state.area === 'rooftop' ? state.progress : state.schoolState?.rooftop;
    if (anchor.current) anchor.current.visible = progress?.discoveredRooms.includes('rooftop-landing') ?? false;
    if (supply.current) supply.current.visible = Boolean(progress?.discoveredRooms.includes('rooftop-service') && !progress.supplyTaken);
    if (note.current) note.current.visible = state.progress.room === 'rooftop-service' && !progress?.keepsakeFound;
    if (echo.current) echo.current.visible = Boolean(progress?.bossDefeated && !progress.areaResolved && !progress.echoCollected);
    if (gate.current) gate.current.visible = state.area === 'rooftop' && state.interaction === 'shortcut';
  });
  return <group>
    <group ref={anchor} visible={false} position={point(plan.checkpoint)}><Ring color="#a8d9b8" radius={.65} />
      <mesh><boxGeometry args={[.16, .035, .25]} /><meshStandardMaterial color="#536d65" roughness={.8} /></mesh></group>
    <group ref={supply} visible={false} position={point(plan.supply, .12)}>
      <mesh><boxGeometry args={[.32, .2, .24]} /><meshStandardMaterial color="#e1dcca" roughness={.85} /></mesh>
      <mesh position={[0, .105, 0]}><boxGeometry args={[.17, .009, .04]} /><meshStandardMaterial color="#8e4941" /></mesh>
      <mesh position={[0, .105, 0]}><boxGeometry args={[.04, .009, .15]} /><meshStandardMaterial color="#8e4941" /></mesh>
      <group position={[0, -.08, 0]}><Ring color="#afd5bb" /></group>
    </group>
    <group ref={note} visible={false} position={point(plan.hidden)}>
      <mesh><boxGeometry args={[.2, .014, .28]} /><meshStandardMaterial color="#c9bc9a" roughness={.95} /></mesh>
      <Ring color="#dcc28b" radius={.3} />
    </group>
    <group ref={echo} visible={false} position={point(plan.echo)}>
      <mesh><boxGeometry args={[.19, .035, .28]} /><meshStandardMaterial color="#636a63" roughness={.7} /></mesh>
      <Ring color="#efd29f" radius={.5} />
    </group>
    <group ref={gate} visible={false} position={point(plan.shortcut.interactPoint)}><Ring color="#f0cf8a" radius={.48} /></group>
  </group>;
}
