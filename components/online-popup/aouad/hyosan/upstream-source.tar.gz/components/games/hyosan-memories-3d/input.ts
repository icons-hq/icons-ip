import type { Hyosan3DInput } from '@/lib/games/hyosan-memories-3d/types';

export interface Hyosan3DInputController {
  attach(target: Window, canvas?: HTMLCanvasElement): () => void;
  /** Restore keyboard control to the attached playfield after a gameplay shortcut. */
  focusGame(): void;
  /** Consumes action edges. Azimuth is atan2(camera.x - target.x, camera.z - target.z). */
  read(cameraAzimuth: number): Hyosan3DInput;
  /** Screen directions: +X right, +Y down. */
  setMovement(x: number, y: number): void;
  setAttackHeld(held: boolean): void;
  pressDash(): void;
  pressInteract(): void;
  setAimDirection(dx: number, dz: number, dy?: number): void;
  clearAim(): void;
  reset(): void;
  dispose(): void;
}

export function createHyosan3DInputController(): Hyosan3DInputController {
  const keys = new Set<string>();
  let movement = { x: 0, y: 0 };
  let touchAttack = false;
  let pointerId: number | null = null;
  let pointerAttackQueued = false;
  let attackQueued = false;
  let dashQueued = false;
  let interactQueued = false;
  let aim: { x: number; y: number; z: number } | null = null;
  let detach: (() => void) | null = null;
  let releaseCapture: (() => void) | null = null;
  let playfield: HTMLCanvasElement | undefined;
  const focusGame = () => {
    if (!playfield) return;
    playfield.tabIndex = -1;
    playfield.focus({ preventScroll: true });
  };
  const fireKeys = ['KeyJ', 'Space'];
  const dashKeys = ['ShiftLeft', 'ShiftRight', 'KeyL'];
  const controlKeys = new Set(['KeyW', 'KeyA', 'KeyS', 'KeyD', 'ArrowUp', 'ArrowLeft', 'ArrowDown', 'ArrowRight', ...fireKeys, ...dashKeys, 'KeyE']);
  const pressed = (...codes: string[]) => codes.some((code) => keys.has(code));
  const reset = () => {
    keys.clear();
    movement = { x: 0, y: 0 };
    touchAttack = false;
    attackQueued = false;
    pointerAttackQueued = false;
    dashQueued = false;
    interactQueued = false;
    aim = null;
    releaseCapture?.();
    pointerId = null;
  };

  return {
    attach: (target, canvas) => {
      detach?.();
      reset();
      playfield = canvas;
      const document = target.document;
      const onKeyDown = (event: KeyboardEvent) => {
        const code = event.code;
        const element = event.target as Element | null;
        if (!controlKeys.has(code) || event.defaultPrevented || event.altKey || event.ctrlKey || event.metaKey
          || (typeof element?.closest === 'function'
            && (element.closest('input, select, textarea, [contenteditable="true"], [role="dialog"]')
              || (code === 'Space' && element.closest('button, a, [role="button"]'))))) return;
        event.preventDefault();
        // A held key cannot silently restart firing after reset/pause/blur.
        if (event.repeat || keys.has(code)) return;
        if (typeof element?.closest === 'function' && element.closest('button, a, [role="button"]')) focusGame();
        keys.add(code);
        if (fireKeys.includes(code)) attackQueued = true;
        if (dashKeys.includes(code)) dashQueued = true;
        if (code === 'KeyE') interactQueued = true;
      };
      const onKeyUp = (event: KeyboardEvent) => { keys.delete(event.code); };
      const onVisibility = () => { if (document.visibilityState === 'hidden') reset(); };
      const onPointerDown = (event: PointerEvent) => {
        if (event.button !== 0 || pointerId !== null
          || (event.pointerType && event.pointerType !== 'mouse' && event.pointerType !== 'pen')) return;
        event.preventDefault();
        focusGame();
        pointerId = event.pointerId;
        pointerAttackQueued = true;
        canvas?.setPointerCapture(event.pointerId);
      };
      const onPointerEnd = (event: PointerEvent) => {
        if (event.pointerId !== pointerId) return;
        pointerId = null;
        if (event.type !== 'pointerup') pointerAttackQueued = false;
      };
      releaseCapture = () => {
        const captured = pointerId;
        pointerId = null;
        if (captured !== null && canvas?.hasPointerCapture(captured)) canvas.releasePointerCapture(captured);
      };
      target.addEventListener('keydown', onKeyDown);
      target.addEventListener('keyup', onKeyUp);
      target.addEventListener('blur', reset);
      target.addEventListener('pointerup', onPointerEnd);
      target.addEventListener('pointercancel', onPointerEnd);
      document.addEventListener('visibilitychange', onVisibility);
      canvas?.addEventListener('pointerdown', onPointerDown);
      canvas?.addEventListener('lostpointercapture', onPointerEnd);
      let attached = true;
      const cleanup = () => {
        if (!attached) return;
        attached = false;
        if (playfield === canvas) playfield = undefined;
        target.removeEventListener('keydown', onKeyDown);
        target.removeEventListener('keyup', onKeyUp);
        target.removeEventListener('blur', reset);
        target.removeEventListener('pointerup', onPointerEnd);
        target.removeEventListener('pointercancel', onPointerEnd);
        document.removeEventListener('visibilitychange', onVisibility);
        canvas?.removeEventListener('pointerdown', onPointerDown);
        canvas?.removeEventListener('lostpointercapture', onPointerEnd);
        reset();
        releaseCapture = null;
        if (detach === cleanup) detach = null;
      };
      detach = cleanup;
      return cleanup;
    },
    focusGame,
    read: (cameraAzimuth) => {
      const angle = Number.isFinite(cameraAzimuth) ? cameraAzimuth : 0;
      const x = movement.x + Number(pressed('KeyD', 'ArrowRight')) - Number(pressed('KeyA', 'ArrowLeft'));
      const y = movement.y + Number(pressed('KeyS', 'ArrowDown')) - Number(pressed('KeyW', 'ArrowUp'));
      const scale = 1 / Math.max(1, Math.hypot(x, y));
      const frame: Hyosan3DInput = {
        moveX: (x * Math.cos(angle) + y * Math.sin(angle)) * scale,
        moveZ: (-x * Math.sin(angle) + y * Math.cos(angle)) * scale,
        attackHeld: touchAttack || pointerId !== null || pointerAttackQueued || pressed(...fireKeys) || attackQueued,
        dashPressed: dashQueued,
        interactPressed: interactQueued,
        ...(aim && (pointerId !== null || pointerAttackQueued) ? { aimX: aim.x, aimY: aim.y, aimZ: aim.z } : {}),
      };
      attackQueued = false;
      pointerAttackQueued = false;
      dashQueued = false;
      interactQueued = false;
      return frame;
    },
    setMovement: (x, y) => {
      const length = Math.hypot(x, y);
      movement = Number.isFinite(length) ? { x: x / Math.max(1, length), y: y / Math.max(1, length) } : { x: 0, y: 0 };
    },
    setAttackHeld: (held) => {
      if (held && !touchAttack) attackQueued = true;
      touchAttack = held;
    },
    pressDash: () => { dashQueued = true; },
    pressInteract: () => { interactQueued = true; },
    setAimDirection: (dx, dz, dy = 0) => {
      const length = Math.hypot(dx, dy, dz);
      aim = Number.isFinite(length) && length > 0.0001 ? { x: dx / length, y: dy / length, z: dz / length } : null;
    },
    clearAim: () => { aim = null; },
    reset,
    dispose: () => { detach?.(); reset(); },
  };
}
