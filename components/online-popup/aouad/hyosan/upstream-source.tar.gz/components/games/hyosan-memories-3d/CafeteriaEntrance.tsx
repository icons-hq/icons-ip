'use client';
import { cafeteriaPresentation } from './school-presentation';

import { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import type { Group } from 'three';
import layout from '@/docs/games/hyosan-memories-3d/world-layout.json';
import { hyosanCafeteriaDoorLeaves, hyosanCafeteriaEntrance } from '@/lib/games/hyosan-memories-3d/cafeteria-entrance';
import type { Hyosan3DLayout } from '@/lib/games/hyosan-memories-3d/physics';
import type { Hyosan3DPlayRuntime } from '@/lib/games/hyosan-memories-3d/types';

type DoorLeaf = ReturnType<typeof hyosanCafeteriaDoorLeaves>[number];

function GlassLeaf({ leaf }: { leaf: DoorLeaf }) {
  const rail = .045;
  const freeEdge = leaf.id === 'cafeteria-glass-north' ? 1 : -1;
  return <>
    <mesh name={`${leaf.id}-glass`} receiveShadow>
      <boxGeometry args={[leaf.width * .28, leaf.height - rail * 2, leaf.depth - rail * 2]} />
      <meshStandardMaterial color="#b2d2cd" transparent opacity={.22} roughness={.16} metalness={.08} depthWrite={false} />
    </mesh>
    {[-1, 1].map((side) => <mesh key={`vertical-${side}`} name={`${leaf.id}-vertical-${side}`} position={[0, 0, side * (leaf.depth / 2 - rail / 2)]} castShadow receiveShadow>
      <boxGeometry args={[leaf.width, leaf.height, rail]} />
      <meshStandardMaterial color="#9baba6" metalness={.68} roughness={.32} />
    </mesh>)}
    {[-1, 1].map((side) => <mesh key={`horizontal-${side}`} name={`${leaf.id}-horizontal-${side}`} position={[0, side * (leaf.height / 2 - rail / 2), 0]} castShadow receiveShadow>
      <boxGeometry args={[leaf.width, rail, leaf.depth]} />
      <meshStandardMaterial color="#9baba6" metalness={.68} roughness={.32} />
    </mesh>)}
    <mesh name={`${leaf.id}-handle`} position={[.012, -.07, freeEdge * (leaf.depth / 2 - .20)]} castShadow>
      <boxGeometry args={[.044, .44, .042]} />
      <meshStandardMaterial color="#d0d7cc" metalness={.8} roughness={.23} />
    </mesh>
  </>;
}

/** Door rendering consumes the same leaf OBB poses as Rapier; it owns no animation clock. */
export function CafeteriaEntrance({ simulation, source = layout }: { simulation: Hyosan3DPlayRuntime; source?: Hyosan3DLayout }) {
  const entrance = useMemo(() => hyosanCafeteriaEntrance(source), [source]);
  const leaves = useRef(new Map<string, Group>());
  useFrame(() => {
    if (!entrance) return;
    for (const leaf of hyosanCafeteriaDoorLeaves(entrance, cafeteriaPresentation(simulation.read()).entranceOpen)) {
      const object = leaves.current.get(leaf.id);
      if (!object) continue;
      object.position.set(leaf.x, leaf.height / 2, leaf.z);
      object.rotation.y = leaf.rotation;
    }
  });
  if (!entrance) return null;
  return <group name="cafeteria-entrance">
    {hyosanCafeteriaDoorLeaves(entrance, cafeteriaPresentation(simulation.read()).entranceOpen).map((leaf) => <group key={leaf.id} name={leaf.id}
      ref={(object) => { if (object) leaves.current.set(leaf.id, object); else leaves.current.delete(leaf.id); }}
      position={[leaf.x, leaf.height / 2, leaf.z]} rotation={[0, leaf.rotation, 0]}>
      <GlassLeaf leaf={leaf} />
    </group>)}
  </group>;
}
