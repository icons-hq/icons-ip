'use client';

import { HYOSAN_REUNION, reunionPlaying } from '@/lib/games/hyosan-memories-3d/ending';
import { HYOSAN_BOW_HEIGHT } from '@/lib/games/hyosan-memories-3d/bow-projectiles';
import { createHyosanArcheryEquipment } from './archery-equipment';
import { useCallback, useLayoutEffect, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { useGLTF } from '@react-three/drei';
import { clone as cloneSkeleton } from 'three/examples/jsm/utils/SkeletonUtils.js';
import {
  AnimationClip, AnimationMixer, Bone, Color, Group, LoopOnce, LoopRepeat,
  Material, Matrix4, Mesh, MeshStandardMaterial, Object3D, Quaternion, Skeleton, SkinnedMesh, Sphere, Vector3,
  type AnimationAction,
} from 'three';
import type { Hyosan3DEnemy, Hyosan3DPlayRuntime, Hyosan3DSnapshot } from '@/lib/games/hyosan-memories-3d/types';
import { directionalFootOffset, directionalGait, type DirectionalGait } from './directional-gait';
import layout from '@/docs/games/hyosan-memories-3d/world-layout.json';
import { createHyosanSupportGeometry } from '@/lib/games/hyosan-memories-3d/support-geometry';

const surfaces = createHyosanSupportGeometry(layout);
const footwearSurfaces = surfaces.surfaces.filter(surface => surface.kind === 'ramp' || surface.kind === 'stair');

interface ActorAsset { scene: Group; animations: AnimationClip[] }
interface MaterialCopy { material: Material; opacity: number; transparent: boolean; emissive?: Color }
interface FootContact {
  position: Vector3 | null; restRotation: Quaternion; restHeight: number;
  vertices: { mesh: SkinnedMesh; index: number }[];
}
interface ArcheryHand {
  wrist: Bone; orientation: Quaternion; palm: Vector3; hook: Bone;
  fingers: { bone: Bone; open: Quaternion; curled: Quaternion }[];
}
interface ActorRig {
  id: string; asset: ActorAsset; carrier: Group; model: Object3D; mixer: AnimationMixer;
  actions: Map<string, AnimationAction>; materials: MaterialCopy[]; skeletons: Set<Skeleton>;
  bones: Map<string, Bone>; bow: Object3D | undefined; nockedArrow: Object3D | undefined;
  arrowRest: Vector3 | null; bowRest: Quaternion | null;
  equipment: ReturnType<typeof createHyosanArcheryEquipment> | null;
  bowRestPosition: Vector3 | null; hands: Record<'l' | 'r', ArcheryHand> | null;
  lastX: number; lastZ: number; lastTime: number | null; gait: number; deathAt: number | null; bowWeight: number; wasDormant: boolean;
  feet: Record<'l' | 'r', FootContact>;
  hitPose: Map<Bone, Quaternion>;
  archeryPose: Map<Bone, Quaternion>;
}

const lowerBone = /^(root|pelvis|thigh_[lr]|calf_[lr]|foot_[lr]|ball(?:_leaf)?_[lr])$/;
const lowerTrack = (name: string) => lowerBone.test(name.slice(0, name.indexOf('.')));
const scratch = {
  start: new Vector3(), joint: new Vector3(), end: new Vector3(), target: new Vector3(),
  axis: new Vector3(), pole: new Vector3(), elbow: new Vector3(), current: new Vector3(), wanted: new Vector3(),
  rotation: new Quaternion(), parent: new Quaternion(), world: new Quaternion(),
};

/** Clone only skeletons and fading materials; cached GLB geometries/textures stay shared. */
function createRig(asset: ActorAsset, id: string): ActorRig {
  const model = cloneSkeleton(asset.scene);
  const carrier = new Group();
  carrier.name = `hyosan-actor-${id}`;
  carrier.add(model);
  const materialMap = new Map<Material, Material>();
  const materials: MaterialCopy[] = [];
  const skeletons = new Set<Skeleton>();
  const bones = new Map<string, Bone>();
  model.traverse((object) => {
    if ((object as Bone).isBone) bones.set(object.name, object as Bone);
    if (!(object as Mesh).isMesh) return;
    const mesh = object as Mesh;
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    if ((mesh as SkinnedMesh).isSkinnedMesh) {
      const skin = mesh as SkinnedMesh;
      // These metre-scale, root-stationary rigs need room for attack/death limbs
      // and foot IK beyond their rest pose. A conservative owned sphere keeps
      // edge poses intact while each camera/shadow pass culls distant students.
      // Actual packaged clips are checked against this envelope in lifecycle QA.
      skin.boundingSphere = new Sphere(new Vector3(0, .9, 0), 3);
      skin.frustumCulled = true;
      skeletons.add(skin.skeleton);
    }
    const copyMaterial = (source: Material) => {
      let copy = materialMap.get(source);
      if (!copy) {
        copy = source.clone();
        materialMap.set(source, copy);
        materials.push({ material: copy, opacity: source.opacity, transparent: source.transparent,
          ...((source as MeshStandardMaterial).isMeshStandardMaterial ? { emissive: (source as MeshStandardMaterial).emissive.clone() } : {}) });
      }
      return copy;
    };
    mesh.material = Array.isArray(mesh.material) ? mesh.material.map(copyMaterial) : copyMaterial(mesh.material);
  });
  const mixer = new AnimationMixer(model);
  const actions = new Map<string, AnimationAction>();
  for (const clip of asset.animations) {
    for (const part of ['lower', 'upper'] as const) {
      const tracks = clip.tracks.filter((track) => lowerTrack(track.name) === (part === 'lower'));
      if (!tracks.length) continue;
      const key = `${clip.name}:${part}`;
      const action = mixer.clipAction(new AnimationClip(key, clip.duration, tracks));
      action.setLoop(clip.name === 'death' || clip.name === 'attack' ? LoopOnce : LoopRepeat, Infinity);
      action.clampWhenFinished = true;
      action.play(); action.paused = true; action.setEffectiveWeight(0);
      actions.set(key, action);
    }
  }
  for (const required of ['idle', 'walk', 'run', 'attack', 'death']) {
    if (!actions.has(`${required}:lower`) || !actions.has(`${required}:upper`)) throw new Error(`Missing Hyosan character animation: ${required}`);
  }
  const bow = model.getObjectByName('hyosan_bow');
  const nockedArrow = model.getObjectByName('hyosan_nocked_arrow');
  const equipment = bow ? createHyosanArcheryEquipment(bow) : null;
  if (equipment) materials.push({ material: equipment.material, opacity: 1, transparent: false });
  carrier.updateWorldMatrix(true, true);
  const footContact = (side: 'l' | 'r'): FootContact => {
    const foot = bones.get(`foot_${side}`)!;
    return { position: null, restRotation: foot.getWorldQuaternion(new Quaternion()), restHeight: foot.getWorldPosition(new Vector3()).y, vertices: [] };
  };
  const feet = { l: footContact('l'), r: footContact('r') };
  const hands = bow ? { l: createArcheryHand(bones, 'l'), r: createArcheryHand(bones, 'r') } : null;
  // Cache actual footwear vertices once. Body/coat/arm bounds are not a sole,
  // and the cone's rubber base is wider than its ankle contact point.
  model.traverse((object) => {
    if (!(object as SkinnedMesh).isSkinnedMesh) return;
    const mesh = object as SkinnedMesh;
    const materials = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
    const slots = new Set(materials.flatMap((material, index) => /Shoes|EunjiShoeRubber|ConeBlackRubberBase/.test(material.name) ? [index] : []));
    if (!slots.size) return;
    const indices = new Set<number>();
    if (!Array.isArray(mesh.material)) for (let index = 0; index < mesh.geometry.attributes.position.count; index++) indices.add(index);
    else for (const group of mesh.geometry.groups) if (slots.has(group.materialIndex ?? 0)) {
      for (let index = group.start; index < group.start + group.count; index++) indices.add(mesh.geometry.index?.getX(index) ?? index);
    }
    const skin = mesh.geometry.attributes.skinIndex; const weights = mesh.geometry.attributes.skinWeight;
    for (const index of indices) {
      let left = 0; let right = 0;
      for (let component = 0; component < 4; component++) {
        const name = mesh.skeleton.bones[skin.getComponent(index, component)]?.name ?? '';
        if (/^(?:foot|ball(?:_leaf)?)_l$/.test(name)) left += weights.getComponent(index, component);
        if (/^(?:foot|ball(?:_leaf)?)_r$/.test(name)) right += weights.getComponent(index, component);
      }
      if (left || right) feet[left > right ? 'l' : 'r'].vertices.push({ mesh, index });
    }
  });
  return { id, asset, carrier, model, mixer, actions, materials, skeletons, bones,
    bow, nockedArrow, equipment, arrowRest: nockedArrow?.position.clone() ?? null, bowRest: bow?.quaternion.clone() ?? null,
    bowRestPosition: bow?.position.clone() ?? null, hands,
    lastX: 0, lastZ: 0, lastTime: null, gait: 0, deathAt: null, bowWeight: 0, wasDormant: false, feet, hitPose: new Map(), archeryPose: new Map() };
}

/** Calibrate the shipped hand axes from palm landmarks, preserving the rest rig. */
function createArcheryHand(bones: Map<string, Bone>, side: 'l' | 'r'): ArcheryHand {
  const wrist = bones.get(`hand_${side}`)!;
  const index = bones.get(`index_01_${side}`)!.position;
  const middle = bones.get(`middle_01_${side}`)!.position;
  const pinky = bones.get(`pinky_01_${side}`)!.position;
  const forward = index.clone().add(middle).add(pinky).normalize();
  const up = index.clone().sub(pinky); up.addScaledVector(forward, -up.dot(forward)).normalize();
  const localBasis = new Quaternion().setFromRotationMatrix(new Matrix4().makeBasis(
    forward.clone().cross(up), forward, up));
  // Fingers point toward the bow; the thumb side points upward. The source
  // hands are mirrored, so their palm surfaces face one another in this frame.
  const aimedBasis = new Quaternion().setFromRotationMatrix(new Matrix4().makeBasis(
    new Vector3(-1, 0, 0), new Vector3(0, 0, 1), new Vector3(0, 1, 0)));
  const fingers: ArcheryHand['fingers'] = [];
  for (const finger of ['index', 'middle', 'ring', 'pinky', 'thumb']) {
    const angles = side === 'r' ? finger === 'pinky' ? [.65, 1.3, .7]
      : finger === 'thumb' ? [.25, .45, .3] : [.15, 1.15, .7]
      : finger === 'thumb' ? [.1, .25, .25] : finger === 'index' ? [.2, .75, .4] : [.4, .9, .5];
    for (let part = 1; part <= 3; part++) {
      const bone = bones.get(`${finger}_0${part}_${side}`)!;
      const open = bone.quaternion.clone();
      fingers.push({ bone, open, curled: open.clone().multiply(
        new Quaternion().setFromAxisAngle(new Vector3(1, 0, 0), angles[part - 1])) });
    }
  }
  return { wrist, orientation: aimedBasis.multiply(localBasis.invert()),
    palm: index.clone().add(bones.get(`thumb_01_${side}`)!.position).multiplyScalar(.5),
    hook: bones.get(`middle_02_${side}`)!, fingers };
}

function poseArcheryFingers(hand: ArcheryHand, curl: number, weight: number) {
  for (const { bone, open, curled } of hand.fingers) {
    scratch.rotation.copy(open).slerp(curled, curl);
    bone.quaternion.slerp(scratch.rotation, weight);
  }
}

function orientWrist(hand: ArcheryHand, world: Quaternion, weight: number) {
  hand.wrist.parent!.getWorldQuaternion(scratch.parent).invert();
  scratch.rotation.copy(scratch.parent).multiply(world);
  hand.wrist.quaternion.slerp(scratch.rotation, weight);
  hand.wrist.updateWorldMatrix(false, true);
}

/** Release owned clones only; useGLTF continues to own shared geometry/textures. */
function disposeRig(rig: ActorRig) {
  rig.carrier.removeFromParent();
  rig.mixer.stopAllAction(); rig.mixer.uncacheRoot(rig.model);
  for (const copy of rig.materials) copy.material.dispose();
  for (const skeleton of rig.skeletons) skeleton.dispose();
  rig.equipment?.dispose();
}

function aimBone(bone: Bone, child: Bone, target: Vector3) {
  bone.getWorldPosition(scratch.start);
  child.getWorldPosition(scratch.current).sub(scratch.start).normalize();
  scratch.wanted.copy(target).sub(scratch.start).normalize();
  scratch.rotation.setFromUnitVectors(scratch.current, scratch.wanted);
  bone.getWorldQuaternion(scratch.world).premultiply(scratch.rotation);
  bone.parent!.getWorldQuaternion(scratch.parent).invert();
  bone.quaternion.copy(scratch.parent).multiply(scratch.world);
  bone.updateWorldMatrix(false, true);
}

/** Two-bone world-space solution retains source segment lengths and visible elbow bend. */
function poseLimb(rig: ActorRig, names: readonly [string, string, string], target: Vector3, pole: Vector3, weight: number) {
  const upper = rig.bones.get(names[0]);
  const lower = rig.bones.get(names[1]);
  const hand = rig.bones.get(names[2]);
  if (!upper || !lower || !hand) return;
  upper.getWorldPosition(scratch.start);
  lower.getWorldPosition(scratch.joint);
  hand.getWorldPosition(scratch.end);
  const a = scratch.start.distanceTo(scratch.joint);
  const b = scratch.joint.distanceTo(scratch.end);
  scratch.target.copy(scratch.end).lerp(target, weight);
  scratch.axis.copy(scratch.target).sub(scratch.start);
  const length = Math.min(a + b - 0.002, Math.max(Math.abs(a - b) + 0.002, scratch.axis.length()));
  scratch.axis.normalize();
  const along = (a * a - b * b + length * length) / (2 * length);
  scratch.pole.copy(pole).sub(scratch.start);
  scratch.pole.addScaledVector(scratch.axis, -scratch.pole.dot(scratch.axis)).normalize();
  scratch.elbow.copy(scratch.start).addScaledVector(scratch.axis, along)
    .addScaledVector(scratch.pole, Math.sqrt(Math.max(0, a * a - along * along)));
  // aimBone shares scratch vectors, so preserve the actual wrist goal first.
  const wrist = scratch.target.clone();
  aimBone(upper, lower, scratch.elbow);
  aimBone(lower, hand, wrist);
}

/** Preserve the aimed chest while hips and the feet follow the real velocity. */
function poseDirectionalLegs(rig: ActorRig, gait: DirectionalGait) {
  rig.carrier.updateWorldMatrix(true, true);
  const pelvis = rig.bones.get('pelvis')!;
  const spine = rig.bones.get('spine_01')!;
  const center = rig.carrier.worldToLocal(pelvis.getWorldPosition(new Vector3()));
  const chestRotation = spine.getWorldQuaternion(new Quaternion());
  const footGoals = (['l', 'r'] as const).map((side) => {
    const foot = rig.bones.get(`foot_${side}`)!;
    const source = rig.carrier.worldToLocal(foot.getWorldPosition(new Vector3()));
    const offset = directionalFootOffset(source.x - center.x, source.z - center.z, gait);
    return { side, foot, sourceY: source.y, target: new Vector3(center.x + offset.x, source.y, center.z + offset.z),
      rotation: foot.getWorldQuaternion(new Quaternion()) };
  });
  const hipRotation = new Quaternion().setFromAxisAngle(new Vector3(0, 1, 0), gait.hipYaw);
  pelvis.getWorldQuaternion(scratch.world).premultiply(hipRotation);
  pelvis.parent!.getWorldQuaternion(scratch.parent).invert();
  pelvis.quaternion.copy(scratch.parent).multiply(scratch.world);
  pelvis.updateWorldMatrix(false, true);
  spine.parent!.getWorldQuaternion(scratch.parent).invert();
  spine.quaternion.copy(scratch.parent).multiply(chestRotation);
  spine.updateWorldMatrix(false, true);

  for (const { side, foot, sourceY, target, rotation } of footGoals) {
    const contact = rig.feet[side];
    const upper = rig.bones.get(`thigh_${side}`)!;
    const lower = rig.bones.get(`calf_${side}`)!;
    const hip = upper.getWorldPosition(new Vector3());
    const knee = lower.getWorldPosition(new Vector3());
    const length = hip.distanceTo(knee) + knee.distanceTo(foot.getWorldPosition(new Vector3())) - 0.002;
    // The low part of this run cycle is the stance, the high arc is the swing.
    const grounded = sourceY < 0.19;
    const weight = Math.min(1, Math.max(0, (0.25 - sourceY) / 0.08));
    target.y += (contact.restHeight - target.y) * weight;
    rig.carrier.localToWorld(target);
    const surface = surfaces.sample(target);
    const ground = surface?.height ?? 0;
    if (Math.abs(ground - rig.carrier.position.y) < .4) target.y += (ground - rig.carrier.position.y) * weight;
    if (!grounded) contact.position = null;
    const horizontalReach = Math.sqrt(Math.max(0, length * length - (hip.y - target.y) ** 2));
    const reach = Math.hypot(target.x - hip.x, target.z - hip.z);
    if (reach > horizontalReach) {
      target.x = hip.x + (target.x - hip.x) * horizontalReach / reach;
      target.z = hip.z + (target.z - hip.z) * horizontalReach / reach;
    }
    if (grounded) {
      if (!contact.position || contact.position.distanceTo(hip) > length) contact.position = target.clone();
      target.copy(contact.position);
    }
    const pole = rig.carrier.localToWorld(new Vector3((side === 'l' ? 0.16 : -0.16) + gait.right * 0.12, 0.55, 1));
    poseLimb(rig, [`thigh_${side}`, `calf_${side}`, `foot_${side}`], target, pole, 1);
    const normal = new Vector3(-Number(surface?.slopeX ?? 0), 1, -Number(surface?.slopeZ ?? 0)).normalize();
    const plantedRotation = new Quaternion().setFromUnitVectors(new Vector3(0, 1, 0), normal)
      .multiply(rig.carrier.getWorldQuaternion(new Quaternion())).multiply(hipRotation).multiply(contact.restRotation);
    rotation.slerp(plantedRotation, weight);
    foot.parent!.getWorldQuaternion(scratch.parent).invert();
    foot.quaternion.copy(scratch.parent).multiply(rotation);
    foot.updateWorldMatrix(false, true);
  }
}

/** Both feet meet the authored slope; the body remains on the physics capsule. */
function poseSurfaceFeet(rig: ActorRig) {
  const bodySurface = surfaces.sample(rig.carrier.position);
  if (!bodySurface || bodySurface.kind === 'floor') { poseSupportFootwear(rig); return; }
  rig.carrier.updateWorldMatrix(true, true);
  for (const side of ['l', 'r'] as const) {
    const foot = rig.bones.get(`foot_${side}`)!;
    const target = foot.getWorldPosition(new Vector3());
    const relativeY = target.y - rig.carrier.position.y;
    const weight = Math.min(1, Math.max(0, (.25 - relativeY) / .08));
    if (weight <= 0) continue;
    const surface = surfaces.sample(target);
    // A swinging toe over the edge does not reach down to an unrelated floor.
    if (!surface || Math.abs(surface.height - rig.carrier.position.y) > .4) continue;
    const rotation = foot.getWorldQuaternion(new Quaternion());
    target.y += (surface.height + rig.feet[side].restHeight - target.y) * weight;
    const pole = rig.carrier.localToWorld(new Vector3(side === 'l' ? .16 : -.16, .55, 1));
    poseLimb(rig, [`thigh_${side}`, `calf_${side}`, `foot_${side}`], target, pole, 1);
    const normal = new Vector3(-surface.slopeX, 1, -surface.slopeZ).normalize();
    const slope = new Quaternion().setFromUnitVectors(new Vector3(0, 1, 0), normal);
    const planted = slope.multiply(rig.carrier.getWorldQuaternion(new Quaternion())).multiply(rig.feet[side].restRotation);
    rotation.slerp(planted, weight);
    foot.parent!.getWorldQuaternion(scratch.parent).invert();
    foot.quaternion.copy(scratch.parent).multiply(rotation);
    foot.updateWorldMatrix(false, true);
  }
  poseSupportFootwear(rig);
}

/** Real toes and soles clear stairs and ramps, including a planted/swinging
 * foot ahead of the ankle. This changes only leg pose, never the body capsule. */
function poseSupportFootwear(rig: ActorRig) {
  const body = rig.carrier.position;
  if (!footwearSurfaces.some(surface => Math.abs(body.x - surface.x) <= surface.width / 2 + .4
    && Math.abs(body.z - surface.z) <= surface.depth / 2 + .4)) return;
  rig.carrier.updateMatrixWorld(true);
  const vertex = new Vector3();
  for (const side of ['l', 'r'] as const) {
    const foot = rig.bones.get(`foot_${side}`)!;
    const contact = rig.feet[side];
    for (let iteration = 0; iteration < 4; iteration++) {
      let lift = 0;
      for (const point of contact.vertices) {
        point.mesh.getVertexPosition(point.index, vertex).applyMatrix4(point.mesh.matrixWorld);
        const surface = surfaces.sample(vertex);
        if (surface && Math.abs(surface.height - body.y) < .5) lift = Math.max(lift, surface.height + .005 - vertex.y);
      }
      if (lift <= .001) break;
      const target = foot.getWorldPosition(new Vector3());
      target.y += lift;
      const rotation = foot.getWorldQuaternion(new Quaternion());
      const pole = rig.carrier.localToWorld(new Vector3(side === 'l' ? .16 : -.16, .55, 1));
      poseLimb(rig, [`thigh_${side}`, `calf_${side}`, `foot_${side}`], target, pole, 1);
      foot.parent!.getWorldQuaternion(scratch.parent).invert();
      foot.quaternion.copy(scratch.parent).multiply(rotation);
      rig.carrier.updateMatrixWorld(true);
    }
    if (contact.position) contact.position.copy(foot.getWorldPosition(vertex));
  }
}

function setOpacity(rig: ActorRig, opacity: number) {
  for (const copy of rig.materials) {
    const transparent = opacity < 0.999 || copy.transparent;
    if (copy.material.transparent !== transparent) { copy.material.transparent = transparent; copy.material.needsUpdate = true; }
    copy.material.opacity = copy.opacity * opacity;
  }
}

function hideRig(rig: ActorRig) { rig.carrier.visible = false; }

const hitTint = new Color('#ebe4d6');
const hurtTint = new Color('#b55045');

/** One brief contact response on the damaged body. Feet, aim and physics stay authoritative. */
function poseHitReaction(rig: ActorRig, state: Hyosan3DSnapshot, enemy: Readonly<Hyosan3DEnemy> | undefined) {
  const actor = enemy ?? state.player;
  const contact = actor.hp > 0 && !enemy?.dormant && !reunionPlaying(state.ending)
    ? state.effects.findLast(effect => effect.actorId === rig.id && (effect.kind === 'hit' || effect.kind === 'hurt')
      && state.time >= effect.startedAt && state.time - effect.startedAt < .24) : undefined;
  const weight = contact ? (1 - (state.time - contact.startedAt) / .24) ** 2 : 0;
  for (const copy of rig.materials) if (copy.emissive) {
    (copy.material as MeshStandardMaterial).emissive.copy(copy.emissive).lerp(enemy ? hitTint : hurtTint,
      weight * (enemy?.kind === 'boss' ? .09 : enemy ? .14 : .2));
  }
  if (!contact) return;
  rig.carrier.updateWorldMatrix(true, true);
  const spine = rig.bones.get('spine_01');
  // The archer's aimed arms stay locked to the release direction. While firing,
  // a head/colour response communicates damage without deflecting the bow.
  if (spine && (enemy || rig.bowWeight < .01)) {
    rig.hitPose.set(spine, spine.quaternion.clone());
    const x = contact.directionX ?? -Math.sin(actor.yaw);
    const z = contact.directionZ ?? -Math.cos(actor.yaw);
    scratch.axis.set(z, 0, -x).normalize();
    scratch.rotation.setFromAxisAngle(scratch.axis, weight * (enemy?.kind === 'boss' ? .045 : enemy ? .16 : .075));
    spine.getWorldQuaternion(scratch.world).premultiply(scratch.rotation);
    spine.parent!.getWorldQuaternion(scratch.parent).invert();
    spine.quaternion.copy(scratch.parent).multiply(scratch.world);
    spine.updateWorldMatrix(false, true);
  }
  const head = rig.bones.get('Head');
  if (head) { rig.hitPose.set(head, head.quaternion.clone()); head.rotation.x += weight * .075; head.updateWorldMatrix(false, true); }
}

function resetBowPose(rig: ActorRig) {
  if (rig.bow && rig.bowRest) rig.bow.quaternion.copy(rig.bowRest);
  if (rig.bow && rig.bowRestPosition) rig.bow.position.copy(rig.bowRestPosition);
  if (rig.nockedArrow && rig.arrowRest) rig.nockedArrow.position.copy(rig.arrowRest);
  rig.equipment?.updateDraw(0);
}

function sample(rig: ActorRig, lower: string, upper: string, lowerPhase: number, upperPhase: number, dt: number, snap: boolean) {
  const blend = snap ? 1 : 1 - Math.exp(-dt / 0.075);
  for (const [key, action] of rig.actions) {
    const selected = key === `${lower}:lower` || key === `${upper}:upper`;
    action.setEffectiveWeight(action.getEffectiveWeight() + (Number(selected) - action.getEffectiveWeight()) * blend);
    if (selected) {
      const phase = key.endsWith(':lower') ? lowerPhase : upperPhase;
      action.time = Math.max(0, Math.min(0.99999, phase)) * action.getClip().duration;
    }
  }
  rig.mixer.update(0);
}

function updateRig(rig: ActorRig, state: Hyosan3DSnapshot, enemy: Readonly<Hyosan3DEnemy> | undefined, time: number, dt: number, reset: boolean) {
  // A paused animation action may skip writing an unchanged track. Remove the
  // previous additive contact pose before sampling so it cannot accumulate.
  for (const [bone, rotation] of rig.hitPose) bone.quaternion.copy(rotation);
  rig.hitPose.clear();
  for (const [bone, rotation] of rig.archeryPose) bone.quaternion.copy(rotation);
  rig.archeryPose.clear();
  if (enemy?.dormant) { rig.wasDormant = true; hideRig(rig); return; }
  // A reused boss rig may still contain its previous death action. Its first
  // visible pose must snap, even when the simulation reset occurred while hidden.
  reset ||= rig.wasDormant;
  rig.wasDormant = false;
  const actor = enemy ?? state.player;
  if (reset) { rig.gait = 0; rig.bowWeight = 0; resetBowPose(rig); }
  const dead = actor.hp <= 0;
  if (rig.bow) rig.bow.visible = true;
  rig.equipment?.updateLevel(state.bow.level);
  const dx = reset ? 0 : actor.x - rig.lastX;
  const dz = reset ? 0 : actor.z - rig.lastZ;
  const travelled = Math.hypot(dx, dz);
  if (reset || dead || travelled < 0.00001) { rig.feet.l.position = null; rig.feet.r.position = null; }
  rig.lastX = actor.x; rig.lastZ = actor.z;
  rig.carrier.position.set(actor.x, actor.y, actor.z);
  rig.carrier.rotation.y = actor.yaw;
  if (reset || !dead) rig.deathAt = null;
  if (dead && rig.deathAt === null) rig.deathAt = enemy?.defeatedAt ?? time;
  const deathAge = rig.deathAt === null ? 0 : Math.max(0, time - rig.deathAt);
  const remains = dead && enemy?.kind === 'boss';
  rig.carrier.visible = !dead || remains || deathAge < 1.2;
  setOpacity(rig, dead && !remains ? Math.max(0, 1 - Math.max(0, deathAge - 0.65) / 0.55) : 1);
  if (!rig.carrier.visible) return;

  if (dead) {
    const fallDuration = enemy?.profile === 'eunji' || enemy?.profile === 'daewon' || enemy?.profile === 'gwinam-human' || enemy?.profile === 'gwinam-halfbie' ? rig.actions.get('death:lower')!.getClip().duration : 1.15;
    sample(rig, 'death', 'death', deathAge / fallDuration, deathAge / fallDuration, dt, reset);
    if (rig.nockedArrow) rig.nockedArrow.visible = false;
    return;
  }
  if (!enemy && reunionPlaying(state.ending)) {
    rig.carrier.rotation.y = Math.atan2(HYOSAN_REUNION.namra.x - actor.x, HYOSAN_REUNION.namra.z - actor.z);
    const phase = ((state.ending?.elapsed ?? state.ending?.time ?? 0) / rig.actions.get('idle:lower')!.getClip().duration) % 1;
    sample(rig, 'idle', 'idle', phase, phase, dt, true);
    if (rig.bow) rig.bow.visible = false;
    if (rig.nockedArrow) rig.nockedArrow.visible = false;
    poseSurfaceFeet(rig); return;
  }
  if (enemy?.profile === 'gwinam-halfbie' && enemy.rooftopBeat) {
    const beat = enemy.rooftopBeat;
    const moving = beat === 'stalk' && travelled > .00001;
    if (moving) rig.gait += travelled / 1.1;
    const clip = beat === 'stalk' && !moving ? 'idle' : beat;
    const phase = clip === 'idle' ? (time / rig.actions.get('idle:lower')!.getClip().duration) % 1
      : moving ? rig.gait % 1 : enemy.attackProgress;
    sample(rig, clip, clip, phase, phase, dt, reset);
    poseSurfaceFeet(rig); return;
  }
  if (enemy?.profile === 'eunji' && enemy.staffroomBeat) {
    const beat = enemy.staffroomBeat;
    const walking = beat === 'investigate' || beat === 'return';
    const clip = walking ? 'walk' : beat;
    if (walking || beat === 'pursuit') rig.gait += travelled / (walking ? 1.15 : 1.6);
    const phase = beat === 'idle' ? (time / rig.actions.get('idle:lower')!.getClip().duration) % 1
      : walking || beat === 'pursuit' ? rig.gait % 1 : enemy.attackProgress;
    sample(rig, clip, clip, phase, phase, dt, reset); poseSurfaceFeet(rig); return;
  }
  if (enemy?.profile === 'gwinam-human' && enemy.libraryBeat) {
    const beat = enemy.libraryBeat;
    if (beat === 'stalk') rig.gait += travelled / 1.1;
    const phase = beat === 'stalk' ? rig.gait % 1 : enemy.attackProgress;
    const lateral = beat === 'sidestep' && travelled > .00001 && directionalGait(dx, dz, actor.yaw).right < 0;
    sample(rig, beat, beat, lateral ? 1 - phase : phase, phase, dt, reset);
    poseSurfaceFeet(rig); return;
  }
  if (enemy?.profile === 'daewon' && enemy.broadcastBeat) {
    const beat = enemy.broadcastBeat;
    if (beat === 'limp') rig.gait += travelled / .8;
    const phase = beat === 'limp' ? rig.gait % 1 : enemy.attackProgress;
    sample(rig, beat, beat, phase, phase, dt, reset);
    poseSurfaceFeet(rig); return;
  }
  if (enemy?.profile === 'jingu' && enemy.classroomBeat) {
    const beat = enemy.classroomBeat;
    const rushing = beat === 'rush';
    const clip = rushing ? 'ram' : beat;
    if (rushing) rig.gait += travelled / 2.6;
    sample(rig, rushing ? 'run' : clip, clip, rushing ? rig.gait % 1 : enemy.attackProgress,
      enemy.attackProgress, dt, reset);
    poseSurfaceFeet(rig); return;
  }
  if (enemy?.profile === 'hyunju' && enemy.scienceBeat) {
    const beat = enemy.scienceBeat;
    const chasing = beat === 'approach' || beat === 'pursuit';
    const clip = chasing ? 'pursuit' : beat === 'bite-windup' || beat === 'bite' ? 'bite' : beat;
    if (rig.actions.has(`${clip}:lower`)) {
      if (chasing) rig.gait += travelled / 1.8;
      const phase = chasing ? rig.gait % 1 : beat === 'bite-windup' ? enemy.attackProgress * .45
        : beat === 'bite' ? .45 + enemy.attackProgress * .55 : enemy.attackProgress;
      sample(rig, clip, clip, phase, phase, dt, reset); poseSurfaceFeet(rig); return;
    }
  }
  const attacking = enemy && enemy.attackPhase !== 'idle';
  if (attacking) {
    const progress = enemy.attackPhase === 'windup' ? enemy.attackProgress * 0.38
      : enemy.attackPhase === 'strike' ? 0.38 + enemy.attackProgress * 0.24 : 0.62 + enemy.attackProgress * 0.38;
    const rushing = enemy.attackStyle === 'charge' && enemy.attackPhase === 'strike';
    if (rushing) rig.gait += travelled / 3.2;
    sample(rig, rushing ? 'run' : 'attack', 'attack', rushing ? rig.gait % 1 : progress, progress, dt, reset);
    if (enemy.comboBeat === 'tremor') {
      // A visible shoulder/head tremor precedes movement; it never shifts the
      // collider or follows the target after the warning direction is locked.
      const head = rig.bones.get('Head');
      if (head) head.rotation.z += Math.sin(enemy.attackProgress * Math.PI * 12) * .035;
    }
    if (enemy.comboBeat === 'sweep-windup' || enemy.comboBeat === 'sweep') {
      rig.carrier.updateWorldMatrix(true, true);
      const arc = enemy.comboBeat === 'sweep-windup' ? -1.25 : -1.25 + enemy.attackProgress * 2.5;
      const hand = rig.carrier.localToWorld(new Vector3(Math.sin(arc) * .88, 1.25, Math.cos(arc) * .88));
      const elbow = rig.carrier.localToWorld(new Vector3(-.62, 1.38, .12));
      poseLimb(rig, ['upperarm_r', 'lowerarm_r', 'hand_r'], hand, elbow, 1);
    }
    poseSurfaceFeet(rig);
    return;
  }
  const moving = enemy ? travelled > 0.001 : state.player.moving;
  const gait = !moving ? 'idle' : enemy ? rig.actions.has('zombie_walk:lower') ? 'zombie_walk' : 'walk' : 'run';
  const duration = rig.actions.get(`${gait}:lower`)!.getClip().duration;
  const direction = directionalGait(dx, dz, actor.yaw);
  rig.gait += moving ? enemy ? travelled / 1.15 : direction.phaseAdvance : dt / duration;
  const phase = rig.gait % 1;
  const sinceShot = time - state.player.shotTime;
  const releaseTime = Math.min(.07, state.bow.interval * .24);
  const drawEnd = Math.max(releaseTime + 1 / 60, state.bow.interval - .025);
  const drawProgress = Math.min(1, Math.max(0, (sinceShot - releaseTime) / (drawEnd - releaseTime)));
  const drawn = drawProgress * drawProgress * (3 - 2 * drawProgress);
  const shooting = !enemy && state.player.shotTime >= 0 && sinceShot >= 0 && sinceShot < Math.max(.4, state.bow.interval + .12);
  const bowClip = sinceShot < releaseTime ? 'archery_release' : 'archery_draw';
  const idleZombie = enemy && !moving && rig.actions.has('zombie_walk:upper');
  const upper = shooting && rig.actions.has(`${bowClip}:upper`) ? bowClip : idleZombie ? 'zombie_walk' : gait;
  const bowPhase = sinceShot < releaseTime ? .25 + sinceShot / releaseTime * .5 : .05 + drawn * .9;
  sample(rig, gait, upper, phase, shooting ? bowPhase : idleZombie ? 0.18 + Math.sin(state.time * 0.8) * 0.025 : phase, dt, reset);
  if (enemy) { poseSurfaceFeet(rig); return; }
  if (moving && travelled > 0.00001) poseDirectionalLegs(rig, direction);
  if (!moving) poseSurfaceFeet(rig);
  else poseSupportFootwear(rig);
  rig.bowWeight += (Number(shooting) - rig.bowWeight) * (reset ? 1 : 1 - Math.exp(-dt / 0.055));
  if (rig.bowWeight > 0.001) {
    const chest = rig.bones.get('spine_01')!;
    const head = rig.bones.get('Head')!;
    rig.archeryPose.set(chest, chest.quaternion.clone());
    rig.archeryPose.set(head, head.quaternion.clone());
    rig.carrier.updateWorldMatrix(true, true);
    const headRotation = head.getWorldQuaternion(new Quaternion());
    chest.getWorldQuaternion(scratch.world).premultiply(new Quaternion().setFromAxisAngle(new Vector3(0, 1, 0), -.7 * rig.bowWeight));
    chest.parent!.getWorldQuaternion(scratch.parent).invert();
    chest.quaternion.copy(scratch.parent).multiply(scratch.world);
    chest.updateWorldMatrix(false, true);
    head.parent!.getWorldQuaternion(scratch.parent).invert();
    head.quaternion.copy(scratch.parent).multiply(headRotation);
    rig.carrier.updateWorldMatrix(true, true);
    const pitch = new Quaternion().setFromAxisAngle(new Vector3(1, 0, 0), -state.player.aimPitch);
    const aimed = (point: Vector3) => {
      point.y -= HYOSAN_BOW_HEIGHT; point.applyQuaternion(pitch); point.y += HYOSAN_BOW_HEIGHT;
      return rig.carrier.localToWorld(point);
    };
    const aimedRotation = rig.carrier.getWorldQuaternion(new Quaternion()).multiply(pitch);
    const leftRotation = rig.hands ? aimedRotation.clone().multiply(rig.hands.l.orientation) : null;
    const rightRotation = rig.hands ? aimedRotation.clone().multiply(rig.hands.r.orientation) : null;
    if (rig.hands && rig.bow && rig.bowRestPosition) {
      poseArcheryFingers(rig.hands.l, 1, rig.bowWeight);
      // The draw hand opens at release, then hooks the string for the next draw.
      poseArcheryFingers(rig.hands.r, sinceShot < releaseTime ? .08 : 1, rig.bowWeight);
      rig.bow.position.copy(rig.bowRestPosition).lerp(rig.hands.l.palm, rig.bowWeight);
    }
    const left = aimed(new Vector3(0, HYOSAN_BOW_HEIGHT - .012, .51));
    if (leftRotation && rig.bow) left.sub(rig.bow.position.clone().applyQuaternion(leftRotation));
    // Retract along the flight axis when a raised bow exceeds the short source
    // arm's reach. Clamping toward the shoulder would lower the visible arrow
    // below its physical trajectory.
    const shoulder = rig.bones.get('upperarm_l')!.getWorldPosition(new Vector3());
    const elbow = rig.bones.get('lowerarm_l')!.getWorldPosition(new Vector3());
    const reach = shoulder.distanceTo(elbow) + elbow.distanceTo(rig.bones.get('hand_l')!.getWorldPosition(new Vector3())) - .005;
    const flight = new Vector3(0, 0, 1).applyQuaternion(aimedRotation);
    const offset = left.clone().sub(shoulder);
    const along = offset.dot(flight);
    const furthest = Math.sqrt(Math.max(0, reach * reach - offset.lengthSq() + along * along));
    if (along > furthest) left.addScaledVector(flight, furthest - along);
    const leftPole = aimed(new Vector3(0.4, 1.18, 0.06));
    const rightPole = aimed(new Vector3(-0.12, 1.34, -0.5));
    poseLimb(rig, ['upperarm_l', 'lowerarm_l', 'hand_l'], left, leftPole, rig.bowWeight);
    if (rig.hands && leftRotation) orientWrist(rig.hands.l, leftRotation, rig.bowWeight);
    if (rig.bow) {
      rig.bow.parent!.getWorldQuaternion(scratch.parent).invert();
      rig.carrier.getWorldQuaternion(scratch.world);
      scratch.world.multiply(pitch);
      rig.bow.quaternion.copy(scratch.parent).multiply(scratch.world);
      rig.bow.updateWorldMatrix(false, true);
    }
    rig.equipment?.updateDraw(drawn);
    const right = rig.bow && rig.equipment ? rig.bow.localToWorld(new Vector3(0, 0, rig.equipment.braceZ - drawn * rig.equipment.drawDistance))
      : rig.carrier.localToWorld(new Vector3(0.07, 1.34, 0.101 - drawn * 0.22));
    if (rig.hands && rightRotation) {
      // Align a finger joint with the string; a wrist target leaves the entire
      // palm beyond the string even when the arm IK itself is exact.
      rig.hands.r.wrist.updateWorldMatrix(true, true);
      const contact = rig.hands.r.wrist.worldToLocal(rig.hands.r.hook.getWorldPosition(new Vector3()));
      const basis = rightRotation.clone();
      const forward = new Vector3(0, 0, 1).applyQuaternion(aimedRotation);
      // The wrist and elbow constrain one another. A short positional solve
      // follows the forearm without allowing the hooked fingers to drift.
      for (let pass = 0; pass < 12; pass++) {
        const wrist = right.clone().sub(contact.clone().applyQuaternion(rightRotation));
        poseLimb(rig, ['upperarm_r', 'lowerarm_r', 'hand_r'], wrist, rightPole, rig.bowWeight);
        orientWrist(rig.hands.r, rightRotation, rig.bowWeight);
        if (pass < 11) {
          const direction = rig.hands.r.wrist.getWorldPosition(new Vector3())
            .sub(rig.bones.get('lowerarm_r')!.getWorldPosition(new Vector3())).normalize();
          const aligned = new Quaternion().setFromUnitVectors(forward, direction).multiply(basis);
          rightRotation.slerp(aligned, .25);
        }
      }
    } else poseLimb(rig, ['upperarm_r', 'lowerarm_r', 'hand_r'], right, rightPole, rig.bowWeight);
    if (rig.nockedArrow && rig.arrowRest && rig.equipment) rig.nockedArrow.position.copy(rig.arrowRest).add(new Vector3(0, 0, -drawn * rig.equipment.drawDistance));
  } else resetBowPose(rig);
  if (rig.nockedArrow) rig.nockedArrow.visible = shooting && sinceShot > releaseTime + .012;
}

export interface Hyosan3DActorsProps {
  simulation: Hyosan3DPlayRuntime;
  studentUrl: string;
  zombieUrl: string;
  nurseUrl: string;
  hyunjuUrl?: string;
  jinguUrl?: string;
  daewonUrl?: string;
  gwinamHumanUrl?: string;
  eunjiUrl?: string;
  gwinamHalfbieUrl?: string;
}

/** The rendered roster is exactly the shared combat roster. */
function renderedEnemies(snapshot: Hyosan3DSnapshot) {
  const enemies = new Map<string, { enemy: Readonly<Hyosan3DEnemy>; time: number }>();
  for (const enemy of snapshot.enemies) enemies.set(enemy.id, { enemy, time: snapshot.time });
  return enemies;
}

/** useGLTF suspends until real rigged assets are ready; no geometric stand-ins. */
export function Actors({ simulation, studentUrl, zombieUrl, nurseUrl, hyunjuUrl, jinguUrl, daewonUrl, gwinamHumanUrl, eunjiUrl, gwinamHalfbieUrl }: Hyosan3DActorsProps) {
  const loaded = useGLTF([studentUrl, zombieUrl, nurseUrl, ...(hyunjuUrl ? [hyunjuUrl] : []), ...(jinguUrl ? [jinguUrl] : []), ...(daewonUrl ? [daewonUrl] : []), ...(gwinamHumanUrl ? [gwinamHumanUrl] : []), ...(eunjiUrl ? [eunjiUrl] : []), ...(gwinamHalfbieUrl ? [gwinamHalfbieUrl] : [])]);
  const [student, zombie, nurse] = loaded;
  const hyunju = hyunjuUrl ? loaded[3] : undefined;
  const jingu = jinguUrl ? loaded[hyunjuUrl ? 4 : 3] : undefined;
  const daewon = daewonUrl ? loaded[3 + Number(Boolean(hyunjuUrl)) + Number(Boolean(jinguUrl))] : undefined;
  const gwinam = gwinamHumanUrl ? loaded[3 + Number(Boolean(hyunjuUrl)) + Number(Boolean(jinguUrl)) + Number(Boolean(daewonUrl))] : undefined;
  const eunji = eunjiUrl ? loaded[3 + Number(Boolean(hyunjuUrl)) + Number(Boolean(jinguUrl)) + Number(Boolean(daewonUrl)) + Number(Boolean(gwinamHumanUrl))] : undefined;
  const halfbie = gwinamHalfbieUrl ? loaded[3 + Number(Boolean(hyunjuUrl)) + Number(Boolean(jinguUrl)) + Number(Boolean(daewonUrl)) + Number(Boolean(gwinamHumanUrl)) + Number(Boolean(eunjiUrl))] : undefined;
  const assetFor = useCallback((enemy: Readonly<Hyosan3DEnemy>) => {
    const profiles = { eunji, 'gwinam-human': gwinam, 'gwinam-halfbie': halfbie, daewon, jingu, hyunju };
    const asset = enemy.profile ? profiles[enemy.profile] : enemy.kind === 'boss' ? nurse : zombie;
    if (!asset) throw new Error(`Missing Hyosan actor asset: ${enemy.profile}`);
    return asset;
  }, [eunji, gwinam, halfbie, daewon, jingu, hyunju, nurse, zombie]);
  const container = useRef<Group>(null);
  const runtime = useRef<{ rigs: Map<string, ActorRig> } | null>(null);
  useLayoutEffect(() => {
    const parent = container.current!;
    const snapshot = simulation.read();
    const rigs = new Map<string, ActorRig>();
    const initialRigs = [createRig(student, 'player'), ...[...renderedEnemies(snapshot).values()].map(({ enemy }) =>
      createRig(assetFor(enemy), enemy.id))];
    for (const rig of initialRigs) { rigs.set(rig.id, rig); parent.add(rig.carrier); }
    const current = { rigs };
    runtime.current = current;
    return () => {
      if (runtime.current === current) runtime.current = null;
      for (const rig of current.rigs.values()) disposeRig(rig);
      current.rigs.clear();
    };
  }, [simulation, student, assetFor]);
  useFrame(() => {
    const current = runtime.current;
    if (!current) return;
    const snapshot = simulation.read();
    const enemies = renderedEnemies(snapshot);
    // A region can publish a different roster at the same simulation timestamp.
    // Retire its actual resources before the repeated-frame guard can return.
    for (const [id, rig] of current.rigs) {
      if (id === 'player') continue;
      const enemy = enemies.get(id)?.enemy;
      if (!enemy || rig.asset !== assetFor(enemy)) {
        disposeRig(rig); current.rigs.delete(id);
      }
    }
    for (const { enemy } of enemies.values()) {
      if (current.rigs.has(enemy.id)) continue;
      const rig = createRig(assetFor(enemy), enemy.id);
      current.rigs.set(enemy.id, rig); container.current!.add(rig.carrier);
    }
    for (const rig of current.rigs.values()) {
      const entry = enemies.get(rig.id);
      const time = entry?.time ?? (reunionPlaying(snapshot.ending) ? snapshot.time + 1 + (snapshot.ending?.elapsed ?? snapshot.ending?.time ?? 0) : snapshot.time);
      const placedAtSameTime = rig.id === 'player' && time === rig.lastTime
        && (snapshot.player.x !== rig.lastX || snapshot.player.z !== rig.lastZ);
      const reset = rig.lastTime === null || time < rig.lastTime || placedAtSameTime;
      // Repeated render frames preserve the last sampled shared simulation pose.
      if (!reset && rig.lastTime === time) continue;
      const dt = reset ? 0 : Math.min(0.1, time - rig.lastTime!);
      updateRig(rig, snapshot, entry?.enemy, time, dt, reset);
      poseHitReaction(rig, snapshot, entry?.enemy);
      rig.lastTime = time;
    }
  });
  return <group ref={container} dispose={null} />;
}

export default Actors;
