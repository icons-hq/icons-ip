import layout from '@/docs/games/hyosan-memories-3d/world-layout.json';

const OUTSIDE_Y = -.52;
const EXCAVATED_Y = -3.52;

export function SchoolGround({ cameraOffset }: { cameraOffset: Readonly<{ x: number; y: number; z: number }> }) {
  // This is scenery beneath the authored floors, never collision geometry.
  // Sweep each opening toward the camera so the higher surround cannot hide
  // a lower actor before the sightline reaches the authored cutout itself.
  const rise = OUTSIDE_Y - EXCAVATED_Y;
  const projectedX = cameraOffset.x / cameraOffset.y * rise;
  const projectedZ = cameraOffset.z / cameraOffset.y * rise;
  const edgeMargin = .08;
  const rooftopOpenings = [
    ...layout.floors.filter((floor) => floor.id.startsWith('rooftop-') && (floor.y ?? 0) < OUTSIDE_Y)
      .map((floor) => ({ minX: floor.x - floor.width / 2, maxX: floor.x + floor.width / 2,
        minZ: floor.z - floor.depth / 2, maxZ: floor.z + floor.depth / 2 })),
    ...layout.stairs.filter((stair) => stair.id.startsWith('rooftop-') && Math.min(stair.start.y, stair.end.y) < OUTSIDE_Y)
      .map((stair) => ({ minX: Math.min(stair.start.x, stair.end.x) - (stair.start.x === stair.end.x ? stair.width / 2 : 0),
        maxX: Math.max(stair.start.x, stair.end.x) + (stair.start.x === stair.end.x ? stair.width / 2 : 0),
        minZ: Math.min(stair.start.z, stair.end.z) - (stair.start.z === stair.end.z ? stair.width / 2 : 0),
        maxZ: Math.max(stair.start.z, stair.end.z) + (stair.start.z === stair.end.z ? stair.width / 2 : 0) })),
  ];
  const holes = [layout.broadcast.subgradeCutout, layout.library.subgradeCutout, layout.staffroom.subgradeCutout, layout.gymnasium.subgradeCutout, ...rooftopOpenings].map((hole) => ({
    minX: hole.minX + Math.min(0, projectedX) - edgeMargin,
    maxX: hole.maxX + Math.max(0, projectedX) + edgeMargin,
    minZ: hole.minZ + Math.min(0, projectedZ) - edgeMargin,
    maxZ: hole.maxZ + Math.max(0, projectedZ) + edgeMargin,
  }));
  const xs = [...new Set([-77, Math.max(141, ...layout.floors.map((floor) => floor.x + floor.width / 2 + 12)), ...holes.flatMap((hole) => [hole.minX, hole.maxX])])].sort((a, b) => a - b);
  const zs = [...new Set([-50, 50, ...holes.flatMap((hole) => [hole.minZ, hole.maxZ])])].sort((a, b) => a - b);
  const rectangles = zs.slice(0, -1).flatMap((minZ, row) => xs.slice(0, -1).map((minX, col) => {
    const maxX = xs[col + 1]; const maxZ = zs[row + 1];
    const x = (minX + maxX) / 2; const z = (minZ + maxZ) / 2;
    const excavated = holes.some((hole) => x > hole.minX && x < hole.maxX && z > hole.minZ && z < hole.maxZ);
    return [minX, maxX, minZ, maxZ, excavated ? EXCAVATED_Y : OUTSIDE_Y];
  }));
  return <group>{rectangles.map(([minX, maxX, minZ, maxZ, y], index) => <mesh key={index}
    receiveShadow rotation={[-Math.PI / 2, 0, 0]} position={[(minX + maxX) / 2, y, (minZ + maxZ) / 2]}>
    <planeGeometry args={[maxX - minX, maxZ - minZ]} /><meshStandardMaterial color="#233332" roughness={.95} />
  </mesh>)}</group>;
}
