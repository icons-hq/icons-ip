'use client';

import { useLayoutEffect, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { useGLTF } from '@react-three/drei';
import { clone } from 'three/examples/jsm/utils/SkeletonUtils.js';
import { AnimationMixer, Group, Mesh, ShaderMaterial, SkinnedMesh, type Skeleton, type PointLight } from 'three';
import { HYOSAN_REUNION, reunionPlaying } from '@/lib/games/hyosan-memories-3d/ending';
import type { Hyosan3DPlayRuntime } from '@/lib/games/hyosan-memories-3d/types';

const flameVertex = `varying vec2 vUv;
void main() { vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`;
const flameFragment = `varying vec2 vUv; uniform float uTime;
float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float noise(vec2 p) { vec2 i = floor(p), f = fract(p); f = f*f*(3.0-2.0*f);
return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x),f.y); }
void main() {
 float y = vUv.y, x = vUv.x-.5;
 float flow = noise(vec2(x*5.0,y*5.0-uTime*1.6));
 x += sin(y*8.0-uTime*2.1)*.045*y + (flow-.5)*.18*y;
 float width = .32*pow(1.0-y,1.5);
 float edge = 1.0-smoothstep(width*.4,width+.03,abs(x));
 float alpha = edge*smoothstep(0.0,.10,y)*(1.0-smoothstep(.58+flow*.38,1.0,y));
 vec3 color = mix(vec3(1.0,.16,.012),vec3(1.0,.85,.3),pow(edge,3.0)*(1.0-y));
 gl_FragColor = vec4(color*1.8,alpha*.9);
 #include <tonemapping_fragment>
 #include <colorspace_fragment>
}`;

/** Namra is visible only while player movement is locked; she is never a combat target. */
export function RooftopReunion({ simulation }: { simulation: Hyosan3DPlayRuntime }) {
  const asset = useGLTF('/api/dev/hyosan-3d/namra.glb');
  const holder = useRef<Group>(null);
  const flame = useRef<Mesh>(null);
  const light = useRef<PointLight>(null);
  const marker = useRef<Group>(null);
  const owned = useRef<{ mixer: AnimationMixer } | null>(null);
  const shader = useRef<ShaderMaterial>(null);
  useLayoutEffect(() => {
    const clip = asset.animations.find((candidate) => candidate.name === 'reunion');
    if (!clip) throw new Error('Missing Namra reunion animation');
    const parent = holder.current!;
    const model = clone(asset.scene);
    const skeletons = new Set<Skeleton>();
    model.traverse((object) => {
      if (!(object as Mesh).isMesh) return;
      const mesh = object as Mesh;
      mesh.castShadow = true; mesh.receiveShadow = true;
      if ((mesh as SkinnedMesh).isSkinnedMesh) {
        skeletons.add((mesh as SkinnedMesh).skeleton); mesh.frustumCulled = false;
      }
    });
    parent.add(model);
    const mixer = new AnimationMixer(model);
    mixer.clipAction(clip).play();
    owned.current = { mixer };
    return () => {
      owned.current = null; parent.remove(model); mixer.stopAllAction(); mixer.uncacheRoot(model);
      skeletons.forEach((skeleton) => skeleton.dispose());
    };
  }, [asset]);
  useFrame(({ camera }) => {
    const snapshot = simulation.read(); const ending = snapshot.ending;
    const visible = reunionPlaying(ending);
    const present = visible || ending?.phase === 'complete';
    const t = ending?.phase === 'returning' ? Math.min(1, ending.time / HYOSAN_REUNION.returnDuration) : present ? 1 : 0;
    if (holder.current) {
      holder.current.visible = visible;
      holder.current.rotation.y = Math.atan2(snapshot.player.x - HYOSAN_REUNION.namra.x, snapshot.player.z - HYOSAN_REUNION.namra.z);
    }
    if (owned.current) {
      owned.current.mixer.setTime((ending?.elapsed ?? ending?.time ?? 0) % 4);
    }
    if (shader.current) shader.current.uniforms.uTime.value = visible ? (ending?.elapsed ?? ending?.time ?? 0) : snapshot.time;
    if (flame.current) { flame.current.visible = t > 0; flame.current.quaternion.copy(camera.quaternion); flame.current.scale.setScalar(t); }
    if (light.current) light.current.intensity = t * 65;
    if (marker.current) marker.current.visible = ending?.phase === 'available' || ending?.phase === 'complete';
  });
  return <>
    <group ref={holder} position={[HYOSAN_REUNION.namra.x, HYOSAN_REUNION.namra.y, HYOSAN_REUNION.namra.z]} visible={false} dispose={null} />
    <mesh ref={flame} position={[HYOSAN_REUNION.fire.x, HYOSAN_REUNION.fire.y + .66, HYOSAN_REUNION.fire.z]} visible={false} renderOrder={4}>
      <planeGeometry args={[1.2, 1.3]} /><shaderMaterial ref={shader} uniforms={{ uTime: { value: 0 } }} vertexShader={flameVertex} fragmentShader={flameFragment} transparent depthWrite={false} />
    </mesh>
    <pointLight ref={light} position={[HYOSAN_REUNION.fire.x, HYOSAN_REUNION.fire.y + 1.1, HYOSAN_REUNION.fire.z]} color="#ffb361" intensity={0} distance={11} decay={2} />
    <group ref={marker} position={[HYOSAN_REUNION.approach.x, 3.06, HYOSAN_REUNION.approach.z]} visible={false}>
      <mesh rotation={[-Math.PI / 2, 0, 0]}><ringGeometry args={[.37, .44, 48]} /><meshBasicMaterial color="#e9d497" transparent opacity={.75} depthWrite={false} /></mesh>
    </group>
  </>;
}
