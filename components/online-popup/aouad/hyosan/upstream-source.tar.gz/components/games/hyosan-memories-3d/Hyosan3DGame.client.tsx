'use client';

import { reunionPlaying } from '@/lib/games/hyosan-memories-3d/ending';
import { Suspense, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Canvas } from '@react-three/fiber';
import * as THREE from 'three';
import { createHyosanCampaignSession, type HyosanCampaignSession } from '@/lib/games/hyosan-memories-3d/campaign-session';
import { createHyosanCampaignStorage, hasHyosanCampaignProgress } from '@/lib/games/hyosan-memories-3d/campaign-storage';
import { HYOSAN_CAMPAIGN_SAVE_KEY } from '@/lib/games/hyosan-memories-3d/campaign-save';
import { HYOSAN_3D_SAVE_KEY, parseHyosan3DSave, serializeHyosan3DSave } from '@/lib/games/hyosan-memories-3d/save';
import type { Hyosan3DSave, Hyosan3DSimulation, Hyosan3DSnapshot } from '@/lib/games/hyosan-memories-3d/types';
import { Hyosan3DScene } from './Scene';
import { Hyosan3DOverlay, HyosanCampaignGuard, type HyosanCampaignGuardReason } from './Hyosan3DOverlay';
import { acquireHyosanCampaignWriterLease, type HyosanCampaignWriterLease } from './campaign-writer-lease';
import { getHyosan3DMapGoal } from './NavigationMap';
import type { GroundPoint } from '@/lib/games/hyosan-memories-3d/physics';
import { createHyosan3DInputController } from './input';
import styles from './Hyosan3D.module.css';
import { Hyosan3DDiagnostics } from './diagnostics';
import { createHyosan3DAudio, type Hyosan3DAudio } from './audio';
import { SceneBoundary } from './SceneBoundary';
import { supportsHyosanWebGL } from './webgl';
import { createHyosanDifficultyStorage } from './difficulty-storage';
import type { HyosanDifficulty } from '@/lib/games/hyosan-memories-3d/difficulty';

type SaveStorage = Pick<Storage, 'getItem' | 'setItem' | 'removeItem'>;
type WriterPhase = 'loading' | 'ready' | HyosanCampaignGuardReason;
const TEMPORARY_NOTICE = '이번 탐험은 저장되지 않습니다. 이 탭을 닫으면 진행이 사라집니다.';
const hasProgress = (save: Hyosan3DSave) => save.anchorReached || save.kitCollected || save.supplyCollected
  || save.incidentTriggered || save.shortcutOpened || save.discoveredRooms.length > 1;

/** Browser persistence only accepts the core's durable DTO, never a live combat snapshot. */
export function createHyosan3DSaveController(accessStorage: () => SaveStorage) {
  let signature: string | null = null;
  let failedSignature: string | null = null;
  let unavailable = false;
  return {
    load() {
      try {
        const saved = parseHyosan3DSave(accessStorage().getItem(HYOSAN_3D_SAVE_KEY));
        signature = saved ? serializeHyosan3DSave(saved) : null;
        return saved;
      } catch { unavailable = true; return null; }
    },
    write(save: Hyosan3DSave): 'saved' | 'unchanged' | 'unavailable' {
      try {
        const next = serializeHyosan3DSave(save);
        if (next === signature || !hasProgress(save)) return 'unchanged';
        if (next === failedSignature) return 'unavailable';
        failedSignature = next;
        accessStorage().setItem(HYOSAN_3D_SAVE_KEY, next);
        signature = next; failedSignature = null; unavailable = false;
        return 'saved';
      } catch { unavailable = true; return 'unavailable'; }
    },
    clear() {
      signature = null; failedSignature = null;
      try { accessStorage().removeItem(HYOSAN_3D_SAVE_KEY); unavailable = false; return true; }
      catch { unavailable = true; return false; }
    },
    isUnavailable: () => unavailable,
  };
}

/** An expanded map temporarily pauses play while preserving an existing pause. */
export function createHyosan3DMapPauseController() {
  let opened = false;
  let previouslyPaused = false;
  return {
    toggle(sim: Pick<Hyosan3DSimulation, 'read' | 'setPaused'>) {
      if (!opened) { previouslyPaused = sim.read().paused; sim.setPaused(true); opened = true; }
      else { sim.setPaused(previouslyPaused); opened = false; }
      return opened;
    },
    keepPaused() { if (opened) previouslyPaused = true; },
    reset() { opened = false; previouslyPaused = false; },
  };
}

export default function Hyosan3DGame() {
  const cameraOptions = useMemo(() => ({ position: [4, 24, 22] as [number, number, number], zoom: 45, near: .1, far: 120 }), []);
  const input = useMemo(() => createHyosan3DInputController(), []);
  const simulationRef = useRef<HyosanCampaignSession | null>(null);
  const diagnostics = useMemo(() => new Hyosan3DDiagnostics(), []);
  const audioRef = useRef<Hyosan3DAudio | null>(null);
  const [simulation, setSimulation] = useState<HyosanCampaignSession | null>(null);
  const [snapshot, setSnapshot] = useState<Hyosan3DSnapshot | null>(null);
  const [ready, setReady] = useState(false);
  const [started, setStarted] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [muted, setMuted] = useState(false);
  const savesRef = useRef<ReturnType<typeof createHyosanCampaignStorage> | null>(null);
  const writerRef = useRef<HyosanCampaignWriterLease | null>(null);
  const generation = useRef(0);
  const documentActive = useRef(true);
  const writerPhaseRef = useRef<WriterPhase>('loading');
  const [writerPhase, setWriterPhaseState] = useState<WriterPhase>('loading');
  const [bootAttempt, setBootAttempt] = useState(0);
  const [temporary, setTemporary] = useState(false);
  const difficulties = useMemo(() => createHyosanDifficultyStorage(() => window.localStorage), []);
  const [difficultyUnavailable, setDifficultyUnavailable] = useState(false);
  const mapPause = useMemo(() => createHyosan3DMapPauseController(), []);
  const startedRef = useRef(false);
  const noticeTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [hasSave, setHasSave] = useState(false);
  const [saveUnavailable, setSaveUnavailable] = useState(false);
  const [saveNotice, setSaveNotice] = useState<string | null>(null);
  const [mapOpen, setMapOpen] = useState(false);
  const [mapRoute, setMapRoute] = useState<readonly GroundPoint[]>([]);
  const [routeVisible, setRouteVisible] = useState(true);
  const onToggleRoute = useCallback(() => setRouteVisible((visible) => !visible), []);

  const setWriterPhase = useCallback((phase: WriterPhase) => {
    writerPhaseRef.current = phase; setWriterPhaseState(phase);
  }, []);
  const clearNoticeTimer = useCallback(() => {
    if (noticeTimer.current) clearTimeout(noticeTimer.current);
    noticeTimer.current = null;
  }, []);
  const stopWriter = useCallback((reason: HyosanCampaignGuardReason) => {
    input.reset(); simulationRef.current?.setPaused(true);
    mapPause.reset(); setMapOpen(false); setMapRoute([]); setReady(false);
    clearNoticeTimer(); setWriterPhase(reason); writerRef.current?.release();
  }, [clearNoticeTimer, input, mapPause, setWriterPhase]);
  const canUseWorld = useCallback(() => {
    if (writerPhaseRef.current !== 'ready') return false;
    if (!writerRef.current?.active) { stopWriter('conflict'); return false; }
    if (temporary) return true;
    const current = savesRef.current?.checkCurrent();
    if (current === 'current') return true;
    stopWriter(current === 'conflict' ? 'conflict' : 'read-failed'); return false;
  }, [stopWriter, temporary]);
  const retrySession = useCallback((withoutSave = false) => {
    if (writerPhaseRef.current === 'loading') return;
    generation.current++; documentActive.current = true;
    input.reset(); simulationRef.current?.setPaused(true); writerRef.current?.release();
    mapPause.reset(); setMapOpen(false); setMapRoute([]); clearNoticeTimer();
    startedRef.current = false; setStarted(false); setReady(false); setSimulation(null); setSnapshot(null);
    setError(null); setSaveNotice(null); setTemporary(withoutSave); setWriterPhase('loading');
    setBootAttempt((attempt) => attempt + 1);
  }, [clearNoticeTimer, input, mapPause, setWriterPhase]);

  const persist = useCallback(() => {
    const sim = simulationRef.current;
    if (!sim || !startedRef.current || sim.read().transitioning || writerPhaseRef.current !== 'ready') return;
    if (!writerRef.current?.active) { stopWriter('conflict'); return; }
    if (temporary) return;
    const saves = savesRef.current;
    if (!saves) return;
    const save = sim.exportSave();
    const result = saves.write(save);
    if (result === 'conflict') { stopWriter('conflict'); return; }
    setSaveUnavailable(saves.isUnavailable());
    if (result === 'saved') {
      setHasSave(true);
      setSaveNotice(save[save.activeArea]?.anchorReached ? '기억 지점에 탐험을 저장했습니다' : '탐험을 기록했습니다');
      clearNoticeTimer();
      noticeTimer.current = setTimeout(() => { setSaveNotice(null); noticeTimer.current = null; }, 3200);
    } else if (result === 'unavailable') {
      clearNoticeTimer(); setSaveNotice('기억을 저장하지 못했습니다. 창을 닫으면 마지막 저장 이후의 진행이 사라집니다.');
    }
  }, [clearNoticeTimer, stopWriter, temporary]);

  useEffect(() => {
    const sound = createHyosan3DAudio();
    audioRef.current = sound;
    return () => { sound.dispose(); audioRef.current = null; };
  }, []);
  const onToggleSound = useCallback(() => {
    const sound = audioRef.current;
    if (!sound) return;
    const next = !sound.isMuted();
    sound.setMuted(next); setMuted(next);
    if (!next) void sound.unlock();
  }, []);
  const onFailure = useCallback(() => {
    input.reset(); simulationRef.current?.setPaused(true); persist(); writerRef.current?.release();
    setWriterPhase('suspended');
    setError('3D 화면을 불러오지 못했습니다. 다시 시도해 주세요.');
  }, [input, persist, setWriterPhase]);

  useEffect(() => {
    let alive = true;
    const ownershipGeneration = generation;
    const attempt = ++ownershipGeneration.current;
    let lease: HyosanCampaignWriterLease | null = null;
    let saves: ReturnType<typeof createHyosanCampaignStorage> | null = null;
    let owned: HyosanCampaignSession | null = null;
    const current = () => alive && attempt === ownershipGeneration.current && documentActive.current;
    Promise.resolve().then(async () => {
      if (!current()) return null;
      let manager: LockManager | null = null;
      try { manager = navigator.locks ?? null; } catch { /* Restricted browser. */ }
      const acquired = await acquireHyosanCampaignWriterLease(manager);
      if (!current()) { if (acquired.status === 'acquired') acquired.release(); return null; }
      if (acquired.status !== 'acquired') {
        setWriterPhase(acquired.status === 'contended' ? 'contended' : 'unsupported'); return null;
      }
      lease = acquired; writerRef.current = acquired;
      saves = temporary ? null : createHyosanCampaignStorage(() => window.localStorage,
        () => alive && attempt === ownershipGeneration.current && acquired.active);
      savesRef.current = saves;
      const saved = saves?.load() ?? null;
      if (saves?.isConflicted()) { stopWriter('conflict'); return null; }
      if (saves?.isUnavailable()) { stopWriter('read-failed'); return null; }
      setHasSave(saved !== null && hasHyosanCampaignProgress(saved));
      setSaveUnavailable(temporary); setSaveNotice(temporary ? TEMPORARY_NOTICE : null);
      if (!supportsHyosanWebGL()) throw new Error('WebGL unavailable');
      const difficulty = difficulties.load(saved !== null && hasHyosanCampaignProgress(saved));
      setDifficultyUnavailable(temporary || !difficulties.write(difficulty));
      return createHyosanCampaignSession({ saved, difficulty });
    }).then((created) => {
      if (!created) return;
      if (!current() || !lease?.active) {
        created.dispose(); lease?.release();
        if (current()) stopWriter('conflict');
        return;
      }
      owned = created;
      created.setPaused(true);
      simulationRef.current = created;
      setSimulation(created);
      setSnapshot(created.read());
      setWriterPhase('ready');
    }).catch(() => {
      lease?.release();
      if (current()) setError('3D 화면을 준비하지 못했습니다. 브라우저의 그래픽 가속을 확인하고 다시 시도해 주세요.');
    });
    return () => {
      // Save only while this effect still owns the exact live session and lease.
      // After pagehide/conflict/retry neither this cleanup nor a queued HUD can write.
      if (owned && simulationRef.current === owned && startedRef.current && writerPhaseRef.current === 'ready'
        && lease?.active && !owned.read().transitioning) saves?.write(owned.exportSave());
      alive = false;
      if (ownershipGeneration.current === attempt) ownershipGeneration.current++;
      lease?.release(); owned?.dispose();
      if (simulationRef.current === owned) simulationRef.current = null;
      if (writerRef.current === lease) writerRef.current = null;
      if (savesRef.current === saves) savesRef.current = null;
      input.reset(); clearNoticeTimer();
    };
  }, [bootAttempt, clearNoticeTimer, difficulties, input, setWriterPhase, stopWriter, temporary]);

  useEffect(() => {
    if (!simulation || writerPhase !== 'ready' || process.env.NODE_ENV !== 'development' || process.env.NEXT_PUBLIC_HYOSAN_TEST_DRIVER !== 'enabled') return;
    const driver = {
      read: () => simulation.read(),
      manual: (enabled: boolean) => { diagnostics.setManual(enabled); input.reset(); },
      advance: (frames: Parameters<NonNullable<Window['__HYOSAN_3D_QA__']>['advance']>[0]) => {
        if (simulationRef.current !== simulation || !canUseWorld()) throw new Error('This exploration no longer owns its browser save.');
        if (!diagnostics.isManual()) throw new Error('Enable manual simulation before advancing recorded input.');
        for (const frame of frames) simulation.step(frame, 1 / 60);
        setSnapshot(simulation.read()); persist();
        return simulation.read();
      },
      rendering: () => diagnostics.read(),
      project: (x: number, y: number, z: number) => diagnostics.project(x, y, z),
    };
    window.__HYOSAN_3D_QA__ = driver;
    return () => { if (window.__HYOSAN_3D_QA__ === driver) delete window.__HYOSAN_3D_QA__; };
  }, [canUseWorld, diagnostics, input, persist, simulation, writerPhase]);

  const onReady = useCallback(() => {
    if (simulationRef.current === simulation && writerPhaseRef.current === 'ready') setReady(true);
  }, [simulation]);
  const onChangeDifficulty = useCallback((difficulty: HyosanDifficulty) => {
    const sim = simulationRef.current;
    if (!sim || !canUseWorld()) return;
    input.reset(); sim.setDifficulty(difficulty); setSnapshot(sim.read());
    setDifficultyUnavailable(temporary || !difficulties.write(difficulty));
  }, [canUseWorld, difficulties, input, temporary]);
  const onHud = useCallback((state: Hyosan3DSnapshot) => {
    if (simulationRef.current !== simulation || writerPhaseRef.current !== 'ready') return;
    if (state.transitionFailed) { onFailure(); return; }
    const sim = simulationRef.current;
    if (startedRef.current && sim?.beginStory('music')) { input.reset(); setSnapshot(sim.read()); }
    else setSnapshot(state);
    persist();
  }, [input, onFailure, persist, simulation]);
  const onStart = useCallback(() => {
    if (!ready || !canUseWorld()) return;
    void audioRef.current?.unlock();
    input.reset(); simulationRef.current?.setPaused(false); simulationRef.current?.beginStory('opening'); startedRef.current = true; setStarted(true);
    if (simulationRef.current) setSnapshot(simulationRef.current.read());
  }, [canUseWorld, input, ready]);
  const onPause = useCallback(() => {
    const sim = simulationRef.current;
    if (!sim || !started || !canUseWorld()) return;
    void audioRef.current?.unlock();
    input.reset(); sim.setPaused(!sim.read().paused); setSnapshot(sim.read()); persist();
  }, [canUseWorld, input, persist, started]);
  const onRestart = useCallback(() => {
    if (!ready || !simulationRef.current || !canUseWorld()) return;
    const saves = savesRef.current;
    if (!temporary && (!saves || !saves.clear())) {
      stopWriter(saves?.isConflicted() ? 'conflict' : 'reset-failed'); return;
    }
    input.reset(); mapPause.reset(); setMapOpen(false); setMapRoute([]);
    setSaveUnavailable(temporary); setHasSave(false); clearNoticeTimer();
    setSaveNotice(temporary ? TEMPORARY_NOTICE : null);
    simulationRef.current.reset(); simulationRef.current.beginStory('opening'); startedRef.current = true; setStarted(true);
    setSnapshot(simulationRef.current.read());
  }, [canUseWorld, clearNoticeTimer, input, mapPause, ready, stopWriter, temporary]);
  const onAdvanceStory = useCallback((action: 'next' | 'skip') => {
    const sim = simulationRef.current;
    if (!sim || !startedRef.current || !canUseWorld()) return;
    input.reset(); sim.advanceStory(action); setSnapshot(sim.read()); persist();
  }, [canUseWorld, input, persist]);
  const onAdvanceEnding = useCallback((action: 'next' | 'skip') => {
    const sim = simulationRef.current;
    if (!sim || !startedRef.current || !canUseWorld()) return;
    input.reset(); sim.advanceEnding(action); setSnapshot(sim.read()); persist();
  }, [canUseWorld, input, persist]);
  const onToggleMap = useCallback(() => {
    const sim = simulationRef.current;
    if (!sim || !ready || !startedRef.current || !canUseWorld() || sim.read().player.hp <= 0 || sim.read().progress.completed || sim.read().story || reunionPlaying(sim.read().ending)) return;
    input.reset();
    const opened = mapPause.toggle(sim); const state = sim.read();
    const goal = opened ? getHyosan3DMapGoal(state) : null;
    // Collision queries happen once on opening, never in the render or frame loop.
    setMapRoute(goal ? sim.navigationRoute(goal, state.progress.discoveredRooms) : []);
    setMapOpen(opened); setSnapshot(state); persist();
  }, [canUseWorld, input, mapPause, persist, ready]);
  useEffect(() => {
    const pause = () => {
      const sim = simulationRef.current;
      if (!sim || !started || writerPhaseRef.current !== 'ready') return;
      input.reset(); mapPause.keepPaused(); sim.setPaused(true); setSnapshot(sim.read()); persist();
    };
    const onHidden = () => { if (document.hidden) pause(); };
    const checkStorage = () => { if (writerPhaseRef.current === 'ready') canUseWorld(); };
    const onStorage = (event: StorageEvent) => {
      if (event.key === null || event.key === HYOSAN_CAMPAIGN_SAVE_KEY || event.key === HYOSAN_3D_SAVE_KEY) checkStorage();
    };
    const onPageHide = () => {
      documentActive.current = false; pause(); persist(); stopWriter('suspended'); generation.current++;
    };
    const onPageShow = (event: PageTransitionEvent) => { if (event.persisted) retrySession(); };
    window.addEventListener('blur', pause);
    window.addEventListener('focus', checkStorage);
    window.addEventListener('storage', onStorage);
    document.addEventListener('visibilitychange', onHidden);
    window.addEventListener('pagehide', onPageHide);
    window.addEventListener('pageshow', onPageShow);
    return () => {
      window.removeEventListener('blur', pause); window.removeEventListener('focus', checkStorage); window.removeEventListener('storage', onStorage);
      document.removeEventListener('visibilitychange', onHidden); window.removeEventListener('pagehide', onPageHide); window.removeEventListener('pageshow', onPageShow);
    };
  }, [canUseWorld, input, mapPause, persist, retrySession, started, stopWriter]);

  return <main className={styles.game} data-hyosan-renderer="three" data-hyosan-ready={ready} aria-label="효산의 기억 3D 게임">
    {simulation && !error && writerPhase === 'ready' && <SceneBoundary onFailure={onFailure}><Canvas className={styles.canvas} shadows={{ type: THREE.PCFShadowMap }} orthographic
      camera={cameraOptions} dpr={[1, 1.5]}
      fallback="3D 화면을 표시할 수 없습니다. WebGL을 지원하는 브라우저에서 다시 시도해 주세요."
      gl={{ antialias: true, powerPreference: 'high-performance', toneMapping: THREE.ACESFilmicToneMapping, toneMappingExposure: 1.1 }}>
      <Suspense fallback={null}><Hyosan3DScene simulation={simulation} input={input} onReady={onReady} onHud={onHud} diagnostics={diagnostics} audioRef={audioRef} onFailure={onFailure} /></Suspense>
    </Canvas></SceneBoundary>}
    {error ? <div className={styles.loading} role="alert">{error}<button onClick={() => location.reload()}>다시 시도</button></div>
      : writerPhase !== 'loading' && writerPhase !== 'ready'
        ? <HyosanCampaignGuard reason={writerPhase} onRetry={() => retrySession()} onTemporary={writerPhase === 'read-failed' ? () => retrySession(true) : undefined} />
        : <Hyosan3DOverlay snapshot={ready ? snapshot : null} started={started} onStart={onStart} onAdvanceEnding={onAdvanceEnding} onAdvanceStory={onAdvanceStory} onPause={onPause} onRestart={onRestart} input={input} muted={muted} onToggleSound={onToggleSound} hasSave={hasSave} saveUnavailable={saveUnavailable} saveNotice={saveNotice} temporary={temporary} mapOpen={mapOpen} onToggleMap={onToggleMap} mapRoute={mapRoute} routeVisible={routeVisible} onToggleRoute={onToggleRoute} onChangeDifficulty={onChangeDifficulty} difficultyUnavailable={difficultyUnavailable} />}
  </main>;
}
