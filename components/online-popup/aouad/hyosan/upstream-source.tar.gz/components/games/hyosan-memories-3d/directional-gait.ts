export interface DirectionalGait {
  right: number;
  forward: number;
  strideScale: number;
  hipYaw: number;
  phaseAdvance: number;
}

/** +Z faces forward. Sample the same continuous cycle; rotate its foot travel instead of jumping/reversing clip time at 90°. */
export function directionalGait(dx: number, dz: number, facing: number): DirectionalGait {
  const distance = Math.hypot(dx, dz);
  if (distance < 0.00001) return { right: 0, forward: 1, strideScale: 1, hipYaw: 0, phaseAdvance: 0 };
  const right = (dx * Math.cos(facing) - dz * Math.sin(facing)) / distance;
  const forward = (dx * Math.sin(facing) + dz * Math.cos(facing)) / distance;
  const strideScale = 0.64 + 0.36 * Math.max(0, forward);
  return { right, forward, strideScale, hipYaw: right * 0.35,
    // Measured stance-foot travel in the shipped run clip is 4.8m/cycle.
    phaseAdvance: distance / (4.8 * strideScale) };
}

export function directionalFootOffset(side: number, foreAft: number, gait: DirectionalGait) {
  return { x: side + foreAft * gait.strideScale * gait.right, z: foreAft * gait.strideScale * gait.forward };
}
