'use client';
import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import type { Group } from 'three';
import layout from '@/docs/games/hyosan-memories-3d/world-layout.json';
import type { Hyosan3DPlayRuntime } from '@/lib/games/hyosan-memories-3d/types';

const plan = layout.library;
export function LibraryObjects({ simulation }: { simulation: Hyosan3DPlayRuntime }) {
  const string = useRef<Group>(null); const echo = useRef<Group>(null); const keepsake = useRef<Group>(null);
  useFrame(() => {
    const state = simulation.read();
    const progress = state.area === 'library' ? state.progress : state.schoolState?.library;
    if (string.current) string.current.visible = Boolean(progress?.discoveredRooms.includes('library-workroom') && !progress.stringReinforced);
    if (echo.current) echo.current.visible = Boolean(progress && !progress.areaResolved && progress.bossDefeated && !progress.echoCollected);
    // The archive reward is visible only after entering the actual hidden room.
    if (keepsake.current) keepsake.current.visible = state.area === 'library' && state.progress.room === 'library-archive' && !progress?.keepsakeFound;
  });
  return <group>
    <group ref={string} visible={false} position={[plan.upgrade.x, plan.upgrade.y + .04, plan.upgrade.z]}>
      <mesh rotation={[-Math.PI / 2, 0, 0]}><torusGeometry args={[.12, .03, 5, 18]} /><meshStandardMaterial color="#d7bc89" roughness={.9} /></mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]}><ringGeometry args={[.4, .43, 40]} /><meshBasicMaterial color="#e4c88e" transparent opacity={.65} depthWrite={false} /></mesh>
    </group>
    <group position={[plan.checkpoint.x, plan.checkpoint.y + .035, plan.checkpoint.z]}>
      <mesh castShadow><boxGeometry args={[.26, .045, .18]} /><meshStandardMaterial color="#9caa95" roughness={.8} /></mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]}><ringGeometry args={[.38, .405, 40]} /><meshBasicMaterial color="#a8d9b8" transparent opacity={.65} depthWrite={false} /></mesh>
    </group>
    <group ref={keepsake} visible={false} position={[plan.hidden.x, plan.hidden.y + .035, plan.hidden.z]}>
      <mesh castShadow><boxGeometry args={[.09, .012, .24]} /><meshStandardMaterial color="#b2715c" roughness={.95} /></mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]}><ringGeometry args={[.32, .35, 36]} /><meshBasicMaterial color="#e4c88e" transparent opacity={.65} depthWrite={false} /></mesh>
    </group>
    <group ref={echo} visible={false} position={[plan.echo.x, plan.echo.y + .04, plan.echo.z]}>
      <mesh castShadow><boxGeometry args={[.24, .05, .16]} /><meshStandardMaterial color="#bdab84" roughness={.9} /></mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]}><ringGeometry args={[.52, .56, 48]} /><meshBasicMaterial color="#f0d0a0" transparent opacity={.8} depthWrite={false} /></mesh>
    </group>
  </group>;
}
