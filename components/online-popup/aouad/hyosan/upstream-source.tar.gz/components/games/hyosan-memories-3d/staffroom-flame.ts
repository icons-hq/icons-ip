import { DoubleSide, ShaderMaterial } from 'three';

/** One soft, animated flame sheet per authored fuel point. It never defines damage. */
export function createStaffroomFlameMaterial(seed: number) {
  return new ShaderMaterial({
    uniforms: { time: { value: 0 }, seed: { value: seed }, intensity: { value: 1 } },
    transparent: true, depthWrite: false, side: DoubleSide, toneMapped: false,
    vertexShader: `varying vec2 flameUv;
      void main() { flameUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,
    fragmentShader: `
      varying vec2 flameUv;
      uniform float time;
      uniform float seed;
      uniform float intensity;
      float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
      float noise(vec2 p) {
        vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f);
        return mix(mix(hash(i), hash(i + vec2(1., 0.)), f.x),
          mix(hash(i + vec2(0., 1.)), hash(i + vec2(1., 1.)), f.x), f.y);
      }
      float tongue(vec2 p, float center, float height, float width, float phase) {
        float y = p.y / height;
        float sway = sin(time * 3.0 + y * 5.0 + phase) * .04 * y;
        float radius = width * pow(max(0.0, 1.0 - y), .65);
        return (radius - abs(p.x - center - sway)) * 3.5;
      }
      void main() {
        vec2 p = vec2(flameUv.x - .5, flameUv.y);
        float t = time + seed * 1.73;
        float turbulence = noise(vec2(p.x * 12.0 + seed, p.y * 5.0 - t * 2.8)) * .65
          + noise(vec2(p.x * 24.0, p.y * 11.0 - t * 5.0)) * .35;
        float body = max(tongue(p, -.24, .70, .17, seed),
          max(tongue(p, .01, .98, .22, seed + 2.), tongue(p, .26, .78, .17, seed + 4.)));
        body += (turbulence - .5) * (.18 + p.y * .30);
        float alpha = smoothstep(-.035, .10, body) * smoothstep(0., .05, p.y)
          * (1.0 - smoothstep(.80, 1.0, p.y)) * intensity * .88;
        if (alpha < .01) discard;
        float core = smoothstep(.02, .40, body) * (1.0 - p.y);
        vec3 color = mix(vec3(.85, .13, .025), vec3(1., .57, .12), smoothstep(-.03, .18, body));
        color = mix(color, vec3(1., .91, .61), core);
        gl_FragColor = vec4(color, alpha);
        #include <colorspace_fragment>
      }`,
  });
}
