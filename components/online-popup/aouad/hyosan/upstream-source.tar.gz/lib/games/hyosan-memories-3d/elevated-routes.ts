export interface HyosanElevatedRoute {
  id: string; propId: string; roomId: string; label: string;
  deck: { x: number; z: number; width: number; depth: number; height: number };
  ramps: readonly { id: string; x: number; z: number; width: number; depth: number;
    axis: string; lowAt: string }[];
}

export interface HyosanElevatedSample {
  height: number; slopeX: number; slopeZ: number;
  routeId: string; kind: 'deck' | 'ramp';
}

/** One authored surface description supplies the rendered and colliding wedge. */
export function createHyosanElevatedRouteGeometry(source: { elevatedRoutes?: readonly HyosanElevatedRoute[] }) {
  const routes = structuredClone(source.elevatedRoutes ?? []);
  const ids = new Set<string>();
  for (const route of routes) {
    if (ids.has(route.id) || ![route.deck.x, route.deck.z, route.deck.width, route.deck.depth, route.deck.height].every(Number.isFinite)
      || route.deck.width <= 0 || route.deck.depth <= 0 || route.deck.height <= 0 || !route.ramps.length) {
      throw new Error('Invalid Hyosan elevated route geometry');
    }
    ids.add(route.id);
    for (const ramp of route.ramps) {
      if (ids.has(ramp.id) || ![ramp.x, ramp.z, ramp.width, ramp.depth].every(Number.isFinite)
        || ramp.width <= 0 || ramp.depth <= 0 || !['x', 'z'].includes(ramp.axis) || !['min', 'max'].includes(ramp.lowAt)) {
        throw new Error('Invalid Hyosan elevated ramp geometry');
      }
      ids.add(ramp.id);
    }
  }
  const ramps = routes.flatMap((route) => route.ramps.map((ramp) => {
    const run = ramp.axis === 'x' ? ramp.width : ramp.depth;
    const slope = route.deck.height / run * (ramp.lowAt === 'min' ? 1 : -1);
    const vertices: number[] = [];
    for (const x of [-1, 1]) for (const z of [-1, 1]) {
      const high = (ramp.axis === 'x' ? x : z) === (ramp.lowAt === 'min' ? 1 : -1);
      const px = ramp.x + x * ramp.width / 2; const pz = ramp.z + z * ramp.depth / 2;
      vertices.push(px, -.1, pz, px, high ? route.deck.height : 0, pz);
    }
    return { ...ramp, routeId: route.id, height: route.deck.height,
      slopeX: ramp.axis === 'x' ? slope : 0, slopeZ: ramp.axis === 'z' ? slope : 0, vertices };
  }));
  const contains = (rect: { x: number; z: number; width: number; depth: number }, point: { x: number; z: number }) =>
    Math.abs(point.x - rect.x) <= rect.width / 2 + 1e-9 && Math.abs(point.z - rect.z) <= rect.depth / 2 + 1e-9;
  const sample = (point: { x: number; z: number }): HyosanElevatedSample | null => {
    if (![point.x, point.z].every(Number.isFinite)) return null;
    const route = routes.find(({ deck }) => contains(deck, point));
    if (route) return { height: route.deck.height, slopeX: 0, slopeZ: 0, routeId: route.id, kind: 'deck' };
    const ramp = ramps.find((entry) => contains(entry, point));
    return ramp ? { height: Math.max(0, Math.min(ramp.height,
      ramp.height / 2 + (point.x - ramp.x) * ramp.slopeX + (point.z - ramp.z) * ramp.slopeZ)),
      slopeX: ramp.slopeX, slopeZ: ramp.slopeZ, routeId: ramp.routeId, kind: 'ramp' } : null;
  };
  return {
    routes, ramps, sample,
    /** Only shared-height boundaries connect; a low ramp side is still a wall. */
    continuous(from: { x: number; z: number }, to: { x: number; z: number }) {
      const dx = to.x - from.x; const dz = to.z - from.z;
      const epsilon = Math.min(.1, .00001 / Math.max(1e-10, Math.hypot(dx, dz)));
      for (const rect of [...routes.map(({ deck }) => deck), ...ramps]) {
        for (const [delta, origin, centre, half] of [[dx, from.x, rect.x, rect.width / 2], [dz, from.z, rect.z, rect.depth / 2]]) {
          if (Math.abs(delta) < 1e-10) continue;
          for (const edge of [centre - half, centre + half]) {
            const t = (edge - origin) / delta;
            if (t < 0 || t > 1) continue;
            const before = { x: from.x + dx * (t - epsilon), z: from.z + dz * (t - epsilon) };
            const after = { x: from.x + dx * (t + epsilon), z: from.z + dz * (t + epsilon) };
            if (Math.abs((sample(before)?.height ?? 0) - (sample(after)?.height ?? 0)) > 1e-4) return false;
          }
        }
      }
      return true;
    },
  };
}
