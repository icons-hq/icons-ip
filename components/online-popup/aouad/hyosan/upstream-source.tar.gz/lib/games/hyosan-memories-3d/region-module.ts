import type { createHyosan3DPhysics, GroundPoint, Hyosan3DLayout } from './physics';
import type { Hyosan3DNavigator } from './navigation';
import type { ScienceSaveDTO } from './science-save';
import type { ClassroomSaveDTO } from './classroom-save';
import type { BroadcastSaveDTO } from './broadcast-save';
import type { LibrarySaveDTO } from './library-save';
import type { StaffroomSaveDTO } from './staffroom-save';
import type { RooftopSaveDTO } from './rooftop-save';
import type { GymnasiumSaveDTO } from './gymnasium-save';
import type { HyosanLayerPoint } from './combat-layers';
import type {
  Hyosan3DArea, Hyosan3DEffect, Hyosan3DEnemy, Hyosan3DEquipment,
  Hyosan3DFurniture, Hyosan3DPlayer, Hyosan3DSave, Hyosan3DSnapshot,
} from './types';

export type RegionSave = ScienceSaveDTO | ClassroomSaveDTO | BroadcastSaveDTO | LibrarySaveDTO | StaffroomSaveDTO | GymnasiumSaveDTO | RooftopSaveDTO | Hyosan3DSave;
export type CombatMoverKind = 'player' | Hyosan3DEnemy['kind'];
export interface CombatEnemy extends Hyosan3DEnemy {
  ownerArea: Hyosan3DArea;
  active: boolean;
}

/** Host owns the lifetime, player, clock, damage and global projectile list. */
export interface SharedCombatContext {
  readonly source: Hyosan3DLayout;
  /** Regions may move their own actors/props; only the host calls sync/dispose. */
  readonly physics: Awaited<ReturnType<typeof createHyosan3DPhysics>>;
  readonly navigate: Hyosan3DNavigator;
  readonly time: number;
  readonly dt: number;
  /** Guidance area, selected by the existing authored seams; never an AI filter. */
  readonly area: Hyosan3DArea;
  /** These objects keep their identity for the lifetime of the host. */
  readonly player: Hyosan3DPlayer;
  readonly equipment: Required<Hyosan3DEquipment>;
  /** Getter over every module's current enemy references, including dormant IDs. */
  readonly enemies: readonly CombatEnemy[];
  effect(kind: Hyosan3DEffect['kind'], at: GroundPoint, duration?: number, heightOffset?: number): void;
  /** Actor attacks provide their layer; global hazards may omit an attacker. */
  hurtPlayer(amount: number, attacker?: HyosanLayerPoint & Partial<GroundPoint>): void;
  /** Applies one hit/death lifecycle to any living owner; callers validate hazard exposure. */
  hurtEnemy(id: string, amount: number, hitPoint?: GroundPoint): boolean;
  /** Full HP, shot/dash cooldown reset, and one upgrade effect at this point. */
  checkpoint(point: GroundPoint): void;
  /** All authored hazards apply by location, irrespective of an actor's owner. */
  movementMultiplier(point: GroundPoint, kind: CombatMoverKind): number;
}

export interface RegionInputEdges {
  /** True for only the module owning the selected, physically nearby interaction. */
  interactPressed: boolean;
}

/** Encounter state only. It never creates another physics world or player. */
export interface RegionModule<Save extends RegionSave = RegionSave> {
  readonly id: Hyosan3DArea;
  /** Stable array; each actor object is shared with host hit/separation handling. */
  readonly enemies: CombatEnemy[];
  /** Host removes all old actor colliders before resetting each module. */
  reset(saved: unknown, resolved: boolean): void;
  /** Discovery only; starts entry grace when context.area first becomes this id. */
  observePlayer(): void;
  /** Existing local objectives/furniture and own actor AI; no player/fire/physics tick. */
  update(edges: Readonly<RegionInputEdges>): void;
  /** Called after global arrow hits: resolve first, then admit finite arrivals. */
  afterCombat(): void;
  /** Records completion without removing living enemies, corpses or projectiles. */
  markResolved(): void;
  interaction(): Hyosan3DSnapshot['interaction'];
  readProgress(): Hyosan3DSnapshot['progress'];
  exportSave(): Save;
  respawnPoint(): GroundPoint;
  furniture(): readonly Hyosan3DFurniture[];
  fires?(): NonNullable<Hyosan3DSnapshot['fires']>;
  inflow?(): Hyosan3DSnapshot['inflow'];
  movementMultiplier?(point: GroundPoint, kind: CombatMoverKind): number;
  /** Host already applied HP/active state and removes the collider on death. */
  onHit?(enemy: CombatEnemy): void;
}

export type RegionFactory = (context: SharedCombatContext) => RegionModule;
