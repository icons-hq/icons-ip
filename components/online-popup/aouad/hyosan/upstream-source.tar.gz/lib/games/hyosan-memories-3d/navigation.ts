import type { GroundBounds, GroundPoint, Hyosan3DLayout } from './physics';
import { createHyosanSupportGeometry } from './support-geometry';
import { createHyosanNavigationEntrances } from './navigation-entrances';

interface Graph {
  revision: number; valid: boolean[]; edges: number[][];
  destination: number; next: Int32Array; distance: Int32Array;
  attachments: Map<string, number | undefined>;
  detours: Map<string, readonly [GroundPoint, GroundPoint]>;
}

export interface Hyosan3DNavigator {
  (from: GroundPoint, to: GroundPoint, radius?: number, targetRadius?: number): GroundPoint;
  /** Read-only graph preparation; no target, actor movement or simulation step. */
  prepare(radii: readonly number[]): void;
}

/** Small shared reverse field; all pursuers reuse it while the player stays in one cell. */
export function createHyosan3DNavigator(layout: Hyosan3DLayout, clear: (from: GroundPoint, to: GroundPoint, radius: number) => boolean,
  geometryRevision: () => number = () => 0, changesSince?: (revision: number) => readonly GroundBounds[] | null): Hyosan3DNavigator {
  const spacing = 0.65;
  // Anchor to world metres: adding a remote room must not shift every old path cell.
  const leftCell = Math.floor(Math.min(...layout.floors.map((floor) => floor.x - floor.width / 2)) / spacing);
  const topCell = Math.floor(Math.min(...layout.floors.map((floor) => floor.z - floor.depth / 2)) / spacing);
  const left = leftCell * spacing; const top = topCell * spacing;
  const columns = Math.ceil((Math.max(...layout.floors.map((floor) => floor.x + floor.width / 2)) - left) / spacing) + 1;
  const rows = Math.ceil((Math.max(...layout.floors.map((floor) => floor.z + floor.depth / 2)) - top) / spacing) + 1;
  const geometry = createHyosanSupportGeometry(layout);
  const layered = geometry.stairs.length > 0 || geometry.ramps.length > 0 || layout.floors.some((floor) => (floor.y ?? 0) !== 0);
  const points: GroundPoint[] = [];
  const byCell = new Map<number, number[]>();
  for (let cell = 0; cell < columns * rows; cell++) {
    const point = { x: (leftCell + cell % columns) * spacing, z: (topCell + Math.floor(cell / columns)) * spacing };
    const candidates: GroundPoint[] = layered ? geometry.candidates(point).map((surface) => ({ ...point, y: surface.height,
      surfaceId: surface.surfaceId, currentLayerId: surface.currentLayerId })) : [point];
    const unique = new Set<string>(); const indices: number[] = [];
    for (const candidate of candidates) {
      const key = `${candidate.currentLayerId}:${candidate.y}`;
      if (unique.has(key)) continue;
      unique.add(key); indices.push(points.length); points.push(candidate);
    }
    byCell.set(cell, indices);
  }
  // A legal aisle beside a doorway can lie entirely between grid columns for
  // a larger body. Retain the authored approach line inside its actual floor;
  // standing validity and every edge still use the full pursuer footprint.
  const pointKeys = new Set(points.map((point) => `${point.x}:${point.z}:${point.y ?? 0}:${point.currentLayerId}`));
  for (const entrance of createHyosanNavigationEntrances(layout).entrances) for (const { point: approach } of entrance.sides) {
    for (const floor of layout.floors) {
      if (Math.abs(approach.x - floor.x) > floor.width / 2 || Math.abs(approach.z - floor.z) > floor.depth / 2
        || Math.abs((approach.y ?? 0) - (floor.y ?? 0)) > .2) continue;
      const across = entrance.normal === 'x' ? 'z' : 'x';
      const span = across === 'x' ? floor.width : floor.depth;
      for (let cell = Math.ceil((floor[across] - span / 2) / spacing); cell <= Math.floor((floor[across] + span / 2) / spacing); cell++) {
        const point = { x: approach.x, z: approach.z, [across]: cell * spacing };
        const candidates: GroundPoint[] = layered ? geometry.candidates(point).filter((surface) => Math.abs(surface.height - (approach.y ?? 0)) < .2)
          .map((surface) => ({ ...point, y: surface.height, surfaceId: surface.surfaceId, currentLayerId: surface.currentLayerId })) : [point];
        for (const candidate of candidates) {
          const key = `${candidate.x}:${candidate.z}:${candidate.y ?? 0}:${candidate.currentLayerId}`;
          if (pointKeys.has(key)) continue;
          const column = Math.round((point.x - left) / spacing); const row = Math.round((point.z - top) / spacing);
          const bucket = byCell.get(row * columns + column);
          if (!bucket) continue;
          pointKeys.add(key); bucket.push(points.length); points.push(candidate);
        }
      }
    }
  }
  const caches = new Map<number, Graph>();
  const neighbors = points.map((point, index) => {
    const column = Math.round((point.x - left) / spacing); const row = Math.round((point.z - top) / spacing);
    const adjacent: number[] = [];
    for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
      const x = column + dx; const z = row + dz;
      if (x >= 0 && x < columns && z >= 0 && z < rows) adjacent.push(...byCell.get(z * columns + x)!.filter((next) => next !== index));
    }
    // Extra approach samples share buckets with the coarse grid. Keep the
    // original edge reach so local geometry invalidation still covers every edge.
    return adjacent.filter((next) => Math.hypot(points[next].x - point.x, points[next].z - point.z) <= spacing * Math.SQRT2 + 1e-9);
  });
  const edgesAt = (index: number, valid: readonly boolean[], radius: number) => valid[index]
    ? neighbors[index].filter((next) => valid[next] && clear(points[index], points[next], radius)) : [];
  const build = (radius: number, revision: number): Graph => {
    const valid = points.map((point) => clear(point, point, radius));
    return { revision, valid, edges: points.map((_, index) => edgesAt(index, valid, radius)),
      destination: -1, next: new Int32Array(points.length), distance: new Int32Array(points.length), attachments: new Map(), detours: new Map() };
  };
  const invalidate = (cache: Graph, bounds: readonly GroundBounds[], radius: number) => {
    const affected = new Set<number>();
    // Any changed edge must have an endpoint within one grid diagonal of the
    // changed footprint expanded by this actor's radius. This also includes all
    // inbound edges of a node whose standing validity could have changed. An
    // approach sample may sit half a cell away from its bucket's centre.
    const margin = radius + spacing * (Math.SQRT2 + .5) + 1e-9;
    for (const box of bounds) {
      const minColumn = Math.max(0, Math.ceil((box.minX - margin - left) / spacing));
      const maxColumn = Math.min(columns - 1, Math.floor((box.maxX + margin - left) / spacing));
      const minRow = Math.max(0, Math.ceil((box.minZ - margin - top) / spacing));
      const maxRow = Math.min(rows - 1, Math.floor((box.maxZ + margin - top) / spacing));
      for (let row = minRow; row <= maxRow; row++) for (let column = minColumn; column <= maxColumn; column++) {
        for (const index of byCell.get(row * columns + column) ?? []) affected.add(index);
      }
    }
    // Complete the validity pass before reconnecting newly opened neighbors.
    for (const index of affected) cache.valid[index] = clear(points[index], points[index], radius);
    for (const index of affected) cache.edges[index] = edgesAt(index, cache.valid, radius);
    cache.destination = -1;
    cache.attachments.clear();
    cache.detours.clear();
  };
  const graphFor = (radius: number): Graph => {
    const revision = geometryRevision();
    let cache = caches.get(radius);
    if (!cache) {
      cache = build(radius, revision);
      caches.set(radius, cache);
    } else if (cache.revision !== revision) {
      const bounds = changesSince?.(cache.revision);
      if (!bounds || bounds.some((box) => ![box.minX, box.maxX, box.minZ, box.maxZ].every(Number.isFinite)
        || box.minX > box.maxX || box.minZ > box.maxZ)) {
        cache = build(radius, revision);
        caches.set(radius, cache);
      } else {
        invalidate(cache, bounds, radius);
        cache.revision = revision;
      }
    }
    return cache;
  };
  // A legal narrow gap can fall between grid columns. Before taking a long
  // detour from a nearby target, try six short orthogonal paths. Every travelled
  // segment retains the full actor footprint; only the final target attachment
  // may use the smaller target radius, just like the shared reverse field.
  const shortenNearbyDetour = (from: GroundPoint, to: GroundPoint, fallback: GroundPoint, radius: number, targetRadius: number,
    cache: Graph, targetKey: string) => {
    const dx = to.x - from.x; const dz = to.z - from.z;
    const distance = Math.hypot(dx, dz);
    if (distance > 4 || distance < .001 || Math.abs((from.y ?? 0) - (to.y ?? 0)) > .05) return fallback;
    const follow = ([a, b]: readonly [GroundPoint, GroundPoint]) => {
      if (!clear(to, b, Math.min(radius, targetRadius))) return undefined;
      if (clear(from, b, radius)) return b;
      if (clear(from, a, radius) && clear(a, b, radius)) return a;
      return undefined;
    };
    // Resampling relative to a moving pursuer can shift a valid lane out of a
    // narrow gap each tick. Keep its bends for this exact target, but recheck
    // every used segment because another pursuer may approach from elsewhere.
    const saved = cache.detours.get(targetKey);
    if (saved) {
      const waypoint = follow(saved);
      if (waypoint) return waypoint;
      cache.detours.delete(targetKey);
    }
    const detourX = fallback.x - from.x; const detourZ = fallback.z - from.z;
    if (detourX * dx + detourZ * dz >= 0 && Math.hypot(detourX, detourZ) <= distance) return fallback;
    for (const fraction of [.25, .5, .75]) {
      const x = from.x + dx * fraction; const z = from.z + dz * fraction;
      const bends: [GroundPoint, GroundPoint][] = [
        [{ ...from, x }, { ...from, x, z: to.z }],
        [{ ...from, z }, { ...from, x: to.x, z }],
      ];
      for (const pair of bends) {
        const waypoint = follow(pair);
        if (waypoint) {
          if (cache.detours.size >= 64) cache.detours.clear();
          cache.detours.set(targetKey, pair);
          return waypoint;
        }
      }
    }
    return fallback;
  };
  // Use the actual actor radius: extra padding can invalidate a legal KCC wall
  // contact and strand the actor. A smaller target needs only a safe approach
  // node, while every traversed edge still uses the pursuer's full footprint.
  const navigate = (from: GroundPoint, to: GroundPoint, radius = 0.32, targetRadius = radius): GroundPoint => {
    if (clear(from, to, radius)) return to;
    const cache = graphFor(radius);
    const near = (point: GroundPoint) => {
      const column = Math.round((point.x - left) / spacing);
      const row = Math.round((point.z - top) / spacing);
      const candidates: number[] = [];
      for (let dz = -2; dz <= 2; dz += 1) for (let dx = -2; dx <= 2; dx += 1) {
        const x = column + dx;
        const z = row + dz;
        if (x < 0 || x >= columns || z < 0 || z >= rows) continue;
        for (const i of byCell.get(z * columns + x) ?? []) {
          if (cache.edges[i].length) candidates.push(i);
        }
      }
      return candidates.sort((a, b) => Math.hypot(points[a].x - point.x, points[a].z - point.z) - Math.hypot(points[b].x - point.x, points[b].z - point.z));
    };
    // Many pursuers attach to the exact same player pose in one tick. Keep the
    // expensive support/collision query shared, without rounding a moving target
    // or reusing an attachment after a door or furniture geometry change.
    const connectionRadius = Math.min(radius, targetRadius);
    const attachmentKey = JSON.stringify([to.x, to.y, to.z, to.surfaceId, to.currentLayerId, connectionRadius]);
    if (!cache.attachments.has(attachmentKey)) {
      if (cache.attachments.size >= 64) cache.attachments.clear();
      cache.attachments.set(attachmentKey, near(to).find((i) => clear(to, points[i], connectionRadius)));
    }
    const destination = cache.attachments.get(attachmentKey);
    if (destination === undefined) return from;
    if (cache.destination !== destination) {
      cache.destination = destination;
      cache.next.fill(-1);
      cache.distance.fill(-1);
      cache.distance[destination] = 0;
      const queue = [destination];
      for (let head = 0; head < queue.length; head += 1) {
        const i = queue[head];
        for (const neighbor of cache.edges[i]) {
          if (cache.distance[neighbor] >= 0) continue;
          cache.distance[neighbor] = cache.distance[i] + 1;
          cache.next[neighbor] = i;
          queue.push(neighbor);
        }
      }
    }
    // Order by the same route/planar costs before testing visibility. Once the
    // best reachable attachment is clear, later candidates cannot improve it.
    let index = near(from).filter((i) => cache.distance[i] >= 0)
      .sort((a, b) => cache.distance[a] - cache.distance[b]).find((i) => clear(from, points[i], radius));
    if (index === undefined) return from;
    const path = [points[index]];
    for (let i = 0; i < 24 && cache.next[index] >= 0; i += 1) {
      index = cache.next[index];
      path.push(points[index]);
    }
    // Seek a useful clear lookahead with logarithmic probes. Visibility need
    // not be monotonic around corners: every accepted segment is still traced
    // exactly, and the known-clear first attachment is always the fallback.
    let low = 0; let high = path.length - 1;
    while (low < high) {
      const middle = Math.ceil((low + high) / 2);
      if (clear(from, path[middle], radius)) low = middle;
      else high = middle - 1;
    }
    return shortenNearbyDetour(from, to, path[low], radius, targetRadius, cache, attachmentKey);
  };
  return Object.assign(navigate, {
    prepare(radii: readonly number[]) {
      if (radii.some((radius) => !Number.isFinite(radius) || radius <= 0)) {
        throw new RangeError('Navigation radii must be finite and positive');
      }
      for (const radius of radii) graphFor(radius);
    },
  });
}
