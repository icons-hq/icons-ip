import layout from '@/docs/games/hyosan-memories-3d/world-layout.json';
import { HYOSAN_BROADCAST_ROOMS } from './types';
import { hyosan3DBow } from './save';
import { parseHyosanBroadcastSave, type BroadcastSaveDTO, type HyosanBroadcastRoom } from './broadcast-save';
import { createHyosanBroadcastBossController, HYOSAN_BROADCAST_BOSS } from './broadcast-boss-controller';
import { createHyosanSupportGeometry } from './support-geometry';
import { direction, distance, planarDistance } from './combat-geometry';
import { sameHyosanCombatLayer } from './combat-layers';
import type { GroundPoint } from './physics';
import type { CombatEnemy, RegionModule, SharedCombatContext } from './region-module';

interface BroadcastEnemy extends CombatEnemy { since: number; homeRoom: HyosanBroadcastRoom }
const STUDENT = { windup: .55, strike: .16, recovery: .85 };

/** Broadcast owns its investigation and brains; the shared host owns combat. */
export function createHyosanBroadcastRegion(ctx: SharedCombatContext): RegionModule<BroadcastSaveDTO> {
  const { source, physics, navigate, player, equipment } = ctx;
  const plan = source.broadcast;
  if (!plan) throw new Error('Hyosan broadcast layout is required');
  const gate = source.props.find((prop) => prop.id === plan.shortcut.id);
  const trolley = source.props.find((prop) => prop.id === plan.hose.propId);
  if (!gate || !trolley) throw new Error('Hyosan broadcast furniture has no physical prop');
  const support = createHyosanSupportGeometry(source);
  const roomsBySurface = new Map(support.surfaces.map((surface) => [surface.surfaceId, surface.roomId ?? surface.surfaceId]));
  const ownRoomAt = (point: GroundPoint): HyosanBroadcastRoom | undefined => {
    const sample = support.sample(point);
    return HYOSAN_BROADCAST_ROOMS.find((room) => room === (sample && roomsBySurface.get(sample.surfaceId)));
  };
  const enemies: BroadcastEnemy[] = [];
  const bossController = createHyosanBroadcastBossController();
  let firstEnteredAt: number | null = null; let slideBlocked = false;
  const discovered = new Set<HyosanBroadcastRoom>();
  let resolved = false; let completed = false; let consoleInspected = false; let hoseSecured = false;
  let shortcutOpened = false; let anchorReached = false; let supplyTaken = false; let echoCollected = false;
  let gateProgress = 0; let opening = false; let hoseProgress = 0; let securing = false;
  const gatePose = (progress: number) => {
    if (progress === 1) return plan.shortcut.open;
    const rotation = gate.rotation + (plan.shortcut.open.rotation - gate.rotation) * progress;
    const delta = rotation - gate.rotation;
    const dx = gate.x - plan.shortcut.hinge.x; const dz = gate.z - plan.shortcut.hinge.z;
    return { x: plan.shortcut.hinge.x + dx * Math.cos(delta) + dz * Math.sin(delta), y: plan.shortcut.y,
      z: plan.shortcut.hinge.z - dx * Math.sin(delta) + dz * Math.cos(delta), rotation };
  };
  const hosePose = (progress: number) => ({ x: trolley.x + (plan.hose.to.x - trolley.x) * progress,
    y: plan.hose.y, z: trolley.z + (plan.hose.to.z - trolley.z) * progress, rotation: plan.hose.to.rotation });
  const boss = () => enemies.find((enemy) => enemy.kind === 'boss');
  const nearby = (point: GroundPoint, ignore?: string) => distance(player, point) < 1.55 && physics.lineOfSight(player, point, ignore);
  const interaction: RegionModule['interaction'] = () => {
    if (player.hp <= 0 || completed) return null;
    if (!resolved && boss()?.hp === 0 && !echoCollected && nearby(plan.echo)) return 'echo';
    if (!supplyTaken && player.hp < player.maxHp && nearby(plan.supply)) return 'supply';
    if (!consoleInspected && nearby(plan.console, plan.console.propId)) return 'origin';
    if (!hoseSecured && !securing && nearby(plan.hose.interactPoint, trolley.id)) return 'hose';
    if (!shortcutOpened && !opening && player.x > gate.x + .2 && nearby(plan.shortcut.interactPoint, gate.id)) return 'shortcut';
    return null;
  };
  const createEnemy = (id: string, at: GroundPoint, isBoss = false): BroadcastEnemy => {
    const hp = isBoss ? HYOSAN_BROADCAST_BOSS.hp : 2;
    return { id, ...physics.addActor(id, at, isBoss ? .5 : .32), yaw: 0, hp, maxHp: hp,
      ownerArea: 'broadcast', kind: isBoss ? 'boss' : 'student', ...(isBoss ? { profile: 'daewon' as const } : {}),
      active: false, dormant: false, since: 0, homeRoom: ownRoomAt(at) ?? 'broadcast-entry',
      attackPhase: 'idle', attackStyle: 'melee', attackProgress: 0,
      attackRange: isBoss ? HYOSAN_BROADCAST_BOSS.reach : 1.25,
      attackHalfAngle: isBoss ? HYOSAN_BROADCAST_BOSS.halfAngle : Math.acos(.35), defeatedAt: null };
  };
  const hitsPlayer = (enemy: BroadcastEnemy) => {
    const aim = direction(player.x - enemy.x, player.z - enemy.z);
    return sameHyosanCombatLayer(enemy, player) && distance(enemy, player) <= enemy.attackRange
      && aim.x * Math.sin(enemy.yaw) + aim.z * Math.cos(enemy.yaw) > Math.cos(enemy.attackHalfAngle)
      && physics.lineOfSight(enemy, player);
  };
  const walk = (enemy: BroadcastEnemy, aim: { x: number; z: number }, speed: number) => {
    if (aim.x || aim.z) enemy.yaw = Math.atan2(aim.x, aim.z);
    const step = speed * ctx.dt * ctx.movementMultiplier(enemy, enemy.kind);
    Object.assign(enemy, physics.moveActor(enemy.id, aim.x * step, aim.z * step));
  };
  const updateEnemies = () => {
    for (const enemy of enemies) {
      if (enemy.hp <= 0 || enemy.dormant) continue;
      enemy.active ||= firstEnteredAt !== null && ctx.time - firstEnteredAt >= 2.2 && distance(enemy, player) < 9
        && (ownRoomAt(player) === enemy.homeRoom || distance(enemy, player) < 5 && physics.lineOfSight(enemy, player));
      if (!enemy.active) continue;
      const waypoint = navigate(enemy, player, enemy.kind === 'boss' ? .5 : .32, .32);
      const aim = direction(waypoint.x - enemy.x, waypoint.z - enemy.z);
      if (enemy.kind === 'boss') {
        const sample = support.sample(enemy);
        const stair = sample?.stairId ? support.stairs.find(({ id }) => id === sample.stairId) : undefined;
        const frame = bossController.advance({ time: ctx.time, x: enemy.x, z: enemy.z, targetX: player.x, targetZ: player.z,
          distance: distance(enemy, player), visible: physics.lineOfSight(enemy, player), sameLayer: sameHyosanCombatLayer(enemy, player),
          stair, ascending: stair && aim.x * stair.downhill.x + aim.z * stair.downhill.z < -.1, blocked: slideBlocked });
        enemy.broadcastBeat = frame.beat; enemy.attackPhase = frame.attackPhase; enemy.attackProgress = frame.attackProgress;
        if (frame.beat === 'grab-windup' || frame.beat === 'grab') enemy.yaw = frame.yaw;
        if (frame.speed > 0) walk(enemy, aim, frame.speed);
        if (frame.beat === 'slide') {
          const previous = { x: enemy.x, z: enemy.z };
          Object.assign(enemy, physics.moveActor(enemy.id, frame.slideX * ctx.dt, frame.slideZ * ctx.dt));
          slideBlocked = planarDistance(previous, enemy) < .001;
        } else slideBlocked = false;
        if (frame.strike && hitsPlayer(enemy)) ctx.hurtPlayer(2, enemy);
      } else if (enemy.attackPhase === 'idle') {
        if (sameHyosanCombatLayer(enemy, player) && distance(enemy, player) <= 1.05 && physics.lineOfSight(enemy, player)) {
          enemy.yaw = Math.atan2(player.x - enemy.x, player.z - enemy.z); enemy.attackPhase = 'windup'; enemy.since = ctx.time;
        } else walk(enemy, aim, 1.05);
      } else if (enemy.attackPhase === 'windup' && ctx.time - enemy.since >= STUDENT.windup) {
        enemy.attackPhase = 'strike'; enemy.since = ctx.time; if (hitsPlayer(enemy)) ctx.hurtPlayer(1, enemy);
      } else if (enemy.attackPhase === 'strike' && ctx.time - enemy.since >= STUDENT.strike) { enemy.attackPhase = 'recover'; enemy.since = ctx.time; }
      else if (enemy.attackPhase === 'recover' && ctx.time - enemy.since >= STUDENT.recovery) { enemy.attackPhase = 'idle'; enemy.since = ctx.time; }
      if (enemy.kind === 'student') enemy.attackProgress = enemy.attackPhase === 'idle' ? 0 : Math.min(1,
        (ctx.time - enemy.since) / (enemy.attackPhase === 'windup' ? STUDENT.windup : enemy.attackPhase === 'strike' ? STUDENT.strike : STUDENT.recovery));
    }
  };
  return {
    id: 'broadcast', enemies,
    reset(raw, isResolved) {
      const saved = parseHyosanBroadcastSave(raw);
      resolved = isResolved; completed = false; echoCollected = false;
      firstEnteredAt = null; slideBlocked = false; bossController.reset();
      consoleInspected = resolved || saved?.consoleInspected === true; hoseSecured = resolved || saved?.hoseSecured === true;
      shortcutOpened = saved?.shortcutOpened === true; anchorReached = saved?.anchorReached === true; supplyTaken = saved?.supplyTaken === true;
      discovered.clear(); for (const room of saved?.discoveredRooms ?? []) discovered.add(room);
      gateProgress = shortcutOpened ? 1 : 0; hoseProgress = hoseSecured ? 1 : 0; opening = false; securing = false;
      physics.trySetPropPose(gate.id, gatePose(gateProgress)); physics.trySetPropPose(trolley.id, hosePose(hoseProgress));
      enemies.length = 0;
      if (!resolved) {
        for (const group of plan.encounters) for (let index = 0; index < group.count; index++) {
          enemies.push(createEnemy(`${group.id}-${index}`, { ...group, x: group.x + index % 2 * .95, z: group.z + Math.floor(index / 2) * .95 }));
        }
        enemies.push(createEnemy(plan.boss.id, plan.boss, true));
      }
    },
    observePlayer() {
      const room = ownRoomAt(player); if (room) discovered.add(room);
      if (ctx.area === 'broadcast' && firstEnteredAt === null) firstEnteredAt = ctx.time;
    },
    update({ interactPressed }) {
      if (player.hp <= 0) return;
      if (!anchorReached && distance(player, plan.checkpoint) <= plan.checkpoint.radius && nearby(plan.checkpoint)) {
        anchorReached = true; ctx.checkpoint(plan.checkpoint);
      }
      if (interactPressed) {
        const action = interaction();
        if (action === 'origin') consoleInspected = true;
        if (action === 'hose') securing = true;
        if (action === 'shortcut') opening = true;
        if (action === 'supply') { supplyTaken = true; player.hp = Math.min(player.maxHp, player.hp + plan.supply.heal); }
        if (action === 'echo') echoCollected = true;
        if (action) ctx.effect(action === 'shortcut' || action === 'hose' ? 'door' : 'upgrade', player, .7);
      }
      if (opening) {
        const next = Math.min(1, gateProgress + ctx.dt / plan.shortcut.duration);
        if (physics.trySetPropPose(gate.id, gatePose(next))) gateProgress = next;
        if (gateProgress === 1) { shortcutOpened = true; opening = false; }
      }
      if (securing) {
        const next = Math.min(1, hoseProgress + ctx.dt / plan.hose.duration);
        if (physics.trySetPropPose(trolley.id, hosePose(next))) hoseProgress = next;
        if (hoseProgress === 1) { hoseSecured = true; securing = false; }
      }
      updateEnemies();
    },
    afterCombat() {
      if (!resolved && player.hp > 0 && consoleInspected && hoseSecured && boss()?.hp === 0 && echoCollected
        && Math.abs(player.y - plan.exit.y) < .25 && (player.x - plan.exit.x) * plan.exit.forward >= 0
        && Math.abs(player.z - plan.exit.z) <= 1.2) completed = true;
    },
    interaction,
    markResolved() { resolved = true; completed = false; },
    readProgress() {
      const bow = hyosan3DBow(equipment.kitCollected, equipment.supplyCollected, equipment.piercingCollected, equipment.stringReinforced);
      return { room: ownRoomAt(player) ?? 'broadcast-entry', discoveredRooms: [...discovered], consoleInspected, hoseSecured, supplyTaken,
        areaResolved: resolved, objective: completed ? 'completed' : resolved ? 'explore_school'
          : boss()?.active && boss()!.hp > 0 ? 'defeat_boss' : !consoleInspected ? 'inspect_broadcast'
            : !hoseSecured ? 'secure_hose' : boss()?.hp !== 0 ? 'descend_stairs' : !echoCollected ? 'collect_echo' : 'reach_exit',
        upgraded: equipment.kitCollected, supplyCollected: equipment.supplyCollected, piercingCollected: equipment.piercingCollected,
        bowLevel: bow.level, bossDefeated: resolved || boss()?.hp === 0, completed, echoCollected, anchorReached, shortcutOpened,
        incidentTriggered: false, entranceOpen: 1, inWater: ctx.movementMultiplier(player, 'player') < 1,
        activeWaterIds: [], incidentShortcutOpened: false };
    },
    exportSave: () => ({ version: 1, worldVersion: layout.version, consoleInspected, hoseSecured, shortcutOpened, anchorReached, supplyTaken,
      discoveredRooms: HYOSAN_BROADCAST_ROOMS.filter((room) => discovered.has(room)) }),
    respawnPoint: () => anchorReached ? plan.checkpoint : plan.spawn,
    furniture: () => [{ id: gate.id, ...gatePose(gateProgress), progress: gateProgress },
      { id: trolley.id, ...hosePose(hoseProgress), progress: hoseProgress }],
  };
}
