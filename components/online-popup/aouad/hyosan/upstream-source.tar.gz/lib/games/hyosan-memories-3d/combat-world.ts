import { HYOSAN_3D_AREAS } from './types';
import canonicalLayout from '@/docs/games/hyosan-memories-3d/world-layout.json';
import nativeCounterData from '@/docs/games/hyosan-memories-3d/assets/environment/s2-serving-counter/counter-ray-source.json';
import type { HyosanServingCounterRayData } from './serving-counter-rays';
import { HYOSAN_DIFFICULTY, isHyosanDifficulty, type HyosanDifficulty } from './difficulty';
import { HYOSAN_BOW_HEIGHT, createHyosanBowProjectile, advanceHyosanBowProjectile, type HyosanBowProjectile } from './bow-projectiles';
import { createHyosan3DPhysics, type GroundPoint, type Hyosan3DLayout } from './physics';
import { createHyosan3DNavigator } from './navigation';
import { traceHyosanNavigationRoute } from './navigation-route';
import { createHyosanNavigationEntrances } from './navigation-entrances';
import { createHyosanNavigationFlights } from './navigation-flights';
import type { HyosanNavigationTarget } from './navigation-target';
import { overlapsHyosanStaffroomFire } from './staffroom-fire';
import { hyosan3DRoomForFloor } from './rooms';
import { aimDirection, direction, distance, planarDistance } from './combat-geometry';
import { hyosan3DBow } from './save';
import { createHyosanSupportGeometry } from './support-geometry';
import { HYOSAN_MAIN_LAYER, hyosanLayerBoundaryHit, sameHyosanCombatLayer } from './combat-layers';
import type { CombatEnemy, RegionFactory, RegionModule, RegionSave, SharedCombatContext } from './region-module';
import { type Hyosan3DArea, type Hyosan3DEffect, type Hyosan3DEnemy, type Hyosan3DEntry,
  type Hyosan3DEquipment, type Hyosan3DInput, type Hyosan3DPlayer, type Hyosan3DRegionRuntime, type Hyosan3DSnapshot } from './types';

const TICK = 1 / 60;
// The exact native extraction is immutable, so physics worlds reuse its BVHs.
for (const mesh of nativeCounterData.meshes) {
  Object.freeze(mesh.positions); Object.freeze(mesh.indices); Object.freeze(mesh);
}
export interface HyosanCombatWorldOptions {
  factories: readonly RegionFactory[];
  area: Hyosan3DArea;
  savedByArea?: Partial<Record<Hyosan3DArea, unknown>>;
  equipment?: Hyosan3DEquipment;
  completedAreas?: readonly Hyosan3DArea[];
  entry?: Hyosan3DEntry;
  /** Campaign seams change guidance only; standalone regions freeze at completion. */
  campaign?: boolean;
  difficulty?: HyosanDifficulty;
}
export interface HyosanCombatWorld extends Hyosan3DRegionRuntime {
  setDifficulty(difficulty: HyosanDifficulty): void;
  /** Unvisited regions are omitted even though their live bodies are prepared. */
  exportRegionSaves(): Partial<Record<Hyosan3DArea, RegionSave>>;
  readEquipment(): Required<Hyosan3DEquipment>;
  completedAreas(): readonly Hyosan3DArea[];
  /** Cancel airborne/held actions at a narrative boundary without relocating the player. */
  cancelActions(): void;
  /** Physical route through known rooms, plus an explicitly selected entrance. */
  navigationRoute(to: HyosanNavigationTarget, knownRooms: readonly string[]): readonly GroundPoint[];
  settled(): Promise<void>;
}

const copyEnemy = (enemy: CombatEnemy): Hyosan3DEnemy => ({
  surfaceId: enemy.surfaceId,
  currentLayerId: enemy.currentLayerId ?? HYOSAN_MAIN_LAYER,
  ownerArea: enemy.ownerArea, id: enemy.id, x: enemy.x, y: enemy.y, z: enemy.z, yaw: enemy.yaw,
  hp: enemy.hp, maxHp: enemy.maxHp, kind: enemy.kind, dormant: enemy.dormant, entering: enemy.entering,
  profile: enemy.profile, rooftopBeat: enemy.rooftopBeat, rooftopPhase: enemy.rooftopPhase, staffroomBeat: enemy.staffroomBeat, libraryBeat: enemy.libraryBeat, scienceBeat: enemy.scienceBeat, classroomBeat: enemy.classroomBeat, broadcastBeat: enemy.broadcastBeat, comboBeat: enemy.comboBeat,
  attackStyle: enemy.attackStyle, attackRange: enemy.attackRange, attackHalfAngle: enemy.attackHalfAngle,
  attackPhase: enemy.attackPhase, attackProgress: enemy.attackProgress, defeatedAt: enemy.defeatedAt,
});

/** One clock, player, Rapier world and projectile list for all authored encounters. */
export async function createHyosanCombatWorld(source: Hyosan3DLayout, options: HyosanCombatWorldOptions): Promise<HyosanCombatWorld> {
  if (!options.factories.length) throw new Error('A Hyosan combat world needs at least one region');
  const supports = createHyosanSupportGeometry(source);
  const entrances = createHyosanNavigationEntrances(source);
  const flights = createHyosanNavigationFlights(source);
  const supportRooms = new Map(supports.surfaces.map((surface) => [surface.surfaceId,
    hyosan3DRoomForFloor({ id: surface.surfaceId, roomId: surface.roomId })]));
  const physics = await createHyosan3DPhysics(source, source === canonicalLayout
    ? { servingCounterRays: nativeCounterData as HyosanServingCounterRayData } : undefined);
  const navigate = createHyosan3DNavigator(source, physics.clearGround, physics.revision, physics.changesSince);
  const modules: RegionModule[] = [];
  const byArea = new Map<Hyosan3DArea, RegionModule>();
  const equipment: Required<Hyosan3DEquipment> = { kitCollected: false, supplyCollected: false, piercingCollected: false, stringReinforced: false, tipReinforced: false };
  const player: Hyosan3DPlayer = { x: 0, y: 0, z: 0, yaw: Math.PI, aimPitch: 0,
    hp: 0, maxHp: 6, moving: false, shotTime: -1, dashUntil: 0, invulnerableUntil: 0 };
  let area = options.area;
  let difficulty = isHyosanDifficulty(options.difficulty) ? options.difficulty : 'standard';
  let time = 0; let accumulator = 0; let serial = 0; let paused = false; let disposed = false; let frozen = false;
  let arrows: HyosanBowProjectile[] = []; let effects: Hyosan3DEffect[] = [];
  let nextShotAt = 0; let dashReadyAt = 0; let deadUntil = 0; let dashDirection = { x: 1, z: 0 };
  let nextRecoveryAt = Infinity;
  let requireRelease = false; let previousDash = false; let previousInteract = false; let pendingDash = false; let pendingInteract = false;
  let pendingShot: Pick<Hyosan3DInput, 'aimX' | 'aimY' | 'aimZ'> | null = null;
  let terminalSnapshot: Readonly<Hyosan3DSnapshot> | null = null; let failure: unknown;
  const completed = new Set<Hyosan3DArea>();
  const savedAreas = new Set<Hyosan3DArea>();
  const enemies = () => modules.flatMap((region) => region.enemies);
  const effect = (kind: Hyosan3DEffect['kind'], at: GroundPoint, duration = .35, heightOffset = 1.1,
    contact?: Pick<Hyosan3DEffect, 'actorId' | 'directionX' | 'directionZ'>) => {
    effects.push({ id: `school-effect-${serial++}`, kind, x: at.x,
      y: (at.y ?? physics.heightAt(at) ?? 0) + heightOffset, z: at.z, startedAt: time, duration, ...contact });
  };
  const contactDirection = (from: Partial<GroundPoint> | undefined, to: GroundPoint) => {
    const x = to.x - (from?.x ?? NaN); const z = to.z - (from?.z ?? NaN); const length = Math.hypot(x, z);
    return Number.isFinite(length) && length > 1e-6 ? { directionX: x / length, directionZ: z / length } : {};
  };
  const hurtPlayer: SharedCombatContext['hurtPlayer'] = (amount, attacker) => {
    if (player.hp <= 0 || time < player.invulnerableUntil || attacker && !sameHyosanCombatLayer(player, attacker)) return;
    player.hp = Math.max(0, player.hp - amount); player.invulnerableUntil = time + HYOSAN_DIFFICULTY[difficulty].damageGrace;
    nextRecoveryAt = time + HYOSAN_DIFFICULTY[difficulty].recoveryDelay;
    effect('hurt', player, .55, 1.1, { actorId: 'player', ...contactDirection(attacker, player) });
    if (player.hp === 0) { deadUntil = time + 1.5; player.moving = false; arrows = []; }
  };
  const hurtEnemy: SharedCombatContext['hurtEnemy'] = (id, amount, hitPoint) => {
    if (!Number.isFinite(amount) || amount <= 0) return false;
    const enemy = enemies().find((candidate) => candidate.id === id && candidate.hp > 0 && !candidate.dormant);
    if (!enemy) return false;
    enemy.active = true; enemy.hp = Math.max(0, enemy.hp - amount);
    effect('hit', hitPoint ?? enemy, .35, hitPoint ? 0 : 1.1, { actorId: enemy.id, ...contactDirection(hitPoint, enemy) });
    if (enemy.hp === 0) { enemy.defeatedAt = time; physics.removeActor(enemy.id); effect('defeat', enemy, .75); }
    byArea.get(enemy.ownerArea)?.onHit?.(enemy);
    return true;
  };
  const context: SharedCombatContext = {
    source, physics, navigate, player, equipment,
    get time() { return time; }, get dt() { return TICK; }, get area() { return area; }, get enemies() { return enemies(); },
    effect, hurtPlayer, hurtEnemy,
    checkpoint(point) {
      if (player.hp <= 0) return;
      player.hp = player.maxHp; nextShotAt = dashReadyAt = time; player.dashUntil = time;
      effect('upgrade', point, 1.2);
    },
    movementMultiplier(point, kind) {
      return modules.reduce((multiplier, region) => Math.min(multiplier, region.movementMultiplier?.(point, kind) ?? 1), 1);
    },
  };
  const clearInputs = () => {
    accumulator = 0; requireRelease = true; previousDash = false; previousInteract = false;
    pendingDash = false; pendingInteract = false; pendingShot = null;
  };
  const exportRegionSaves = (): Partial<Record<Hyosan3DArea, RegionSave>> => {
    if (failure) return {};
    return Object.fromEntries(modules.filter((region) => savedAreas.has(region.id) || region.readProgress().discoveredRooms.length > 0)
      .map((region) => [region.id, structuredClone(region.exportSave())]));
  };
  const checkRoster = () => {
    const seen = new Set(['player']);
    for (const enemy of enemies()) {
      if (seen.has(enemy.id)) throw new Error(`Duplicate Hyosan combat actor ${enemy.id}`);
      seen.add(enemy.id);
      if (!byArea.has(enemy.ownerArea)) throw new Error(`Unknown Hyosan actor owner ${enemy.ownerArea}`);
    }
  };
  const initialize = (saves: Partial<Record<Hyosan3DArea, unknown>>, gear: Hyosan3DEquipment | undefined,
    resolved: readonly Hyosan3DArea[], destination: Hyosan3DArea, entry?: Hyosan3DEntry, release = true) => {
    physics.removeActor('player');
    for (const enemy of enemies()) physics.removeActor(enemy.id);
    area = destination; time = 0; serial = 0; frozen = false; paused = false; arrows = []; effects = [];
    nextShotAt = dashReadyAt = deadUntil = 0;
    Object.assign(player, { hp: 0, moving: false, shotTime: -1, dashUntil: 0, invulnerableUntil: 0, aimPitch: 0 });
    Object.assign(equipment, { kitCollected: gear?.kitCollected === true, supplyCollected: gear?.supplyCollected === true,
      piercingCollected: gear?.piercingCollected === true, stringReinforced: gear?.stringReinforced === true, tipReinforced: gear?.tipReinforced === true });
    completed.clear(); for (const id of resolved) if (byArea.has(id)) completed.add(id);
    savedAreas.clear(); for (const region of modules) if (saves[region.id] != null) savedAreas.add(region.id);
    for (const region of modules) region.reset(saves[region.id], completed.has(region.id));
    checkRoster();
    const selected = byArea.get(area);
    if (!selected) throw new Error(`Unknown Hyosan combat area ${area}`);
    if (entry && (![entry.x, entry.y, entry.z, entry.yaw, entry.hp].every(Number.isFinite) || entry.hp < 0 || entry.hp > player.maxHp)) {
      throw new Error('Invalid Hyosan combat entry');
    }
    Object.assign(player, physics.addActor('player', entry ?? selected.respawnPoint()), {
      yaw: entry?.yaw ?? Math.PI, hp: entry?.hp ?? player.maxHp,
    });
    deadUntil = player.hp === 0 ? 1.5 : 0;
    nextRecoveryAt = player.hp < player.maxHp ? time + HYOSAN_DIFFICULTY[difficulty].recoveryDelay : Infinity;
    for (const region of modules) region.observePlayer();
    clearInputs(); requireRelease = release; physics.sync();
  };
  const observe = () => {
    if (options.campaign && player.hp > 0) {
      const seams = [
        ...(source.rooftop ? [{ west: 'gymnasium' as const, east: 'rooftop' as const, ...source.rooftop.entrySeam, halfWidth: 1.5 }] : []),
        ...(source.gymnasium ? [{ west: 'staffroom' as const, east: 'gymnasium' as const, ...source.gymnasium.entrySeam, halfWidth: 1.5 }] : []),
        ...(source.staffroom ? [{ west: 'library' as const, east: 'staffroom' as const, ...source.staffroom.entrySeam, halfWidth: 1.5 }] : []),
        ...(source.science ? [{ west: 'science' as const, east: 'cafeteria' as const, ...source.science.exit, halfWidth: 1.2 }] : []),
        ...(source.classroom ? [{ west: 'cafeteria' as const, east: 'classroom' as const, ...source.classroom.entrySeam, halfWidth: 1.5 }] : []),
        ...(source.library ? [{ west: 'broadcast' as const, east: 'library' as const, ...source.library.entrySeam, halfWidth: 1.5 }] : []),
        ...(source.broadcast ? [{ west: 'classroom' as const, east: 'broadcast' as const, ...source.broadcast.entrySeam, halfWidth: 1.5 }] : []),
      ];
      for (const seam of seams) {
        if (!byArea.has(seam.west) || !byArea.has(seam.east) || Math.abs(player.z - seam.z) >= seam.halfWidth) continue;
        if (area === seam.west && player.x > seam.x + .3) area = seam.east;
        else if (area === seam.east && player.x < seam.x - .3) area = seam.west;
      }
    }
    for (const region of modules) region.observePlayer();
  };
  const interactionPoint = (id: Hyosan3DArea, action: Hyosan3DSnapshot['interaction']): GroundPoint | undefined => {
    if (id === 'rooftop') {
      const plan = source.rooftop;
      return action === 'echo' ? plan?.echo : action === 'supply' ? plan?.supply
        : action === 'keepsake' ? plan?.hidden : plan?.shortcut.interactPoint;
    }
    if (id === 'gymnasium') {
      const plan = source.gymnasium;
      if (action === 'cover-cart' && plan) {
        const cart = byArea.get(id)?.furniture().find((item) => item.id === plan.coverCart.id);
        return cart ? { ...cart, x: cart.x + plan.coverCart.interactOffset.x, z: cart.z + plan.coverCart.interactOffset.z } : undefined;
      }
      return action === 'exit-cart' ? plan?.exitCart.interactPoint : action === 'echo' ? plan?.echo
        : action === 'supply' ? plan?.supply : action === 'keepsake' ? plan?.hidden : plan?.shortcut.interactPoint;
    }
    if (id === 'science') {
      const plan = source.science;
      return action === 'origin' ? plan?.origin : action === 'upgrade' ? plan?.upgrade : action === 'echo' ? plan?.echo : plan?.shortcut;
    }
    if (id === 'classroom') {
      const plan = source.classroom;
      return action === 'barricade' ? plan?.barricade.interactPoint : action === 'upgrade' ? plan?.upgrade
        : action === 'echo' ? plan?.echo : plan?.shortcut.interactPoint;
    }
    if (id === 'staffroom') {
      const plan = source.staffroom;
      return action === 'arrowtip' ? plan?.upgrade : action === 'keepsake' ? plan?.hidden
        : action === 'echo' ? plan?.echo : plan?.shortcut.interactPoint;
    }
    if (id === 'library') {
      const plan = source.library;
      return action === 'bowstring' ? plan?.upgrade : action === 'keepsake' ? plan?.hidden
        : action === 'echo' ? plan?.echo : plan?.shortcut.interactPoint;
    }
    if (id === 'broadcast') {
      const plan = source.broadcast;
      return action === 'origin' ? plan?.console : action === 'hose' ? plan?.hose.interactPoint
        : action === 'supply' ? plan?.supply : action === 'echo' ? plan?.echo : plan?.shortcut.interactPoint;
    }
    return action === 'upgrade' ? source.upgrade : action === 'echo' ? source.adventure?.echo
      : action === 'supply' ? source.adventure?.supply : source.adventure?.shortcut;
  };
  const selectedInteraction = () => {
    if (player.hp <= 0 || frozen) return undefined;
    return modules.flatMap((region) => {
      const action = region.interaction(); if (!action) return [];
      const point = interactionPoint(region.id, action);
      return [{ region, action, distance: point ? distance(player, point) : Infinity }];
    }).sort((a, b) => a.distance - b.distance || a.region.id.localeCompare(b.region.id))[0];
  };
  const shoot = (input: Readonly<Hyosan3DInput>) => {
    if (!input.attackHeld || player.hp <= 0) return;
    const explicit = Number.isFinite(input.aimX) && Number.isFinite(input.aimZ)
      ? aimDirection(input.aimX!, Number.isFinite(input.aimY) ? input.aimY! : 0, input.aimZ!) : null;
    const target = enemies().filter((enemy) => enemy.hp > 0 && !enemy.dormant && sameHyosanCombatLayer(player, enemy)
      && distance(player, enemy) <= 14 && physics.lineOfSight(player, enemy, undefined, HYOSAN_BOW_HEIGHT))
      .sort((a, b) => distance(player, a) - distance(player, b) || a.id.localeCompare(b.id))[0];
    const aim = explicit && (explicit.x || explicit.y || explicit.z) ? explicit : target
      ? aimDirection(target.x - player.x, target.y - player.y, target.z - player.z)
      : { x: Math.sin(player.yaw), y: 0, z: Math.cos(player.yaw) };
    if (aim.x || aim.z) player.yaw = Math.atan2(aim.x, aim.z);
    player.aimPitch = Math.atan2(aim.y, Math.hypot(aim.x, aim.z));
    if (time < nextShotAt) return;
    const bow = hyosan3DBow(equipment.kitCollected, equipment.supplyCollected, equipment.piercingCollected, equipment.stringReinforced, equipment.tipReinforced);
    nextShotAt = time + bow.interval; player.shotTime = time;
    arrows.push({ ...createHyosanBowProjectile(`school-arrow-${serial++}`, { x: player.x, y: player.y + HYOSAN_BOW_HEIGHT, z: player.z }, aim, bow),
      currentLayerId: player.currentLayerId ?? HYOSAN_MAIN_LAYER });
    effect('shot', player, .18, HYOSAN_BOW_HEIGHT);
  };
  const separate = () => {
    const living = enemies().filter((enemy) => enemy.hp > 0 && !enemy.dormant);
    for (let index = 0; index < living.length; index++) {
      const enemy = living[index]; if (enemy.kind === 'boss') continue;
      for (const other of [player, ...living.slice(index + 1)]) {
        if (!sameHyosanCombatLayer(enemy, other)) continue;
        const radius = 'kind' in other && other.kind === 'boss' ? .5 : .32;
        if (enemy.y >= other.y + 1.1 + radius * 2 || other.y >= enemy.y + 1.74) continue;
        const gap = planarDistance(enemy, other); const separation = radius === .5 ? .84 : .66;
        if (gap >= separation) continue;
        const away = gap > .001 ? direction(enemy.x - other.x, enemy.z - other.z) : direction(index % 2 ? 1 : -1, 1);
        const desired = Math.min(.025, (separation - gap) / 2);
        // Locomotion crosses floors; the small visual spacing correction must
        // not push an arriving attacker back across the seam every tick.
        const boundary = hyosanLayerBoundaryHit(enemy, { ...away, y: 0 }, desired,
          enemy.currentLayerId ?? HYOSAN_MAIN_LAYER, supports.transitionPlanes);
        const amount = boundary ? Math.max(0, Math.min(desired, boundary.distance - .001)) : desired;
        if (amount === 0) continue;
        Object.assign(enemy, physics.moveActor(enemy.id, away.x * amount, away.z * amount));
      }
    }
  };
  const tick = (input: Readonly<Hyosan3DInput>, dash: boolean, interact: boolean): boolean => {
    time += TICK; effects = effects.filter((item) => time < item.startedAt + item.duration);
    if (player.hp <= 0) {
      if (time >= deadUntil) {
        initialize(exportRegionSaves(), { ...equipment }, [...completed], area);
        effect('respawn', player, .8); return true;
      }
      return false;
    }
    const movement = direction(Number.isFinite(input.moveX) ? input.moveX : 0, Number.isFinite(input.moveZ) ? input.moveZ : 0);
    if (dash && time >= dashReadyAt) {
      dashDirection = movement.x || movement.z ? movement : { x: Math.sin(player.yaw), z: Math.cos(player.yaw) };
      player.dashUntil = time + .18; player.invulnerableUntil = Math.max(player.invulnerableUntil, player.dashUntil); dashReadyAt = time + 1.1;
    }
    const moving = time < player.dashUntil ? dashDirection : movement;
    const speed = time < player.dashUntil ? 10 : 3.9 * context.movementMultiplier(player, 'player');
    const previous = { x: player.x, z: player.z };
    Object.assign(player, physics.moveActor('player', moving.x * speed * TICK, moving.z * speed * TICK));
    player.moving = planarDistance(previous, player) > .001;
    if (player.moving) { player.yaw = Math.atan2(moving.x, moving.z); player.aimPitch = 0; }
    observe();
    const selected = interact ? selectedInteraction()?.region : undefined;
    // Preserve the local checkpoint/interaction priority when foreign pursuers
    // attack in the same tick. The remaining encounter order stays stable.
    const first = selected ?? byArea.get(area)!;
    for (const region of [first, ...modules.filter((candidate) => candidate !== first)]) {
      if (player.hp <= 0) break;
      region.update({ interactPressed: region === selected });
    }
    physics.sync(); shoot(input); separate(); physics.sync();
    arrows = arrows.filter((arrow) => advanceHyosanBowProjectile(arrow, (from, direction, travel, ignored) => {
      const excluded = new Set(typeof ignored === 'string' ? [ignored] : ignored);
      for (const enemy of enemies()) if (!sameHyosanCombatLayer(arrow, enemy)) excluded.add(enemy.id);
      const collision = physics.cast(from, direction, travel, excluded);
      const boundary = hyosanLayerBoundaryHit({ x: from.x, y: from.y ?? arrow.y, z: from.z },
        { x: direction.x, y: direction.y ?? 0, z: direction.z }, travel, arrow.currentLayerId, supports.transitionPlanes);
      return boundary && (!collision || boundary.distance <= collision.distance)
        ? { distance: boundary.distance, actorId: null, geometryId: `layer-transition:${boundary.id}` } : collision;
    }, (id, hit) => {
      return hurtEnemy(id, hit.damage, hit);
    }, (at) => effect('impact', at, .35, 0)));
    for (const region of modules) region.afterCombat();
    if (player.hp > 0 && player.hp < player.maxHp && time >= nextRecoveryAt) {
      player.hp = Math.min(player.maxHp, player.hp + 1);
      nextRecoveryAt = time + HYOSAN_DIFFICULTY[difficulty].recoveryInterval;
    }
    physics.sync();
    let finished = false;
    if (player.hp > 0) for (const region of modules) {
      if (!region.readProgress().completed) continue;
      finished = true;
      if (options.campaign) { completed.add(region.id); region.markResolved(); }
      else { frozen = true; player.moving = false; arrows = []; }
    }
    return finished;
  };
  const read = (): Readonly<Hyosan3DSnapshot> => {
    if (terminalSnapshot) return terminalSnapshot;
    const selected = byArea.get(area)!;
    const progress = structuredClone(selected.readProgress());
    // A doorway's destination floor can precede the encounter guidance seam.
    // Locate the player on their physical support throughout that hysteresis.
    const room = supportRooms.get(player.surfaceId ?? '') ?? progress.room;
    return { area, time, difficulty,
      recoveryIn: difficulty === 'relaxed' && player.hp > 0 && player.hp < player.maxHp ? Math.max(0, nextRecoveryAt - time) : null,
      player: { ...player }, enemies: enemies().map(copyEnemy),
      arrows: arrows.map(({ id, x, y, z, dx, dy, dz, currentLayerId }) => ({ id, x, y, z, dx, dy, dz, currentLayerId })),
      effects: effects.map((item) => ({ ...item })), furniture: modules.flatMap((region) => region.furniture().map((item) => ({ ...item }))),
      fires: modules.flatMap((region) => region.fires?.() ?? []),
      schoolState: Object.fromEntries(modules.map((region) => [region.id, structuredClone(region.readProgress())])),
      bow: hyosan3DBow(equipment.kitCollected, equipment.supplyCollected, equipment.piercingCollected, equipment.stringReinforced, equipment.tipReinforced),
      inflow: selected.inflow?.() ?? modules.find((region) => region.inflow)?.inflow?.(), interaction: selectedInteraction()?.action ?? null,
      progress: { ...progress, room, inWater: context.movementMultiplier(player, 'player') < 1 }, paused };
  };
  try {
    for (const factory of options.factories) {
      const region = factory(context);
      if (byArea.has(region.id)) throw new Error(`Duplicate Hyosan region ${region.id}`);
      modules.push(region); byArea.set(region.id, region);
    }
    const regionOrder: readonly Hyosan3DArea[] = HYOSAN_3D_AREAS;
    modules.sort((a, b) => regionOrder.indexOf(a.id) - regionOrder.indexOf(b.id));
    initialize(options.savedByArea ?? {}, options.equipment, options.completedAreas ?? [], options.area, options.entry, false);
    navigate.prepare([.32, .5]);
  } catch (error) { physics.dispose(); throw error; }
  return {
    setDifficulty(next) {
      if (disposed || !isHyosanDifficulty(next) || next === difficulty) return;
      difficulty = next;
      nextRecoveryAt = time + HYOSAN_DIFFICULTY[difficulty].recoveryDelay;
    },
    read, exportRegionSaves, readEquipment: () => ({ ...equipment }), completedAreas: () => modules.map((region) => region.id).filter((id) => completed.has(id)),
    navigationRoute(to, knownRooms) {
      if (disposed || failure) return [];
      const known = new Set(knownRooms);
      if (to.entrance && to.flight) return [];
      const crossing = to.entrance && entrances.crossing(to.entrance.id, to.entrance.fromRoom);
      if (to.entrance && (!crossing || !known.has(crossing.fromRoom)
        || Math.hypot(to.x - crossing.to.x, to.z - crossing.to.z, (to.y ?? 0) - (crossing.to.y ?? 0)) > .001)) return [];
      const flight = to.flight && flights.crossing(to.flight.id, to.flight.exit);
      const playerSupport = supports.sample(player);
      if (to.flight && (!flight || Math.hypot(to.x - flight.to.x, to.z - flight.to.z, (to.y ?? 0) - flight.to.y) > .001
        || !known.has(flight.fromRoom ?? '') && !(known.has(flight.room) && flight.onFlight(playerSupport)))) return [];
      const hot = new Set(read().fires?.filter((fire) => fire.phase === 'warning' || fire.phase === 'burning').map((fire) => fire.id));
      const hazards = (source.staffroom?.fire.zones ?? []).filter((zone) => hot.has(zone.id));
      const segment = (from: GroundPoint, to: GroundPoint, radius: number, permitCrossing: boolean) => traceHyosanNavigationRoute({ from, to, next: navigate, clear: physics.clearGround, radius,
        allows(point) {
          const candidates = supports.candidates(point).filter((surface) => Math.abs(surface.height - (point.y ?? surface.height)) <= .35);
          if (!candidates.some((surface) => known.has(supportRooms.get(surface.surfaceId) ?? '')
            || permitCrossing && (crossing && crossing.contains(point) && supportRooms.get(surface.surfaceId) === crossing.toRoom
              || flight && flight.allows(point, surface)))) return false;
          return !hazards.some((zone) => overlapsHyosanStaffroomFire({ x: point.x, z: point.z,
            y: point.y ?? candidates[0].height, currentLayerId: candidates[0].currentLayerId }, radius, zone));
        } });
      const trace = (radius: number) => {
        if (flight) {
          const atExit = flight.onLanding(player);
          const approach = atExit || flight.onFlight(playerSupport) ? [{ ...player }] : segment(player, flight.from, radius, false);
          if (!approach.length) return [];
          const traverse = atExit ? [approach[approach.length - 1]] : segment(approach[approach.length - 1], flight.edge, radius, true);
          if (!traverse.length) return [];
          const arrival = segment(traverse[traverse.length - 1], flight.to, radius, true);
          return arrival.length ? [...approach, ...traverse.slice(1), ...arrival.slice(1)] : [];
        }
        if (!crossing) return segment(player, to, radius, false);
        // Align before the doorway instead of drawing a diagonal across its jamb.
        const approach = crossing.contains(player) ? [{ ...player }] : segment(player, crossing.from, radius, false);
        if (!approach.length) return [];
        const exit = segment(approach[approach.length - 1], to, radius, true);
        return exit.length ? [...approach, ...exit.slice(1)] : [];
      };
      // Prefer steering room, without sending a beginner on a large detour.
      // Wall contact and narrow passages retain the player's real footprint.
      const comfortable = trace(.5); const actual = trace(.32);
      const length = (points: readonly GroundPoint[]) => points.slice(1).reduce((sum, point, index) =>
        sum + Math.hypot(point.x - points[index].x, point.z - points[index].z), 0);
      return comfortable.length && (!actual.length || length(comfortable) <= length(actual) * 1.35) ? comfortable : actual;
    },
    step(input, dt = TICK) {
      if (disposed || paused || frozen || !Number.isFinite(dt) || dt <= 0) return;
      if (requireRelease && !input.attackHeld && !input.dashPressed && !input.interactPressed) requireRelease = false;
      pendingDash ||= !requireRelease && input.dashPressed && !previousDash;
      pendingInteract ||= !requireRelease && input.interactPressed && !previousInteract;
      if (!requireRelease && input.attackHeld) pendingShot = { aimX: input.aimX, aimY: input.aimY, aimZ: input.aimZ };
      previousDash = input.dashPressed; previousInteract = input.interactPressed; accumulator += Math.min(dt, .1);
      while (accumulator + 1e-9 >= TICK) {
        accumulator -= TICK;
        const stop = tick(requireRelease ? { ...input, attackHeld: false } : pendingShot ? { ...input, ...pendingShot, attackHeld: true } : input,
          pendingDash, pendingInteract);
        pendingDash = false; pendingInteract = false; pendingShot = null;
        if (stop || accumulator < 0) { accumulator = 0; break; }
      }
    },
    enter(entry: Hyosan3DEntry, gear: Hyosan3DEquipment, continuingInput?: Readonly<Hyosan3DInput>) {
      if (disposed) return;
      if (![entry.x, entry.y, entry.z, entry.yaw, entry.hp].every(Number.isFinite) || entry.hp < 0 || entry.hp > player.maxHp || !physics.canStand(entry)) {
        throw new Error('Invalid Hyosan combat entry');
      }
      physics.removeActor('player');
      Object.assign(player, physics.addActor('player', entry), { yaw: entry.yaw, hp: entry.hp, aimPitch: 0,
        moving: false, dashUntil: time, invulnerableUntil: time });
      equipment.kitCollected ||= gear.kitCollected; equipment.supplyCollected ||= gear.supplyCollected;
      equipment.piercingCollected ||= gear.piercingCollected === true; equipment.stringReinforced ||= gear.stringReinforced === true; equipment.tipReinforced ||= gear.tipReinforced === true;
      deadUntil = player.hp === 0 ? time + 1.5 : 0; effects = []; clearInputs();
      nextRecoveryAt = time + HYOSAN_DIFFICULTY[difficulty].recoveryDelay;
      if (continuingInput) { requireRelease = false; previousDash = continuingInput.dashPressed; previousInteract = continuingInput.interactPressed; }
      observe(); physics.sync();
    },
    cancelActions() {
      if (disposed) return;
      arrows = []; effects = []; clearInputs();
      player.moving = false; player.shotTime = -1; player.dashUntil = time;
    },
    canLeave: () => !disposed && !enemies().some((enemy) => enemy.hp > 0 && !enemy.dormant && distance(player, enemy) <= 14 && physics.lineOfSight(player, enemy)),
    setPaused(value) { if (!disposed && value !== paused) { paused = value; clearInputs(); } },
    reset() {
      if (disposed) return;
      const previous = read();
      try {
        initialize({}, undefined, [], options.campaign && byArea.has('science') ? 'science' : options.area);
        navigate.prepare([.32, .5]);
      } catch (error) {
        failure = error; disposed = true; physics.dispose(); terminalSnapshot = { ...previous, paused: true }; throw error;
      }
    },
    async settled() { if (failure) throw failure; },
    dispose() { if (!disposed) { terminalSnapshot = read(); disposed = true; physics.dispose(); } },
  };
}
