export type HyosanStaffroomBossBeat = 'idle' | 'notice' | 'pursuit' | 'investigate' | 'return'
  | 'grab-windup' | 'grab' | 'recovery' | 'ignite-windup' | 'ignite-recovery' | 'death';
export interface HyosanStaffroomBossPoint { x: number; y: number; z: number }
export interface HyosanStaffroomBossInput extends HyosanStaffroomBossPoint {
  time: number; targetX: number; targetY: number; targetZ: number; distance: number;
  visible: boolean; sameLayer: boolean; canAttack?: boolean; hit?: boolean; dead?: boolean;
  /** Region supplies only a still-available authored point with a clear same-layer reach. */
  igniteZone?: HyosanStaffroomBossPoint & { id: string };
}
export interface HyosanStaffroomBossFrame {
  beat: HyosanStaffroomBossBeat; yaw: number; navigationTarget: Readonly<HyosanStaffroomBossPoint> | null;
  speed: number; attackPhase: 'idle' | 'windup' | 'strike' | 'recover'; attackProgress: number;
  attackId: number; strike: boolean; contact: boolean; moveDistance: number;
  range: number; contactRange: number; halfAngle: number; damage: number; igniteZoneId: string | null;
}
export const HYOSAN_STAFFROOM_BOSS = {
  hp: 64, notice: .75, noticeRange: 9, pursuitSpeed: 2.4, investigate: 6, arrivalRange: .25,
  grab: { windup: .7, duration: .2, distance: .45, range: 1.55, contactRange: 1.1, halfAngle: Math.PI / 4, damage: 2 },
  recovery: 1.05, ignite: { windup: 1.1, recovery: 1.2, range: 1.8, attempts: 2 },
} as const;

/** Clock and witnessed intent only. The region owns KCC, LOS, layer and damage checks. */
export function createHyosanStaffroomBossController(home: Readonly<HyosanStaffroomBossPoint>) {
  const origin = { ...home };
  let beat: HyosanStaffroomBossBeat = 'idle'; let since = 0; let lastTime = -1; let yaw = 0;
  let lastSeen: HyosanStaffroomBossPoint | null = null; let lastSeenAt = -Infinity;
  let attackId = 0; let travelled = 0; let pendingDistance = 0; let pendingContact = false; let pendingFeedback = false; let grabbed = false;
  let igniteZone: HyosanStaffroomBossInput['igniteZone'];
  const attemptedZones = new Set<string>();
  const reset = () => { beat = 'idle'; since = 0; lastTime = -1; yaw = 0; lastSeen = null; lastSeenAt = -Infinity;
    attackId = 0; travelled = 0; pendingDistance = 0; pendingContact = false; pendingFeedback = false; grabbed = false; igniteZone = undefined; attemptedZones.clear(); };
  const enter = (next: HyosanStaffroomBossBeat) => { beat = next; since = lastTime; };
  return {
    reset,
    advance(input: HyosanStaffroomBossInput): HyosanStaffroomBossFrame {
      if (input.time < lastTime) reset();
      const changed = input.time !== lastTime; const previousTime = lastTime; lastTime = input.time;
      let strike = false; let moveDistance = 0; let igniteZoneId: string | null = null;
      const nearbyZone = (zone: HyosanStaffroomBossPoint) => Math.hypot(zone.x - input.x, zone.y - input.y, zone.z - input.z) <= HYOSAN_STAFFROOM_BOSS.ignite.range;
      const seek = () => {
        if (input.visible && lastSeen) enter('pursuit');
        else if (lastSeen && input.time - lastSeenAt < HYOSAN_STAFFROOM_BOSS.investigate) enter('investigate');
        else enter('return');
      };
      if (input.dead) {
        if (beat !== 'death') enter('death');
        pendingDistance = 0; pendingContact = false; pendingFeedback = false;
      } else if (changed && beat !== 'death') {
        pendingContact = false; pendingDistance = 0; pendingFeedback = false;
        if (input.visible) {
          lastSeen = { x: input.targetX, y: input.targetY, z: input.targetZ }; lastSeenAt = input.time;
        }
        if ((beat === 'idle' || beat === 'return') && (input.hit || input.visible && input.sameLayer && input.distance <= HYOSAN_STAFFROOM_BOSS.noticeRange)) {
          if (input.visible) yaw = Math.atan2(input.targetX - input.x, input.targetZ - input.z);
          else if (!lastSeen || input.time - lastSeenAt >= HYOSAN_STAFFROOM_BOSS.investigate) {
            // A hit proves a local impact, not the unseen shooter's position.
            lastSeen = { x: input.x, y: input.y, z: input.z }; lastSeenAt = input.time;
          }
          enter('notice');
        } else if (beat === 'notice' && input.time - since >= HYOSAN_STAFFROOM_BOSS.notice - 1e-8) seek();
        else if (beat === 'pursuit' && input.visible && input.sameLayer && input.canAttack !== false && input.distance <= HYOSAN_STAFFROOM_BOSS.grab.range) {
          yaw = Math.atan2(input.targetX - input.x, input.targetZ - input.z);
          attackId++; travelled = 0; grabbed = false; enter('grab-windup');
        }
        else if (beat === 'grab-windup' && input.time - since >= HYOSAN_STAFFROOM_BOSS.grab.windup - 1e-8) { enter('grab'); strike = true; }
        else if (beat === 'grab' && input.time - since >= HYOSAN_STAFFROOM_BOSS.grab.duration - 1e-8) enter('recovery');
        else if (beat === 'recovery' && input.time - since >= HYOSAN_STAFFROOM_BOSS.recovery - 1e-8) {
          const zone = input.igniteZone;
          if (zone && attemptedZones.size < HYOSAN_STAFFROOM_BOSS.ignite.attempts && !attemptedZones.has(zone.id) && nearbyZone(zone)) {
            attemptedZones.add(zone.id); igniteZone = { ...zone };
            yaw = Math.atan2(zone.x - input.x, zone.z - input.z); enter('ignite-windup');
          } else seek();
        }
        else if (beat === 'ignite-windup' && input.time - since >= HYOSAN_STAFFROOM_BOSS.ignite.windup - 1e-8) {
          if (igniteZone && input.igniteZone?.id === igniteZone.id && nearbyZone(igniteZone)) igniteZoneId = igniteZone.id;
          enter('ignite-recovery');
        }
        else if (beat === 'ignite-recovery' && input.time - since >= HYOSAN_STAFFROOM_BOSS.ignite.recovery - 1e-8) seek();
        else if (beat === 'pursuit' && !input.visible || beat === 'investigate' && (input.visible || input.time - lastSeenAt >= HYOSAN_STAFFROOM_BOSS.investigate)) seek();
        else if (beat === 'return' && Math.hypot(input.x - origin.x, input.y - origin.y, input.z - origin.z) <= HYOSAN_STAFFROOM_BOSS.arrivalRange) enter('idle');
      }
      const current: HyosanStaffroomBossBeat = beat;
      const navigationTarget = current === 'pursuit' || current === 'investigate' ? lastSeen : current === 'return' ? origin : null;
      const moving = navigationTarget && Math.hypot(input.x - navigationTarget.x, input.y - navigationTarget.y, input.z - navigationTarget.z) > HYOSAN_STAFFROOM_BOSS.arrivalRange;
      if (moving) yaw = Math.atan2(navigationTarget.x - input.x, navigationTarget.z - input.z);
      if (changed && current === 'grab') {
        const dt = previousTime < 0 ? 0 : Math.min(1 / 60, Math.max(0, input.time - previousTime));
        pendingDistance = moveDistance = Math.min(HYOSAN_STAFFROOM_BOSS.grab.distance - travelled, HYOSAN_STAFFROOM_BOSS.grab.distance * dt / HYOSAN_STAFFROOM_BOSS.grab.duration);
        pendingContact = input.sameLayer; pendingFeedback = true;
      }
      const duration = current === 'notice' ? HYOSAN_STAFFROOM_BOSS.notice : current === 'grab-windup' ? HYOSAN_STAFFROOM_BOSS.grab.windup
        : current === 'grab' ? HYOSAN_STAFFROOM_BOSS.grab.duration : current === 'recovery' ? HYOSAN_STAFFROOM_BOSS.recovery
          : current === 'ignite-windup' ? HYOSAN_STAFFROOM_BOSS.ignite.windup : current === 'ignite-recovery' ? HYOSAN_STAFFROOM_BOSS.ignite.recovery : 0;
      return { beat: current, yaw, speed: moving ? HYOSAN_STAFFROOM_BOSS.pursuitSpeed : 0, navigationTarget,
        attackPhase: current === 'notice' || current === 'grab-windup' || current === 'ignite-windup' ? 'windup' : current === 'grab' ? 'strike'
          : current === 'recovery' || current === 'ignite-recovery' ? 'recover' : 'idle',
        attackProgress: duration ? Math.min(1, Math.max(0, (input.time - since) / duration)) : 0,
        strike, attackId, contact: current === 'grab' && input.sameLayer, moveDistance,
        range: HYOSAN_STAFFROOM_BOSS.grab.range - (current === 'grab' ? travelled : 0),
        contactRange: HYOSAN_STAFFROOM_BOSS.grab.contactRange, halfAngle: HYOSAN_STAFFROOM_BOSS.grab.halfAngle,
        damage: HYOSAN_STAFFROOM_BOSS.grab.damage, igniteZoneId };
    },
    /** Called once after KCC, with actual-pose same-layer cone and LOS contact. */
    resolveGrab(feedback: { movedDistance: number; blocked: boolean; contact: boolean }): boolean {
      if (beat !== 'grab' || !pendingFeedback) return false;
      const hit = pendingContact && feedback.contact && !grabbed;
      grabbed ||= hit;
      travelled += Math.max(0, Math.min(pendingDistance, feedback.movedDistance));
      pendingDistance = 0; pendingContact = false; pendingFeedback = false;
      if (travelled >= HYOSAN_STAFFROOM_BOSS.grab.distance - .001) travelled = HYOSAN_STAFFROOM_BOSS.grab.distance;
      if (feedback.blocked) enter('recovery');
      return hit;
    },
  };
}
