import type { GroundPoint, createHyosan3DPhysics } from './physics';
import type { Hyosan3DArrow } from './types';

/** Chin-height arrow axis: 1.45m bow grip plus the shipped arrow's 12mm rest. */
export const HYOSAN_BOW_HEIGHT = 1.462;

export interface HyosanBowProjectile extends Hyosan3DArrow {
  remaining: number; speed?: number; damage: number; penetrations: number; hitActors: Set<string>;
}

export function createHyosanBowProjectile(id: string, origin: GroundPoint & { y: number }, direction: GroundPoint & { y: number },
  bow: { damage: number; penetration?: number; projectileSpeed?: number }): HyosanBowProjectile {
  return { id, ...origin, dx: direction.x, dy: direction.y, dz: direction.z,
    remaining: 14, ...(bow.projectileSpeed === undefined ? {} : { speed: bow.projectileSpeed }), damage: bow.damage, penetrations: bow.penetration ?? 0, hitActors: new Set(['player']) };
}

/** A hit consumes the remaining distance of this tick; penetration never skips geometry or damages one actor twice. */
export function advanceHyosanBowProjectile(arrow: HyosanBowProjectile,
  cast: Awaited<ReturnType<typeof createHyosan3DPhysics>>['cast'],
  hitActor: (id: string, arrow: Readonly<HyosanBowProjectile>) => boolean,
  hitGeometry: (arrow: Readonly<HyosanBowProjectile>) => void, dt = 1 / 60): boolean {
  let travel = Math.min(arrow.remaining, (arrow.speed ?? 22) * dt);
  while (travel > 1e-8) {
    const hit = cast(arrow, { x: arrow.dx, y: arrow.dy, z: arrow.dz }, travel, arrow.hitActors);
    const moved = hit?.distance ?? travel;
    arrow.x += arrow.dx * moved; arrow.y += arrow.dy * moved; arrow.z += arrow.dz * moved;
    arrow.remaining -= moved; travel -= moved;
    if (!hit) break;
    if (!hit.actorId || !hitActor(hit.actorId, arrow)) { hitGeometry(arrow); return false; }
    arrow.hitActors.add(hit.actorId);
    if (arrow.penetrations === 0) return false;
    arrow.penetrations--;
  }
  return arrow.remaining > 1e-8;
}
