import type { GroundPoint } from './physics';

// Shared world-space combat geometry for each authored school area.
export const planarDistance = (a: GroundPoint, b: GroundPoint) => Math.hypot(a.x - b.x, a.z - b.z);
export const distance = (a: GroundPoint, b: GroundPoint) => Math.hypot(a.x - b.x, (a.y ?? 0) - (b.y ?? 0), a.z - b.z);
export const aimDirection = (x: number, y: number, z: number) => {
  const length = Math.hypot(x, y, z);
  return length > .001 ? { x: x / length, y: y / length, z: z / length } : { x: 0, y: 0, z: 0 };
};
export const direction = (x: number, z: number) => {
  const length = Math.hypot(x, z);
  return length > 0.001 ? { x: x / length, z: z / length } : { x: 0, z: 0 };
};
export const distanceToSegment = (point: GroundPoint, from: GroundPoint, to: GroundPoint) => {
  const dx = to.x - from.x;
  const dy = (to.y ?? 0) - (from.y ?? 0);
  const dz = to.z - from.z;
  const fraction = Math.max(0, Math.min(1, ((point.x - from.x) * dx + ((point.y ?? 0) - (from.y ?? 0)) * dy
    + (point.z - from.z) * dz) / (dx * dx + dy * dy + dz * dz || 1)));
  return Math.hypot(point.x - from.x - dx * fraction, (point.y ?? 0) - (from.y ?? 0) - dy * fraction,
    point.z - from.z - dz * fraction);
};
