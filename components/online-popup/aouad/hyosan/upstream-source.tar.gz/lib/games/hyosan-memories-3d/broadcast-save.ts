import layout from '@/docs/games/hyosan-memories-3d/world-layout.json';
import { HYOSAN_BROADCAST_ROOMS } from './types';

export type HyosanBroadcastRoom = typeof HYOSAN_BROADCAST_ROOMS[number];
export interface BroadcastSaveDTO {
  version: 1; worldVersion: string;
  consoleInspected: boolean; hoseSecured: boolean; shortcutOpened: boolean; anchorReached: boolean; supplyTaken: boolean;
  discoveredRooms: readonly HyosanBroadcastRoom[];
}
const flags = ['consoleInspected', 'hoseSecured', 'shortcutOpened', 'anchorReached', 'supplyTaken'] as const;
const fields = ['version', 'worldVersion', 'discoveredRooms', ...flags];

/** S4 starts in v8; the staffroom extension preserves its durable flags. HP, boss state, echo and the clock are attempt-local. */
export function parseHyosanBroadcastSave(raw: unknown): BroadcastSaveDTO | null {
  try {
    const value: unknown = typeof raw === 'string' ? JSON.parse(raw) : raw;
    if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
    const candidate = value as Record<string, unknown>;
    if (Object.keys(candidate).length !== fields.length || Object.keys(candidate).some((key) => !fields.includes(key))
      || candidate.version !== 1 || candidate.worldVersion !== layout.version && !(layout.version === 'hyosan-3d-school-v12' && ['hyosan-3d-school-v8', 'hyosan-3d-school-v9', 'hyosan-3d-school-v10', 'hyosan-3d-school-v11'].includes(candidate.worldVersion as string))
      || flags.some((key) => typeof candidate[key] !== 'boolean')) return null;
    const rooms = candidate.discoveredRooms;
    if (!Array.isArray(rooms) || !rooms.length || rooms.length > 6 || new Set(rooms).size !== rooms.length
      || Array.from(rooms).some((room) => !HYOSAN_BROADCAST_ROOMS.includes(room))) return null;
    return { version: 1, worldVersion: layout.version, consoleInspected: candidate.consoleInspected as boolean,
      hoseSecured: candidate.hoseSecured as boolean, shortcutOpened: candidate.shortcutOpened as boolean,
      anchorReached: candidate.anchorReached as boolean, supplyTaken: candidate.supplyTaken as boolean,
      discoveredRooms: HYOSAN_BROADCAST_ROOMS.filter((room) => rooms.includes(room)) };
  } catch { return null; }
}

export function serializeHyosanBroadcastSave(save: BroadcastSaveDTO): string {
  const parsed = parseHyosanBroadcastSave(save);
  if (!parsed) throw new TypeError('Invalid Hyosan broadcast exploration save');
  return JSON.stringify(parsed);
}
