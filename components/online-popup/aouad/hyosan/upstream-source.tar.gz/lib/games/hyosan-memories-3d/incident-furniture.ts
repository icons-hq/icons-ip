import type { Hyosan3DLayout, Hyosan3DPropPose } from './physics';
import type { Hyosan3DFurniture } from './types';

/** Simulation owns the transform. A rejected physics transaction freezes just that prop. */
export function createHyosanIncidentFurniture(source: Hyosan3DLayout,
  accept: (id: string, pose: Hyosan3DPropPose) => boolean) {
  const moves = (source.adventure?.furniture ?? []).flatMap((move) => {
    const from = source.props.find((prop) => prop.id === move.id);
    return from ? [{ ...move, from }] : [];
  });
  let state: Hyosan3DFurniture[] = [];
  const poseAt = (index: number, progress: number): Hyosan3DFurniture => {
    const { id, from, to } = moves[index];
    const eased = progress * progress * (3 - 2 * progress);
    return { id, progress, x: from.x + (to.x - from.x) * eased,
      z: from.z + (to.z - from.z) * eased, rotation: from.rotation + (to.rotation - from.rotation) * eased };
  };
  return {
    /** Call before recreating actors so durable C2 restores cannot move a body. */
    reset(completed: boolean) {
      state = moves.map((_, index) => {
        const pose = poseAt(index, completed ? 1 : 0);
        if (!accept(pose.id, pose)) throw new Error(`Cannot restore Hyosan furniture ${pose.id}`);
        return pose;
      });
    },
    update(active: boolean, dt: number) {
      if (!active || !Number.isFinite(dt) || dt <= 0) return;
      state.forEach((current, index) => {
        if (current.progress === 1) return;
        const next = poseAt(index, Math.min(1, current.progress + dt / moves[index].duration));
        if (accept(next.id, next)) state[index] = next;
      });
    },
    read: () => state.map((pose) => ({ ...pose })),
    shortcutOpen: () => state.some((pose) => pose.id === source.adventure?.incidentShortcut.propId && pose.progress === 1),
  };
}
