import layout from '@/docs/games/hyosan-memories-3d/world-layout.json';
import { HYOSAN_LIBRARY_ROOMS } from './types';
import { hyosan3DBow } from './save';
import { parseHyosanLibrarySave, type LibrarySaveDTO, type HyosanLibraryRoom } from './library-save';
import { createHyosanLibraryBossController, HYOSAN_LIBRARY_BOSS } from './library-boss-controller';
import { createHyosanSupportGeometry } from './support-geometry';
import { direction, distance } from './combat-geometry';
import { sameHyosanCombatLayer } from './combat-layers';
import type { GroundPoint } from './physics';
import type { CombatEnemy, RegionModule, SharedCombatContext } from './region-module';

interface LibraryEnemy extends CombatEnemy { since: number; homeRoom: HyosanLibraryRoom }
const STUDENT = { windup: .55, strike: .16, recovery: .85 };

/** Library discovery follows physical support, so the floor below never reveals the shelf route. */
export function createHyosanLibraryRegion(ctx: SharedCombatContext): RegionModule<LibrarySaveDTO> {
  const { source, physics, navigate, player, equipment } = ctx;
  const plan = source.library;
  if (!plan) throw new Error('Hyosan library layout is required');
  const gate = source.props.find((prop) => prop.id === plan.shortcut.id);
  if (!gate) throw new Error('Hyosan library shortcut has no physical prop');
  const support = createHyosanSupportGeometry(source);
  const roomsBySurface = new Map(support.surfaces.map((surface) => [surface.surfaceId, surface.roomId ?? surface.surfaceId]));
  const ownRoomAt = (point: GroundPoint): HyosanLibraryRoom | undefined => {
    const sample = support.sample(point);
    return HYOSAN_LIBRARY_ROOMS.find((room) => room === (sample && roomsBySurface.get(sample.surfaceId)));
  };
  const enemies: LibraryEnemy[] = [];
  const bossController = createHyosanLibraryBossController();
  const discovered = new Set<HyosanLibraryRoom>();
  let firstEnteredAt: number | null = null; let lastContactId = -1;
  let resolved = false; let completed = false; let echoCollected = false;
  let shortcutOpened = false; let anchorReached = false; let stringReinforced = false;
  let keepsakeFound = false; let keepsakeSecured = false;
  let gateProgress = 0; let opening = false;
  const gatePose = (progress: number) => {
    if (progress === 1) return plan.shortcut.open;
    const rotation = gate.rotation + (plan.shortcut.open.rotation - gate.rotation) * progress;
    const delta = rotation - gate.rotation;
    const dx = gate.x - plan.shortcut.hinge.x; const dz = gate.z - plan.shortcut.hinge.z;
    return { x: plan.shortcut.hinge.x + dx * Math.cos(delta) + dz * Math.sin(delta), y: plan.shortcut.y,
      z: plan.shortcut.hinge.z - dx * Math.sin(delta) + dz * Math.cos(delta), rotation };
  };
  const boss = () => enemies.find((enemy) => enemy.kind === 'boss');
  const nearby = (point: GroundPoint, ignore?: string) => distance(player, point) < 1.5 && physics.lineOfSight(player, point, ignore);
  const interaction: RegionModule['interaction'] = () => {
    if (player.hp <= 0 || completed) return null;
    if (!resolved && boss()?.hp === 0 && !echoCollected && nearby(plan.echo)) return 'echo';
    if (!stringReinforced && nearby(plan.upgrade, plan.upgrade.propId)) return 'bowstring';
    if (!keepsakeFound && ownRoomAt(player) === 'library-archive' && nearby(plan.hidden, plan.hidden.propId)) return 'keepsake';
    if (!shortcutOpened && !opening && player.x > gate.x + .2 && nearby(plan.shortcut.interactPoint, gate.id)) return 'shortcut';
    return null;
  };
  const createEnemy = (id: string, at: GroundPoint, isBoss = false): LibraryEnemy => {
    const hp = isBoss ? HYOSAN_LIBRARY_BOSS.hp : 2;
    return { id, ...physics.addActor(id, at, isBoss ? .5 : .32), yaw: 0, hp, maxHp: hp,
      ownerArea: 'library', kind: isBoss ? 'boss' : 'student', ...(isBoss ? { profile: 'gwinam-human' as const } : {}),
      active: false, dormant: false, since: 0, homeRoom: ownRoomAt(at) ?? 'library-entry',
      attackPhase: 'idle', attackStyle: 'melee', attackProgress: 0,
      attackRange: isBoss ? HYOSAN_LIBRARY_BOSS.thrust.range : 1.25,
      attackHalfAngle: isBoss ? HYOSAN_LIBRARY_BOSS.thrust.halfAngle : Math.acos(.35), defeatedAt: null };
  };
  const hitsPlayer = (enemy: LibraryEnemy, reach = enemy.attackRange) => {
    const aim = direction(player.x - enemy.x, player.z - enemy.z);
    return sameHyosanCombatLayer(enemy, player) && distance(enemy, player) <= reach
      && aim.x * Math.sin(enemy.yaw) + aim.z * Math.cos(enemy.yaw) > Math.cos(enemy.attackHalfAngle)
      && physics.lineOfSight(enemy, player);
  };
  const walk = (enemy: LibraryEnemy, aim: { x: number; z: number }, speed: number) => {
    if (aim.x || aim.z) enemy.yaw = Math.atan2(aim.x, aim.z);
    const step = speed * ctx.dt * ctx.movementMultiplier(enemy, enemy.kind);
    Object.assign(enemy, physics.moveActor(enemy.id, aim.x * step, aim.z * step));
  };
  const updateEnemies = () => {
    for (const enemy of enemies) {
      if (enemy.hp <= 0 || enemy.dormant) continue;
      enemy.active ||= firstEnteredAt !== null && ctx.time - firstEnteredAt >= 2.2 && distance(enemy, player) < 9
        && sameHyosanCombatLayer(enemy, player) && physics.lineOfSight(enemy, player);
      if (!enemy.active) continue;
      const waypoint = navigate(enemy, player, enemy.kind === 'boss' ? .5 : .32, .32);
      const aim = direction(waypoint.x - enemy.x, waypoint.z - enemy.z);
      if (enemy.kind === 'boss') {
        const frame = bossController.advance({ time: ctx.time, x: enemy.x, z: enemy.z, targetX: player.x, targetZ: player.z,
          distance: distance(enemy, player), visible: physics.lineOfSight(enemy, player), sameLayer: sameHyosanCombatLayer(enemy, player) });
        if (frame.beat !== 'death') enemy.libraryBeat = frame.beat;
        enemy.attackPhase = frame.attackPhase; enemy.attackProgress = frame.attackProgress;
        enemy.attackRange = frame.range; enemy.attackHalfAngle = frame.halfAngle;
        if (frame.beat !== 'stalk') enemy.yaw = frame.yaw;
        if (frame.speed > 0) walk(enemy, aim, frame.speed);
        if (frame.moveX || frame.moveZ) Object.assign(enemy, physics.moveActor(enemy.id, frame.moveX, frame.moveZ));
        // Telegraph includes the future step; damage only reaches from the accepted body pose.
        if (frame.contact && frame.attackId !== lastContactId && hitsPlayer(enemy, frame.contactRange)) {
          lastContactId = frame.attackId; ctx.hurtPlayer(frame.damage, enemy);
        }
      } else if (enemy.attackPhase === 'idle') {
        if (sameHyosanCombatLayer(enemy, player) && distance(enemy, player) <= 1.05 && physics.lineOfSight(enemy, player)) {
          enemy.yaw = Math.atan2(player.x - enemy.x, player.z - enemy.z); enemy.attackPhase = 'windup'; enemy.since = ctx.time;
        } else walk(enemy, aim, 1.1);
      } else if (enemy.attackPhase === 'windup' && ctx.time - enemy.since >= STUDENT.windup) {
        enemy.attackPhase = 'strike'; enemy.since = ctx.time; if (hitsPlayer(enemy)) ctx.hurtPlayer(1, enemy);
      } else if (enemy.attackPhase === 'strike' && ctx.time - enemy.since >= STUDENT.strike) { enemy.attackPhase = 'recover'; enemy.since = ctx.time; }
      else if (enemy.attackPhase === 'recover' && ctx.time - enemy.since >= STUDENT.recovery) { enemy.attackPhase = 'idle'; enemy.since = ctx.time; }
      if (enemy.kind === 'student') enemy.attackProgress = enemy.attackPhase === 'idle' ? 0 : Math.min(1,
        (ctx.time - enemy.since) / (enemy.attackPhase === 'windup' ? STUDENT.windup : enemy.attackPhase === 'strike' ? STUDENT.strike : STUDENT.recovery));
    }
  };
  return {
    id: 'library', enemies,
    reset(raw, isResolved) {
      const saved = parseHyosanLibrarySave(raw);
      resolved = isResolved; completed = false; echoCollected = false;
      firstEnteredAt = null; lastContactId = -1; bossController.reset();
      shortcutOpened = saved?.shortcutOpened === true; anchorReached = saved?.anchorReached === true;
      stringReinforced = saved?.stringReinforced === true; equipment.stringReinforced ||= stringReinforced;
      keepsakeSecured = saved?.keepsakeSecured === true; keepsakeFound = keepsakeSecured;
      discovered.clear(); for (const room of saved?.discoveredRooms ?? []) discovered.add(room);
      gateProgress = shortcutOpened ? 1 : 0; opening = false;
      physics.trySetPropPose(gate.id, gatePose(gateProgress));
      enemies.length = 0;
      if (!resolved) {
        for (const group of plan.encounters) for (let index = 0; index < group.count; index++) {
          enemies.push(createEnemy(`${group.id}-${index}`, { ...group, x: group.x + index % 2 * .95, z: group.z + Math.floor(index / 2) * .95 }));
        }
        enemies.push(createEnemy(plan.boss.id, plan.boss, true));
      }
    },
    observePlayer() {
      const room = ownRoomAt(player); if (room) discovered.add(room);
      if (ctx.area === 'library' && firstEnteredAt === null) firstEnteredAt = ctx.time;
    },
    update({ interactPressed }) {
      if (player.hp <= 0) return;
      if (distance(player, plan.checkpoint) <= plan.checkpoint.radius && nearby(plan.checkpoint)) {
        if (!anchorReached) { anchorReached = true; ctx.checkpoint(plan.checkpoint); }
        if (keepsakeFound && !keepsakeSecured) { keepsakeSecured = true; ctx.effect('upgrade', plan.checkpoint, 1.2); }
      }
      if (interactPressed) {
        const action = interaction();
        if (action === 'bowstring') { stringReinforced = true; equipment.stringReinforced = true; }
        if (action === 'keepsake') keepsakeFound = true;
        if (action === 'shortcut') opening = true;
        if (action === 'echo') echoCollected = true;
        if (action) ctx.effect(action === 'shortcut' ? 'door' : 'upgrade', player, .7);
      }
      if (opening) {
        const next = Math.min(1, gateProgress + ctx.dt / plan.shortcut.duration);
        if (physics.trySetPropPose(gate.id, gatePose(next))) gateProgress = next;
        if (gateProgress === 1) { shortcutOpened = true; opening = false; }
      }
      updateEnemies();
    },
    afterCombat() {
      if (!resolved && player.hp > 0 && boss()?.hp === 0 && echoCollected
        && Math.abs(player.y - plan.exit.y) < .25 && (player.x - plan.exit.x) * plan.exit.forward >= 0
        && Math.abs(player.z - plan.exit.z) <= 1.2) {
        completed = true; keepsakeSecured ||= keepsakeFound;
      }
    },
    interaction,
    markResolved() { resolved = true; completed = false; },
    readProgress() {
      const bow = hyosan3DBow(equipment.kitCollected, equipment.supplyCollected, equipment.piercingCollected, equipment.stringReinforced);
      return { room: ownRoomAt(player) ?? 'library-entry', discoveredRooms: [...discovered], stringReinforced, keepsakeFound, keepsakeSecured,
        areaResolved: resolved, objective: completed ? 'completed' : resolved ? 'explore_school'
          : boss()?.active && boss()!.hp > 0 ? 'defeat_boss' : boss()?.hp !== 0
            ? anchorReached || discovered.has('library-stacks') ? 'climb_shelves' : 'explore_library' : !echoCollected ? 'collect_echo' : 'reach_exit',
        upgraded: equipment.kitCollected, supplyCollected: equipment.supplyCollected, piercingCollected: equipment.piercingCollected,
        bowLevel: bow.level, bossDefeated: resolved || boss()?.hp === 0, completed, echoCollected, anchorReached, shortcutOpened,
        incidentTriggered: false, entranceOpen: 1, inWater: ctx.movementMultiplier(player, 'player') < 1,
        activeWaterIds: [], incidentShortcutOpened: false };
    },
    exportSave: () => ({ version: 1, worldVersion: layout.version, shortcutOpened, anchorReached, stringReinforced, keepsakeSecured,
      discoveredRooms: HYOSAN_LIBRARY_ROOMS.filter((room) => discovered.has(room)) }),
    respawnPoint: () => anchorReached ? plan.checkpoint : plan.spawn,
    furniture: () => [{ id: gate.id, ...gatePose(gateProgress), progress: gateProgress }],
  };
}
