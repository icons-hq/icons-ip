import { HYOSAN_ALL_ROOMS, HYOSAN_ROOFTOP_ROOMS, type Hyosan3DArea, type Hyosan3DRoom } from './types';

export function hyosan3DAreaForRoom(room: Hyosan3DRoom): Hyosan3DArea {
  return room.startsWith('science-') ? 'science' : room.startsWith('classroom-') ? 'classroom'
    : room.startsWith('broadcast-') ? 'broadcast' : room.startsWith('library-') ? 'library'
      : room.startsWith('staffroom-') ? 'staffroom' : room.startsWith('gym-') ? 'gymnasium' : room.startsWith('rooftop-') ? 'rooftop' : 'cafeteria';
}

interface RoomFloor {
  id: string; roomId?: string;
  x: number; z: number; width: number; depth: number;
}

/** Several connected floor pieces can share one discovered and saved school room. */
export function hyosan3DRoomForFloor(floor: Pick<RoomFloor, 'id' | 'roomId'>): Hyosan3DRoom | null {
  const id = floor.roomId ?? floor.id;
  return [...HYOSAN_ALL_ROOMS, ...HYOSAN_ROOFTOP_ROOMS].find((room) => room === id) ?? null;
}

export function hyosan3DRoomAt(point: { x: number; z: number }, floors: readonly RoomFloor[]): Hyosan3DRoom {
  const floor = floors.find((candidate) => Math.abs(point.x - candidate.x) <= candidate.width / 2
    && Math.abs(point.z - candidate.z) <= candidate.depth / 2);
  return floor ? hyosan3DRoomForFloor(floor) ?? 'infirmary' : 'infirmary';
}
