export type HyosanBroadcastBossBeat = 'limp' | 'grab-windup' | 'grab' | 'recovery' | 'trip' | 'slide' | 'brace';
export const HYOSAN_BROADCAST_BOSS = { hp: 72, reach: 1.35, halfAngle: Math.PI / 3 } as const;
const duration = { 'grab-windup': .65, grab: .12, recovery: 1, trip: .65, slide: .45, brace: .3 };

/** Timing only: physical movement and same-layer contact remain with the region. */
export function createHyosanBroadcastBossController() {
  let beat: HyosanBroadcastBossBeat = 'limp';
  let since = 0; let yaw = 0; let lastTime = -1;
  let slideX = 0; let slideZ = 0;
  // A finite stumble per flight per attempt prevents an upper-floor safe spot.
  const stumbled = new Set<string>();
  const reset = () => { beat = 'limp'; since = 0; yaw = 0; lastTime = -1; slideX = 0; slideZ = 0; stumbled.clear(); };
  return {
    reset,
    advance(input: { time: number; x: number; z: number; targetX: number; targetZ: number;
      distance: number; visible: boolean; sameLayer: boolean; blocked?: boolean; ascending?: boolean;
      stair?: { id: string; downhill: { x: number; z: number } } }) {
      if (input.time < lastTime) reset();
      const changed = input.time !== lastTime; lastTime = input.time;
      let strike = false;
      const enter = (next: HyosanBroadcastBossBeat) => { beat = next; since = input.time; };
      if (changed) {
        if (beat === 'limp' && input.stair && input.ascending && !stumbled.has(input.stair.id)) {
          stumbled.add(input.stair.id); slideX = input.stair.downhill.x * 2; slideZ = input.stair.downhill.z * 2;
          enter('trip');
        } else if (beat === 'limp' && input.sameLayer && input.visible && input.distance <= 1.15) {
          yaw = Math.atan2(input.targetX - input.x, input.targetZ - input.z); enter('grab-windup');
        } else if (beat === 'grab-windup' && input.time - since >= duration['grab-windup'] - 1e-8) {
          enter('grab'); strike = true;
        } else if (beat === 'grab' && input.time - since >= duration.grab - 1e-8) enter('recovery');
        else if (beat === 'trip' && input.time - since >= duration.trip - 1e-8) enter('slide');
        else if (beat === 'slide' && (input.blocked || input.time - since >= duration.slide - 1e-8)) enter('brace');
        else if (beat === 'brace' && input.time - since >= duration.brace - 1e-8) enter('recovery');
        else if (beat === 'recovery' && input.time - since >= duration.recovery - 1e-8) enter('limp');
      }
      const current: HyosanBroadcastBossBeat = beat;
      return { beat: current, yaw, strike, speed: current === 'limp' ? 1.45 : 0,
        slideX: current === 'slide' ? slideX : 0, slideZ: current === 'slide' ? slideZ : 0,
        attackPhase: current === 'grab-windup' ? 'windup' as const : current === 'grab' ? 'strike' as const
          : current === 'limp' ? 'idle' as const : 'recover' as const,
        attackProgress: current === 'limp' ? 0 : Math.min(1, Math.max(0, (input.time - since) / duration[current])) };
    },
  };
}
