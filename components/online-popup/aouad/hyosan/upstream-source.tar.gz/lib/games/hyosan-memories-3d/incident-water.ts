interface WaterPoint { readonly x: number; readonly z: number }
interface WaterOccupant extends WaterPoint { readonly radius: number }
interface WaterPatch extends WaterPoint {
  readonly id: string;
  /** Local XZ offsets from this patch's centre, in the order rendered on the floor. */
  readonly points: readonly WaterPoint[];
}

export const HYOSAN_INCIDENT_WATER_MULTIPLIER = .72;

const random = (index: number) => {
  const value = Math.sin(index * 127.1 + 311.7) * 43758.5453;
  return value - Math.floor(value);
};

/** C2 water is one shared polygon contract for both floor rendering and movement. */
export const HYOSAN_INCIDENT_WATER: readonly WaterPatch[] = Object.freeze([
  { x: 6.4, z: -.4, width: 3.8, depth: 1.7 },
  { x: 11.8, z: 1.2, width: 4.6, depth: 2.0 },
  { x: 17.1, z: -.2, width: 2.8, depth: 2.3 },
  { x: 16.0, z: 6.7, width: 2.4, depth: 1.2 },
].map((patch, index) => Object.freeze({
  id: `incident-water-${index + 1}`, x: patch.x, z: patch.z,
  points: Object.freeze(Array.from({ length: 20 }, (_, side) => {
    const angle = side / 20 * Math.PI * 2;
    const radius = .86 + random(index * 20 + side) * .14;
    // Preserve the old THREE.Shape rotation: local Shape Y became world -Z.
    return Object.freeze({ x: Math.cos(angle) * radius * patch.width / 2,
      z: -Math.sin(angle) * radius * patch.depth / 2 });
  })),
})));

function insidePatch(point: WaterPoint, patch: WaterPatch) {
  const x = point.x - patch.x;
  const z = point.z - patch.z;
  let inside = false;
  for (let index = 0; index < patch.points.length; index++) {
    const a = patch.points[index];
    const b = patch.points[(index + 1) % patch.points.length];
    const dx = b.x - a.x;
    const dz = b.z - a.z;
    const length = Math.hypot(dx, dz);
    const cross = (x - a.x) * dz - (z - a.z) * dx;
    const along = (x - a.x) * dx + (z - a.z) * dz;
    // Inclusive boundaries with only a numerical tolerance, not a hidden wider hazard.
    if (Math.abs(cross) <= 1e-9 * length && along >= -1e-9 && along <= length * length + 1e-9) return true;
    if ((a.z > z) !== (b.z > z) && x < a.x + (z - a.z) * dx / dz) inside = !inside;
  }
  return inside;
}

/** Authored world-space geometry query; gameplay uses state.contains() for activated water. */
export function hyosanIncidentWaterAt(point: WaterPoint): boolean {
  if (!Number.isFinite(point.x) || !Number.isFinite(point.z)) return false;
  return HYOSAN_INCIDENT_WATER.some((patch) => insidePatch(point, patch));
}

function overlapsPatch(occupant: WaterOccupant, patch: WaterPatch) {
  if (insidePatch(occupant, patch)) return true;
  const x = occupant.x - patch.x;
  const z = occupant.z - patch.z;
  for (let index = 0; index < patch.points.length; index++) {
    const a = patch.points[index];
    const b = patch.points[(index + 1) % patch.points.length];
    const dx = b.x - a.x;
    const dz = b.z - a.z;
    const fraction = Math.max(0, Math.min(1, ((x - a.x) * dx + (z - a.z) * dz) / (dx * dx + dz * dz)));
    const distance = Math.hypot(x - a.x - fraction * dx, z - a.z - fraction * dz);
    if (distance <= occupant.radius + 1e-9) return true;
  }
  return false;
}

/** New water waits until the complete supplied capsules leave; active water never retreats. */
export function createHyosanIncidentWaterState() {
  const active = new Set<string>();
  function update(enabled: boolean, occupants: readonly WaterOccupant[]) {
    if (!enabled) { active.clear(); return; }
    // A malformed capsule cannot establish that any waiting pool is safely clear.
    if (occupants.some((occupant) => !Number.isFinite(occupant.x) || !Number.isFinite(occupant.z)
      || !Number.isFinite(occupant.radius) || occupant.radius < 0)) return;
    for (const patch of HYOSAN_INCIDENT_WATER) {
      if (!active.has(patch.id) && !occupants.some((occupant) => overlapsPatch(occupant, patch))) active.add(patch.id);
    }
  }
  return {
    reset(enabled: boolean, occupants: readonly WaterOccupant[]) { active.clear(); update(enabled, occupants); },
    update,
    activeIds(): readonly string[] {
      return Object.freeze(HYOSAN_INCIDENT_WATER.filter((patch) => active.has(patch.id)).map((patch) => patch.id));
    },
    contains(point: WaterPoint): boolean {
      return Number.isFinite(point.x) && Number.isFinite(point.z)
        && HYOSAN_INCIDENT_WATER.some((patch) => active.has(patch.id) && insidePatch(point, patch));
    },
  };
}
