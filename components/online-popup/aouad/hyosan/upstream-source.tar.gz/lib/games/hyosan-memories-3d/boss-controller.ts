export type HyosanBossBeat = 'idle' | 'tremor' | 'charge' | 'sweep-windup' | 'sweep' | 'recovery';

export const HYOSAN_BOSS_COMBO = {
  startRange: 9, chargeDistance: 4.2, chargeContactRadius: .85,
  sweepRange: 2.05, sweepHalfAngle: Math.PI * 4 / 9, lowHealthRatio: .4,
} as const;

const normal = { tremor: .9, charge: .45, 'sweep-windup': .5, sweep: .22, recovery: 1.15 };
const faster = { tremor: .8, charge: .42, 'sweep-windup': .42, sweep: .22, recovery: 1.05 };
const epsilon = 1e-8;
// Rapier stores translations as float32; sub-millimetre requests can round to
// zero at room coordinates. Reaching this tolerance must finish the charge.
const arrivalTolerance = .001;

export interface HyosanBossInput {
  /** Simulation seconds only. Call once per fixed tick; omit calls while paused. */
  time: number;
  x: number; z: number; targetX: number; targetZ: number;
  hp: number; maxHp: number; lineOfSight: boolean;
  /** Physical approach permission, checked only before a new combo. */
  canStartCombo?: boolean;
}

export interface HyosanBossPresentation {
  beat: HyosanBossBeat;
  attackPhase: 'idle' | 'windup' | 'strike' | 'recover';
  attackStyle: 'charge' | 'melee';
  yaw: number; attackRange: number; attackHalfAngle: number; attackProgress: number;
}

export interface HyosanBossFrame extends HyosanBossPresentation {
  /** Apply along yaw through collision, with slide:false, then call resolveCharge. */
  moveDistance: number;
  /** A single contact-check request, not unconditional player damage. */
  strike: 'sweep' | null;
}

export interface HyosanBossChargeResult {
  /** Actual post-collision position and current player position. */
  x: number; z: number; targetX: number; targetZ: number;
  movedDistance: number; blocked: boolean;
  /** Swept player contact validated by the caller, including geometry LOS. */
  contact: boolean;
}

/**
 * Deterministic physical combo; owns no physics, player damage, clock or assets.
 * advance -> move through physics -> resolveCharge -> read is one simulation tick.
 * Resolve a charge movement once, even when blocked. Apply its returned contact
 * attempt and advance's sweep attempt through the shared player invulnerability.
 * A sweep uses read().yaw/range/halfAngle plus LOS. Idle pursuit belongs to the caller.
 */
export function createHyosanBossController() {
  let beat: HyosanBossBeat = 'idle';
  let yaw = 0;
  let now = 0;
  let phaseSince = 0;
  let lastTime: number | null = null;
  let durations = normal;
  let travelled = 0;
  let requested = 0;
  let chargeContact = false;
  const enter = (next: HyosanBossBeat) => { beat = next; phaseSince = now; };
  const faceTarget = (point: Pick<HyosanBossInput, 'x' | 'z' | 'targetX' | 'targetZ'>) => {
    if (Math.hypot(point.targetX - point.x, point.targetZ - point.z) > epsilon) yaw = Math.atan2(point.targetX - point.x, point.targetZ - point.z);
  };
  const read = (): HyosanBossPresentation => {
    const charging = beat === 'tremor' || beat === 'charge';
    return {
      beat, yaw, attackStyle: charging ? 'charge' : 'melee',
      attackPhase: beat === 'idle' ? 'idle' : beat === 'tremor' || beat === 'sweep-windup' ? 'windup'
        : beat === 'recovery' ? 'recover' : 'strike',
      attackRange: charging ? HYOSAN_BOSS_COMBO.chargeDistance - travelled + HYOSAN_BOSS_COMBO.chargeContactRadius : HYOSAN_BOSS_COMBO.sweepRange,
      attackHalfAngle: HYOSAN_BOSS_COMBO.sweepHalfAngle,
      attackProgress: beat === 'idle' ? 0 : Math.max(0, Math.min(1, (now - phaseSince) / durations[beat])),
    };
  };
  const reset = () => {
    beat = 'idle'; yaw = 0; now = 0; phaseSince = 0; lastTime = null;
    durations = normal; travelled = 0; requested = 0; chargeContact = false;
  };
  return {
    read,
    reset,
    advance(input: HyosanBossInput): HyosanBossFrame {
      if (lastTime !== null && input.time < lastTime) reset();
      const dt = lastTime === null ? 0 : Math.min(.1, Math.max(0, input.time - lastTime));
      const unchanged = lastTime === input.time;
      now = input.time; lastTime = now;
      if (input.hp <= 0) { requested = 0; enter('idle'); return { ...read(), moveDistance: 0, strike: null }; }
      if (unchanged) return { ...read(), moveDistance: 0, strike: null };
      requested = 0;
      let strike: HyosanBossFrame['strike'] = null;
      if (beat === 'idle') {
        faceTarget(input);
        if (input.canStartCombo !== false && input.lineOfSight && Math.hypot(input.targetX - input.x, input.targetZ - input.z) <= HYOSAN_BOSS_COMBO.startRange) {
          // Lock tempo for this complete combo; a hit never shortens a shown warning.
          durations = input.hp / input.maxHp <= HYOSAN_BOSS_COMBO.lowHealthRatio ? faster : normal;
          travelled = 0; chargeContact = false; enter('tremor');
        }
      } else if (beat === 'tremor' && now - phaseSince + epsilon >= durations.tremor) enter('charge');
      else if (beat === 'sweep-windup' && now - phaseSince + epsilon >= durations['sweep-windup']) {
        enter('sweep'); strike = 'sweep';
      } else if (beat === 'sweep' && now - phaseSince + epsilon >= durations.sweep) enter('recovery');
      else if (beat === 'recovery' && now - phaseSince + epsilon >= durations.recovery) enter('idle');
      if (beat === 'charge') requested = Math.min(HYOSAN_BOSS_COMBO.chargeDistance - travelled,
        HYOSAN_BOSS_COMBO.chargeDistance / durations.charge * Math.min(dt, now - phaseSince));
      return { ...read(), moveDistance: requested, strike };
    },
    resolveCharge(result: HyosanBossChargeResult): 'charge' | null {
      if (beat !== 'charge' || requested <= 0) return null;
      const attempted = requested;
      const moved = Math.max(0, Math.min(attempted, result.movedDistance));
      requested = 0; travelled += moved;
      const strike = result.contact && !chargeContact ? 'charge' : null;
      chargeContact ||= result.contact;
      if (result.blocked || moved < attempted - arrivalTolerance || travelled + arrivalTolerance >= HYOSAN_BOSS_COMBO.chargeDistance) {
        // A wall ends movement, not the readable follow-up. Lock from the real endpoint.
        faceTarget(result); enter('sweep-windup');
      }
      return strike;
    },
  };
}
