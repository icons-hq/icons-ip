import { HYOSAN_3D_SAVE_KEY } from './save';
import { HYOSAN_CAMPAIGN_SAVE_KEY, migrateHyosanCafeteriaSave, parseHyosanCampaignSave, serializeHyosanCampaignSave, type HyosanCampaignSave } from './campaign-save';
import { HYOSAN_3D_AREAS } from './types';
type SaveStorage = Pick<Storage, 'getItem' | 'setItem' | 'removeItem'>;
type StorageCheck = 'current' | 'unavailable' | 'conflict';
type RawSave = { campaign: string | null; legacy: string | null };
const keys = { campaign: HYOSAN_CAMPAIGN_SAVE_KEY, legacy: HYOSAN_3D_SAVE_KEY } as const;
const sameRaw = (a: RawSave, b: RawSave) => a.campaign === b.campaign && a.legacy === b.legacy;
export const hasHyosanCampaignProgress = (save: HyosanCampaignSave) => Boolean(save.introSeen || HYOSAN_3D_AREAS.some((area) => area !== 'science' && save[area]) || save.completedAreas.length
  || save.science && (save.science.originInspected || save.science.anchorReached || save.science.kitCollected
    || save.science.shortcutOpened || save.science.discoveredRooms.length > 1));

/** One controller belongs to one uninterrupted browser writer lease. Reacquiring
 * ownership requires a new controller and load, never rebasing a live world. */
export function createHyosanCampaignStorage(access: () => SaveStorage, ownsWriter: () => boolean) {
  let loaded = false; let blocked = false; let conflict = false; let unavailable = false;
  let expected: RawSave | null = null; let usesLegacy = false;
  let saved: HyosanCampaignSave | null = null;
  let signature: string | null = null; let failed: string | null = null;
  const lost = (): 'conflict' => { conflict = true; return 'conflict'; };
  const unavailableResult = (): 'unavailable' => { unavailable = true; return 'unavailable'; };
  const owner = (): StorageCheck => {
    if (conflict) return 'conflict';
    try { return ownsWriter() ? 'current' : lost(); }
    catch { blocked = true; return unavailableResult(); }
  };
  const readPair = (storage: SaveStorage): RawSave => ({ campaign: storage.getItem(keys.campaign), legacy: storage.getItem(keys.legacy) });
  const verify = (): { status: 'current'; storage: SaveStorage } | { status: 'unavailable' | 'conflict' } => {
    const ownership = owner();
    if (ownership !== 'current') return { status: ownership };
    if (!loaded || !expected || blocked) return { status: unavailableResult() };
    try {
      const storage = access();
      if (storage.getItem(keys.campaign) !== expected.campaign
        || usesLegacy && storage.getItem(keys.legacy) !== expected.legacy) return { status: lost() };
      return { status: 'current', storage };
    } catch { return { status: unavailableResult() }; }
  };
  return {
    load(): HyosanCampaignSave | null {
      if (loaded) return saved ? structuredClone(saved) : null;
      loaded = true;
      if (owner() !== 'current') return null;
      try {
        const storage = access(); const campaign = storage.getItem(keys.campaign);
        const current = parseHyosanCampaignSave(campaign);
        // An unreadable existing record is not an empty/new campaign.
        if (campaign !== null && !current) { blocked = true; unavailableResult(); return null; }
        usesLegacy = campaign === null;
        const legacy = usesLegacy ? storage.getItem(keys.legacy) : null;
        saved = current ?? migrateHyosanCafeteriaSave(legacy);
        if (legacy !== null && !saved) { blocked = true; unavailableResult(); return null; }
        expected = { campaign, legacy };
        signature = current ? serializeHyosanCampaignSave(current) : null;
        unavailable = false;
        return saved ? structuredClone(saved) : null;
      } catch { blocked = true; unavailableResult(); return null; }
    },
    write(save: HyosanCampaignSave): 'saved' | 'unchanged' | 'unavailable' | 'conflict' {
      const checked = verify();
      if (checked.status !== 'current') return checked.status;
      try {
        if (!hasHyosanCampaignProgress(save)) return 'unchanged';
        const next = serializeHyosanCampaignSave(save);
        if (next === signature) return 'unchanged';
        if (next === failed) return unavailableResult();
        failed = next;
        if (owner() !== 'current') return conflict ? 'conflict' : 'unavailable';
        try { checked.storage.setItem(keys.campaign, next); }
        catch {
          // A denied write may retry different progress only when the previous
          // raw base is still intact. Ambiguous writes require a fresh load.
          try {
            const actual = checked.storage.getItem(keys.campaign);
            if (actual === next) blocked = true;
            else if (actual !== expected!.campaign) return lost();
          } catch { blocked = true; }
          return unavailableResult();
        }
        let committed: string | null;
        try { committed = checked.storage.getItem(keys.campaign); }
        catch { blocked = true; return unavailableResult(); }
        if (owner() !== 'current') return conflict ? 'conflict' : 'unavailable';
        if (committed !== next) return lost();
        expected = { campaign: next, legacy: null }; usesLegacy = false;
        signature = next; saved = structuredClone(save); failed = null; unavailable = false;
        return 'saved';
      } catch { return unavailableResult(); }
    },
    clear(): boolean {
      const checked = verify();
      if (checked.status !== 'current') { blocked = true; return false; }
      const storage = checked.storage;
      let original: RawSave;
      try { original = readPair(storage); }
      catch { blocked = true; unavailableResult(); return false; }
      if (original.campaign !== expected!.campaign || usesLegacy && original.legacy !== expected!.legacy) { lost(); return false; }
      let lastKnown = { ...original }; let attempted = { ...original };
      try {
        // Preserve the authoritative primary until removal of the legacy copy
        // succeeds. Skip absent keys so legacy-only saves need one mutation.
        for (const key of ['legacy', 'campaign'] as const) {
          if (original[key] === null) continue;
          if (owner() !== 'current') return false;
          if (!sameRaw(readPair(storage), lastKnown)) { lost(); return false; }
          attempted = { ...lastKnown, [key]: null };
          storage.removeItem(keys[key]); lastKnown = { ...attempted };
        }
        if (owner() !== 'current') return false;
        if (!sameRaw(readPair(storage), { campaign: null, legacy: null })) { lost(); return false; }
        expected = { campaign: null, legacy: null }; usesLegacy = true;
        signature = null; failed = null; saved = null; unavailable = false;
        return true;
      } catch {
        // Storage has no multi-key transaction. Restore only our own observable
        // intermediate values, never a foreign writer's latest record.
        blocked = true; unavailableResult();
        try {
          if (owner() !== 'current') return false;
          let actual = readPair(storage);
          if (!sameRaw(actual, lastKnown) && !sameRaw(actual, attempted)) { lost(); return false; }
          for (const key of ['campaign', 'legacy'] as const) {
            if (actual[key] === original[key]) continue;
            if (owner() !== 'current') return false;
            if (!sameRaw(readPair(storage), actual)) { lost(); return false; }
            storage.setItem(keys[key], original[key]!);
            actual = { ...actual, [key]: original[key] };
          }
          if (!sameRaw(readPair(storage), original)) lost();
        } catch { /* Preserve the live world; this controller can no longer write. */ }
        return false;
      }
    },
    checkCurrent: (): StorageCheck => verify().status,
    isUnavailable: () => unavailable,
    isConflicted: () => conflict,
  };
}
