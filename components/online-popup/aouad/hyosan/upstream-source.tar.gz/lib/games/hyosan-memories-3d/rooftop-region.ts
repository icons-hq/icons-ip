import { HYOSAN_ROOFTOP_ROOMS } from './types';
import { hyosan3DBow } from './save';
import { parseHyosanRooftopSave, type RooftopSaveDTO, type HyosanRooftopRoom } from './rooftop-save';
import { createHyosanRooftopBossController, HYOSAN_ROOFTOP_BOSS } from './rooftop-boss-controller';
import { createHyosanSupportGeometry } from './support-geometry';
import { direction, distance } from './combat-geometry';
import { sameHyosanCombatLayer } from './combat-layers';
import type { GroundPoint } from './physics';
import type { CombatEnemy, RegionModule, SharedCombatContext } from './region-module';

interface RooftopEnemy extends CombatEnemy { since: number }
const STUDENT = { windup: .6, strike: .16, recovery: .9 };

/** The final memory encounter shares arrows, KCC, damage and time with the school. */
export function createHyosanRooftopRegion(ctx: SharedCombatContext): RegionModule<RooftopSaveDTO> {
  const { source, physics, navigate, player, equipment } = ctx;
  const plan = source.rooftop;
  if (!plan) throw new Error('Hyosan rooftop layout is required');
  const gate = source.props.find((prop) => prop.id === plan.shortcut.id);
  if (!gate) throw new Error('Hyosan rooftop shortcut has no physical prop');
  const support = createHyosanSupportGeometry(source);
  const roomsBySurface = new Map(support.surfaces.map((surface) => [surface.surfaceId, surface.roomId ?? surface.surfaceId]));
  const roomAt = (point: GroundPoint): HyosanRooftopRoom | undefined => {
    const sample = support.sample(point);
    return HYOSAN_ROOFTOP_ROOMS.find((room) => room === (sample && roomsBySurface.get(sample.surfaceId)));
  };
  const enemies: RooftopEnemy[] = [];
  const bossController = createHyosanRooftopBossController();
  const discovered = new Set<HyosanRooftopRoom>();
  let firstEnteredAt: number | null = null; let lastContactId = -1;
  let resolved = false; let completed = false; let echoCollected = false;
  let shortcutOpened = false; let anchorReached = false; let supplyTaken = false;
  let keepsakeFound = false; let keepsakeSecured = false;
  let gateProgress = 0; let opening = false;
  const gatePose = (progress: number) => {
    if (progress === 1) return plan.shortcut.open;
    const rotation = gate.rotation + (plan.shortcut.open.rotation - gate.rotation) * progress;
    const delta = rotation - gate.rotation;
    const dx = gate.x - plan.shortcut.hinge.x; const dz = gate.z - plan.shortcut.hinge.z;
    return { x: plan.shortcut.hinge.x + dx * Math.cos(delta) + dz * Math.sin(delta), y: plan.shortcut.y,
      z: plan.shortcut.hinge.z - dx * Math.sin(delta) + dz * Math.cos(delta), rotation };
  };
  const boss = () => enemies.find((enemy) => enemy.kind === 'boss');
  const nearby = (point: GroundPoint, ignore?: string) => distance(player, point) < 1.5 && physics.lineOfSight(player, point, ignore);
  const interaction: RegionModule['interaction'] = () => {
    if (player.hp <= 0 || completed) return null;
    if (!resolved && boss()?.hp === 0 && !echoCollected && nearby(plan.echo)) return 'echo';
    if (!supplyTaken && player.hp < player.maxHp && roomAt(player) === 'rooftop-service' && nearby(plan.supply)) return 'supply';
    if (!keepsakeFound && roomAt(player) === 'rooftop-service' && nearby(plan.hidden)) return 'keepsake';
    if (!shortcutOpened && !opening && roomAt(player) === 'rooftop-service' && nearby(plan.shortcut.interactPoint, gate.id)) return 'shortcut';
    return null;
  };
  const createEnemy = (id: string, at: GroundPoint, isBoss = false): RooftopEnemy => {
    const hp = isBoss ? HYOSAN_ROOFTOP_BOSS.hp : 2;
    return { id, ...physics.addActor(id, at, isBoss ? .5 : .32), yaw: 0, hp, maxHp: hp,
      ownerArea: 'rooftop', kind: isBoss ? 'boss' : 'student', ...(isBoss ? { profile: 'gwinam-halfbie' as const } : {}),
      active: false, dormant: false, since: 0, attackPhase: 'idle', attackStyle: 'melee', attackProgress: 0,
      attackRange: 1.25, attackHalfAngle: Math.acos(.35), defeatedAt: null };
  };
  const hitsPlayer = (enemy: RooftopEnemy, reach = enemy.attackRange) => {
    const aim = direction(player.x - enemy.x, player.z - enemy.z);
    return sameHyosanCombatLayer(enemy, player) && distance(enemy, player) <= reach
      && aim.x * Math.sin(enemy.yaw) + aim.z * Math.cos(enemy.yaw) > Math.cos(enemy.attackHalfAngle)
      && physics.lineOfSight(enemy, player);
  };
  const walk = (enemy: RooftopEnemy, aim: { x: number; z: number }, speed: number) => {
    if (aim.x || aim.z) enemy.yaw = Math.atan2(aim.x, aim.z);
    const step = speed * ctx.dt * ctx.movementMultiplier(enemy, enemy.kind);
    Object.assign(enemy, physics.moveActor(enemy.id, aim.x * step, aim.z * step));
  };
  const updateEnemies = () => {
    const ignoredActors = new Set(['player', ...ctx.enemies.map((enemy) => enemy.id)]);
    for (const enemy of enemies) {
      if (enemy.hp <= 0 || enemy.dormant) continue;
      enemy.active ||= firstEnteredAt !== null && ctx.time - firstEnteredAt >= 2.2 && distance(enemy, player) < 10
        && sameHyosanCombatLayer(enemy, player) && physics.lineOfSight(enemy, player);
      if (!enemy.active) continue;
      const waypoint = navigate(enemy, player, enemy.kind === 'boss' ? .5 : .32, .32);
      const aim = direction(waypoint.x - enemy.x, waypoint.z - enemy.z);
      if (enemy.kind === 'boss') {
        const visible = physics.lineOfSight(enemy, player);
        const frame = bossController.advance({ time: ctx.time, x: enemy.x, z: enemy.z, targetX: player.x, targetZ: player.z,
          distance: distance(enemy, player), visible, sameLayer: sameHyosanCombatLayer(enemy, player),
          canCharge: visible && physics.clearGround(enemy, player, .5), hpRatio: enemy.hp / enemy.maxHp });
        if (frame.beat !== 'death') enemy.rooftopBeat = frame.beat;
        enemy.rooftopPhase = frame.phase; enemy.attackPhase = frame.attackPhase; enemy.attackProgress = frame.attackProgress;
        enemy.attackHalfAngle = frame.halfAngle;
        const charging = frame.beat === 'rush-windup' || frame.beat === 'rush';
        enemy.attackStyle = charging ? 'charge' : 'melee';
        if (frame.beat !== 'stalk') enemy.yaw = frame.yaw;
        if (frame.speed > 0) walk(enemy, aim, frame.speed);
        if (frame.moveX || frame.moveZ) Object.assign(enemy, physics.moveActor(enemy.id, frame.moveX, frame.moveZ, { slide: false }));
        enemy.attackRange = frame.contactRange + (charging ? Math.max(0,
          (frame.telegraph.end.x - enemy.x) * Math.sin(frame.yaw) + (frame.telegraph.end.z - enemy.z) * Math.cos(frame.yaw)) : 0);
        if (charging) {
          // Bound the warning's forward centerline by solid geometry. Actors
          // do not shorten it: they can leave during the commitment window.
          const wall = physics.cast({ x: enemy.x, y: enemy.y + 1.05, z: enemy.z },
            { x: Math.sin(enemy.yaw), z: Math.cos(enemy.yaw) }, enemy.attackRange, ignoredActors);
          if (wall) enemy.attackRange = Math.max(0, wall.distance - .02);
        }
        if (frame.strike) ctx.effect(charging ? 'boss-warning' : 'boss-sweep', enemy, .24);
        // Body movement is accepted first. A blocked rush cannot hit through a
        // wall, across a layer, outside its locked cone or twice in one attack.
        if (frame.contact && frame.attackId !== lastContactId && hitsPlayer(enemy, frame.contactRange)) {
          lastContactId = frame.attackId; ctx.hurtPlayer(frame.damage, enemy);
        }
      } else if (enemy.attackPhase === 'idle') {
        if (sameHyosanCombatLayer(enemy, player) && distance(enemy, player) <= 1.05 && physics.lineOfSight(enemy, player)) {
          enemy.yaw = Math.atan2(player.x - enemy.x, player.z - enemy.z); enemy.attackPhase = 'windup'; enemy.since = ctx.time;
        } else walk(enemy, aim, 1.18);
      } else if (enemy.attackPhase === 'windup' && ctx.time - enemy.since >= STUDENT.windup) {
        enemy.attackPhase = 'strike'; enemy.since = ctx.time; if (hitsPlayer(enemy)) ctx.hurtPlayer(1, enemy);
      } else if (enemy.attackPhase === 'strike' && ctx.time - enemy.since >= STUDENT.strike) { enemy.attackPhase = 'recover'; enemy.since = ctx.time; }
      else if (enemy.attackPhase === 'recover' && ctx.time - enemy.since >= STUDENT.recovery) { enemy.attackPhase = 'idle'; enemy.since = ctx.time; }
      if (enemy.kind === 'student') enemy.attackProgress = enemy.attackPhase === 'idle' ? 0 : Math.min(1,
        (ctx.time - enemy.since) / (enemy.attackPhase === 'windup' ? STUDENT.windup : enemy.attackPhase === 'strike' ? STUDENT.strike : STUDENT.recovery));
    }
  };
  return {
    id: 'rooftop', enemies,
    reset(raw, isResolved) {
      const saved = parseHyosanRooftopSave(raw);
      resolved = isResolved; completed = false; echoCollected = false;
      firstEnteredAt = null; lastContactId = -1; bossController.reset();
      shortcutOpened = saved?.shortcutOpened === true; anchorReached = saved?.anchorReached === true; supplyTaken = saved?.supplyTaken === true;
      keepsakeSecured = saved?.keepsakeSecured === true; keepsakeFound = keepsakeSecured;
      discovered.clear(); for (const room of saved?.discoveredRooms ?? []) discovered.add(room);
      gateProgress = shortcutOpened ? 1 : 0; opening = false; physics.trySetPropPose(gate.id, gatePose(gateProgress));
      enemies.length = 0;
      if (!resolved) {
        for (const at of plan.encounters) enemies.push(createEnemy(at.id, at));
        enemies.push(createEnemy(plan.boss.id, plan.boss, true));
      }
    },
    observePlayer() {
      const room = roomAt(player); if (room) discovered.add(room);
      if (ctx.area === 'rooftop' && firstEnteredAt === null) firstEnteredAt = ctx.time;
    },
    update({ interactPressed }) {
      if (player.hp <= 0) return;
      if (distance(player, plan.checkpoint) <= plan.checkpoint.radius && nearby(plan.checkpoint)) {
        if (!anchorReached) { anchorReached = true; ctx.checkpoint(plan.checkpoint); }
        if (keepsakeFound && !keepsakeSecured) { keepsakeSecured = true; ctx.effect('upgrade', plan.checkpoint, 1.2); }
      }
      if (interactPressed) {
        const action = interaction();
        if (action === 'supply') { supplyTaken = true; player.hp = Math.min(player.maxHp, player.hp + 2); }
        if (action === 'keepsake') keepsakeFound = true;
        if (action === 'shortcut') opening = true;
        if (action === 'echo') echoCollected = true;
        if (action) ctx.effect(action === 'shortcut' ? 'door' : 'upgrade', player, .7);
      }
      if (opening) {
        const next = Math.min(1, gateProgress + ctx.dt / plan.shortcut.duration);
        if (physics.trySetPropPose(gate.id, gatePose(next))) gateProgress = next;
        if (gateProgress === 1) { shortcutOpened = true; opening = false; }
      }
      updateEnemies();
    },
    afterCombat() {
      if (!resolved && player.hp > 0 && boss()?.hp === 0 && echoCollected && roomAt(player) === 'rooftop-memorial'
        && Math.abs(player.y - plan.exit.y) < .25 && (player.z - plan.exit.z) * plan.exit.forward >= 0
        && Math.abs(player.x - plan.exit.x) <= 1.2) {
        completed = true; keepsakeSecured ||= keepsakeFound;
      }
    },
    interaction,
    markResolved() { resolved = true; completed = false; },
    readProgress() {
      const bow = hyosan3DBow(equipment.kitCollected, equipment.supplyCollected, equipment.piercingCollected, equipment.stringReinforced, equipment.tipReinforced);
      const room = roomAt(player) ?? 'rooftop-foot';
      return { room, discoveredRooms: [...discovered], supplyTaken, keepsakeFound, keepsakeSecured,
        areaResolved: resolved, objective: completed ? 'completed' : resolved ? 'explore_school'
          : boss()?.active && boss()!.hp > 0 ? 'defeat_boss' : boss()?.hp !== 0
            ? room === 'rooftop-foot' || room === 'rooftop-ascent' || room === 'rooftop-landing' ? 'ascend_rooftop' : 'explore_rooftop'
            : !echoCollected ? 'collect_echo' : 'reach_exit',
        upgraded: equipment.kitCollected, supplyCollected: equipment.supplyCollected, piercingCollected: equipment.piercingCollected,
        stringReinforced: equipment.stringReinforced, tipReinforced: equipment.tipReinforced,
        bowLevel: bow.level, bossDefeated: resolved || boss()?.hp === 0, completed, echoCollected, anchorReached, shortcutOpened,
        incidentTriggered: false, entranceOpen: 1, inWater: ctx.movementMultiplier(player, 'player') < 1,
        activeWaterIds: [], incidentShortcutOpened: false };
    },
    exportSave: () => ({ version: 1, worldVersion: source.version, shortcutOpened, anchorReached, supplyTaken, keepsakeSecured,
      discoveredRooms: HYOSAN_ROOFTOP_ROOMS.filter((room) => discovered.has(room)) }),
    respawnPoint: () => anchorReached ? plan.checkpoint : plan.spawn,
    furniture: () => [{ id: gate.id, ...gatePose(gateProgress), progress: gateProgress }],
  };
}
