import { HYOSAN_REUNION, HYOSAN_REUNION_PAGES, nearReunion, reunionPlaying } from './ending';
import type { Hyosan3DEnding, Hyosan3DStory } from './types';
import { HYOSAN_STORIES } from './story';
import { hyosan3DRoomForFloor } from './rooms';
import { createHyosanRooftopRegion } from './rooftop-region';
import type { RooftopSaveDTO } from './rooftop-save';
import layout from '@/docs/games/hyosan-memories-3d/world-layout.json';
import { createHyosanCombatWorld } from './combat-world';
import { createHyosanScienceRegion } from './science-region';
import { createHyosanCafeteriaRegion } from './cafeteria-region';
import { createHyosanClassroomRegion } from './classroom-region';
import { createHyosanLibraryRegion } from './library-region';
import type { LibrarySaveDTO } from './library-save';
import { createHyosanStaffroomRegion } from './staffroom-region';
import type { StaffroomSaveDTO } from './staffroom-save';
import { createHyosanGymnasiumRegion } from './gymnasium-region';
import type { GymnasiumSaveDTO } from './gymnasium-save';
import { createHyosanBroadcastRegion } from './broadcast-region';
import { parseHyosanCampaignSave, type HyosanCampaignSave } from './campaign-save';
import type { ScienceSaveDTO } from './science-save';
import type { ClassroomSaveDTO } from './classroom-save';
import type { BroadcastSaveDTO } from './broadcast-save';
import { HYOSAN_3D_AREAS, type Hyosan3DPlayRuntime, type Hyosan3DSave } from './types';
import type { GroundPoint } from './physics';
import type { HyosanNavigationTarget } from './navigation-target';
import type { HyosanDifficulty } from './difficulty';

const musicEntranceFloors = new Set(layout.floors.filter((floor) => hyosan3DRoomForFloor(floor) === 'staffroom-entry').map((floor) => floor.id));

export interface HyosanCampaignSession extends Hyosan3DPlayRuntime {
  setDifficulty(difficulty: HyosanDifficulty): void;
  exportSave(): HyosanCampaignSave;
  advanceEnding(action: 'next' | 'skip'): void;
  beginStory(id: Hyosan3DStory['id']): boolean;
  advanceStory(action: 'next' | 'skip'): void;
  navigationRoute(to: HyosanNavigationTarget, knownRooms: readonly string[]): readonly GroundPoint[];
  /** Loading completes before creation; walking never prepares another world. */
  settled(): Promise<void>;
}
const fresh = (): HyosanCampaignSave => ({ version: 9, introSeen: false, musicMemorySeen: false, endingSeen: false, worldVersion: layout.version, activeArea: 'science',
  equipment: { kitCollected: false, supplyCollected: false, piercingCollected: false, stringReinforced: false, tipReinforced: false },
  completedAreas: [], science: null, cafeteria: null, classroom: null, broadcast: null, library: null, staffroom: null, gymnasium: null, rooftop: null });

/** One school-wide combat world; regional seams only select guidance. */
export async function createHyosanCampaignSession(options: { saved?: unknown; difficulty?: HyosanDifficulty } = {}): Promise<HyosanCampaignSession> {
  let data = parseHyosanCampaignSave(options.saved) ?? fresh();
  let error: unknown = null; let disposed = false;
  const world = await createHyosanCombatWorld(layout, {
    factories: [(context) => createHyosanScienceRegion(context, { teachBow: true }), createHyosanCafeteriaRegion, createHyosanClassroomRegion, createHyosanBroadcastRegion, createHyosanLibraryRegion, createHyosanStaffroomRegion, createHyosanGymnasiumRegion, createHyosanRooftopRegion],
    area: data.activeArea, savedByArea: { science: data.science, cafeteria: data.cafeteria, classroom: data.classroom, broadcast: data.broadcast, library: data.library, staffroom: data.staffroom, gymnasium: data.gymnasium, rooftop: data.rooftop },
    equipment: data.equipment, completedAreas: data.completedAreas, campaign: true, difficulty: options.difficulty,
  });
  const capture = () => {
    if (error || disposed) return;
    const saves = world.exportRegionSaves();
    const guidance = world.read().area ?? 'science';
    // The guidance seam can precede the next region's first floor. Resume from
    // a genuinely visited area until that region has a valid durable record.
    const resumeArea = HYOSAN_3D_AREAS.find((area) => area === guidance && saves[area]) ?? (saves[data.activeArea] ? data.activeArea
      : HYOSAN_3D_AREAS.find((area) => saves[area]) ?? 'science');
    data = { version: 9, introSeen: data.introSeen, musicMemorySeen: data.musicMemorySeen, endingSeen: data.endingSeen, worldVersion: layout.version, activeArea: resumeArea,
      equipment: world.readEquipment(), completedAreas: HYOSAN_3D_AREAS.filter((area) => world.completedAreas().includes(area)),
      science: (saves.science as ScienceSaveDTO | undefined) ?? null,
      cafeteria: (saves.cafeteria as Hyosan3DSave | undefined) ?? null,
      classroom: (saves.classroom as ClassroomSaveDTO | undefined) ?? null,
      broadcast: (saves.broadcast as BroadcastSaveDTO | undefined) ?? null,
      library: (saves.library as LibrarySaveDTO | undefined) ?? null,
      staffroom: (saves.staffroom as StaffroomSaveDTO | undefined) ?? null,
      gymnasium: (saves.gymnasium as GymnasiumSaveDTO | undefined) ?? null,
      rooftop: (saves.rooftop as RooftopSaveDTO | undefined) ?? null };
  };
  let ending: Hyosan3DEnding = { phase: data.endingSeen ? 'complete' : data.completedAreas.length === 8 ? 'available' : 'locked', page: 0, elapsed: 0, time: 0 };
  let interactReleased = false;
  let story: Hyosan3DStory | null = null;
  capture();
  return {
    setDifficulty(next) { if (!disposed && !error) world.setDifficulty(next); },
    beginStory(id) {
      if (disposed || error || story || reunionPlaying(ending)) return false;
      if (id === 'opening' ? data.introSeen : data.musicMemorySeen) return false;
      const state = world.read();
      if (state.paused || state.player.hp <= 0) return false;
      if (id === 'music' && (!world.completedAreas().includes('library')
        || state.area !== 'staffroom' || !musicEntranceFloors.has(state.player.surfaceId ?? ''))) return false;
      world.cancelActions(); interactReleased = false; story = { id, page: 0, time: 0 }; return true;
    },
    advanceStory(action) {
      if (disposed || error || world.read().paused || !story || story.time < .25) return;
      if (action === 'next' && story.page < HYOSAN_STORIES[story.id].pages.length - 1) {
        story = { ...story, page: story.page + 1, time: 0 };
      } else {
        if (story.id === 'opening') data.introSeen = true; else data.musicMemorySeen = true;
        story = null; interactReleased = false; world.cancelActions(); capture();
      }
    },
    navigationRoute: (to, knownRooms) => world.navigationRoute(to, knownRooms),
    step(input, dt = 1 / 60) {
      if (disposed || error || world.read().paused || !Number.isFinite(dt) || dt <= 0) return;
      if (story) { story.time += Math.min(dt, .1); return; }
      if (reunionPlaying(ending)) {
        ending.time += Math.min(dt, .1); ending.elapsed = (ending.elapsed ?? 0) + Math.min(dt, .1);
        if (ending.phase === 'returning' && ending.time >= HYOSAN_REUNION.returnDuration) {
          ending = { phase: 'reunion', page: 0, elapsed: ending.elapsed, time: 0 };
        }
        return;
      }
      if (!input.interactPressed) interactReleased = true;
      const pressed = input.interactPressed && interactReleased;
      if (input.interactPressed) interactReleased = false;
      if (pressed && (ending.phase === 'available' || ending.phase === 'complete') && nearReunion(world.read().player)) {
        world.cancelActions(); ending = { phase: data.endingSeen ? 'reunion' : 'returning', page: 0, elapsed: 0, time: 0 }; return;
      }
      world.step(input, dt);
      if (ending.phase === 'locked' && world.completedAreas().length === 8) ending.phase = 'available';
    },
    advanceEnding(action) {
      if (disposed || error || world.read().paused || ending.phase !== 'reunion' || ending.time < .25) return;
      if (action === 'next' && ending.page < HYOSAN_REUNION_PAGES.length - 1) {
        ending = { phase: 'reunion', page: ending.page + 1, elapsed: ending.elapsed, time: 0 };
      } else {
        data.endingSeen = true; ending = { phase: 'complete', page: 0, elapsed: 0, time: 0 };
        interactReleased = false; world.cancelActions(); capture();
      }
    },
    read() {
      const state = world.read(); const completed = world.completedAreas();
      return { ...state, transitioning: false, transitionFailed: Boolean(error), paused: Boolean(error) || state.paused,
        ending: { ...ending, nextArea: HYOSAN_3D_AREAS.find((area) => !completed.includes(area)) },
        story: story ? { ...story } : null,
        interaction: story || reunionPlaying(ending) ? null : (ending.phase === 'available' || ending.phase === 'complete') && nearReunion(state.player) ? 'campfire' : state.interaction,
        campaign: { scienceComplete: completed.includes('science'), cafeteriaComplete: completed.includes('cafeteria'),
          classroomComplete: completed.includes('classroom'), broadcastComplete: completed.includes('broadcast'), libraryComplete: completed.includes('library'), staffroomComplete: completed.includes('staffroom'), gymnasiumComplete: completed.includes('gymnasium'), rooftopComplete: completed.includes('rooftop') },
        progress: { ...state.progress,
          discoveredRooms: [...new Set(Object.values(state.schoolState ?? {}).flatMap((progress) => progress?.discoveredRooms ?? []))],
          objective: ending.phase === 'complete' ? 'explore_school' as const : completed.length === HYOSAN_3D_AREAS.length ? 'return_campfire' as const : state.area === 'rooftop' && state.progress.areaResolved ? 'return_memory' as const : state.area === 'cafeteria' && state.progress.areaResolved
          ? !completed.includes('science') ? 'return_science' as const : !completed.includes('classroom')
            ? 'reach_classroom' as const : !completed.includes('broadcast') ? 'reach_broadcast' as const : state.progress.objective
          : state.area === 'classroom' && state.progress.areaResolved && !completed.includes('broadcast')
            ? 'reach_broadcast' as const : state.area === 'broadcast' && state.progress.areaResolved && !completed.includes('library')
              ? 'reach_library' as const : state.area === 'library' && state.progress.areaResolved && !completed.includes('staffroom')
                ? 'reach_staffroom' as const : state.area === 'staffroom' && state.progress.areaResolved && !completed.includes('gymnasium')
                  ? 'reach_gym' as const : state.area === 'gymnasium' && state.progress.areaResolved && !completed.includes('rooftop')
                    ? 'ascend_rooftop' as const : state.progress.objective } };
    },
    setPaused(value) { if (!disposed && !error) { interactReleased = false; world.setPaused(value); } },
    reset() {
      if (disposed) return;
      data = fresh(); error = null; story = null; ending = { phase: 'locked', page: 0, elapsed: 0, time: 0 }; interactReleased = false;
      try { world.reset(); capture(); } catch (reason) { error = reason; world.setPaused(true); }
    },
    exportSave() { capture(); return structuredClone(data); },
    async settled() { await world.settled(); if (error) throw error; },
    dispose() { if (!disposed) { capture(); disposed = true; world.dispose(); } },
  };
}
