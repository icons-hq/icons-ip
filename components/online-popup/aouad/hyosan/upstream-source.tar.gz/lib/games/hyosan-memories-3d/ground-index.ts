import type { GroundBounds } from './physics';

type Node<T> = GroundBounds & ({ items: readonly T[] } | { left: Node<T>; right: Node<T> });

/** Broad phase only; the caller retains the exact support/contact predicate. */
export function createHyosanGroundIndex<T extends GroundBounds>(items: readonly T[]) {
  const build = (entries: T[]): Node<T> => {
    const box = { minX: Infinity, maxX: -Infinity, minZ: Infinity, maxZ: -Infinity };
    for (const entry of entries) {
      box.minX = Math.min(box.minX, entry.minX); box.maxX = Math.max(box.maxX, entry.maxX);
      box.minZ = Math.min(box.minZ, entry.minZ); box.maxZ = Math.max(box.maxZ, entry.maxZ);
    }
    if (entries.length <= 8) return { ...box, items: entries };
    const horizontal = box.maxX - box.minX >= box.maxZ - box.minZ;
    entries.sort((a, b) => horizontal ? a.minX + a.maxX - b.minX - b.maxX : a.minZ + a.maxZ - b.minZ - b.maxZ);
    const middle = Math.floor(entries.length / 2);
    return { ...box, left: build(entries.slice(0, middle)), right: build(entries.slice(middle)) };
  };
  // Bounds are a snapshot. Rebuild after an accepted obstacle pose change.
  const root = build([...items]);
  return {
    some(minX: number, maxX: number, minZ: number, maxZ: number, accept: (item: T) => boolean) {
      const visit = (node: Node<T>): boolean => {
        if (maxX < node.minX || minX > node.maxX || maxZ < node.minZ || minZ > node.maxZ) return false;
        if ('items' in node) {
          for (const item of node.items) if (maxX >= item.minX && minX <= item.maxX && maxZ >= item.minZ && minZ <= item.maxZ && accept(item)) return true;
          return false;
        }
        return visit(node.left) || visit(node.right);
      };
      return visit(root);
    },
  };
}
