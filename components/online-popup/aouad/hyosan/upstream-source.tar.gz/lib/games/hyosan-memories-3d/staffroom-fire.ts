export interface HyosanStaffroomFireZone {
  readonly id: string;
  readonly y: number;
  readonly layerId: string;
  readonly polygon: readonly Readonly<{ x: number; z: number }>[];
  readonly visualPoint: Readonly<{ x: number; y: number; z: number }>;
}
export interface HyosanStaffroomFirePlan {
  readonly zones: readonly HyosanStaffroomFireZone[];
  readonly links: readonly Readonly<{ from: string; to: string; cutByShortcut?: boolean }>[];
  readonly seedId: string;
}
export interface HyosanStaffroomFirePoint { readonly x: number; readonly y: number; readonly z: number; readonly currentLayerId: string }
export interface HyosanStaffroomFireActor extends HyosanStaffroomFirePoint { readonly id: string; readonly radius: number; readonly hp: number }
export type HyosanStaffroomFirePhase = 'unlit' | 'warning' | 'burning' | 'embers' | 'scorched';
export interface HyosanStaffroomFireState {
  readonly id: string;
  readonly phase: HyosanStaffroomFirePhase;
  readonly since: number | null;
  /** Earliest next phase; null while occupants prevent a safe ignition. */
  readonly readyAt: number | null;
  readonly waitingForClear: boolean;
}
export interface HyosanStaffroomFireInput {
  readonly time: number;
  readonly actors: readonly HyosanStaffroomFireActor[];
  readonly shortcutOpened: boolean;
  readonly bossDefeated: boolean;
}
export const HYOSAN_STAFFROOM_FIRE = Object.freeze({ warning: 1.5, burn: 8, embers: 1, clearWarning: .5, feetTolerance: .08 });
const EPSILON = 1e-9;
type Point = Readonly<{ x: number; z: number }>;
type MutableState = { -readonly [Key in keyof HyosanStaffroomFireState]: HyosanStaffroomFireState[Key] };

function edgeDistance(point: Point, a: Point, b: Point) {
  const dx = b.x - a.x; const dz = b.z - a.z;
  const fraction = Math.max(0, Math.min(1, ((point.x - a.x) * dx + (point.z - a.z) * dz) / (dx * dx + dz * dz)));
  return Math.hypot(point.x - a.x - fraction * dx, point.z - a.z - fraction * dz);
}

export function overlapsHyosanStaffroomFire(point: HyosanStaffroomFirePoint, radius: number, zone: HyosanStaffroomFireZone) {
  if (point.currentLayerId !== zone.layerId || Math.abs(point.y - zone.y) > HYOSAN_STAFFROOM_FIRE.feetTolerance + EPSILON) return false;
  let inside = false;
  for (let index = 0; index < zone.polygon.length; index++) {
    const a = zone.polygon[index]; const b = zone.polygon[(index + 1) % zone.polygon.length];
    if (edgeDistance(point, a, b) <= radius + EPSILON) return true;
    if ((a.z > point.z) !== (b.z > point.z) && point.x < a.x + (point.z - a.z) * (b.x - a.x) / (b.z - a.z)) inside = !inside;
  }
  return inside;
}

function requireValid(condition: boolean, message: string): asserts condition {
  if (!condition) throw new RangeError(`Invalid staffroom fire ${message}`);
}
const finite = (...values: number[]) => values.every(Number.isFinite);
const named = (value: string) => typeof value === 'string' && value.trim().length > 0;
function validatePoint(point: HyosanStaffroomFirePoint, radius: number) {
  requireValid(finite(point.x, point.y, point.z, radius) && radius >= 0 && named(point.currentLayerId), 'point or radius');
}
function validateActors(actors: readonly HyosanStaffroomFireActor[]) {
  for (const actor of actors) {
    validatePoint(actor, actor.radius);
    requireValid(named(actor.id) && Number.isFinite(actor.hp) && actor.radius > 0, 'actor');
  }
}
function segmentsIntersect(a: Point, b: Point, c: Point, d: Point) {
  const cross = (p: Point, q: Point, r: Point) => (q.x - p.x) * (r.z - p.z) - (q.z - p.z) * (r.x - p.x);
  const abC = cross(a, b, c); const abD = cross(a, b, d);
  const cdA = cross(c, d, a); const cdB = cross(c, d, b);
  if (((abC > EPSILON && abD < -EPSILON) || (abC < -EPSILON && abD > EPSILON)) &&
    ((cdA > EPSILON && cdB < -EPSILON) || (cdA < -EPSILON && cdB > EPSILON))) return true;
  return (Math.abs(abC) <= EPSILON && edgeDistance(c, a, b) <= EPSILON) ||
    (Math.abs(abD) <= EPSILON && edgeDistance(d, a, b) <= EPSILON) ||
    (Math.abs(cdA) <= EPSILON && edgeDistance(a, c, d) <= EPSILON) ||
    (Math.abs(cdB) <= EPSILON && edgeDistance(b, c, d) <= EPSILON);
}
function validatePlan(plan: HyosanStaffroomFirePlan) {
  requireValid(plan.zones.length === 4, 'zone count');
  const ids = new Set<string>();
  for (const zone of plan.zones) {
    requireValid(named(zone.id) && !ids.has(zone.id) && named(zone.layerId), 'zone identity');
    ids.add(zone.id);
    requireValid(finite(zone.y, zone.visualPoint.x, zone.visualPoint.y, zone.visualPoint.z), 'zone height or visual point');
    const points = zone.polygon;
    requireValid(points.length >= 3 && points.every((point) => finite(point.x, point.z)), 'polygon vertices');
    let area = 0;
    for (let index = 0; index < points.length; index++) {
      const a = points[index]; const b = points[(index + 1) % points.length];
      area += (a.x - points[0].x) * (b.z - points[0].z) - (b.x - points[0].x) * (a.z - points[0].z);
      for (let other = index + 1; other < points.length; other++) {
        requireValid(Math.hypot(a.x - points[other].x, a.z - points[other].z) > EPSILON, 'repeated polygon vertex');
        if (other === index + 1 || (index === 0 && other === points.length - 1)) continue;
        requireValid(!segmentsIntersect(a, b, points[other], points[(other + 1) % points.length]), 'self-intersecting polygon');
      }
    }
    requireValid(Number.isFinite(area) && Math.abs(area) > EPSILON, 'polygon area');
  }
  requireValid(ids.has(plan.seedId), 'seed');
  const linkIds = new Set<string>();
  for (const link of plan.links) {
    const key = JSON.stringify([link.from, link.to]);
    requireValid(ids.has(link.from) && ids.has(link.to) && link.from !== link.to && !linkIds.has(key), 'link');
    requireValid(link.cutByShortcut === undefined || typeof link.cutByShortcut === 'boolean', 'shortcut link');
    linkIds.add(key);
  }
}

type ZoneRuntime = {
  zone: HyosanStaffroomFireZone;
  state: MutableState;
  clearSince: number | null;
  manual: boolean;
  sources: Set<number>;
};
const unlitState = (id: string): MutableState => ({ id, phase: 'unlit', since: null, readyAt: null, waitingForClear: false });

/**
 * Finite authored fire; the host owns damage, clock advancement and incident discovery.
 * Each request retains its individual spread links and explicit ignition cause. Cutting one
 * link cannot cancel another cause; burning/embers are never cancelled or reignited.
 */
export function createHyosanStaffroomFire(plan: HyosanStaffroomFirePlan) {
  validatePlan(plan);
  const zones: ZoneRuntime[] = plan.zones.map((zone) => ({
    zone: { ...zone, polygon: zone.polygon.map((point) => ({ ...point })), visualPoint: { ...zone.visualPoint } },
    state: unlitState(zone.id), clearSince: null, manual: false, sources: new Set(),
  }));
  const byId = new Map(zones.map((runtime) => [runtime.zone.id, runtime]));
  const links = plan.links.map((link) => ({ ...link }));
  let queue: ZoneRuntime[] = [];
  let shortcutOpened = false;
  let stopped = false;
  let lastTime = 0;
  const read = (): readonly HyosanStaffroomFireState[] => Object.freeze(zones.map(({ state }) => Object.freeze({ ...state })));
  function validateTime(time: number) {
    requireValid(Number.isFinite(time) && time >= 0 && time >= lastTime, 'clock');
  }
  function reset(options: { resolved: boolean }) {
    requireValid(typeof options.resolved === 'boolean', 'reset state');
    stopped = options.resolved; shortcutOpened = false; lastTime = 0; queue = [];
    for (const zone of zones) {
      zone.state = { ...unlitState(zone.zone.id), phase: stopped ? 'scorched' : 'unlit' };
      zone.clearSince = null; zone.manual = false; zone.sources.clear();
    }
  }
  function request(zone: ZoneRuntime, link?: number) {
    if (stopped || (link !== undefined && shortcutOpened && links[link].cutByShortcut) ||
      (zone.state.phase !== 'unlit' && zone.state.phase !== 'warning')) return false;
    if (link === undefined && zone.manual) return false;
    if (!zone.manual && zone.sources.size === 0) queue.push(zone);
    if (link === undefined) zone.manual = true;
    else zone.sources.add(link);
    return true;
  }
  function startNext(time: number) {
    const current = zones.find(({ state }) => state.phase === 'warning');
    if (current) return current;
    const next = queue.shift();
    if (next) next.state = { ...unlitState(next.zone.id), phase: 'warning', since: time, readyAt: time + HYOSAN_STAFFROOM_FIRE.warning };
    return next;
  }
  function updateWarning(zone: ZoneRuntime, input: HyosanStaffroomFireInput) {
    const { state } = zone;
    state.waitingForClear = input.actors.some((actor) => actor.hp > 0 && overlapsHyosanStaffroomFire(actor, actor.radius, zone.zone));
    if (state.waitingForClear) { zone.clearSince = null; state.readyAt = null; return false; }
    zone.clearSince ??= input.time;
    state.readyAt = Math.max(state.since! + HYOSAN_STAFFROOM_FIRE.warning, zone.clearSince + HYOSAN_STAFFROOM_FIRE.clearWarning);
    if (input.time + EPSILON < state.readyAt) return false;
    state.phase = 'burning'; state.since = input.time; state.readyAt = input.time + HYOSAN_STAFFROOM_FIRE.burn;
    zone.manual = false; zone.sources.clear(); zone.clearSince = null;
    return true;
  }
  const isHazardous = (point: HyosanStaffroomFirePoint, radius: number) => zones.some(({ state, zone }) => state.phase === 'burning' && overlapsHyosanStaffroomFire(point, radius, zone));
  return {
    reset, read,
    hazardous(point: HyosanStaffroomFirePoint, radius = 0) {
      validatePoint(point, radius);
      return isHazardous(point, radius);
    },
    exposedActors(actors: readonly HyosanStaffroomFireActor[]): readonly string[] {
      validateActors(actors);
      return Object.freeze([...new Set(actors.filter((actor) => actor.hp > 0 && isHazardous(actor, actor.radius)).map((actor) => actor.id))]);
    },
    ignite(id: string, time: number) {
      validateTime(time);
      const zone = byId.get(id);
      requireValid(!!zone, `unknown zone: ${id}`);
      const accepted = request(zone);
      if (accepted) { lastTime = time; startNext(time); }
      return accepted;
    },
    advance(input: HyosanStaffroomFireInput) {
      validateTime(input.time); validateActors(input.actors);
      requireValid(typeof input.shortcutOpened === 'boolean' && typeof input.bossDefeated === 'boolean', 'advance flags');
      lastTime = input.time;
      shortcutOpened ||= input.shortcutOpened; stopped ||= input.bossDefeated;
      for (const zone of zones) {
        const { state } = zone;
        if (shortcutOpened) for (const index of zone.sources) if (links[index].cutByShortcut) zone.sources.delete(index);
        if ((state.phase === 'warning' || state.phase === 'unlit') && (stopped || (!zone.manual && zone.sources.size === 0))) {
          queue = queue.filter((queued) => queued !== zone);
          zone.state = unlitState(zone.zone.id); zone.manual = false; zone.sources.clear(); zone.clearSince = null;
        }
        if (state.phase === 'burning' && input.time >= state.readyAt!) {
          const endsAt = state.readyAt!;
          state.phase = 'embers'; state.since = endsAt; state.readyAt = endsAt + HYOSAN_STAFFROOM_FIRE.embers;
        }
        if (state.phase === 'embers' && input.time >= state.readyAt!) {
          state.phase = 'scorched'; state.since = state.readyAt; state.readyAt = null;
        }
      }
      const warning = startNext(input.time);
      if (warning && updateWarning(warning, input)) {
        links.forEach((link, index) => { if (link.from === warning.zone.id) request(byId.get(link.to)!, index); });
        const next = startNext(input.time);
        if (next) updateWarning(next, input);
      }
      return read();
    },
  };
}
