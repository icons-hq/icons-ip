import layout from '@/docs/games/hyosan-memories-3d/world-layout.json';
import { HYOSAN_LIBRARY_ROOMS } from './types';

export type HyosanLibraryRoom = typeof HYOSAN_LIBRARY_ROOMS[number];
export interface LibrarySaveDTO {
  version: 1; worldVersion: string;
  shortcutOpened: boolean; anchorReached: boolean; stringReinforced: boolean; keepsakeSecured: boolean;
  discoveredRooms: readonly HyosanLibraryRoom[];
}
const flags = ['shortcutOpened', 'anchorReached', 'stringReinforced', 'keepsakeSecured'] as const;
const fields = ['version', 'worldVersion', 'discoveredRooms', ...flags];

/** Only a keepsake brought back to an anchor or carried through completion is durable. */
export function parseHyosanLibrarySave(raw: unknown): LibrarySaveDTO | null {
  try {
    const value = typeof raw === 'string' ? JSON.parse(raw) : raw;
    if (!value || typeof value !== 'object' || Array.isArray(value)
      || Object.keys(value).length !== fields.length || Object.keys(value).some((key) => !fields.includes(key))
      || value.version !== 1 || value.worldVersion !== layout.version && !(layout.version === 'hyosan-3d-school-v12' && ['hyosan-3d-school-v9', 'hyosan-3d-school-v10', 'hyosan-3d-school-v11'].includes(value.worldVersion))
      || flags.some((key) => typeof value[key] !== 'boolean')) return null;
    const rooms = value.discoveredRooms;
    if (!Array.isArray(rooms) || !rooms.length || rooms.length > HYOSAN_LIBRARY_ROOMS.length
      || new Set(rooms).size !== rooms.length || Array.from(rooms).some((room) => !HYOSAN_LIBRARY_ROOMS.includes(room))
      || value.keepsakeSecured && !rooms.includes('library-archive')) return null;
    return { version: 1, worldVersion: layout.version, shortcutOpened: value.shortcutOpened,
      anchorReached: value.anchorReached, stringReinforced: value.stringReinforced, keepsakeSecured: value.keepsakeSecured,
      discoveredRooms: HYOSAN_LIBRARY_ROOMS.filter((room) => rooms.includes(room)) };
  } catch { return null; }
}

export function serializeHyosanLibrarySave(save: LibrarySaveDTO): string {
  const parsed = parseHyosanLibrarySave(save);
  if (!parsed) throw new TypeError('Invalid Hyosan library exploration save');
  return JSON.stringify(parsed);
}
