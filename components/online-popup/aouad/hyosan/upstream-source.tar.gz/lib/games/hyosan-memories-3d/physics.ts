import type { HyosanRooftopPlan } from './rooftop-layout';
import RAPIER from '@dimforge/rapier3d-compat';
import type { HyosanGymnasiumPlan } from './gymnasium-layout';
import layout from '@/docs/games/hyosan-memories-3d/world-layout.json';
import { hyosanCafeteriaDoorLeaves, hyosanCafeteriaEntrance } from './cafeteria-entrance';
import { hyosanArrivalGeometry } from './arrival-geometry';
import { createHyosanElevatedRouteGeometry, type HyosanElevatedRoute } from './elevated-routes';
import { createHyosanSupportGeometry, type HyosanStair, type HyosanLayerTransition, type HyosanSupportSample, type HyosanSupportRamp } from './support-geometry';
import { createHyosanGroundIndex } from './ground-index';
import { createHyosanServingCounterRayQuery, type HyosanServingCounterRayData } from './serving-counter-rays';

export type Hyosan3DLayout = Omit<typeof layout, 'adventure' | 'elevatedRoutes' | 'science' | 'classroom' | 'broadcast' | 'library' | 'staffroom' | 'gymnasium' | 'rooftop' | 'floors' | 'walls' | 'props' | 'stairs' | 'supportRamps' | 'layerTransitions'> & {
  adventure?: Omit<typeof layout.adventure, 'inflow'> & { inflow?: typeof layout.adventure.inflow };
  elevatedRoutes?: readonly HyosanElevatedRoute[];
  floors: readonly (Omit<typeof layout.floors[number], 'y' | 'currentLayerId' | 'thickness' | 'roomId'> & { y?: number; thickness?: number; roomId?: string; currentLayerId?: string })[];
  walls: readonly (Omit<typeof layout.walls[number], 'y'> & { y?: number })[];
  props: readonly (Omit<typeof layout.props[number], 'y'> & { y?: number })[];
  stairs?: readonly HyosanStair[];
  supportRamps?: readonly HyosanSupportRamp[];
  layerTransitions?: readonly HyosanLayerTransition[];
  broadcast?: typeof layout.broadcast;
  science?: typeof layout.science;
  classroom?: typeof layout.classroom;
  library?: typeof layout.library;
  staffroom?: typeof layout.staffroom;
  gymnasium?: HyosanGymnasiumPlan;
  rooftop?: HyosanRooftopPlan;
};
export interface GroundPoint { x: number; z: number; y?: number; surfaceId?: string; currentLayerId?: string }
export interface ActorPoint extends GroundPoint { y: number }
export interface GroundBounds { minX: number; maxX: number; minZ: number; maxZ: number }
export interface Hyosan3DPropPose extends GroundPoint { rotation: number }
export interface Hyosan3DPhysicsOptions {
  /** Only ray queries replace these static counter proxies; movement keeps their cuboids. */
  servingCounterRays?: HyosanServingCounterRayData;
}
type ObstacleFootprint = GroundPoint & { rotation: number; width: number; depth: number };
const queryGeometry = (obstacle: ObstacleFootprint) => {
  const cosine = Math.cos(obstacle.rotation);
  const sine = Math.sin(obstacle.rotation);
  const halfWidth = obstacle.width / 2;
  const halfDepth = obstacle.depth / 2;
  const x = halfWidth * Math.abs(cosine) + halfDepth * Math.abs(sine);
  const z = halfWidth * Math.abs(sine) + halfDepth * Math.abs(cosine);
  return { cosine, sine, halfWidth, halfDepth,
    minX: obstacle.x - x, maxX: obstacle.x + x, minZ: obstacle.z - z, maxZ: obstacle.z + z };
};
const groundBounds = (obstacle: GroundPoint & { rotation: number; width: number; depth: number }): GroundBounds => {
  const cosine = Math.abs(Math.cos(obstacle.rotation));
  const sine = Math.abs(Math.sin(obstacle.rotation));
  const x = (obstacle.width * cosine + obstacle.depth * sine) / 2;
  const z = (obstacle.width * sine + obstacle.depth * cosine) / 2;
  return { minX: obstacle.x - x, maxX: obstacle.x + x, minZ: obstacle.z - z, maxZ: obstacle.z + z };
};
const obstacleDistance = (point: GroundPoint, obstacle: ObstacleFootprint & ReturnType<typeof queryGeometry>) => {
  const dx = point.x - obstacle.x;
  const dz = point.z - obstacle.z;
  const x = Math.abs(dx * obstacle.cosine - dz * obstacle.sine);
  const z = Math.abs(dx * obstacle.sine + dz * obstacle.cosine);
  return Math.hypot(Math.max(0, x - obstacle.halfWidth), Math.max(0, z - obstacle.halfDepth));
};
let initialization: Promise<void> | undefined;

/** The renderer and Rapier consume the same metre-based geometry description. */
export async function createHyosan3DPhysics(source: Hyosan3DLayout = layout, options: Hyosan3DPhysicsOptions = {}) {
  const arrival = hyosanArrivalGeometry(source);
  const elevated = createHyosanElevatedRouteGeometry(source);
  const support = createHyosanSupportGeometry(source);
  for (const route of elevated.routes) {
    const prop = source.props.find(({ id }) => id === route.propId);
    if (!prop || prop.rotation !== 0 || source.adventure?.furniture.some(({ id }) => id === route.propId)) {
      throw new Error('An elevated route must belong to a static, aligned Hyosan table');
    }
  }
  await (initialization ??= RAPIER.init());
  const world = new RAPIER.World({ x: 0, y: 0, z: 0 });
  const controller = world.createCharacterController(0.015);
  controller.disableAutostep();
  controller.setSlideEnabled(true);
  controller.setMaxSlopeClimbAngle(Math.PI * 35 / 180);
  controller.setMinSlopeSlideAngle(Math.PI * 40 / 180);
  controller.enableSnapToGround(.12);
  const actors = new Map<string, RAPIER.Collider>();
  const actorIds = new Map<number, string>();
  const staticIds = new Map<number, string>();
  const supportIds = new Set<number>();
  const floorSupportIds = new Set<number>();
  const supportColliderIds = new Map<string, number>();
  const stairSupportIds = new Set<number>();
  const stairLandingIds = new Set<number>();
  const rampSupports = new Map<number, typeof elevated.ramps[number]>();
  let shortcutOpen = false;
  let revision = 0;
  const changes: { revision: number; bounds: GroundBounds[] }[] = [];
  const changed = (bounds: GroundBounds[]) => {
    revision++;
    changes.push({ revision, bounds });
    if (changes.length > 512) changes.shift();
  };
  let shortcutCollider: RAPIER.Collider | null = null;
  const entrance = hyosanCafeteriaEntrance(source);
  let entranceProgress = 0;
  const entranceColliders = new Map<string, RAPIER.Collider>();
  const propColliders = new Map<string, RAPIER.Collider>();
  const entranceLeaves = (entrance ? hyosanCafeteriaDoorLeaves(entrance, 0) : []).map((leaf) => Object.assign(leaf, queryGeometry(leaf)));
  const obstacles = [
    ...source.walls.map((wall) => ({ ...wall, rotation: 0 })),
    ...source.props.map((prop) => {
      const deck = elevated.routes.find(({ propId }) => propId === prop.id)?.deck;
      return { ...prop, ...(deck ?? source.propFootprints[prop.kind as keyof typeof source.propFootprints]) };
    }),
    ...(source.adventure ? [{ ...source.adventure.shortcut, rotation: 0 }] : []),
    ...entranceLeaves,
  ].map((obstacle) => Object.assign(obstacle, { y: 'y' in obstacle ? obstacle.y ?? 0 : 0 }, queryGeometry(obstacle)));
  const floorBounds = [...source.floors, ...support.ramps, ...support.stairs.flatMap((stair) => stair.treads)].map((floor) => ({ minX: floor.x - floor.width / 2, maxX: floor.x + floor.width / 2,
    minZ: floor.z - floor.depth / 2, maxZ: floor.z + floor.depth / 2 }));
  const floorIndex = createHyosanGroundIndex(floorBounds);
  let obstacleIndex = createHyosanGroundIndex(obstacles);
  let obstacleIndexRevision = revision;
  for (const floor of source.floors) {
    const halfThickness = (floor.thickness ?? .2) / 2;
    const collider = world.createCollider(RAPIER.ColliderDesc.cuboid(floor.width / 2, halfThickness, floor.depth / 2)
      .setTranslation(floor.x, (floor.y ?? 0) - halfThickness, floor.z));
    staticIds.set(collider.handle, floor.id);
    supportIds.add(collider.handle);
    supportColliderIds.set(floor.id, collider.handle);
    floorSupportIds.add(collider.handle);
    if (support.stairs.some((stair) => stair.fromFloorId === floor.id || stair.toFloorId === floor.id)) stairLandingIds.add(collider.handle);
  }
  for (const obstacle of obstacles) {
    const collider = world.createCollider(RAPIER.ColliderDesc.cuboid(obstacle.width / 2, obstacle.height / 2, obstacle.depth / 2)
      .setTranslation(obstacle.x, obstacle.y + obstacle.height / 2, obstacle.z)
      .setRotation({ x: 0, y: Math.sin(obstacle.rotation / 2), z: 0, w: Math.cos(obstacle.rotation / 2) }));
    staticIds.set(collider.handle, obstacle.id);
    if (obstacle.id === source.adventure?.shortcut.id) shortcutCollider = collider;
    if (entranceLeaves.some((leaf) => leaf.id === obstacle.id)) entranceColliders.set(obstacle.id, collider);
    if (source.props.some((prop) => prop.id === obstacle.id)) propColliders.set(obstacle.id, collider);
    if (elevated.routes.some((route) => route.propId === obstacle.id)) supportIds.add(collider.handle);
  }
  for (const ramp of elevated.ramps) {
    const shape = RAPIER.ColliderDesc.convexHull(new Float32Array(ramp.vertices));
    if (!shape) throw new Error(`Invalid Hyosan ramp hull ${ramp.id}`);
    const collider = world.createCollider(shape);
    staticIds.set(collider.handle, ramp.id); supportIds.add(collider.handle);
    rampSupports.set(collider.handle, ramp);
    supportColliderIds.set(ramp.id, collider.handle);
  }
  for (const ramp of support.ramps) {
    const shape = RAPIER.ColliderDesc.convexHull(new Float32Array(ramp.vertices));
    if (!shape) throw new Error(`Invalid Hyosan support ramp hull ${ramp.id}`);
    const collider = world.createCollider(shape);
    staticIds.set(collider.handle, ramp.id); supportIds.add(collider.handle);
    supportColliderIds.set(ramp.id, collider.handle);
  }
  for (const stair of support.stairs) for (const tread of stair.treads) {
    const collider = world.createCollider(RAPIER.ColliderDesc.cuboid(tread.width / 2, tread.blockHeight / 2, tread.depth / 2)
      .setTranslation(tread.x, tread.baseY + tread.blockHeight / 2, tread.z));
    staticIds.set(collider.handle, tread.id); supportIds.add(collider.handle); stairSupportIds.add(collider.handle);
    supportColliderIds.set(tread.surfaceId, collider.handle);
  }
  if (arrival) {
    // This overhead occluder is solid in 3D but leaves the shared ground route
    // open. Treating it as a ground footprint would create an invisible wall.
    const canopy = arrival.canopy;
    const collider = world.createCollider(RAPIER.ColliderDesc.cuboid(canopy.width / 2, canopy.height / 2, canopy.depth / 2)
      .setTranslation(canopy.x, canopy.baseY + canopy.height / 2, canopy.z));
    staticIds.set(collider.handle, canopy.id);
  }
  const counterData = options.servingCounterRays;
  const counterFootprint = source.propFootprints.counter;
  // All-or-nothing binding prevents a custom source from losing a proxy at a
  // position or size that the immutable native mesh does not actually cover.
  const countersMatch = counterData && counterFootprint.width === 4.6 && counterFootprint.depth === 1.25
    && counterFootprint.height === 1.12 && counterData.instances.every(instance => {
      const props = source.props.filter(prop => prop.id === instance.id);
      const prop = props[0];
      return props.length === 1 && prop.kind === 'counter'
        && prop.x === instance.x && (prop.y ?? 0) === instance.y && prop.z === instance.z && prop.rotation === instance.rotation
        && !source.adventure?.furniture.some(furniture => furniture.id === instance.id)
        && !elevated.routes.some(route => route.propId === instance.id)
        && [...staticIds.values()].filter(id => id === instance.id).length === 1;
    });
  let counterRays = countersMatch ? createHyosanServingCounterRayQuery(counterData) : null;
  const onFloor = (point: GroundPoint, radius: number) => {
    const span = Math.abs(radius);
    const minX = point.x - span; const maxX = point.x + span;
    const minZ = point.z - span; const maxZ = point.z + span;
    if (floorIndex.some(minX, maxX, minZ, maxZ, (floor) =>
      minX >= floor.minX && maxX <= floor.maxX && minZ >= floor.minZ && maxZ <= floor.maxZ)) return true;
    // Door seams can span two floors. Preserve the original four-cardinal union
    // contract there instead of requiring containment in a single rectangle.
    let west = false; let east = false; let north = false; let south = false;
    return floorIndex.some(minX, maxX, minZ, maxZ, (floor) => {
      if (point.z >= floor.minZ && point.z <= floor.maxZ) {
        west ||= minX >= floor.minX && minX <= floor.maxX;
        east ||= maxX >= floor.minX && maxX <= floor.maxX;
      }
      if (point.x >= floor.minX && point.x <= floor.maxX) {
        north ||= minZ >= floor.minZ && minZ <= floor.maxZ;
        south ||= maxZ >= floor.minZ && maxZ <= floor.maxZ;
      }
      return west && east && north && south;
    });
  };
  const nearStair = (point: GroundPoint, radius = 0) => support.stairs.some((stair) =>
    point.x >= Math.min(stair.start.x, stair.end.x) - (stair.axis === 'z' ? stair.width / 2 : 0) - radius - .025
    && point.x <= Math.max(stair.start.x, stair.end.x) + (stair.axis === 'z' ? stair.width / 2 : 0) + radius + .025
    && point.z >= Math.min(stair.start.z, stair.end.z) - (stair.axis === 'x' ? stair.width / 2 : 0) - radius - .025
    && point.z <= Math.max(stair.start.z, stair.end.z) + (stair.axis === 'x' ? stair.width / 2 : 0) + radius + .025);
  const nearSupportRamp = (point: GroundPoint, radius = 0) => support.ramps.some((ramp) =>
    Math.abs(point.x - ramp.x) <= ramp.width / 2 + radius + .025 && Math.abs(point.z - ramp.z) <= ramp.depth / 2 + radius + .025);
  // Reject distant elevated regions before doing their exact support checks.
  // Padding only broadens the search; authored edges still decide below.
  const surfaceBounds = createHyosanGroundIndex([
    ...support.stairs.map((stair) => ({ minX: Math.min(stair.start.x, stair.end.x) - stair.width / 2 - .026,
      maxX: Math.max(stair.start.x, stair.end.x) + stair.width / 2 + .026,
      minZ: Math.min(stair.start.z, stair.end.z) - stair.width / 2 - .026,
      maxZ: Math.max(stair.start.z, stair.end.z) + stair.width / 2 + .026 })),
    ...support.ramps.map((ramp) => ({ minX: ramp.x - ramp.width / 2 - .026, maxX: ramp.x + ramp.width / 2 + .026,
      minZ: ramp.z - ramp.depth / 2 - .026, maxZ: ramp.z + ramp.depth / 2 + .026 })),
    ...source.floors.filter((floor) => (floor.y ?? 0) !== 0).map((floor) => ({
      minX: floor.x - floor.width / 2 - .001, maxX: floor.x + floor.width / 2 + .001,
      minZ: floor.z - floor.depth / 2 - .001, maxZ: floor.z + floor.depth / 2 + .001 })),
  ]);
  const anyBound = () => true;
  const needsSurface = (point: GroundPoint, radius = 0) =>
    surfaceBounds.some(point.x - Math.abs(radius), point.x + Math.abs(radius), point.z - Math.abs(radius), point.z + Math.abs(radius), anyBound)
    && (nearStair(point, radius) || nearSupportRamp(point, radius) || source.floors.some((floor) =>
      (floor.y ?? 0) !== 0 && Math.abs(point.x - floor.x) <= floor.width / 2 + radius && Math.abs(point.z - floor.z) <= floor.depth / 2 + radius));
  const heightAt = (point: GroundPoint) => needsSurface(point) ? support.sample(point)?.height ?? null
    : onFloor(point, 0) ? elevated.sample(point)?.height ?? 0 : null;
  const identity = { x: 0, y: 0, z: 0, w: 1 };
  const shapes = new Map<number, RAPIER.Capsule>();
  const capsule = (radius: number) => {
    let shape = shapes.get(radius);
    if (!shape) { shape = new RAPIER.Capsule(.55, radius); shapes.set(radius, shape); }
    return shape;
  };
  const elevatedBounds = [...elevated.routes.map(({ deck }) => deck), ...elevated.ramps];
  const nearElevated = (point: GroundPoint, radius: number) => elevatedBounds.some((rect) =>
    Math.abs(point.x - rect.x) <= rect.width / 2 + radius + .025 && Math.abs(point.z - rect.z) <= rect.depth / 2 + radius + .025);
  const highest = Math.max(0, ...elevated.routes.map(({ deck }) => deck.height));
  const leavesRaisedEdge = (from: GroundPoint, to: GroundPoint) => {
    const before = elevated.sample(from)?.height ?? 0;
    const after = elevated.sample(to)?.height ?? 0;
    return before > after + 1e-5 && !elevated.continuous(from, to);
  };
  const supportedTarget = (from: GroundPoint, to: GroundPoint, slide: boolean) => {
    if (!leavesRaisedEdge(from, to)) return to;
    const dx = to.x - from.x; const dz = to.z - from.z;
    let low = 0; let high = 1;
    for (let iteration = 0; iteration < 14; iteration++) {
      const middle = (low + high) / 2;
      const sample = { x: from.x + dx * middle, z: from.z + dz * middle };
      if (leavesRaisedEdge(from, sample)) high = middle; else low = middle;
    }
    // A tenth of a millimetre keeps float32 contact nudges on the actual
    // support edge. It does not create a capsule-radius invisible ledge.
    const fraction = Math.max(0, low - .0001 / Math.max(.0001, Math.hypot(dx, dz)));
    let safe = { x: from.x + dx * fraction, z: from.z + dz * fraction };
    if (slide) {
      for (const tangent of [{ x: to.x, z: safe.z }, { x: safe.x, z: to.z }]) {
        if (!elevated.continuous(from, tangent)) continue;
        if (Math.hypot(tangent.x - to.x, tangent.z - to.z) < Math.hypot(safe.x - to.x, safe.z - to.z)) safe = tangent;
      }
    }
    return safe;
  };
  // A downward capsule cast includes the rounded foot's real contact with a
  // ramp or deck edge. Sampling only the centre would place it inside slopes.
  const standingHeight = (point: GroundPoint, radius: number): number => {
    if (!nearElevated(point, radius)) return .02;
    const onRoute = elevated.sample(point) !== null;
    // A ground capsule beside a deck must not inherit the topmost contact of
    // a cast from above. Only a ramp's low entrance can lift it before its
    // centre reaches the authored route; deck and ramp sides remain walls.
    const lowApproach = (ramp: typeof elevated.ramps[number]) => {
      const along = ramp.axis === 'z' ? point.z - ramp.z : point.x - ramp.x;
      const across = ramp.axis === 'z' ? point.x - ramp.x : point.z - ramp.z;
      const halfLength = (ramp.axis === 'z' ? ramp.depth : ramp.width) / 2;
      const halfWidth = (ramp.axis === 'z' ? ramp.width : ramp.depth) / 2;
      const lowDistance = (ramp.lowAt === 'min' ? -along : along) - halfLength;
      return Math.abs(across) <= halfWidth && lowDistance >= 0 && lowDistance <= radius + .025;
    };
    if (!onRoute && !elevated.ramps.some(lowApproach)) return .02;
    const origin = { x: point.x, y: highest + .2 + .55 + radius, z: point.z };
    const hit = world.castShape(origin, identity, { x: 0, y: -1, z: 0 }, capsule(radius), .016,
      highest + .3, true, undefined, undefined, undefined, undefined, (collider) => {
        if (onRoute) return supportIds.has(collider.handle);
        const ramp = rampSupports.get(collider.handle);
        return floorSupportIds.has(collider.handle) || ramp !== undefined && lowApproach(ramp);
      });
    return hit ? highest + .2 - hit.time_of_impact : NaN;
  };
  const capsuleClear = (point: ActorPoint, radius: number) => {
    const position = { x: point.x, y: point.y + .55 + radius, z: point.z };
    let clear = true;
    world.intersectionsWithShape(position, identity, capsule(radius), (collider) => {
      const contact = collider.contactShape(capsule(radius), position, identity, 0);
      if (contact && contact.distance < -.001) { clear = false; return false; }
      return true;
    }, undefined, undefined, undefined, undefined, (collider) => staticIds.has(collider.handle));
    return clear;
  };
  const surfaceById = new Map(support.surfaces.map((surface) => [surface.surfaceId, surface]));
  const stairById = new Map(support.stairs.map((stair) => [stair.id, stair]));
  const rampById = new Map(support.ramps.map((ramp) => [ramp.id, ramp]));
  const stairsBySurface = new Map(support.surfaces.map((surface) => [surface.surfaceId,
    support.stairs.filter((stair) => stair.id === surface.stairId || stair.fromFloorId === surface.surfaceId || stair.toFloorId === surface.surfaceId)]));
  const rampsBySurface = new Map(support.surfaces.map((surface) => [surface.surfaceId,
    support.ramps.filter((ramp) => ramp.id === surface.rampId || ramp.fromFloorId === surface.surfaceId || ramp.toFloorId === surface.surfaceId)]));
  const standingSurface = (point: GroundPoint, radius: number, sampled = support.sample(point)): number => {
    if (!sampled) return NaN;
    const nearby = stairsBySurface.get(sampled.surfaceId)!.filter((stair) => stair.id === sampled.stairId || nearStair(point, radius));
    const ramps = rampsBySurface.get(sampled.surfaceId)!.filter((ramp) => ramp.id === sampled.rampId || nearSupportRamp(point, radius));
    if (!nearby.length && !ramps.length) return sampled.height + .02;
    const accepted = new Set<number>();
    const own = supportColliderIds.get(sampled.surfaceId); if (own !== undefined) accepted.add(own);
    let top = sampled.height; let bottom = sampled.height;
    for (const stair of nearby) {
      for (const id of [stair.fromFloorId, stair.toFloorId, ...stair.treads.map((tread) => tread.surfaceId)]) {
        const handle = supportColliderIds.get(id); if (handle !== undefined) accepted.add(handle);
      }
      top = Math.max(top, stair.start.y, stair.end.y); bottom = Math.min(bottom, stair.start.y, stair.end.y);
    }
    for (const ramp of ramps) {
      for (const id of [ramp.id, ramp.fromFloorId, ramp.toFloorId]) {
        const handle = supportColliderIds.get(id); if (handle !== undefined) accepted.add(handle);
      }
      top = Math.max(top, ramp.start.y, ramp.end.y); bottom = Math.min(bottom, ramp.start.y, ramp.end.y);
    }
    const hit = world.castShape({ x: point.x, y: top + .2 + .55 + radius, z: point.z }, identity,
      { x: 0, y: -1, z: 0 }, capsule(radius), .016, top - bottom + .3, true,
      undefined, undefined, undefined, undefined, (collider) => accepted.has(collider.handle));
    return hit ? top + .2 - hit.time_of_impact : NaN;
  };
  const canStandSurface = (point: GroundPoint, radius: number, sampled = support.sample(point), sampledHeight?: number): boolean => {
    if (!Number.isFinite(radius) || radius < 0 || !onFloor(point, radius)) return false;
    if (!sampled) return false;
    if (point.y !== undefined && (!Number.isFinite(point.y) || point.y < sampled.height - .002)) return false;
    if (point.y === undefined && sampled.stairId) {
      const stair = stairById.get(sampled.stairId)!;
      const across = stair.axis === 'z' ? point.x - stair.start.x : point.z - stair.start.z;
      if (Math.abs(across) > stair.width / 2 - radius - .02) return false;
    }
    const expected = sampledHeight ?? standingSurface(point, radius, sampled);
    const y = point.y === undefined || Math.abs(point.y - sampled.height) < .002 ? expected : point.y;
    return Number.isFinite(y) && Math.abs(y - expected) <= .085 && capsuleClear({ ...point, y }, radius);
  };
  const supportsConnect = (a: HyosanSupportSample, b: HyosanSupportSample, from: GroundPoint, to: GroundPoint) => {
    if (a.surfaceId === b.surfaceId) return true;
    if (a.currentLayerId !== b.currentLayerId) return support.transitionPlanes.some((plane) => {
      if (!(a.surfaceId === plane.fromFloorId && b.surfaceId === plane.toFloorId
        || a.surfaceId === plane.toFloorId && b.surfaceId === plane.fromFloorId)) return false;
      const along = plane.axis === 'x' ? 'z' : 'x';
      const delta = to[plane.axis] - from[plane.axis];
      if (Math.abs(delta) < 1e-10) return false;
      const t = (plane.coordinate - from[plane.axis]) / delta;
      const span = from[along] + (to[along] - from[along]) * t;
      return t >= -1e-7 && t <= 1 + 1e-7 && span >= plane.min && span <= plane.max;
    });
    if (a.stairId && a.stairId === b.stairId) return Math.abs(a.stepIndex! - b.stepIndex!) <= 1;
    for (const [step, floor] of [[a, b], [b, a]]) if (step.stairId) {
      const stair = stairById.get(step.stairId)!;
      if (step.stepIndex === 0 && floor.surfaceId === stair.fromFloorId
        || step.stepIndex === stair.steps - 1 && floor.surfaceId === stair.toFloorId) return true;
    }
    if (a.stairId || b.stairId) return false;
    for (const [slope, floor] of [[a, b], [b, a]]) if (slope.rampId) {
      const ramp = rampById.get(slope.rampId)!;
      const endpoint = floor.surfaceId === ramp.fromFloorId ? ramp.start : floor.surfaceId === ramp.toFloorId ? ramp.end : null;
      if (!endpoint) continue;
      const delta = to[ramp.axis] - from[ramp.axis];
      if (Math.abs(delta) < 1e-10) continue;
      const t = (endpoint[ramp.axis] - from[ramp.axis]) / delta;
      const across = ramp.axis === 'x' ? 'z' : 'x';
      const span = from[across] + (to[across] - from[across]) * t;
      if (t >= -1e-7 && t <= 1 + 1e-7 && Math.abs(span - endpoint[across]) <= ramp.pathWidth / 2 + 1e-8) return true;
    }
    if (a.rampId || b.rampId) return false;
    const left = surfaceById.get(a.surfaceId)!; const right = surfaceById.get(b.surfaceId)!;
    if (Math.abs(left.x - right.x) > (left.width + right.width) / 2 + 1e-7
      || Math.abs(left.z - right.z) > (left.depth + right.depth) / 2 + 1e-7) return false;
    return Math.abs(a.height - b.height) < 1e-5 || (a.kind === 'ramp' || b.kind === 'ramp') && elevated.continuous(from, to);
  };
  const canStandSampled = (point: GroundPoint, radius: number, sampled: HyosanSupportSample, sampledHeight?: number) =>
    needsSurface(point, Math.abs(radius)) ? canStandSurface(point, radius, sampled, sampledHeight) : canStand(point, radius);
  const traceSurface = (from: GroundPoint, to: GroundPoint, radius: number, verify: boolean): boolean => {
    const initial = support.sample(from); if (!initial) return false;
    const endpoint = to.y !== undefined || to.surfaceId !== undefined || to.currentLayerId !== undefined ? support.sample(to) : null;
    // A straight segment between distinct layers must cross an authored portal.
    // Reject impossible shortcuts before sampling hundreds of capsules below a
    // raised target. A possible crossing still receives the complete trace.
    if (endpoint && initial.currentLayerId !== endpoint.currentLayerId && !support.transitionPlanes.some((plane) => {
      if (plane.fromLayerId !== initial.currentLayerId && plane.toLayerId !== initial.currentLayerId) return false;
      const delta = to[plane.axis] - from[plane.axis];
      if (Math.abs(delta) < 1e-10) return false;
      const t = (plane.coordinate - from[plane.axis]) / delta;
      const across = plane.axis === 'x' ? 'z' : 'x';
      const span = from[across] + (to[across] - from[across]) * t;
      return t >= -1e-7 && t <= 1 + 1e-7 && span >= plane.min - 1e-7 && span <= plane.max + 1e-7;
    })) return false;
    if (verify && !canStandSampled(from, radius, initial)) return false;
    const distance = Math.hypot(to.x - from.x, to.z - from.z);
    if (distance < 1e-10) {
      // Navigation validates a node with the exact same endpoint. Keep distinct
      // height/layer/surface hints separate even when X/Z coincide.
      const identical = from === to || from.x === to.x && from.z === to.z && from.y === to.y
        && from.surfaceId === to.surfaceId && from.currentLayerId === to.currentLayerId;
      return !verify || (identical || canStand(to, radius))
        && Math.abs((to.y ?? initial.height) - (from.y ?? initial.height)) < .085;
    }
    const count = Math.max(1, Math.ceil(distance / .08));
    let previous = initial; let previousPoint = from;
    for (let index = 1; index <= count; index++) {
      const point = { x: from.x + (to.x - from.x) * index / count, z: from.z + (to.z - from.z) * index / count };
      const candidates = support.candidates(point).filter((sample) => supportsConnect(previous, sample, previousPoint, point));
      const explicitEndpoint = index === count && (to.y !== undefined || to.surfaceId !== undefined || to.currentLayerId !== undefined);
      let checked = false;
      const chosen = explicitEndpoint ? support.sample(to) : candidates.sort((a, b) => Math.abs(a.height - previous.height) - Math.abs(b.height - previous.height))
        .find((sample) => {
          if (!verify) return true;
          const y = standingSurface(point, radius, sample);
          const at = { ...point, y, surfaceId: sample.surfaceId };
          // A floor can project beneath a solid ramp. Prefer the connected
          // support the actual capsule can occupy, rather than that lower slab.
          const valid = canStandSampled(at, radius, sample, y);
          checked = valid; return valid;
        });
      if (!chosen || !candidates.some((sample) => sample.surfaceId === chosen.surfaceId)) return false;
      if (verify && !checked) {
        const endpoint = index === count ? to : { ...point, y: standingSurface(point, radius, chosen), surfaceId: chosen.surfaceId };
        if (!canStandSampled(endpoint, radius, chosen)) return false;
      }
      previous = chosen; previousPoint = point;
    }
    return true;
  };
  const clearSurface = (from: GroundPoint, to: GroundPoint, radius: number) => traceSurface(from, to, radius, true);
  const surfaceMetadata = (point: ActorPoint): ActorPoint => {
    const sample = support.sample({ x: point.x, y: point.y, z: point.z });
    return sample ? { ...point, surfaceId: sample.surfaceId, currentLayerId: sample.currentLayerId } : point;
  };
  const canStand = (point: GroundPoint, radius = 0.32, sampledSupport?: number): boolean => {
    if (needsSurface(point, Math.abs(radius))) return canStandSurface(point, radius);
    if (!onFloor(point, radius)) return false;
    const surface = heightAt(point);
    if (point.y !== undefined && (!Number.isFinite(point.y) || surface === null || point.y < surface - .002)) return false;
    const raised = nearElevated(point, Math.abs(radius));
    if (raised || (point.y ?? 0) > .08) {
      if (!Number.isFinite(radius) || radius < 0) return false;
      const expected = sampledSupport ?? standingHeight(point, radius);
      const sample = elevated.sample(point);
      if (point.y === undefined && sample?.kind === 'ramp') {
        const ramp = elevated.ramps.find((entry) => entry.routeId === sample.routeId
          && Math.abs(point.x - entry.x) <= entry.width / 2 && Math.abs(point.z - entry.z) <= entry.depth / 2)!;
        if (ramp && (ramp.axis === 'z' ? Math.abs(point.x - ramp.x) > ramp.width / 2 - radius - .02
          : Math.abs(point.z - ramp.z) > ramp.depth / 2 - radius - .02)) return false;
      }
      const y = point.y === undefined || Math.abs(point.y - (surface ?? 0)) < .002 ? expected : point.y;
      return Number.isFinite(y) && Math.abs(y - expected) <= .085 && capsuleClear({ ...point, y }, radius);
    }
    // The broad phase is conservative. Exact circle/OBB distance still decides
    // tangency and corners, for every requested radius.
    const minX = point.x - radius - 1e-9; const maxX = point.x + radius + 1e-9;
    const minZ = point.z - radius - 1e-9; const maxZ = point.z + radius + 1e-9;
    if (obstacleIndexRevision !== revision) {
      obstacleIndex = createHyosanGroundIndex(obstacles); obstacleIndexRevision = revision;
    }
    return !obstacleIndex.some(minX, maxX, minZ, maxZ, (obstacle) => {
      if (shortcutOpen && obstacle.id === source.adventure?.shortcut.id) return false;
      if ((point.y ?? 0) >= obstacle.y + obstacle.height || (point.y ?? 0) + 1.1 + radius * 2 <= obstacle.y) return false;
      return obstacleDistance(point, obstacle) < radius;
    });
  };
  const clearGround = (from: GroundPoint, to: GroundPoint, radius = 0.34): boolean => {
    if (needsSurface(from, radius) || needsSurface(to, radius) || [...support.stairs, ...support.ramps].some((stair) =>
      Math.max(from.x, to.x) + radius >= Math.min(stair.start.x, stair.end.x) - stair.width / 2
      && Math.min(from.x, to.x) - radius <= Math.max(stair.start.x, stair.end.x) + stair.width / 2
      && Math.max(from.z, to.z) + radius >= Math.min(stair.start.z, stair.end.z) - stair.width / 2
      && Math.min(from.z, to.z) - radius <= Math.max(stair.start.z, stair.end.z) + stair.width / 2)) return clearSurface(from, to, radius);
    const raised = elevatedBounds.some((rect) => Math.max(from.x, to.x) + radius >= rect.x - rect.width / 2
      && Math.min(from.x, to.x) - radius <= rect.x + rect.width / 2
      && Math.max(from.z, to.z) + radius >= rect.z - rect.depth / 2
      && Math.min(from.z, to.z) - radius <= rect.z + rect.depth / 2);
    if (raised && !elevated.continuous(from, to)) return false;
    const distance = Math.hypot(to.x - from.x, to.z - from.z);
    const count = Math.max(1, Math.ceil(distance / (raised ? .08 : .15)));
    const point = { x: from.x, z: from.z };
    let previousHeight: number | undefined;
    let fromSupport: number | undefined;
    let toSupport: number | undefined;
    for (let i = 0; i <= count; i += 1) {
      point.x = from.x + (to.x - from.x) * i / count;
      point.z = from.z + (to.z - from.z) * i / count;
      // Grid endpoints retain the safe ramp-width margin. Between them, or
      // while leaving an actual legal edge contact, validate the real capsule
      // support instead: applying node padding to every interior sample would
      // strand an actor pushed outside that padding during combat.
      // Reuse only this query's exact sample; an interpolated endpoint can
      // differ from the supplied coordinate by a floating-point rounding bit.
      const sampledHeight = raised ? i === count && distance === 0 ? fromSupport : standingHeight(point, radius) : undefined;
      if (i === 0 && point.x === from.x && point.z === from.z) fromSupport = sampledHeight;
      if (i === count && point.x === to.x && point.z === to.z) toSupport = sampledHeight;
      const actualY = i === 0 ? from.y : i === count ? to.y : sampledHeight;
      if (!canStand(actualY === undefined ? point : { ...point, y: actualY }, radius, sampledHeight)) return false;
      if (raised) {
        const y = sampledHeight!;
        if (previousHeight !== undefined && Math.abs(y - previousHeight) > distance / count * Math.tan(Math.PI * 35 / 180) + .003) return false;
        previousHeight = y;
      }
    }
    if (from.y !== undefined && Math.abs(from.y - (fromSupport ?? standingHeight(from, radius))) > .085) return false;
    if (to.y !== undefined && Math.abs(to.y - (toSupport ?? standingHeight(to, radius))) > .085) return false;
    return true;
  };
  const computeMovement = (collider: RAPIER.Collider, translation: { x: number; y: number; z: number }, slide: boolean, stairsAllowed = false) => {
    const { x, y, z } = translation;
    const run = Math.hypot(x, z);
    // Rapier's slide switch also blocks floor contact. A capsule returning
    // from a ramp can sit just inside the 15mm contact margin, so both flat
    // and elevated movement must stop only at non-walkable contact normals.
    controller.setSlideEnabled(true);
    controller.computeColliderMovement(collider, translation, undefined, undefined,
      (candidate) => staticIds.has(candidate.handle));
    if (!slide && run > 0) {
      let allowed = run;
      for (let index = 0; index < controller.numComputedCollisions(); index++) {
        const collision = controller.computedCollision(index);
        if (!collision || collision.normal1.y >= Math.cos(Math.PI * 35 / 180)
          || stairsAllowed && collision.collider && (stairSupportIds.has(collision.collider.handle)
            || stairLandingIds.has(collision.collider.handle))) continue;
        const applied = collision.translationDeltaApplied;
        allowed = Math.min(allowed, Math.max(0, (applied.x * x + applied.z * z) / run));
      }
      if (allowed < run) {
        const fraction = allowed / run;
        controller.computeColliderMovement(collider, { x: x * fraction, y: y * fraction, z: z * fraction }, undefined, undefined,
          (candidate) => staticIds.has(candidate.handle));
      }
    }
    return controller.computedMovement();
  };
  world.step();
  return {
    canStand: (point: GroundPoint, radius = .32) => canStand(point, radius),
    clearGround,
    heightAt,
    revision: () => revision,
    /** Bounded invalidation history. A missed/unknown revision requires a full rebuild. */
    changesSince(since: number): readonly GroundBounds[] | null {
      if (!Number.isInteger(since) || since < 0 || since > revision || revision - since > changes.length) return null;
      return changes.filter((change) => change.revision > since).flatMap((change) => change.bounds.map((bounds) => ({ ...bounds })));
    },
    /** Horizontal authored movement: reject a height change or a body in the swept footprint. */
    trySetPropPose(id: string, pose: Hyosan3DPropPose) {
      const collider = propColliders.get(id);
      const obstacle = obstacles.find((entry) => entry.id === id);
      if (!collider || !obstacle) throw new Error(`Unknown Hyosan prop ${id}`);
      if (![pose.x, pose.z, pose.rotation].every(Number.isFinite)
        || pose.y !== undefined && pose.y !== obstacle.y) return false;
      if (obstacle.x === pose.x && obstacle.z === pose.z && obstacle.rotation === pose.rotation) return true;
      const travel = Math.hypot(pose.x - obstacle.x, pose.z - obstacle.z)
        + Math.abs(pose.rotation - obstacle.rotation) * Math.hypot(obstacle.width, obstacle.depth) / 2;
      let sampleDistance = .04;
      const occupants = [...actors.values()].filter((actor) => {
        const centre = actor.translation().y; const halfHeight = .55 + actor.radius();
        return centre + halfHeight > obstacle.y && centre - halfHeight < obstacle.y + obstacle.height;
      }).map((actor) => {
        const point = actor.translation();
        return { point, radius: actor.radius(), previous: obstacleDistance(point, obstacle) };
      });
      for (const occupant of occupants) {
        if (occupant.previous >= occupant.radius + .035) continue;
        const clearance = occupant.previous - occupant.radius;
        if (clearance <= 0) return false;
        // The KCC rests 15mm from furniture, inside the 35mm waiting margin.
        // Parallel/retreating motion is safe only if every sample preserves
        // clearance and no corner can travel farther than half the initial gap.
        sampleDistance = Math.min(sampleDistance, clearance / 2);
      }
      const steps = Math.max(1, Math.ceil(travel / sampleDistance));
      if (steps > 1024) return false;
      const bounds = groundBounds(obstacle);
      for (let index = 1; index <= steps; index++) {
        const t = index / steps;
        const swept = { ...obstacle, x: obstacle.x + (pose.x - obstacle.x) * t,
          z: obstacle.z + (pose.z - obstacle.z) * t, rotation: obstacle.rotation + (pose.rotation - obstacle.rotation) * t };
        Object.assign(swept, queryGeometry(swept));
        const sample = groundBounds(swept);
        bounds.minX = Math.min(bounds.minX, sample.minX); bounds.maxX = Math.max(bounds.maxX, sample.maxX);
        bounds.minZ = Math.min(bounds.minZ, sample.minZ); bounds.maxZ = Math.max(bounds.maxZ, sample.maxZ);
        for (const occupant of occupants) {
          const distance = obstacleDistance(occupant.point, swept);
          if (distance < occupant.radius + .035 && distance < occupant.previous - 1e-9) return false;
          occupant.previous = distance;
        }
      }
      collider.setTranslation({ x: pose.x, y: obstacle.y + obstacle.height / 2, z: pose.z });
      collider.setRotation({ x: 0, y: Math.sin(pose.rotation / 2), z: 0, w: Math.cos(pose.rotation / 2) });
      const accepted = { x: pose.x, z: pose.z, rotation: pose.rotation };
      Object.assign(obstacle, accepted, queryGeometry({ ...obstacle, ...accepted }));
      // The native extraction is a static snapshot. An accepted authoring move
      // retains the existing mutation contract and restores both cuboid rays.
      if (counterRays?.replacesGeometry(id)) counterRays = null;
      changed([bounds]); world.step();
      return true;
    },
    setEntranceOpen(progress: number) {
      if (!entrance || !Number.isFinite(progress)) return false;
      const next = Math.max(0, Math.min(1, progress));
      if (next === entranceProgress) return true;
      // Bound the outermost corner's hinge arc, including the centre seal.
      // Both leaves commit together only after the complete sweep is clear.
      const travel = Math.abs(next - entranceProgress) * Math.PI / 2 * (entrance.width / 2 + entrance.depth);
      let sampleDistance = .04;
      const occupants = [...actors.values()].filter((actor) => {
        const centre = actor.translation().y; const halfHeight = .55 + actor.radius();
        return centre + halfHeight > 0 && centre - halfHeight < entrance.height;
      }).map((actor) => {
        const point = actor.translation();
        return { point, radius: actor.radius(), previous: entranceLeaves.map((leaf) => obstacleDistance(point, leaf)) };
      });
      for (const occupant of occupants) for (const distance of occupant.previous) {
        if (distance >= occupant.radius + .035) continue;
        const clearance = distance - occupant.radius;
        if (clearance <= 0) return false;
        // Rapier's 15mm contact gap is smaller than the 35mm waiting margin.
        // Allow a leaf to retreat from that contact, but bound each substep by
        // half the actual gap so it cannot cross the capsule between samples.
        sampleDistance = Math.min(sampleDistance, clearance / 2);
      }
      const steps = Math.max(1, Math.ceil(travel / sampleDistance));
      // Submillimetre authored gaps must not turn a request into an unbounded
      // physics stall. Wait for more clearance rather than weakening the sweep.
      if (steps > 1024) return false;
      const bounds = entranceLeaves.map(groundBounds);
      for (let index = 1; index <= steps; index++) {
        const sampleProgress = entranceProgress + (next - entranceProgress) * index / steps;
        for (const [side, leaf] of hyosanCafeteriaDoorLeaves(entrance, sampleProgress).entries()) {
          const swept = Object.assign(leaf, queryGeometry(leaf));
          bounds[side].minX = Math.min(bounds[side].minX, swept.minX);
          bounds[side].maxX = Math.max(bounds[side].maxX, swept.maxX);
          bounds[side].minZ = Math.min(bounds[side].minZ, swept.minZ);
          bounds[side].maxZ = Math.max(bounds[side].maxZ, swept.maxZ);
          for (const occupant of occupants) {
            const distance = obstacleDistance(occupant.point, swept);
            if (distance < occupant.radius + .035 && distance < occupant.previous[side] - 1e-9) return false;
            occupant.previous[side] = distance;
          }
        }
      }
      for (const leaf of hyosanCafeteriaDoorLeaves(entrance, next)) {
        const collider = entranceColliders.get(leaf.id)!;
        collider.setTranslation({ x: leaf.x, y: leaf.height / 2, z: leaf.z });
        collider.setRotation({ x: 0, y: Math.sin(leaf.rotation / 2), z: 0, w: Math.cos(leaf.rotation / 2) });
        Object.assign(entranceLeaves.find((entry) => entry.id === leaf.id)!, leaf, queryGeometry(leaf));
      }
      entranceProgress = next; changed(bounds); world.step();
      return true;
    },
    setShortcutOpen(open: boolean) {
      const gate = source.adventure?.shortcut;
      if (!gate || shortcutOpen === open) return;
      if (shortcutCollider) { staticIds.delete(shortcutCollider.handle); world.removeCollider(shortcutCollider, false); shortcutCollider = null; }
      if (!open) {
        shortcutCollider = world.createCollider(RAPIER.ColliderDesc.cuboid(gate.width / 2, gate.height / 2, gate.depth / 2)
          .setTranslation(gate.x, gate.height / 2, gate.z));
        staticIds.set(shortcutCollider.handle, gate.id);
      }
      shortcutOpen = open; changed([groundBounds({ ...gate, rotation: 0 })]); world.step();
    },
    lineOfSight(from: GroundPoint, to: GroundPoint, ignoreGeometry?: string, height = 1.25) {
      const fromY = (from.y ?? heightAt(from) ?? 0) + height;
      const toY = (to.y ?? heightAt(to) ?? 0) + height;
      const length = Math.hypot(to.x - from.x, toY - fromY, to.z - from.z);
      if (length < 0.001) return true;
      const origin = { x: from.x, y: fromY, z: from.z };
      const direction = { x: (to.x - from.x) / length, y: (toY - fromY) / length, z: (to.z - from.z) / length };
      const hit = world.castRay(new RAPIER.Ray(origin, direction), length, true,
      undefined, undefined, undefined, undefined,
      (collider) => staticIds.has(collider.handle) && staticIds.get(collider.handle) !== ignoreGeometry
        && !counterRays?.replacesGeometry(staticIds.get(collider.handle)));
      const other = hit ? { distance: hit.timeOfImpact, actorId: null, geometryId: staticIds.get(hit.collider.handle) ?? null } : null;
      return !(counterRays ? counterRays.cast(origin, direction, length, other, ignoreGeometry) : other);
    },
    addActor(id: string, point: GroundPoint, radius = 0.32) {
      if (!canStand(point, radius)) throw new Error(`Hyosan 3D actor ${id} overlaps authored geometry`);
      const surface = heightAt(point) ?? 0;
      const y = point.y === undefined || Math.abs(point.y - surface) < .002
        ? needsSurface(point, radius) ? standingSurface(point, radius) : standingHeight(point, radius) : point.y;
      const collider = world.createCollider(RAPIER.ColliderDesc.capsule(0.55, radius)
        .setTranslation(point.x, 0.55 + radius + y, point.z));
      actors.set(id, collider);
      actorIds.set(collider.handle, id);
      return surfaceMetadata({ x: point.x, y, z: point.z });
    },
    removeActor(id: string) {
      const collider = actors.get(id);
      if (!collider) return;
      actorIds.delete(collider.handle);
      actors.delete(id);
      world.removeCollider(collider, false);
    },
    moveActor(id: string, dx: number, dz: number, options: { slide?: boolean } = {}): ActorPoint {
      if (![dx, dz].every(Number.isFinite)) throw new TypeError('Hyosan actor movement must be finite');
      const collider = actors.get(id)!;
      const radius = collider.radius();
      const initial = collider.translation();
      const distance = Math.hypot(dx, dz);
      const steps = nearElevated(initial, radius + distance) || nearStair(initial, radius + distance) || nearSupportRamp(initial, radius + distance)
        ? Math.max(1, Math.ceil(distance / .03)) : 1;
      let result = { x: initial.x, y: initial.y - .55 - radius, z: initial.z };
      for (let step = 0; step < steps; step++) {
        const current = collider.translation();
        const feet = current.y - .55 - radius;
        const stepX = dx / steps; const stepZ = dz / steps;
        const target = { x: current.x + stepX, z: current.z + stepZ };
        const actual = { x: current.x, y: feet, z: current.z };
        if (needsSurface(actual, radius) || needsSurface(target, radius)) {
          let x = stepX; let z = stepZ;
          if (!traceSurface(actual, target, radius, false)) {
            let low = 0; let high = 1;
            for (let iteration = 0; iteration < 14; iteration++) {
              const t = (low + high) / 2;
              if (traceSurface(actual, { x: current.x + stepX * t, z: current.z + stepZ * t }, radius, false)) low = t; else high = t;
            }
            x *= Math.max(0, low - .0001 / Math.max(.0001, Math.hypot(x, z)));
            z *= Math.max(0, low - .0001 / Math.max(.0001, Math.hypot(stepX, stepZ)));
          }
          const stair = nearStair(actual, radius + Math.hypot(x, z));
          if (stair) { controller.enableAutostep(.18, .15, false); controller.enableSnapToGround(.22); }
          else { controller.disableAutostep(); controller.enableSnapToGround(.12); }
          const compute = (x: number, z: number, slide: boolean) => {
            let y = 0;
            if (!stair && nearSupportRamp(actual, radius + Math.hypot(x, z)) && (x || z)) {
              const sampled = support.sample(actual);
              const target = { x: current.x + x, y: (sampled?.height ?? feet) + x * (sampled?.slopeX ?? 0) + z * (sampled?.slopeZ ?? 0), z: current.z + z };
              const before = standingSurface(actual, radius, sampled);
              const after = standingSurface(target, radius);
              if (Math.abs(after - before) <= Math.hypot(x, z) * Math.tan(Math.PI * 35 / 180) + .003
                && Math.abs(feet - before) < .09 && traceSurface(actual, target, radius, false)) y = after - feet;
            }
            return computeMovement(collider, { x, y, z }, slide, stair);
          };
          const correction = compute(x, z, options.slide ?? true);
          let next = { x: current.x + correction.x, y: current.y + correction.y, z: current.z + correction.z };
          const supported = (candidate: { x: number; y: number; z: number }) =>
            onFloor({ x: candidate.x, y: candidate.y - .55 - radius, z: candidate.z }, radius)
            && traceSurface(actual, { x: candidate.x, z: candidate.z }, radius, false);
          if (!supported(next)) next = current;
          if (options.slide !== false && Math.hypot(next.x - current.x, next.z - current.z) < Math.hypot(stepX, stepZ) * .5) {
            // At concave landing edges, use a physical tangent just as the
            // ground controller does at walls; never push through a void.
            for (const [tx, tz] of [[stepX, 0], [0, stepZ]]) {
              if (!traceSurface(actual, { x: current.x + tx, z: current.z + tz }, radius, false)) continue;
              const move = compute(tx, tz, true);
              const tangent = { x: current.x + move.x, y: current.y + move.y, z: current.z + move.z };
              if (supported(tangent) && (tangent.x - current.x) * stepX + (tangent.z - current.z) * stepZ
                > (next.x - current.x) * stepX + (next.z - current.z) * stepZ) next = tangent;
            }
          }
          collider.setTranslation(next);
          result = { x: next.x, y: next.y - .55 - radius, z: next.z };
          controller.disableAutostep(); controller.enableSnapToGround(.12);
          continue;
        }
        if (feet < .08 && !nearElevated(current, radius) && !nearElevated(target, radius)) {
          // No extra gravity step on flat floors: preserve the settled height
          // without allowing its tiny contact residue to block a charge.
          const correction = computeMovement(collider, { x: stepX, y: 0, z: stepZ }, options.slide ?? true);
          let next = { x: current.x + correction.x, z: current.z + correction.z };
          if (!onFloor(next, radius)) next = options.slide === false ? current
            : onFloor({ x: next.x, z: current.z }, radius) ? { x: next.x, z: current.z }
            : onFloor({ x: current.x, z: next.z }, radius) ? { x: current.x, z: next.z } : current;
          collider.setTranslation({ x: next.x, y: current.y, z: next.z });
          result = { ...next, y: feet };
          continue;
        }
        const compute = (x: number, z: number) => {
          const target = supportedTarget(current, { x: current.x + x, z: current.z + z }, options.slide !== false);
          x = target.x - current.x; z = target.z - current.z;
          const currentSupport = standingHeight(current, radius);
          const targetSupport = standingHeight(target, radius);
          const run = Math.hypot(x, z);
          // Supply the tangent translation only across a continuous climbable
          // surface. A nearby tabletop's height must never lift a side approach.
          const continuous = Math.abs(targetSupport - currentSupport) <= run * Math.tan(Math.PI * 35 / 180) + .003
            && elevated.continuous(current, target)
            && (run <= .08 || clearGround({ x: current.x, y: feet, z: current.z }, target, radius));
          const y = continuous && Math.abs(feet - currentSupport) < .09 ? targetSupport - feet : 0;
          const correction = computeMovement(collider, { x, y, z }, options.slide ?? true);
          const corrected = { x: current.x + correction.x, z: current.z + correction.z };
          const accepted = supportedTarget(current, corrected, options.slide !== false);
          return { x: accepted.x, y: current.y + correction.y, z: accepted.z };
        };
        let next = compute(stepX, stepZ);
        if (!onFloor(next, radius)) {
          next = options.slide === false ? current
            : onFloor({ x: next.x, z: current.z }, radius) ? compute(stepX, 0)
            : onFloor({ x: current.x, z: next.z }, radius) ? compute(0, stepZ) : current;
        }
        collider.setTranslation(next);
        // Grounding is a separate vertical move: slide:false still stops a boss
        // at a wall without treating the ordinary floor contact as a wall.
        controller.setSlideEnabled(true);
        controller.computeColliderMovement(collider, { x: 0, y: -.025, z: 0 }, undefined, undefined,
          (candidate) => staticIds.has(candidate.handle));
        const grounding = controller.computedMovement();
        const settled = { x: next.x + grounding.x, y: next.y + grounding.y, z: next.z + grounding.z };
        const supported = supportedTarget(next, settled, false);
        next = { x: supported.x, y: settled.y, z: supported.z };
        collider.setTranslation(next);
        result = { x: next.x, y: next.y - .55 - radius, z: next.z };
      }
      return surfaceMetadata(result);
    },
    cast(from: GroundPoint, direction: GroundPoint, distance: number, ignoreActor?: string | ReadonlySet<string>, height = 1.25) {
      const origin = { x: from.x, y: from.y ?? height, z: from.z };
      const ray = { x: direction.x, y: direction.y ?? 0, z: direction.z };
      const hit = world.castRay(new RAPIER.Ray(origin, ray),
        distance, true, undefined, undefined, undefined, undefined,
        (collider) => {
          const actor = actorIds.get(collider.handle);
          return !counterRays?.replacesGeometry(staticIds.get(collider.handle))
            && (ignoreActor === undefined || !actor || (typeof ignoreActor === 'string' ? actor !== ignoreActor : !ignoreActor.has(actor)));
        });
      const other = hit ? { distance: hit.timeOfImpact, actorId: actorIds.get(hit.collider.handle) ?? null,
        geometryId: staticIds.get(hit.collider.handle) ?? null } : null;
      return counterRays ? counterRays.cast(origin, ray, distance, other) : other;
    },
    sync(dt = 1 / 60) { world.timestep = dt; world.step(); },
    dispose() { world.free(); },
  };
}
