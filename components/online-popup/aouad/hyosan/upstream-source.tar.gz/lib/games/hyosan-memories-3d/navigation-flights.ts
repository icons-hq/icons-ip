import type { HyosanSupportSample, HyosanSupportSource, HyosanSupportPoint } from './support-geometry';
import { hyosan3DRoomForFloor } from './rooms';

/** Keep stair/ramp destinations on their real landing, beyond the last tread. */
export function createHyosanNavigationFlights(source: HyosanSupportSource) {
  const flights = [...source.stairs ?? [], ...source.supportRamps ?? []];
  function crossing(id: string, exit: 'start' | 'end') {
    if (exit !== 'start' && exit !== 'end') return null;
    const flight = flights.find((flight) => flight.id === id);
    if (!flight) return null;
    const entry = exit === 'end' ? 'start' : 'end';
    const from = flight[entry]; const edge = flight[exit];
    const dx = edge.x - from.x; const dz = edge.z - from.z; const run = Math.hypot(dx, dz);
    const ux = dx / run; const uz = dz / run;
    const fromFloor = source.floors.find((floor) => floor.id === (entry === 'start' ? flight.fromFloorId : flight.toFloorId));
    const toFloor = source.floors.find((floor) => floor.id === (exit === 'start' ? flight.fromFloorId : flight.toFloorId));
    if (!fromFloor || !toFloor) return null;
    const to = { x: edge.x + ux * .8, y: edge.y, z: edge.z + uz * .8 };
    // Reject a broken authoring contract rather than invent a floating target.
    if (Math.abs(to.x - toFloor.x) > toFloor.width / 2 || Math.abs(to.z - toFloor.z) > toFloor.depth / 2) return null;
    const onFlight = (support: HyosanSupportSample | null) => support?.stairId === id || support?.rampId === id;
    const onLanding = (point: HyosanSupportPoint) => {
      const x = point.x - edge.x; const z = point.z - edge.z;
      const along = x * ux + z * uz; const across = -x * uz + z * ux;
      return Math.abs((point.y ?? edge.y) - edge.y) < .2 && along >= -.01 && along <= .81
        && Math.abs(across) <= Math.min(.5, flight.width / 2);
    };
    return { from: { ...from }, edge: { ...edge }, to, fromRoom: hyosan3DRoomForFloor(fromFloor), toRoom: hyosan3DRoomForFloor(toFloor),
      room: flight.roomId, onFlight, onLanding,
      allows(point: HyosanSupportPoint, support: HyosanSupportSample) {
        return onFlight(support) || support.surfaceId === toFloor.id && onLanding(point);
      } };
  }
  return { crossing };
}
