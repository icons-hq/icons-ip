/** Existing floors and the cafeteria tabletop belong to the same movement layer. */
export const HYOSAN_MAIN_LAYER = 'school-main';
export interface HyosanLayerPoint { currentLayerId?: string }

/** Height is not layer identity: a table remains attackable from its room floor. */
export function sameHyosanCombatLayer(a: HyosanLayerPoint, b: HyosanLayerPoint): boolean {
  return (a.currentLayerId ?? HYOSAN_MAIN_LAYER) === (b.currentLayerId ?? HYOSAN_MAIN_LAYER);
}

export interface HyosanCombatTransition {
  id: string; axis: 'x' | 'z'; coordinate: number; min: number; max: number;
  yMin: number; yMax: number; fromLayerId: string; toLayerId: string;
}
interface Position { x: number; y: number; z: number }

/** Only the authored landing opening ends a shot; this is not an infinite plane. */
export function hyosanLayerBoundaryHit(from: Position, direction: Position, travel: number,
  currentLayerId: string | undefined, transitions: readonly HyosanCombatTransition[]): { id: string; distance: number } | null {
  const layer = currentLayerId ?? HYOSAN_MAIN_LAYER;
  let nearest: { id: string; distance: number } | null = null;
  for (const transition of transitions) {
    if (layer !== transition.fromLayerId && layer !== transition.toLayerId) continue;
    const delta = direction[transition.axis];
    if (Math.abs(delta) < 1e-10) continue;
    // At the exact seam, firing back into the shooter's layer stays legal.
    if (layer === transition.fromLayerId ? delta < 0 : delta > 0) continue;
    const distance = (transition.coordinate - from[transition.axis]) / delta;
    if (distance < -1e-8 || distance > travel || nearest && distance >= nearest.distance) continue;
    const across = transition.axis === 'x' ? from.z + direction.z * distance : from.x + direction.x * distance;
    const height = from.y + direction.y * distance;
    if (across < transition.min || across > transition.max || height < transition.yMin || height > transition.yMax) continue;
    nearest = { id: transition.id, distance: Math.max(0, distance) };
  }
  return nearest;
}
