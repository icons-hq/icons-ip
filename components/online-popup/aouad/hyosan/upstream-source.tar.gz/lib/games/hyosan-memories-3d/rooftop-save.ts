import { HYOSAN_ROOFTOP_ROOMS } from './types';

export type HyosanRooftopRoom = typeof HYOSAN_ROOFTOP_ROOMS[number];
export interface RooftopSaveDTO {
  version: 1; worldVersion: string;
  anchorReached: boolean; shortcutOpened: boolean; supplyTaken: boolean; keepsakeSecured: boolean;
  discoveredRooms: readonly HyosanRooftopRoom[];
}
const flags = ['anchorReached', 'shortcutOpened', 'supplyTaken', 'keepsakeSecured'] as const;
const fields = ['version', 'worldVersion', 'discoveredRooms', ...flags];

/** The final duel and uncollected echo restart; only banked exploration persists. */
export function parseHyosanRooftopSave(raw: unknown): RooftopSaveDTO | null {
  try {
    const value = typeof raw === 'string' ? JSON.parse(raw) : raw;
    if (!value || typeof value !== 'object' || Array.isArray(value)
      || Object.keys(value).length !== fields.length || Object.keys(value).some((key) => !fields.includes(key))
      || value.version !== 1 || value.worldVersion !== 'hyosan-3d-school-v12'
      || flags.some((key) => typeof value[key] !== 'boolean')) return null;
    const rooms = value.discoveredRooms;
    if (!Array.isArray(rooms) || !rooms.length || new Set(rooms).size !== rooms.length
      || Array.from(rooms).some((room) => !HYOSAN_ROOFTOP_ROOMS.includes(room))
      || value.anchorReached && !rooms.includes('rooftop-landing')
      || (value.shortcutOpened || value.supplyTaken || value.keepsakeSecured) && !rooms.includes('rooftop-service')) return null;
    return { version: 1, worldVersion: value.worldVersion, anchorReached: value.anchorReached,
      shortcutOpened: value.shortcutOpened, supplyTaken: value.supplyTaken, keepsakeSecured: value.keepsakeSecured,
      discoveredRooms: HYOSAN_ROOFTOP_ROOMS.filter((room) => rooms.includes(room)) };
  } catch { return null; }
}
