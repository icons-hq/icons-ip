import layout from '@/docs/games/hyosan-memories-3d/world-layout.json';
import { sameHyosanCombatLayer } from './combat-layers';
import { direction, distance, distanceToSegment, planarDistance } from './combat-geometry';
import { hyosan3DBow } from './save';
import { parseHyosanClassroomSave, type ClassroomSaveDTO, type HyosanClassroomRoom } from './classroom-save';
import { createHyosanClassroomBossController, HYOSAN_CLASSROOM_BOSS } from './classroom-boss-controller';
import { HYOSAN_CLASSROOM_ROOMS } from './types';
import type { GroundPoint } from './physics';
import type { CombatEnemy, RegionModule, SharedCombatContext } from './region-module';

const STUDENT = { reach: 1.25, halfAngle: Math.acos(.35), windup: .55, strike: .16, recovery: .85 };
interface ClassroomEnemy extends CombatEnemy { since: number; homeRoom: HyosanClassroomRoom }

/** Classroom events and owned brains share the host's bodies, clock and damage. */
export function createHyosanClassroomRegion(context: SharedCombatContext): RegionModule<ClassroomSaveDTO> {
  const { source, physics, navigate, player, equipment } = context;
  const plan = source.classroom;
  if (!plan) throw new Error('Hyosan classroom layout is required');
  const gate = source.props.find((prop) => prop.id === plan.shortcut.id);
  const barricade = source.props.find((prop) => prop.id === plan.barricade.id);
  if (!gate || !barricade) throw new Error('Hyosan classroom furniture has no physical prop');
  const enemies: ClassroomEnemy[] = [];
  const bossController = createHyosanClassroomBossController();
  let resolved = false; let completed = false;
  let barricadeReleased = false; let shortcutOpened = false; let anchorReached = false;
  let echoCollected = false;
  const discovered = new Set<HyosanClassroomRoom>();
  let firstEnteredAt: number | null = null;
  let gateProgress = 0; let opening = false; let barricadeProgress = 0; let pushing = false;
  const ownRoomAt = (point: GroundPoint): HyosanClassroomRoom | undefined => {
    const floor = source.floors.find((floor) => Math.abs(point.x - floor.x) <= floor.width / 2 && Math.abs(point.z - floor.z) <= floor.depth / 2);
    return HYOSAN_CLASSROOM_ROOMS.find((room) => room === (floor && ('roomId' in floor ? floor.roomId : floor.id)));
  };
  const gatePose = (progress: number) => {
    const rotation = gate.rotation + (plan.shortcut.open.rotation - gate.rotation) * progress;
    const radius = Math.hypot(gate.x - plan.shortcut.hinge.x, gate.z - plan.shortcut.hinge.z);
    return progress === 1 ? plan.shortcut.open : { x: plan.shortcut.hinge.x - radius * Math.cos(rotation),
      z: plan.shortcut.hinge.z + radius * Math.sin(rotation), rotation };
  };
  const barricadePose = (progress: number) => ({ x: barricade.x + (plan.barricade.to.x - barricade.x) * progress,
    z: barricade.z + (plan.barricade.to.z - barricade.z) * progress, rotation: barricade.rotation });
  const boss = () => enemies.find((enemy) => enemy.kind === 'boss');
  const nearby = (point: GroundPoint, ignore?: string) => distance(player, point) < 1.55 && physics.lineOfSight(player, point, ignore);
  const interaction: RegionModule['interaction'] = () => {
    if (player.hp <= 0 || completed) return null;
    if (!resolved && boss()?.hp === 0 && !echoCollected && nearby(plan.echo)) return 'echo';
    if (!equipment.piercingCollected && nearby(plan.upgrade)) return 'upgrade';
    if (!shortcutOpened && !opening && player.x > gate.x + .2 && nearby(plan.shortcut.interactPoint, gate.id)) return 'shortcut';
    if (!barricadeReleased && !pushing && player.x < barricade.x - .2 && nearby(plan.barricade.interactPoint, barricade.id)) return 'barricade';
    return null;
  };
  const createEnemy = (id: string, at: GroundPoint, isBoss = false): ClassroomEnemy => {
    const point = physics.addActor(id, at, isBoss ? .5 : .32);
    const hp = isBoss ? HYOSAN_CLASSROOM_BOSS.hp : 2;
    return { id, ...point, yaw: 0, hp, maxHp: hp, kind: isBoss ? 'boss' : 'student', dormant: false,
      ownerArea: 'classroom', ...(isBoss ? { profile: 'jingu' as const } : {}), active: false, since: 0,
      homeRoom: ownRoomAt(at) ?? 'classroom-link', attackPhase: 'idle', attackStyle: isBoss ? 'charge' : 'melee', attackProgress: 0,
      attackRange: isBoss ? HYOSAN_CLASSROOM_BOSS.rushDistance + HYOSAN_CLASSROOM_BOSS.contactRadius : STUDENT.reach,
      attackHalfAngle: isBoss ? Math.PI / 2 : STUDENT.halfAngle, defeatedAt: null };
  };
  const hitsPlayer = (enemy: ClassroomEnemy) => {
    const aim = direction(player.x - enemy.x, player.z - enemy.z);
    return sameHyosanCombatLayer(enemy, player) && distance(enemy, player) <= enemy.attackRange
      && aim.x * Math.sin(enemy.yaw) + aim.z * Math.cos(enemy.yaw) > Math.cos(enemy.attackHalfAngle) && physics.lineOfSight(enemy, player);
  };
  const walkToward = (enemy: ClassroomEnemy, speed: number) => {
    const waypoint = navigate(enemy, player, enemy.kind === 'boss' ? .5 : .32, .32);
    const aim = direction(waypoint.x - enemy.x, waypoint.z - enemy.z);
    if (aim.x || aim.z) enemy.yaw = Math.atan2(aim.x, aim.z);
    const travel = speed * context.dt * context.movementMultiplier(enemy, enemy.kind);
    Object.assign(enemy, physics.moveActor(enemy.id, aim.x * travel, aim.z * travel));
  };
  return {
    id: 'classroom', enemies,
    reset(raw, wasResolved) {
      const saved = parseHyosanClassroomSave(raw);
      resolved = wasResolved; completed = false;
      barricadeReleased = saved?.barricadeReleased === true; shortcutOpened = saved?.shortcutOpened === true;
      anchorReached = saved?.anchorReached === true;
      equipment.piercingCollected ||= saved?.piercingCollected === true;
      gateProgress = shortcutOpened ? 1 : 0; opening = false;
      barricadeProgress = barricadeReleased ? 1 : 0; pushing = false;
      physics.trySetPropPose(gate.id, gatePose(gateProgress)); physics.trySetPropPose(barricade.id, barricadePose(barricadeProgress));
      enemies.length = 0;
      if (!resolved) {
        for (const group of plan.encounters) for (let index = 0; index < group.count; index++) {
          enemies.push(createEnemy(`${group.id}-${index}`, { x: group.x + index % 2 * .95, z: group.z + Math.floor(index / 2) * .95 }));
        }
        enemies.push(createEnemy(plan.boss.id, plan.boss, true));
      }
      discovered.clear(); for (const room of saved?.discoveredRooms ?? []) discovered.add(room);
      firstEnteredAt = null; echoCollected = false; bossController.reset();
    },
    observePlayer() {
      const room = ownRoomAt(player); if (room) discovered.add(room);
      if (context.area === 'classroom' && firstEnteredAt === null) firstEnteredAt = context.time;
    },
    update(edges) {
      const time = context.time;
      if (player.hp <= 0) return;
      if (!anchorReached && nearby(plan.checkpoint) && distance(player, plan.checkpoint) <= plan.checkpoint.radius) {
        anchorReached = true; context.checkpoint(plan.checkpoint);
      }
      if (edges.interactPressed) {
        const action = interaction();
        if (action === 'upgrade') { equipment.piercingCollected = true; player.hp = Math.min(6, player.hp + 2); }
        if (action === 'barricade') pushing = true;
        if (action === 'shortcut') opening = true;
        if (action === 'echo') echoCollected = true;
        if (action) context.effect(action === 'shortcut' || action === 'barricade' ? 'door' : 'upgrade', player, .7);
      }
      if (opening) {
        const next = Math.min(1, gateProgress + context.dt / plan.shortcut.duration);
        if (physics.trySetPropPose(gate.id, gatePose(next))) gateProgress = next;
        if (gateProgress === 1) { opening = false; shortcutOpened = true; }
      }
      if (pushing) {
        const next = Math.min(1, barricadeProgress + context.dt / plan.barricade.duration);
        if (physics.trySetPropPose(barricade.id, barricadePose(next))) barricadeProgress = next;
        if (barricadeProgress === 1) { pushing = false; barricadeReleased = true; }
      }
      for (const enemy of enemies) {
        if (enemy.hp <= 0) continue;
        enemy.active ||= firstEnteredAt !== null && time - firstEnteredAt >= 2.2 && distance(enemy, player) < 9
          && (ownRoomAt(player) === enemy.homeRoom || distance(enemy, player) < 5 && physics.lineOfSight(enemy, player));
        if (!enemy.active) continue;
        if (enemy.kind === 'boss') {
          const previousBeat = enemy.classroomBeat;
          const frame = bossController.advance({ time, x: enemy.x, z: enemy.z, targetX: player.x, targetZ: player.z,
            visible: sameHyosanCombatLayer(enemy, player) && physics.lineOfSight(enemy, player),
            // Cross-area pursuit must use ramps before a new ram. A smaller
            // target beside a wall can still be within actual capsule contact.
            canStartRush: previousBeat !== undefined || distance(enemy, player) <= HYOSAN_CLASSROOM_BOSS.contactRadius
              || physics.clearGround(enemy, player, .5) });
          if (frame.beat === 'idle') walkToward(enemy, HYOSAN_CLASSROOM_BOSS.approachSpeed);
          else enemy.yaw = frame.yaw;
          if (frame.moveDistance > 0) {
            const from = { x: enemy.x, y: enemy.y, z: enemy.z };
            Object.assign(enemy, physics.moveActor(enemy.id, Math.sin(frame.yaw) * frame.moveDistance,
              Math.cos(frame.yaw) * frame.moveDistance, { slide: false }));
            const contact = (player.x - from.x) * Math.sin(frame.yaw) + (player.z - from.z) * Math.cos(frame.yaw) >= 0
              && distanceToSegment(player, from, enemy) <= HYOSAN_CLASSROOM_BOSS.contactRadius && physics.lineOfSight(enemy, player);
            if (bossController.resolveRush({ movedDistance: planarDistance(from, enemy),
              blocked: planarDistance(from, enemy) < frame.moveDistance - .001, contact })) context.hurtPlayer(2, enemy);
          }
          const current = bossController.read();
          enemy.classroomBeat = current.beat === 'idle' ? undefined : current.beat;
          enemy.attackStyle = 'charge'; enemy.attackPhase = current.attackPhase;
          enemy.attackProgress = current.attackProgress; enemy.attackRange = current.attackRange;
          if (enemy.classroomBeat === 'brace' && previousBeat !== 'brace') context.effect('boss-warning', enemy, .75);
          if (enemy.classroomBeat === 'impact' && previousBeat !== 'impact') context.effect('impact', enemy, .35);
        } else if (enemy.attackPhase === 'idle') {
          enemy.yaw = Math.atan2(player.x - enemy.x, player.z - enemy.z);
          if (sameHyosanCombatLayer(enemy, player) && distance(enemy, player) <= 1.05 && physics.lineOfSight(enemy, player)) { enemy.attackPhase = 'windup'; enemy.since = time; }
          else walkToward(enemy, 1.05);
        } else if (enemy.attackPhase === 'windup' && time - enemy.since >= STUDENT.windup) {
          enemy.attackPhase = 'strike'; enemy.since = time; if (hitsPlayer(enemy)) context.hurtPlayer(1, enemy);
        } else if (enemy.attackPhase === 'strike' && time - enemy.since >= STUDENT.strike) { enemy.attackPhase = 'recover'; enemy.since = time; }
        else if (enemy.attackPhase === 'recover' && time - enemy.since >= STUDENT.recovery) { enemy.attackPhase = 'idle'; enemy.since = time; }
        if (enemy.kind === 'student') enemy.attackProgress = enemy.attackPhase === 'idle' ? 0 : Math.min(1,
          (time - enemy.since) / (enemy.attackPhase === 'windup' ? STUDENT.windup : enemy.attackPhase === 'strike' ? STUDENT.strike : STUDENT.recovery));
      }
    },
    afterCombat() {
      if (!resolved && player.hp > 0 && boss()?.hp === 0 && echoCollected && distance(player, plan.exit) <= .5) completed = true;
    },
    markResolved() { resolved = true; completed = false; },
    interaction,
    readProgress() {
      const bow = hyosan3DBow(equipment.kitCollected, equipment.supplyCollected, equipment.piercingCollected, equipment.stringReinforced);
      const bossDefeated = resolved || boss()?.hp === 0;
      return { room: ownRoomAt(player) ?? 'classroom-link', discoveredRooms: [...discovered], barricadeReleased, piercingCollected: equipment.piercingCollected,
        areaResolved: resolved, objective: completed ? 'completed' : resolved ? 'explore_school' : !bossDefeated
          ? boss()?.active ? 'defeat_boss' : 'explore_classroom' : !echoCollected ? 'collect_echo' : 'reach_exit',
        upgraded: equipment.kitCollected, supplyCollected: equipment.supplyCollected, bowLevel: bow.level, bossDefeated, completed, echoCollected,
        anchorReached, shortcutOpened, incidentTriggered: false, entranceOpen: 1, inWater: false, activeWaterIds: [], incidentShortcutOpened: false };
    },
    exportSave: () => ({ version: 1, worldVersion: layout.version, barricadeReleased, shortcutOpened, anchorReached, piercingCollected: equipment.piercingCollected,
      discoveredRooms: HYOSAN_CLASSROOM_ROOMS.filter((room) => discovered.has(room)) }),
    respawnPoint: () => anchorReached ? plan.checkpoint : plan.spawn,
    furniture: () => [{ id: gate.id, ...gatePose(gateProgress), progress: gateProgress },
      { id: barricade.id, ...barricadePose(barricadeProgress), progress: barricadeProgress }],
  };
}
