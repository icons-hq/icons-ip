import type { HyosanEncounterPhase } from './finite-inflow';
import type { HyosanStaffroomFireState } from './staffroom-fire';

export interface Hyosan3DInput {
  moveX: number;
  moveZ: number;
  /** World-space aim direction. Omit X/Z for visible-target auto aim; omitted Y keeps horizontal manual aim. */
  aimX?: number;
  aimY?: number;
  aimZ?: number;
  attackHeld: boolean;
  dashPressed: boolean;
  interactPressed: boolean;
}

export interface Hyosan3DPlayer {
  surfaceId?: string;
  /** Authored movement layer, independent of small height changes within a room. */
  currentLayerId?: string;
  /** Actual physical foot height in world metres. */
  x: number; y: number; z: number; yaw: number;
  /** Radians above the horizontal shot plane. */
  aimPitch: number;
  hp: number; maxHp: number; moving: boolean;
  /** Simulation seconds; -1 means no shot yet. Yaw faces +Z at zero. */
  shotTime: number;
  dashUntil: number;
  invulnerableUntil: number;
}

export type Hyosan3DAttackPhase = 'idle' | 'windup' | 'strike' | 'recover';
export interface Hyosan3DEnemy {
  surfaceId?: string;
  currentLayerId?: string;
  /** Encounter ownership selects objectives; every owner shares combat and physics. */
  ownerArea?: Hyosan3DArea;
  id: string; x: number; y: number; z: number; yaw: number;
  hp: number; maxHp: number; kind: 'student' | 'boss';
  /** No rendered body, physics collider, aim target or AI until the encounter boundary opens. */
  dormant?: boolean;
  /** A live, targetable actor walking through the authored arrival gallery. */
  entering?: boolean;
  profile?: 'hyunju' | 'jingu' | 'daewon' | 'gwinam-human' | 'eunji' | 'gwinam-halfbie';
  rooftopBeat?: 'stalk' | 'rush-windup' | 'rush' | 'sweep-windup' | 'sweep' | 'recovery' | 'resolve';
  rooftopPhase?: number;
  staffroomBeat?: 'idle' | 'notice' | 'pursuit' | 'investigate' | 'return' | 'grab-windup' | 'grab' | 'recovery' | 'ignite-windup' | 'ignite-recovery';
  libraryBeat?: 'stalk' | 'sidestep' | 'thrust-windup' | 'thrust' | 'check-windup' | 'check' | 'recovery';
  broadcastBeat?: 'limp' | 'grab-windup' | 'grab' | 'recovery' | 'trip' | 'slide' | 'brace';
  classroomBeat?: 'brace' | 'rush' | 'impact' | 'stagger' | 'recovery';
  scienceBeat?: 'approach' | 'notice' | 'pursuit' | 'bite-windup' | 'bite' | 'recovery';
  comboBeat?: 'idle' | 'tremor' | 'charge' | 'sweep-windup' | 'sweep' | 'recovery';
  attackStyle: 'melee' | 'charge';
  /** Forward telegraph extent, including contact reach, in metres. */
  attackRange: number;
  /** Melee cone half-angle in radians; charge uses its swept contact strip instead. */
  attackHalfAngle: number;
  attackPhase: Hyosan3DAttackPhase;
  attackProgress: number;
  defeatedAt: number | null;
}

export interface Hyosan3DArrow {
  /** Bound at creation; crossing a floor transition never retargets this arrow. */
  currentLayerId?: string;
  id: string; x: number; y: number; z: number; dx: number; dy: number; dz: number;
}

export interface Hyosan3DEffect {
  id: string;
  kind: 'shot' | 'hit' | 'impact' | 'hurt' | 'upgrade' | 'defeat' | 'respawn' | 'door' | 'boss-warning' | 'boss-sweep';
  x: number; y: number; z: number; startedAt: number; duration: number;
  /** Confirmed damage recipient; presentation must never guess the closest body. */
  actorId?: string;
  /** Horizontal contact-to-body direction, when the source is known. */
  directionX?: number; directionZ?: number;
}

export const HYOSAN_3D_ROOMS = ['infirmary', 'corridor', 'cafeteria', 'sheltered-passage', 'supply-room', 'service-gallery'] as const;
export type Hyosan3DCafeteriaRoom = typeof HYOSAN_3D_ROOMS[number];
export const HYOSAN_CLASSROOM_ROOMS = ['classroom-link', 'classroom-west', 'classroom-2-5', 'classroom-east', 'classroom-loop'] as const;
export const HYOSAN_BROADCAST_ROOMS = ['broadcast-entry', 'broadcast-control', 'broadcast-annex', 'broadcast-upper', 'broadcast-stairs', 'broadcast-lower'] as const;
export const HYOSAN_LIBRARY_ROOMS = ['library-entry', 'library-reading', 'library-stacks', 'library-crossing', 'library-crown', 'library-workroom', 'library-archive'] as const;
export const HYOSAN_STAFFROOM_ROOMS = ['staffroom-entry', 'staffroom-desks', 'staffroom-copy', 'staffroom-firebreak', 'staffroom-counselling', 'staffroom-records', 'staffroom-breakroom'] as const;
export const HYOSAN_GYMNASIUM_ROOMS = ['gym-entry', 'gym-equipment', 'gym-court', 'gym-gallery', 'gym-cartlane', 'gym-exit'] as const;
export const HYOSAN_ROOFTOP_ROOMS = ['rooftop-foot', 'rooftop-ascent', 'rooftop-landing', 'rooftop-threshold', 'rooftop-service', 'rooftop-court', 'rooftop-memorial'] as const;
export const HYOSAN_ALL_ROOMS = [...HYOSAN_3D_ROOMS, 'science-lab', 'science-prep', 'science-link', ...HYOSAN_CLASSROOM_ROOMS, ...HYOSAN_BROADCAST_ROOMS, ...HYOSAN_LIBRARY_ROOMS, ...HYOSAN_STAFFROOM_ROOMS, ...HYOSAN_GYMNASIUM_ROOMS, ...HYOSAN_ROOFTOP_ROOMS] as const;
export type Hyosan3DRoom = typeof HYOSAN_ALL_ROOMS[number];
export const HYOSAN_3D_AREAS = ['science', 'cafeteria', 'classroom', 'broadcast', 'library', 'staffroom', 'gymnasium', 'rooftop'] as const;
export type Hyosan3DArea = typeof HYOSAN_3D_AREAS[number];
export interface Hyosan3DEntry { x: number; y: number; z: number; yaw: number; hp: number }
export interface Hyosan3DEquipment { kitCollected: boolean; supplyCollected: boolean; piercingCollected?: boolean; stringReinforced?: boolean; tipReinforced?: boolean }
export interface Hyosan3DSave {
  version: 1;
  worldVersion: string;
  kitCollected: boolean;
  supplyCollected: boolean;
  incidentTriggered: boolean;
  shortcutOpened: boolean;
  anchorReached: boolean;
  discoveredRooms: readonly Hyosan3DCafeteriaRoom[];
}
export interface Hyosan3DBow { level: 1 | 2 | 3 | 4; damage: number; interval: number; penetration?: number; projectileSpeed?: number }
export interface Hyosan3DFurniture { id: string; x: number; y?: number; z: number; rotation: number; progress: number }

export interface Hyosan3DEnding {
  phase: 'locked' | 'available' | 'returning' | 'reunion' | 'complete';
  nextArea?: Hyosan3DArea;
  page: number;
  /** Continuous scene clock; page time resets only the button debounce. */
  elapsed?: number;
  time: number;
}

export interface Hyosan3DStory { id: 'opening' | 'music'; page: number; time: number }

export interface Hyosan3DSnapshot {
  /** Shared combat policy; legacy snapshots can omit this presentation metadata. */
  difficulty?: import('./difficulty').HyosanDifficulty;
  recoveryIn?: number | null;
  /** Local narrative presentation only; never authorizes server completion or rewards. */
  ending?: Readonly<Hyosan3DEnding>;
  story?: Readonly<Hyosan3DStory> | null;
  area?: Hyosan3DArea;
  transitioning?: boolean;
  transitionFailed?: boolean;
  schoolState?: Readonly<Partial<Record<Hyosan3DArea, Hyosan3DSnapshot['progress']>>>;
  campaign?: Readonly<{ scienceComplete: boolean; cafeteriaComplete: boolean; classroomComplete?: boolean; broadcastComplete?: boolean; libraryComplete?: boolean; staffroomComplete?: boolean; gymnasiumComplete?: boolean; rooftopComplete?: boolean }>;
  time: number;
  player: Readonly<Hyosan3DPlayer>;
  enemies: readonly Readonly<Hyosan3DEnemy>[];
  arrows: readonly Readonly<Hyosan3DArrow>[];
  effects: readonly Readonly<Hyosan3DEffect>[];
  /** Physics-accepted poses shared by the GLB renderer and floor plan. */
  furniture: readonly Readonly<Hyosan3DFurniture>[];
  /** Authored fire phases share one simulation clock with gameplay and the map. */
  fires?: readonly HyosanStaffroomFireState[];
  bow: Readonly<Hyosan3DBow>;
  /** Attempt-local finite roster; never serialized as durable progress. */
  inflow?: Readonly<{ phase: HyosanEncounterPhase; pending: readonly string[];
    admitted: readonly string[]; cancelled: readonly string[] }>;
  /** Nearby interaction validated by simulation, shared by keyboard and touch HUD. */
  interaction: 'campfire' | 'origin' | 'echo' | 'supply' | 'upgrade' | 'shortcut' | 'barricade' | 'hose' | 'bowstring' | 'arrowtip' | 'keepsake' | 'cover-cart' | 'exit-cart' | null;
  progress: Readonly<{
    room: Hyosan3DRoom;
    discoveredRooms: readonly Hyosan3DRoom[];
    objective: 'return_memory' | 'return_campfire' | 'ascend_rooftop' | 'explore_rooftop' | 'reach_gym' | 'explore_gym' | 'escape_gym' | 'inspect_lab' | 'return_science' | 'explore_school' | 'find_upgrade' | 'reach_cafeteria' | 'explore_cafeteria' | 'reach_classroom' | 'explore_classroom' | 'reach_broadcast' | 'inspect_broadcast' | 'secure_hose' | 'descend_stairs' | 'reach_library' | 'explore_library' | 'climb_shelves' | 'reach_staffroom' | 'explore_staffroom' | 'inspect_records' | 'defeat_boss' | 'collect_echo' | 'reach_exit' | 'completed';
    /** Fresh campaign S1 waits for the first shot before its student pursuit begins. */
    awaitingFirstShot?: boolean;
    tipReinforced?: boolean; inFire?: boolean;
    escapeResolved?: boolean; escapeCartCleared?: boolean; coverCartStop?: number;
    stringReinforced?: boolean; keepsakeFound?: boolean; keepsakeSecured?: boolean;
    consoleInspected?: boolean; hoseSecured?: boolean; supplyTaken?: boolean;
    barricadeReleased?: boolean; piercingCollected?: boolean;
    originInspected?: boolean; areaResolved?: boolean;
    upgraded: boolean; bossDefeated: boolean; completed: boolean;
    anchorReached: boolean; incidentTriggered: boolean; shortcutOpened: boolean;
    /** Physical glass-leaf rotation fraction; read by rendering without easing. */
    entranceOpen: number;
    /** C2 wet-floor hazard at the player's feet; dash remains unaffected. */
    inWater: boolean;
    activeWaterIds: readonly string[];
    incidentShortcutOpened: boolean;
    bossApproaching?: boolean;
    supplyCollected: boolean; echoCollected: boolean; bowLevel: 1 | 2 | 3 | 4;
  }>;
  paused: boolean;
}

export interface Hyosan3DPlayRuntime {
  step(input: Readonly<Hyosan3DInput>, dt?: number): void;
  read(): Readonly<Hyosan3DSnapshot>;
  setPaused(paused: boolean): void;
  /** Starts a fresh local run, clearing held actions until they are released. */
  reset(): void;
  dispose(): void;
}

export interface Hyosan3DRegionRuntime extends Hyosan3DPlayRuntime {
  /** Explicit standalone placement compatibility. Campaign walking never calls this. */
  enter(entry: Hyosan3DEntry, equipment: Hyosan3DEquipment, continuingInput?: Readonly<Hyosan3DInput>): void;
  /** Standalone encounter inspection; never a campaign transition gate. */
  canLeave(): boolean;
}

export interface Hyosan3DSimulation extends Hyosan3DRegionRuntime {
  /** Only durable exploration flags; never serializes combat or completion state. */
  exportSave(): Hyosan3DSave;
}

export const HYOSAN_3D_EMPTY_INPUT: Readonly<Hyosan3DInput> = Object.freeze({
  moveX: 0, moveZ: 0, attackHeld: false, dashPressed: false, interactPressed: false,
});
