export interface CartPose { x: number; y: number; z: number; rotation: number }
export interface CartState {
  readonly pose: Readonly<CartPose>;
  readonly durableStop: number;
  readonly targetStop: number | null;
  readonly progress: number;
}

/** One cart, authored stops. The injected owner alone decides physical acceptance. */
export function createHyosanCartMovement(stops: readonly CartPose[], duration: number,
  acceptPose: (pose: Readonly<CartPose>) => boolean, savedStop = 0) {
  if (!Number.isFinite(duration) || duration <= 0 || stops.length < 2
    || stops.some((p) => ![p.x,p.y,p.z,p.rotation].every(Number.isFinite))) throw new Error('Invalid cart definition');
  const poses = stops.map((pose) => ({ ...pose }));
  const requireStop = (stop: number) => {
    if (!Number.isInteger(stop) || stop < 0 || stop >= poses.length) throw new Error('Invalid cart stop');
  };
  requireStop(savedStop);
  let durableStop = savedStop;
  let targetStop: number | null = null;
  let progress = 0;
  let pose = { ...poses[savedStop] };
  if (!acceptPose(pose)) throw new Error('Rejected initial cart stop');
  return {
    requestNext() {
      if (targetStop !== null || durableStop === poses.length - 1) return false;
      targetStop = durableStop + 1;
      progress = 0;
      return true;
    },
    step(dt: number) {
      if (!Number.isFinite(dt) || dt < 0) throw new Error('Invalid cart elapsed time');
      if (targetStop === null || dt === 0) return;
      const next = Math.min(1, progress + dt / duration);
      const from = poses[durableStop]; const to = poses[targetStop];
      const candidate = next === 1 ? { ...to } : {
        x: from.x + (to.x - from.x) * next,
        y: from.y + (to.y - from.y) * next,
        z: from.z + (to.z - from.z) * next,
        rotation: from.rotation + (to.rotation - from.rotation) * next,
      };
      if (!acceptPose(candidate)) return;
      pose = candidate; progress = next;
      if (next === 1) { durableStop = targetStop; targetStop = null; }
    },
    read(): CartState { return { pose: { ...pose }, durableStop, targetStop, progress }; },
    reset(stop: number) {
      requireStop(stop);
      const candidate = { ...poses[stop] };
      if (!acceptPose(candidate)) return false;
      pose = candidate; durableStop = stop; targetStop = null; progress = 0;
      return true;
    },
  };
}
