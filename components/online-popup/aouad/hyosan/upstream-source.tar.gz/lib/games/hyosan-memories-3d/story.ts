import type { Hyosan3DStory } from './types';

/** Original game narration. These are not quotations from the series. */
export const HYOSAN_STORIES = {
  opening: {
    label: '프롤로그 · 현재의 효산고', image: '/api/dev/hyosan-3d/hyosan-opening.webp',
    alt: '밤의 철조망 앞에 선 학생이 멀리 학교 옥상의 모닥불을 바라본다.',
    finish: '기억 속으로 들어가기',
    pages: [
      { title: '아직, 불빛이 남아 있다.', text: '사람도, 좀비도 아닌 몸으로 돌아온 학교. 철조망 너머 옥상에 작은 불빛이 보인다.' },
      { title: '우리가 사람이었던 날.', text: '활을 쥐자 잊고 있던 풍경이 되살아난다. 모든 것이 시작된 과학실부터, 남겨진 기억을 따라가 보자.' },
    ],
  },
  music: {
    label: '되살아난 기억 · 음악실', image: '/api/dev/hyosan-3d/hyosan-music-memory.webp',
    alt: '남라가 오래된 피아노 옆에 앉아 한쪽 팔을 감싸고 있다. 옆 의자는 비어 있다.',
    finish: '교무실로 돌아가기',
    pages: [
      { title: '물린 뒤에도, 남라였다.', text: '귀남에게 물린 남라. 음악실에 모인 친구들 사이로 두려움이 번졌다. 어제와 같은 얼굴을, 이제는 쉽게 믿을 수 없었다.' },
      { title: '혼자 남겨 두지 않기.', text: '변해 가는 몸보다 무서운 건 모두에게서 멀어지는 일이었다. 그날의 기억이, 학교를 다시 걷는 나를 붙잡는다.' },
    ],
  },
} as const satisfies Record<Hyosan3DStory['id'], { label: string; image: string; alt: string; finish: string; pages: readonly { title: string; text: string }[] }>;
