import layout from '@/docs/games/hyosan-memories-3d/world-layout.json';
import { HYOSAN_STAFFROOM_ROOMS } from './types';

export type HyosanStaffroomRoom = typeof HYOSAN_STAFFROOM_ROOMS[number];
export interface StaffroomSaveDTO {
  version: 1; worldVersion: string;
  anchorReached: boolean; incidentTriggered: boolean; shortcutOpened: boolean;
  tipReinforced: boolean; keepsakeSecured: boolean;
  discoveredRooms: readonly HyosanStaffroomRoom[];
}
const flags = ['anchorReached', 'incidentTriggered', 'shortcutOpened', 'tipReinforced', 'keepsakeSecured'] as const;
const fields = ['version', 'worldVersion', 'discoveredRooms', ...flags];

/** Only exploration and banked equipment survive; burning timers and enemy HP do not. */
export function parseHyosanStaffroomSave(raw: unknown): StaffroomSaveDTO | null {
  try {
    const value = typeof raw === 'string' ? JSON.parse(raw) : raw;
    if (!value || typeof value !== 'object' || Array.isArray(value)
      || Object.keys(value).length !== fields.length || Object.keys(value).some((key) => !fields.includes(key))
      || value.version !== 1 || layout.version !== 'hyosan-3d-school-v12'
      || value.worldVersion !== layout.version && !['hyosan-3d-school-v10', 'hyosan-3d-school-v11'].includes(value.worldVersion)
      || flags.some((key) => typeof value[key] !== 'boolean')) return null;
    const rooms = value.discoveredRooms;
    if (!Array.isArray(rooms) || !rooms.length || rooms.length > HYOSAN_STAFFROOM_ROOMS.length
      || new Set(rooms).size !== rooms.length || Array.from(rooms).some((room) => !HYOSAN_STAFFROOM_ROOMS.includes(room))
      || value.shortcutOpened && !rooms.includes('staffroom-records')
      || value.tipReinforced && !rooms.includes('staffroom-copy')
      || value.keepsakeSecured && !rooms.includes('staffroom-breakroom')
      || value.anchorReached && !rooms.includes('staffroom-firebreak')) return null;
    return { version: 1, worldVersion: layout.version, anchorReached: value.anchorReached,
      incidentTriggered: value.incidentTriggered, shortcutOpened: value.shortcutOpened,
      tipReinforced: value.tipReinforced, keepsakeSecured: value.keepsakeSecured,
      discoveredRooms: HYOSAN_STAFFROOM_ROOMS.filter((room) => rooms.includes(room)) };
  } catch { return null; }
}

export function serializeHyosanStaffroomSave(save: StaffroomSaveDTO): string {
  const parsed = parseHyosanStaffroomSave(save);
  if (!parsed) throw new TypeError('Invalid Hyosan staffroom exploration save');
  return JSON.stringify(parsed);
}
