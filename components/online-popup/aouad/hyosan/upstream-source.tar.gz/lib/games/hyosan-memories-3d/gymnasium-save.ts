import layout from '@/docs/games/hyosan-memories-3d/world-layout.json';
import { HYOSAN_GYMNASIUM_ROOMS } from './types';

export type HyosanGymnasiumRoom = typeof HYOSAN_GYMNASIUM_ROOMS[number];
export interface GymnasiumSaveDTO {
  version: 1; worldVersion: string;
  discoveredRooms: readonly HyosanGymnasiumRoom[];
  anchorReached: boolean; incidentTriggered: boolean; shortcutOpened: boolean;
  escapeCartCleared: boolean; coverCartStop: number; supplyTaken: boolean; keepsakeSecured: boolean;
}

const flags = ['anchorReached', 'incidentTriggered', 'shortcutOpened', 'escapeCartCleared', 'supplyTaken', 'keepsakeSecured'] as const;
const fields = ['version', 'worldVersion', 'discoveredRooms', 'coverCartStop', ...flags];

/** Only accepted stops and banked exploration survive, never combat or the echo. */
export function parseHyosanGymnasiumSave(raw: unknown): GymnasiumSaveDTO | null {
  try {
    const value = typeof raw === 'string' ? JSON.parse(raw) : raw;
    if (!value || typeof value !== 'object' || Array.isArray(value)
      || Object.keys(value).length !== fields.length || Object.keys(value).some((key) => !fields.includes(key))
      || value.version !== 1 || layout.version !== 'hyosan-3d-school-v12'
      || value.worldVersion !== layout.version && value.worldVersion !== 'hyosan-3d-school-v11'
      || flags.some((key) => typeof value[key] !== 'boolean')
      || !Number.isInteger(value.coverCartStop) || value.coverCartStop < 0 || value.coverCartStop > 2) return null;
    const rooms = value.discoveredRooms;
    if (!Array.isArray(rooms) || !rooms.length || new Set(rooms).size !== rooms.length
      || Array.from(rooms).some((room) => !HYOSAN_GYMNASIUM_ROOMS.includes(room))
      || (value.anchorReached || value.shortcutOpened || value.supplyTaken || value.keepsakeSecured) && !rooms.includes('gym-equipment')
      || (value.escapeCartCleared || value.coverCartStop > 0) && (!value.incidentTriggered || !rooms.includes('gym-cartlane'))) return null;
    return { version: 1, worldVersion: layout.version, anchorReached: value.anchorReached,
      incidentTriggered: value.incidentTriggered, shortcutOpened: value.shortcutOpened,
      escapeCartCleared: value.escapeCartCleared, coverCartStop: value.coverCartStop,
      supplyTaken: value.supplyTaken, keepsakeSecured: value.keepsakeSecured,
      discoveredRooms: HYOSAN_GYMNASIUM_ROOMS.filter((room) => rooms.includes(room)) };
  } catch { return null; }
}
