export type HyosanServingCounterId = 'serving-counter-north' | 'serving-counter-south';
export interface HyosanCounterRayPoint { x: number; y: number; z: number }
export interface HyosanServingCounterRayData {
  version: 1;
  meshes: readonly { id: string; positions: readonly number[]; indices: readonly number[] }[];
  instances: readonly {
    id: HyosanServingCounterId; meshId: string; x: number; y: number; z: number; rotation: number;
  }[];
}
export interface HyosanCounterRayHit { distance: number; actorId: string | null; geometryId: string | null }

interface Bounds { minX: number; minY: number; minZ: number; maxX: number; maxY: number; maxZ: number }
interface Triangle { ax: number; ay: number; az: number; ux: number; uy: number; uz: number;
  vx: number; vy: number; vz: number; normalLength: number; bounds: Bounds }
type Node = { bounds: Bounds } & ({ triangles: readonly number[] } | { left: Node; right: Node });
const EPSILON = 1e-9;
const ENVELOPE_ROUNDING = 1e-6; // Exported POSITION accessors are float32 metres.
const COUNTER_IDS: readonly HyosanServingCounterId[] = ['serving-counter-north', 'serving-counter-south'];
const emptyBounds = (): Bounds => ({ minX: Infinity, minY: Infinity, minZ: Infinity, maxX: -Infinity, maxY: -Infinity, maxZ: -Infinity });
const include = (bounds: Bounds, point: HyosanCounterRayPoint) => {
  bounds.minX = Math.min(bounds.minX, point.x); bounds.maxX = Math.max(bounds.maxX, point.x);
  bounds.minY = Math.min(bounds.minY, point.y); bounds.maxY = Math.max(bounds.maxY, point.y);
  bounds.minZ = Math.min(bounds.minZ, point.z); bounds.maxZ = Math.max(bounds.maxZ, point.z);
};

/** Slab entry includes a ray starting inside the box; the box itself is never a hit. */
function boxEntry(bounds: Bounds, from: HyosanCounterRayPoint, direction: HyosanCounterRayPoint, maximum: number): number | null {
  let near = 0; let far = maximum;
  for (const [origin, delta, min, max] of [[from.x, direction.x, bounds.minX, bounds.maxX],
    [from.y, direction.y, bounds.minY, bounds.maxY], [from.z, direction.z, bounds.minZ, bounds.maxZ]]) {
    if (delta === 0) { if (origin < min - EPSILON || origin > max + EPSILON) return null; continue; }
    const a = (min - origin) / delta; const b = (max - origin) / delta;
    near = Math.max(near, Math.min(a, b)); far = Math.min(far, Math.max(a, b));
    if (near > far + EPSILON) return null;
  }
  return near <= maximum + EPSILON ? Math.min(maximum, near) : null;
}

/** Double-sided Moller-Trumbore: open bowls hit their interior surfaces too. */
function triangleHit(triangle: Triangle, from: HyosanCounterRayPoint, direction: HyosanCounterRayPoint,
  directionLength: number, maximum: number): number | null {
  const px = direction.y * triangle.vz - direction.z * triangle.vy;
  const py = direction.z * triangle.vx - direction.x * triangle.vz;
  const pz = direction.x * triangle.vy - direction.y * triangle.vx;
  const determinant = triangle.ux * px + triangle.uy * py + triangle.uz * pz;
  if (Math.abs(determinant) <= triangle.normalLength * directionLength * 1e-12) return null;
  const tx = from.x - triangle.ax; const ty = from.y - triangle.ay; const tz = from.z - triangle.az;
  const u = (tx * px + ty * py + tz * pz) / determinant;
  if (u < -EPSILON || u > 1 + EPSILON) return null;
  const qx = ty * triangle.uz - tz * triangle.uy;
  const qy = tz * triangle.ux - tx * triangle.uz;
  const qz = tx * triangle.uy - ty * triangle.ux;
  const v = (direction.x * qx + direction.y * qy + direction.z * qz) / determinant;
  if (v < -EPSILON || u + v > 1 + EPSILON) return null;
  const distance = (triangle.vx * qx + triangle.vy * qy + triangle.vz * qz) / determinant;
  return distance < -EPSILON || distance > maximum + EPSILON ? null : Math.max(0, Math.min(maximum, distance));
}

function prepareMesh(mesh: HyosanServingCounterRayData['meshes'][number]) {
  if (!mesh.id || !Array.isArray(mesh.positions) || !Array.isArray(mesh.indices) || mesh.positions.length % 3
    || !mesh.indices.length || mesh.indices.length % 3 || mesh.indices.length > 36_000
    || mesh.positions.some((value) => !Number.isFinite(value))
    || mesh.indices.some((index) => !Number.isInteger(index) || index < 0 || index >= mesh.positions.length / 3)) {
    throw new Error(`Invalid serving-counter mesh ${mesh.id}`);
  }
  const point = (index: number): HyosanCounterRayPoint => ({ x: mesh.positions[index * 3], y: mesh.positions[index * 3 + 1], z: mesh.positions[index * 3 + 2] });
  const triangles: Triangle[] = [];
  for (let index = 0; index < mesh.indices.length; index += 3) {
    const a = point(mesh.indices[index]); const b = point(mesh.indices[index + 1]); const c = point(mesh.indices[index + 2]);
    const ux = b.x - a.x; const uy = b.y - a.y; const uz = b.z - a.z;
    const vx = c.x - a.x; const vy = c.y - a.y; const vz = c.z - a.z;
    const normalLength = Math.hypot(uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx);
    if (!Number.isFinite(normalLength) || normalLength === 0) throw new Error(`Degenerate serving-counter triangle ${mesh.id}:${index / 3}`);
    const bounds = emptyBounds();
    for (const vertex of [a, b, c]) {
      if (Math.abs(vertex.x) > 2.3 + ENVELOPE_ROUNDING || Math.abs(vertex.z) > .625 + ENVELOPE_ROUNDING
        || vertex.y < -ENVELOPE_ROUNDING || vertex.y > 1.12 + ENVELOPE_ROUNDING) {
        throw new Error(`Serving-counter triangle exceeds its movement envelope ${mesh.id}:${index / 3}`);
      }
      include(bounds, vertex);
    }
    triangles.push({ ax: a.x, ay: a.y, az: a.z, ux, uy, uz, vx, vy, vz, normalLength, bounds });
  }
  const build = (ids: number[]): Node => {
    const bounds = emptyBounds();
    for (const id of ids) {
      const triangle = triangles[id].bounds;
      include(bounds, { x: triangle.minX, y: triangle.minY, z: triangle.minZ });
      include(bounds, { x: triangle.maxX, y: triangle.maxY, z: triangle.maxZ });
    }
    if (ids.length <= 8) return { bounds, triangles: ids };
    const dimensions = [['minX', 'maxX'], ['minY', 'maxY'], ['minZ', 'maxZ']] as const;
    const [min, max] = [...dimensions].sort(([a, b], [c, d]) => (bounds[d] - bounds[c]) - (bounds[b] - bounds[a]))[0];
    ids.sort((a, b) => triangles[a].bounds[min] + triangles[a].bounds[max] - triangles[b].bounds[min] - triangles[b].bounds[max] || a - b);
    const middle = Math.floor(ids.length / 2);
    return { bounds, left: build(ids.slice(0, middle)), right: build(ids.slice(middle)) };
  };
  return { triangles, root: build(triangles.map((_, index) => index)) };
}

const immutableMeshCache = new WeakMap<HyosanServingCounterRayData['meshes'][number], ReturnType<typeof prepareMesh>>();
function sharedMesh(mesh: HyosanServingCounterRayData['meshes'][number]) {
  // Runtime freezes the imported extraction. Mutable fixture/caller arrays
  // retain constructor snapshot semantics, including subsequent constructors.
  const immutable = Object.isFrozen(mesh) && Object.isFrozen(mesh.positions) && Object.isFrozen(mesh.indices);
  const cached = immutable ? immutableMeshCache.get(mesh) : undefined;
  if (cached) return cached;
  const prepared = prepareMesh(mesh);
  if (immutable) immutableMeshCache.set(mesh, prepared);
  return prepared;
}

/** Opt-in local-metre/Y-up surfaces. Bake child transforms into each mesh;
 * instances carry only the exact counter yaw and translation from the layout.
 * Frozen meshes share BVHs across worlds; mutable inputs are snapshotted.
 * No physics is mutated. */
export function createHyosanServingCounterRayQuery(data: HyosanServingCounterRayData) {
  if (!data || data.version !== 1 || !Array.isArray(data.meshes) || !data.meshes.length || data.meshes.length > 2
    || !Array.isArray(data.instances) || data.instances.length !== 2) throw new Error('Invalid serving-counter ray data');
  const meshes = new Map(data.meshes.map((mesh) => [mesh.id, sharedMesh(mesh)]));
  const ids = new Set(data.instances.map((instance) => instance.id));
  if (meshes.size !== data.meshes.length || ids.size !== 2 || COUNTER_IDS.some((id) => !ids.has(id))) throw new Error('Invalid serving-counter ray identities');
  const instances = data.instances.map((instance) => {
    const mesh = meshes.get(instance.meshId);
    if (!mesh || ![instance.x, instance.y, instance.z, instance.rotation].every(Number.isFinite)) throw new Error(`Invalid serving-counter instance ${instance.id}`);
    const cosine = Math.cos(instance.rotation); const sine = Math.sin(instance.rotation);
    const bounds = emptyBounds(); const local = mesh.root.bounds;
    for (const x of [local.minX, local.maxX]) for (const y of [local.minY, local.maxY]) for (const z of [local.minZ, local.maxZ]) {
      include(bounds, { x: instance.x + cosine * x + sine * z, y: instance.y + y, z: instance.z - sine * x + cosine * z });
    }
    return { ...instance, mesh, cosine, sine, bounds };
  }).sort((a, b) => a.id.localeCompare(b.id));
  if (new Set(instances.map((instance) => instance.meshId)).size !== meshes.size
    || instances.reduce((count, instance) => count + instance.mesh.triangles.length, 0) > 12_000) throw new Error('Invalid serving-counter rendered triangle budget');
  let boundsTests = 0; let triangleTests = 0;
  const replacesGeometry = (id: string | null | undefined) => id !== null && id !== undefined && ids.has(id as HyosanServingCounterId);
  return {
    replacesGeometry,
    /** Like Rapier, distance is ray parameter t in origin+t*direction (metres
     * for a unit direction). Include both endpoints. otherHit must be the
     * nearest bounded Rapier hit with the two replaced proxies filtered out;
     * its actor/static/ignore filters stay with the caller. Ties preserve it. */
    cast(from: HyosanCounterRayPoint, direction: HyosanCounterRayPoint, maxDistance: number,
      otherHit: HyosanCounterRayHit | null = null, ignoreGeometry?: string): HyosanCounterRayHit | null {
      boundsTests = 0; triangleTests = 0;
      const directionLength = Math.hypot(direction.x, direction.y, direction.z);
      if (![from.x, from.y, from.z, direction.x, direction.y, direction.z, maxDistance].every(Number.isFinite)
        || maxDistance < 0 || directionLength === 0) throw new RangeError('Invalid serving-counter ray');
      if (otherHit && (!Number.isFinite(otherHit.distance) || otherHit.distance < 0 || replacesGeometry(otherHit.geometryId))) {
        throw new Error('Expected a valid non-counter Rapier hit');
      }
      let nearest = otherHit; let maximum = Math.min(maxDistance, otherHit?.distance ?? maxDistance);
      const entry = (bounds: Bounds, origin: HyosanCounterRayPoint, ray: HyosanCounterRayPoint) => {
        boundsTests++; return boxEntry(bounds, origin, ray, maximum);
      };
      for (const instance of instances) {
        if (instance.id === ignoreGeometry || entry(instance.bounds, from, direction) === null) continue;
        const x = from.x - instance.x; const z = from.z - instance.z;
        const origin = { x: instance.cosine * x - instance.sine * z, y: from.y - instance.y, z: instance.sine * x + instance.cosine * z };
        const ray = { x: instance.cosine * direction.x - instance.sine * direction.z, y: direction.y,
          z: instance.sine * direction.x + instance.cosine * direction.z };
        const visit = (node: Node, start: number) => {
          if (start > maximum + EPSILON) return;
          if ('triangles' in node) {
            for (const index of node.triangles) {
              triangleTests++;
              const distance = triangleHit(instance.mesh.triangles[index], origin, ray, directionLength, maximum);
              if (distance !== null && (!nearest || distance < nearest.distance - EPSILON)) {
                maximum = distance; nearest = { distance, actorId: null, geometryId: instance.id };
              }
            }
            return;
          }
          const left = entry(node.left.bounds, origin, ray); const right = entry(node.right.bounds, origin, ray);
          if (left !== null && right !== null) {
            if (left <= right) { visit(node.left, left); visit(node.right, right); }
            else { visit(node.right, right); visit(node.left, left); }
          } else if (left !== null) visit(node.left, left);
          else if (right !== null) visit(node.right, right);
        };
        const start = entry(instance.mesh.root.bounds, origin, ray);
        if (start !== null) visit(instance.mesh.root, start);
      }
      return nearest;
    },
    /** Bounded-work evidence, without exposing the tree or mutable geometry. */
    readStats() { return { boundsTests, triangleTests }; },
  };
}
