import layout from '@/docs/games/hyosan-memories-3d/world-layout.json';
import { sameHyosanCombatLayer } from './combat-layers';
import type { GroundPoint } from './physics';
import { direction, distance } from './combat-geometry';
import { hyosan3DBow } from './save';
import { HYOSAN_SCIENCE_ROOMS, parseHyosanScienceSave, type HyosanScienceRoom, type ScienceSaveDTO } from './science-save';
import { createHyosanScienceBossController, HYOSAN_SCIENCE_BOSS } from './science-boss-controller';
import type { CombatEnemy, RegionModule, SharedCombatContext } from './region-module';
import type { Hyosan3DSnapshot } from './types';

const STUDENT = { reach: 1.25, halfAngle: Math.acos(.35), windup: .55, strike: .16, recovery: .85 };
interface Enemy extends CombatEnemy { since: number; homeRoom: HyosanScienceRoom }

/** Science owns its encounter; the shared host owns the player and combat world. */
export function createHyosanScienceRegion(ctx: SharedCombatContext, options: { teachBow?: boolean } = {}): RegionModule<ScienceSaveDTO> {
  const { source, physics, navigate, player, equipment } = ctx;
  const plan = source.science;
  if (!plan) throw new Error('Hyosan science layout is required');
  const gate = source.props.find((prop) => prop.id === plan.shortcut.id);
  if (!gate) throw new Error('Hyosan science shortcut has no physical prop');
  const bossController = createHyosanScienceBossController();
  const enemies: Enemy[] = [];
  let resolved = false; let completed = false; let firstEnteredAt: number | null = null;
  let awaitingFirstShot = false;
  let originInspected = false; let shortcutOpened = false; let anchorReached = false; let echoCollected = false;
  let discovered = new Set<HyosanScienceRoom>(); let gateProgress = 0; let opening = false;
  const actualRoomAt = (point: GroundPoint): HyosanScienceRoom | undefined => {
    const floor = source.floors.find((floor) => Math.abs(point.x - floor.x) <= floor.width / 2 && Math.abs(point.z - floor.z) <= floor.depth / 2);
    return HYOSAN_SCIENCE_ROOMS.find((room) => room === (floor && ('roomId' in floor ? floor.roomId : floor.id)));
  };
  const roomAt = (point: GroundPoint): HyosanScienceRoom => actualRoomAt(point) ?? 'science-lab';
  const gatePose = (progress: number) => {
    const angle = progress * plan.shortcut.open.rotation;
    const radius = Math.hypot(gate.x - plan.shortcut.hinge.x, gate.z - plan.shortcut.hinge.z);
    return progress === 1 ? plan.shortcut.open : { x: plan.shortcut.hinge.x + radius * Math.cos(angle),
      z: plan.shortcut.hinge.z - radius * Math.sin(angle), rotation: angle };
  };
  const createEnemy = (id: string, at: GroundPoint, boss = false): Enemy => {
    const dormant = boss && !originInspected;
    const point = dormant ? { ...at, y: physics.heightAt(at) ?? 0 } : physics.addActor(id, at, boss ? .5 : .32);
    const hp = boss ? HYOSAN_SCIENCE_BOSS.hp : 2;
    return { id, ...point, ownerArea: 'science', yaw: 0, hp, maxHp: hp, kind: boss ? 'boss' : 'student', dormant,
      ...(boss ? { profile: 'hyunju' as const } : {}), active: false, since: 0, homeRoom: roomAt(at),
      attackPhase: 'idle', attackStyle: 'melee', attackProgress: 0,
      attackRange: boss ? HYOSAN_SCIENCE_BOSS.reach : STUDENT.reach,
      attackHalfAngle: boss ? HYOSAN_SCIENCE_BOSS.halfAngle : STUDENT.halfAngle, defeatedAt: null };
  };
  const boss = () => enemies.find((enemy) => enemy.kind === 'boss');
  const nearby = (point: GroundPoint, ignore?: string) => distance(player, point) < 1.55 && physics.lineOfSight(player, point, ignore);
  const interaction = (): Hyosan3DSnapshot['interaction'] => {
    if (player.hp <= 0 || completed) return null;
    if (!resolved && originInspected && boss()?.hp === 0 && !echoCollected && nearby(plan.echo)) return 'echo';
    if (!equipment.kitCollected && nearby(plan.upgrade)) return 'upgrade';
    if (!shortcutOpened && !opening && player.z < gate.z - .2 && nearby(plan.shortcut, gate.id)) return 'shortcut';
    if (!originInspected && nearby(plan.origin, plan.origin.propId)) return 'origin';
    return null;
  };
  const hitsPlayer = (enemy: Enemy) => {
    const aim = direction(player.x - enemy.x, player.z - enemy.z);
    return sameHyosanCombatLayer(enemy, player) && distance(enemy, player) <= enemy.attackRange
      && aim.x * Math.sin(enemy.yaw) + aim.z * Math.cos(enemy.yaw) > Math.cos(enemy.attackHalfAngle)
      && physics.lineOfSight(enemy, player);
  };
  const walkToward = (enemy: Enemy, speed: number) => {
    const waypoint = navigate(enemy, player, enemy.kind === 'boss' ? .5 : .32, .32);
    const aim = direction(waypoint.x - enemy.x, waypoint.z - enemy.z);
    if (aim.x || aim.z) enemy.yaw = Math.atan2(aim.x, aim.z);
    const step = speed * ctx.dt * ctx.movementMultiplier(enemy, enemy.kind);
    Object.assign(enemy, physics.moveActor(enemy.id, aim.x * step, aim.z * step));
  };
  return {
    id: 'science', enemies, interaction,
    reset(raw, isResolved) {
      const saved = parseHyosanScienceSave(raw);
      resolved = isResolved; originInspected = resolved || saved?.originInspected === true;
      shortcutOpened = saved?.shortcutOpened === true; anchorReached = saved?.anchorReached === true;
      equipment.kitCollected ||= saved?.kitCollected === true;
      awaitingFirstShot = options.teachBow === true && !resolved && !originInspected && !anchorReached
        && !equipment.kitCollected && !(saved?.discoveredRooms.some((room) => room !== 'science-lab'));
      gateProgress = shortcutOpened ? 1 : 0; opening = false;
      physics.trySetPropPose(gate.id, gatePose(gateProgress));
      enemies.splice(0);
      if (!resolved) {
        for (const group of plan.encounters) for (let index = 0; index < group.count; index++) {
          enemies.push(createEnemy(`${group.id}-${index}`, { x: group.x + index % 2 * .95, z: group.z + Math.floor(index / 2) * .95 }));
        }
        enemies.push(createEnemy(plan.boss.id, plan.boss, true));
      }
      discovered = new Set(saved?.discoveredRooms ?? []);
      echoCollected = false; completed = false; firstEnteredAt = null; bossController.reset();
    },
    observePlayer() {
      const room = actualRoomAt(player);
      if (room) discovered.add(room);
      if (awaitingFirstShot && player.shotTime >= 0) { awaitingFirstShot = false; firstEnteredAt = ctx.time; }
      if (ctx.area === 'science' && !awaitingFirstShot && firstEnteredAt === null) {
        firstEnteredAt = ctx.time;
        const enemy = boss();
        if (originInspected && enemy && enemy.hp > 0 && !enemy.dormant) enemy.active = true;
      }
    },
    update({ interactPressed }) {
      if (player.hp <= 0) return;
      const time = ctx.time;
      if (!anchorReached && nearby(plan.checkpoint) && distance(player, plan.checkpoint) <= plan.checkpoint.radius) {
        anchorReached = true; ctx.checkpoint(plan.checkpoint);
      }
      if (interactPressed) {
        const action = interaction();
        if (action === 'origin') {
          originInspected = true; awaitingFirstShot = false; firstEnteredAt ??= ctx.time;
          const enemy = boss()!; enemy.dormant = false; enemy.active = true;
          Object.assign(enemy, physics.addActor(enemy.id, plan.boss, .5));
        }
        if (action === 'upgrade') { equipment.kitCollected = true; player.hp = Math.min(6, player.hp + 2); }
        if (action === 'shortcut') opening = true;
        if (action === 'echo') echoCollected = true;
        if (action) ctx.effect(action === 'shortcut' ? 'door' : 'upgrade', player, .7);
      }
      if (opening) {
        const next = Math.min(1, gateProgress + ctx.dt / .7);
        if (physics.trySetPropPose(gate.id, gatePose(next))) gateProgress = next;
        if (gateProgress === 1) { opening = false; shortcutOpened = true; }
      }
      for (const enemy of enemies) {
        if (enemy.hp <= 0 || enemy.dormant) continue;
        enemy.active ||= firstEnteredAt !== null && time - firstEnteredAt >= 2.2 && distance(enemy, player) < 9
          && (actualRoomAt(player) === enemy.homeRoom || distance(enemy, player) < 5 && physics.lineOfSight(enemy, player));
        if (!enemy.active) continue;
        if (enemy.kind === 'boss') {
          const frame = bossController.advance({ time, x: enemy.x, z: enemy.z, targetX: player.x, targetZ: player.z,
            distance: distance(enemy, player), visible: sameHyosanCombatLayer(enemy, player) && physics.lineOfSight(enemy, player) });
          enemy.scienceBeat = frame.beat === 'idle' ? undefined : frame.beat;
          enemy.attackPhase = frame.attackPhase; enemy.attackProgress = frame.attackProgress; enemy.yaw = frame.yaw;
          if (frame.speed > 0) walkToward(enemy, frame.speed);
          if (frame.strike && hitsPlayer(enemy)) ctx.hurtPlayer(2, enemy);
        } else if (enemy.attackPhase === 'idle') {
          enemy.yaw = Math.atan2(player.x - enemy.x, player.z - enemy.z);
          if (sameHyosanCombatLayer(enemy, player) && distance(enemy, player) <= 1.05 && physics.lineOfSight(enemy, player)) { enemy.attackPhase = 'windup'; enemy.since = time; }
          else walkToward(enemy, 1.05);
        } else if (enemy.attackPhase === 'windup' && time - enemy.since >= STUDENT.windup) {
          enemy.attackPhase = 'strike'; enemy.since = time; if (hitsPlayer(enemy)) ctx.hurtPlayer(1, enemy);
        } else if (enemy.attackPhase === 'strike' && time - enemy.since >= STUDENT.strike) { enemy.attackPhase = 'recover'; enemy.since = time; }
        else if (enemy.attackPhase === 'recover' && time - enemy.since >= STUDENT.recovery) { enemy.attackPhase = 'idle'; enemy.since = time; }
        if (enemy.kind === 'student') enemy.attackProgress = enemy.attackPhase === 'idle' ? 0 : Math.min(1,
          (time - enemy.since) / (enemy.attackPhase === 'windup' ? STUDENT.windup : enemy.attackPhase === 'strike' ? STUDENT.strike : STUDENT.recovery));
      }
    },
    afterCombat() {
      if (!resolved && player.hp > 0 && originInspected && boss()?.hp === 0 && echoCollected
        && player.x >= plan.exit.x + .3 && Math.abs(player.z - plan.exit.z) <= 1.2) completed = true;
    },
    markResolved() { resolved = true; completed = false; },
    readProgress() {
      const bow = hyosan3DBow(equipment.kitCollected, equipment.supplyCollected, equipment.piercingCollected, equipment.stringReinforced);
      const bossDefeated = resolved || boss()?.hp === 0;
      return { room: roomAt(player), discoveredRooms: [...discovered], originInspected, awaitingFirstShot, areaResolved: resolved,
        objective: completed ? 'completed' : resolved ? 'explore_school' : !originInspected ? 'inspect_lab' : !bossDefeated ? 'defeat_boss' : !echoCollected ? 'collect_echo' : 'reach_exit',
        upgraded: equipment.kitCollected, supplyCollected: equipment.supplyCollected, piercingCollected: equipment.piercingCollected,
        bowLevel: bow.level, bossDefeated, completed, echoCollected, anchorReached, shortcutOpened,
        incidentTriggered: false, entranceOpen: 1, inWater: ctx.movementMultiplier(player, 'player') < 1,
        activeWaterIds: [], incidentShortcutOpened: false };
    },
    exportSave: () => ({ version: 1, worldVersion: layout.version, originInspected, shortcutOpened,
      anchorReached, kitCollected: equipment.kitCollected, discoveredRooms: HYOSAN_SCIENCE_ROOMS.filter((room) => discovered.has(room)) }),
    respawnPoint: () => anchorReached ? plan.checkpoint : plan.spawn,
    furniture: () => [{ id: gate.id, ...gatePose(gateProgress), progress: gateProgress }],
  };
}
