export type HyosanLibraryBossBeat = 'stalk' | 'sidestep' | 'thrust-windup' | 'thrust'
  | 'check-windup' | 'check' | 'recovery' | 'death';
export const HYOSAN_LIBRARY_BOSS = {
  hp: 72, stalkSpeed: 2, sidestepDuration: .45, sidestepDistance: .55, recovery: 1.05,
  thrust: { windup: .65, duration: .18, distance: .8, range: 1.65, contactRange: .85, halfAngle: Math.PI * 35 / 180, damage: 2 },
  check: { windup: .7, duration: .12, range: 1.15, contactRange: 1.15, halfAngle: Math.PI * 65 / 180, damage: 1 },
} as const;
export interface HyosanLibraryBossInput {
  time: number; x: number; z: number; targetX: number; targetZ: number; distance: number;
  visible: boolean; sameLayer: boolean; canAttack?: boolean; dead?: boolean;
}

/** The region accepts motion through physics and deduplicates contact by attackId.
 * Time is the paused simulation clock; no input/arrow prediction is consumed.
 * Requested distance is finite even if a wall rejects every movement. */
export function createHyosanLibraryBossController() {
  let beat: HyosanLibraryBossBeat = 'stalk';
  let since = 0; let lastTime = -1; let yaw = 0; let side = 1; let sideYaw = 0;
  let nextAttack: 'thrust' | 'check' = 'thrust'; let attack: 'thrust' | 'check' = 'thrust';
  let attackId = 0; let requested = 0; let sidestepped = false;
  const reset = () => { beat = 'stalk'; since = 0; lastTime = -1; yaw = 0; side = 1; sideYaw = 0;
    nextAttack = 'thrust'; attack = 'thrust'; attackId = 0; requested = 0; sidestepped = false; };
  return {
    reset,
    advance(input: HyosanLibraryBossInput) {
      if (input.time < lastTime) reset();
      const changed = input.time !== lastTime;
      const previousTime = lastTime; lastTime = input.time;
      let strike = false; let moveX = 0; let moveZ = 0;
      const enter = (next: HyosanLibraryBossBeat) => { beat = next; since = input.time; requested = 0; };
      const mayCommit = input.sameLayer && input.visible && input.canAttack !== false;
      const commit = () => {
        yaw = Math.atan2(input.targetX - input.x, input.targetZ - input.z);
        attack = nextAttack; nextAttack = attack === 'thrust' ? 'check' : 'thrust'; attackId++;
        sidestepped = false;
        enter(attack === 'thrust' ? 'thrust-windup' : 'check-windup');
      };
      if (input.dead) enter('death');
      else if (changed && beat !== 'death') {
        if (beat === 'stalk' && mayCommit && input.distance <= (nextAttack === 'thrust' ? 1.6 : 1.1)
          && (attackId === 0 || input.time - since >= .3 - 1e-8)) {
          if (sidestepped) commit();
          else {
            yaw = Math.atan2(input.targetX - input.x, input.targetZ - input.z);
            sideYaw = yaw + side * Math.PI / 2; side *= -1; sidestepped = true; enter('sidestep');
          }
        } else if (beat === 'sidestep' && input.time - since >= HYOSAN_LIBRARY_BOSS.sidestepDuration - 1e-8) {
          if (mayCommit && input.distance <= (nextAttack === 'thrust' ? 1.6 : 1.1)) {
            commit();
          } else enter('stalk');
        } else if ((beat === 'thrust-windup' || beat === 'check-windup')
          && input.time - since >= HYOSAN_LIBRARY_BOSS[attack].windup - 1e-8) {
          enter(attack); strike = true;
        } else if ((beat === 'thrust' || beat === 'check')
          && input.time - since >= HYOSAN_LIBRARY_BOSS[attack].duration - 1e-8) enter('recovery');
        else if (beat === 'recovery' && input.time - since >= HYOSAN_LIBRARY_BOSS.recovery - 1e-8) enter('stalk');
      }
      const current: HyosanLibraryBossBeat = beat;
      if (changed && (current === 'sidestep' || current === 'thrust')) {
        const duration = current === 'sidestep' ? HYOSAN_LIBRARY_BOSS.sidestepDuration : HYOSAN_LIBRARY_BOSS.thrust.duration;
        const distance = current === 'sidestep' ? HYOSAN_LIBRARY_BOSS.sidestepDistance : HYOSAN_LIBRARY_BOSS.thrust.distance;
        // Integrate the upcoming fixed interval; the final partial step is capped.
        const dt = previousTime < 0 ? 0 : Math.min(1 / 60, Math.max(0, input.time - previousTime));
        const amount = Math.min(distance - requested, distance * dt / duration);
        requested += amount;
        const direction = current === 'sidestep' ? sideYaw : yaw;
        moveX = Math.sin(direction) * amount; moveZ = Math.cos(direction) * amount;
      }
      const windup = current === 'thrust-windup' || current === 'check-windup';
      const contact = current === 'thrust' || current === 'check';
      const duration = current === 'sidestep' ? HYOSAN_LIBRARY_BOSS.sidestepDuration
        : windup ? HYOSAN_LIBRARY_BOSS[attack].windup : contact ? HYOSAN_LIBRARY_BOSS[attack].duration : HYOSAN_LIBRARY_BOSS.recovery;
      const stats = HYOSAN_LIBRARY_BOSS[attack];
      return { beat: current, yaw, strike, attackId, contact: contact && input.sameLayer,
        attackPhase: windup ? 'windup' as const : contact ? 'strike' as const
          : current === 'stalk' || current === 'sidestep' ? 'idle' as const : 'recover' as const,
        attackProgress: current === 'stalk' || current === 'death' ? 0 : Math.min(1, Math.max(0, (input.time - since) / duration)),
        range: attack === 'thrust' ? stats.range - (current === 'thrust' ? requested : 0) : stats.range,
        contactRange: stats.contactRange, halfAngle: stats.halfAngle, damage: stats.damage,
        moveX, moveZ, speed: current === 'stalk' ? HYOSAN_LIBRARY_BOSS.stalkSpeed : 0 };
    },
  };
}
