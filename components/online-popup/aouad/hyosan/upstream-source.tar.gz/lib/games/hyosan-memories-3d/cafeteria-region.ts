import { planarDistance, distance, direction, distanceToSegment } from './combat-geometry';
import layout from '@/docs/games/hyosan-memories-3d/world-layout.json';
import { sameHyosanCombatLayer } from './combat-layers';
import type { GroundPoint } from './physics';
import { hyosan3DBow, parseHyosan3DSave } from './save';
import { hyosanCafeteriaEntrance } from './cafeteria-entrance';
import { createHyosanBossController, HYOSAN_BOSS_COMBO } from './boss-controller';
import { createHyosanIncidentWaterState, HYOSAN_INCIDENT_WATER_MULTIPLIER } from './incident-water';
import { createHyosanIncidentFurniture } from './incident-furniture';
import { createHyosanFiniteInflow } from './finite-inflow';
import { hyosanArrivalGeometry } from './arrival-geometry';
import { hyosan3DRoomAt, hyosan3DRoomForFloor } from './rooms';
import { createHyosanSupportGeometry } from './support-geometry';
import type { CombatEnemy, RegionInputEdges, RegionModule, SharedCombatContext } from './region-module';
import { HYOSAN_3D_ROOMS, type Hyosan3DRoom, type Hyosan3DSave, type Hyosan3DSnapshot } from './types';

const TICK = 1 / 60;
const MELEE = { studentReach: 1.05, bossReach: 1.85, contactAllowance: 0.2, halfAngle: Math.acos(0.35) } as const;
const CHARGE = { minRange: 4, maxRange: 9, windup: 0.85, duration: 0.45, distance: 4.2,
  contactRadius: 0.85, recovery: 1.2, cooldown: 4 } as const;
const touchesWetFloor = (point: GroundPoint) => Math.abs(point.y ?? 0) < .05;
// Capsule stems extend 1.1m, with caps of the actor's physical radius.
const bodiesOverlapVertically = (a: GroundPoint, aRadius: number, b: GroundPoint, bRadius: number) =>
  (a.y ?? 0) < (b.y ?? 0) + 1.1 + bRadius * 2 && (b.y ?? 0) < (a.y ?? 0) + 1.1 + aRadius * 2;
interface Enemy extends CombatEnemy {
  phaseSince: number; active: boolean; homeX: number; homeRoom: Hyosan3DRoom;
  activation: 'proximity' | 'incident' | 'climax';
  chargeReadyAt: number; chargeTravelled: number; chargeContact: boolean;
  arrivalIndex?: number;
}


/** Authored cafeteria incident; all combat bodies live in the shared school host. */
export function createHyosanCafeteriaRegion(context: SharedCombatContext): RegionModule<Hyosan3DSave> {
  const { source, physics, player, navigate: nextWaypoint, effect, hurtPlayer } = context;
  const adventure = source.adventure;
  const arrival = hyosanArrivalGeometry(source);
  const roster = [...source.encounters.flatMap((encounter) => Array.from({ length: encounter.count }, (_, index) => `${encounter.id}-${index}`)), source.boss.id];
  const inflow = arrival ? createHyosanFiniteInflow(arrival, roster) : null;
  const entrance = hyosanCafeteriaEntrance(source);
  const bossController = createHyosanBossController();
  const furniture = createHyosanIncidentFurniture(source, physics.trySetPropPose);
  const water = createHyosanIncidentWaterState();
  const enemies: Enemy[] = [];
  let resolved = false; let enteredAt: number | null = null;
  let waterNeedsReset = false;
  let incidentTriggered = false; let shortcutOpened = false; let anchorReached = false;
  let echoCollected = false; let completed = false; let entranceOpening = false; let entranceOpen = 0;
  let discoveredRooms = new Set<Hyosan3DRoom>();
  const roomAt = (point: GroundPoint): Hyosan3DRoom => hyosan3DRoomAt(point, source.floors);
  const support = createHyosanSupportGeometry(source);
  const supportRooms = new Map(support.surfaces.map((surface) => [surface.surfaceId,
    hyosan3DRoomForFloor({ id: surface.surfaceId, roomId: surface.roomId })]));
  const exportSave = (): Hyosan3DSave => ({ version: 1, worldVersion: layout.version, kitCollected: context.equipment.kitCollected,
    supplyCollected: context.equipment.supplyCollected, incidentTriggered, shortcutOpened, anchorReached,
    discoveredRooms: HYOSAN_3D_ROOMS.some((room) => discoveredRooms.has(room)) ? HYOSAN_3D_ROOMS.filter((room) => discoveredRooms.has(room)) : ['infirmary'] });
  const createEnemy = (id: string, position: GroundPoint, boss = false): Enemy => {
    const hp = resolved ? 0 : boss ? 48 : 2;
    const dormant = Boolean(resolved || inflow?.includes(id) || boss && adventure);
    const placed = dormant ? { ...position, y: physics.heightAt(position) ?? 0 }
      : physics.addActor(id, position, boss ? 0.5 : 0.32);
    return { ownerArea: 'cafeteria', id, ...placed, yaw: Math.PI, hp, maxHp: hp, kind: boss ? 'boss' : 'student',
      dormant,
      attackStyle: 'melee', attackRange: (boss ? MELEE.bossReach : MELEE.studentReach) + MELEE.contactAllowance,
      attackHalfAngle: boss && adventure ? HYOSAN_BOSS_COMBO.sweepHalfAngle : MELEE.halfAngle,
      ...(boss && adventure ? { comboBeat: 'idle' as const } : {}),
      attackPhase: 'idle', attackProgress: 0, defeatedAt: null, phaseSince: 0, active: false, homeX: position.x, homeRoom: roomAt(position),
      activation: !boss && adventure && roomAt(position) === 'cafeteria'
        ? position.x >= adventure.bossBoundary.minX && !adventure.incidentStudents.includes(id) ? 'climax' : 'incident' : 'proximity',
      chargeReadyAt: 0, chargeTravelled: 0, chargeContact: false };
  };
  const reset = (raw: unknown, isResolved: boolean) => {
    resolved = isResolved; enteredAt = null;
    const saved = adventure ? parseHyosan3DSave(raw) : null;
    context.equipment.kitCollected ||= saved?.kitCollected === true;
    context.equipment.supplyCollected ||= saved?.supplyCollected === true;
    incidentTriggered = resolved || saved?.incidentTriggered === true;
    shortcutOpened = saved?.shortcutOpened === true; anchorReached = saved?.anchorReached === true;
    echoCollected = resolved; completed = false;
    entranceOpening = incidentTriggered; entranceOpen = incidentTriggered ? 1 : 0;
    physics.setEntranceOpen(entranceOpen); physics.setShortcutOpen(shortcutOpened);
    furniture.reset(incidentTriggered); bossController.reset(); inflow?.reset();
    enemies.length = 0;
    for (const encounter of source.encounters) for (let index = 0; index < encounter.count; index++) {
      enemies.push(createEnemy(`${encounter.id}-${index}`, {x: encounter.x + index % 2 * .95,
        z: encounter.z + Math.floor(index / 2) * .95}));
    }
    enemies.push(createEnemy(source.boss.id, source.boss, true));
    waterNeedsReset = true;
    discoveredRooms = new Set(saved?.discoveredRooms ?? []);
  };
  const waterOccupants = () => [
    ...(player.hp > 0 && touchesWetFloor(player) ? [{ x: player.x, z: player.z, radius: .32 }] : []),
    ...context.enemies.filter((enemy) => enemy.kind === 'student' && enemy.hp > 0 && !enemy.dormant && touchesWetFloor(enemy))
      .map((enemy) => ({ x: enemy.x, z: enemy.z, radius: .32 })),
  ];
  const visible = (from: GroundPoint, to: GroundPoint) => sameHyosanCombatLayer(from, to) && physics.lineOfSight(from, to);
  const nearby = (point: GroundPoint, ignoreGeometry?: string) => distance(player, point) < 1.55 && physics.lineOfSight(player, point, ignoreGeometry);
  const interaction = (): Exclude<Hyosan3DSnapshot['interaction'], 'origin' | 'barricade' | 'hose'> => {
    if (player.hp <= 0 || completed) return null;
    if (adventure && !echoCollected && enemies.find((enemy) => enemy.kind === 'boss')!.hp === 0 && nearby(adventure.echo)) return 'echo';
    if (adventure && !context.equipment.supplyCollected && nearby(adventure.supply)) return 'supply';
    if (!context.equipment.kitCollected && nearby(source.upgrade)) return 'upgrade';
    if (adventure && !shortcutOpened && player.z > adventure.shortcut.z + 0.2 && nearby(adventure.shortcut, adventure.shortcut.id)) return 'shortcut';
    return null;
  };
  const inside = (point: GroundPoint, boundary: { minX: number; maxX: number; minZ: number; maxZ: number }) =>
    point.x >= boundary.minX && point.x <= boundary.maxX && point.z >= boundary.minZ && point.z <= boundary.maxZ;
  const waterMultiplier = (point: GroundPoint) => adventure && touchesWetFloor(point) && water.contains(point)
    ? HYOSAN_INCIDENT_WATER_MULTIPLIER : 1;
  const update = ({interactPressed}: Readonly<RegionInputEdges>) => {
    if (adventure) {
      if (!anchorReached && distance(player, adventure.checkpoint) <= adventure.checkpoint.radius
        && physics.lineOfSight(player, adventure.checkpoint)) {
        anchorReached = true; context.checkpoint(adventure.checkpoint);
      }
      incidentTriggered ||= inside(player, adventure.incident);
      furniture.update(incidentTriggered, TICK);
      water.update(incidentTriggered, waterOccupants());
      if (entrance) {
        const nearDoor = Math.hypot(player.x - entrance.x,
          Math.max(0, Math.abs(player.z - entrance.z) - entrance.width / 2)) <= entrance.triggerRadius;
        if (!entranceOpening && (nearDoor || incidentTriggered)) {
          entranceOpening = true; effect('door', entrance, .65);
        }
        if (entranceOpening && entranceOpen < 1) {
          const next = Math.min(1, entranceOpen + TICK / entrance.openingDuration);
          if (physics.setEntranceOpen(next)) entranceOpen = next;
        }
      }
      const boss = enemies.find((enemy) => enemy.kind === 'boss')!;
      inflow?.update({ incident: incidentTriggered && roomAt(player) === 'cafeteria',
        advanced: Boolean(arrival && inside(player, arrival.advanceBoundary)),
        climax: incidentTriggered && inside(player, adventure.bossBoundary) });
      if (!inflow && boss.dormant && incidentTriggered && inside(player, adventure.bossBoundary)) {
        boss.dormant = false; boss.active = true;
        Object.assign(boss, physics.addActor(boss.id, boss, 0.5));
      }
    }
    if (interactPressed) {
      const action = interaction();
      if (action === 'upgrade') context.equipment.kitCollected = true;
      if (action === 'supply') context.equipment.supplyCollected = true;
      if (action === 'echo') echoCollected = true;
      if (action === 'shortcut') { shortcutOpened = true; physics.setShortcutOpen(true); }
      if (action) {
        if (action === 'upgrade' || action === 'supply') player.hp = Math.min(player.maxHp, player.hp + 2);
        effect('upgrade', action === 'upgrade' ? source.upgrade : action === 'supply' ? adventure!.supply : action === 'echo' ? adventure!.echo : adventure!.shortcut, 1.2);
      }
    }
    for (const enemy of enemies) {
      if (enemy.hp <= 0 || enemy.dormant) continue;
      // Each requested actor is fully alive on the gallery floor. Follow the
      // authored bend until entering the room, unless the player engages it.
      if (arrival && enemy.arrivalIndex !== undefined) {
        const engaged = distance(enemy, player) < 2 && visible(enemy, player);
        const goal = arrival.path[enemy.arrivalIndex];
        if (engaged || !goal) {
          enemy.arrivalIndex = undefined; enemy.entering = false;
        } else {
          if (distance(enemy, goal) < .18) enemy.arrivalIndex++;
          else {
            const radius = enemy.kind === 'boss' ? .5 : .32;
            const waypoint = nextWaypoint(enemy, goal, radius, radius);
            const heading = direction(waypoint.x - enemy.x, waypoint.z - enemy.z);
            enemy.yaw = Math.atan2(heading.x, heading.z);
            const speed = enemy.kind === 'boss' ? 2.1 : 1.7 * context.movementMultiplier(enemy, enemy.kind);
            Object.assign(enemy, physics.moveActor(enemy.id, heading.x * TICK * speed, heading.z * TICK * speed));
          }
          continue;
        }
      }
      enemy.active ||= enemy.activation === 'incident' ? incidentTriggered && roomAt(player) === 'cafeteria'
        : enemy.activation === 'climax' ? !enemies.find((candidate) => candidate.kind === 'boss')!.dormant
        : enteredAt !== null && context.time - enteredAt >= 2 && (adventure
          ? distance(enemy, player) <= 9 && (roomAt(player) === enemy.homeRoom || distance(enemy, player) <= 5 && visible(enemy, player))
          : enemy.homeX < -6 || player.x > (enemy.kind === 'boss' ? 10 : enemy.homeX < 2 ? -6.5 : 1));
      if (!enemy.active) continue;
      const boss = enemy.kind === 'boss';
      if (boss && adventure) {
        const before = bossController.read().beat;
        const targetDistance = distance(enemy, player);
        const seesPlayer = targetDistance <= HYOSAN_BOSS_COMBO.startRange && visible(enemy, player);
        const frame = bossController.advance({ time: context.time, x: enemy.x, z: enemy.z, targetX: player.x, targetZ: player.z,
          hp: enemy.hp, maxHp: enemy.maxHp, lineOfSight: seesPlayer,
          // A nearby target needs to be within the actual 3D swing reach, not
          // occupy a spot large enough for the nurse's wider body. At range,
          // require a real approach so visible tabletops still cause a detour.
          canStartCombo: before !== 'idle' || seesPlayer && (targetDistance <= HYOSAN_BOSS_COMBO.sweepRange
            || physics.clearGround(enemy, player, .5)) });
        if (frame.beat === 'idle') {
          const waypoint = nextWaypoint(enemy, player, .5, .32);
          const heading = direction(waypoint.x - enemy.x, waypoint.z - enemy.z);
          Object.assign(enemy, physics.moveActor(enemy.id, heading.x * TICK * 2.1, heading.z * TICK * 2.1));
        }
        if (frame.moveDistance > 0) {
          const from = { x: enemy.x, y: enemy.y, z: enemy.z };
          Object.assign(enemy, physics.moveActor(enemy.id, Math.sin(frame.yaw) * frame.moveDistance,
            Math.cos(frame.yaw) * frame.moveDistance, { slide: false }));
          const movedDistance = planarDistance(from, enemy);
          const forward = (player.x - from.x) * Math.sin(frame.yaw) + (player.z - from.z) * Math.cos(frame.yaw);
          const contact = forward >= 0 && distanceToSegment(player, from, enemy) <= HYOSAN_BOSS_COMBO.chargeContactRadius && visible(enemy, player);
          if (bossController.resolveCharge({ x: enemy.x, z: enemy.z, targetX: player.x, targetZ: player.z,
            movedDistance, blocked: movedDistance < frame.moveDistance - .001, contact })) hurtPlayer(2, enemy);
        }
        const pose = bossController.read();
        const { beat, ...presentation } = pose;
        Object.assign(enemy, presentation, { comboBeat: beat });
        if (beat === 'tremor' && before !== beat) effect('boss-warning', enemy, .9);
        if (frame.strike === 'sweep') {
          effect('boss-sweep', enemy, .35);
          const aim = direction(player.x - enemy.x, player.z - enemy.z);
          if (distance(enemy, player) <= pose.attackRange
            && aim.x * Math.sin(pose.yaw) + aim.z * Math.cos(pose.yaw) > Math.cos(pose.attackHalfAngle)
            && visible(enemy, player)) hurtPlayer(2, enemy);
        }
        continue;
      }
      const range = boss ? MELEE.bossReach : MELEE.studentReach;
      const windup = enemy.attackStyle === 'charge' ? CHARGE.windup : boss ? 0.85 : 0.55;
      if (enemy.attackPhase === 'idle') {
        enemy.yaw = Math.atan2(player.x - enemy.x, player.z - enemy.z);
        if (distance(enemy, player) <= range && visible(enemy, player)) {
          enemy.attackStyle = 'melee'; enemy.attackRange = range + MELEE.contactAllowance;
          enemy.attackPhase = 'windup'; enemy.phaseSince = context.time;
        } else if (boss && context.time >= enemy.chargeReadyAt && distance(enemy, player) >= CHARGE.minRange
          && distance(enemy, player) <= CHARGE.maxRange && visible(enemy, player)) {
          enemy.attackStyle = 'charge'; enemy.attackRange = CHARGE.distance + CHARGE.contactRadius;
          enemy.attackPhase = 'windup'; enemy.phaseSince = context.time;
          enemy.chargeReadyAt = context.time + CHARGE.cooldown;
          enemy.chargeTravelled = 0; enemy.chargeContact = false;
        } else {
          const waypoint = nextWaypoint(enemy, player, boss ? 0.5 : 0.32, 0.32);
          const heading = direction(waypoint.x - enemy.x, waypoint.z - enemy.z);
          const pursuitSpeed = boss ? 2.1 : 1.05 * context.movementMultiplier(enemy, enemy.kind);
          Object.assign(enemy, physics.moveActor(enemy.id, heading.x * TICK * pursuitSpeed, heading.z * TICK * pursuitSpeed));
        }
      } else if (enemy.attackPhase === 'windup' && context.time - enemy.phaseSince >= windup) {
        enemy.attackPhase = 'strike'; enemy.phaseSince = context.time;
        if (enemy.attackStyle === 'melee') {
          const aim = direction(player.x - enemy.x, player.z - enemy.z);
          const facing = aim.x * Math.sin(enemy.yaw) + aim.z * Math.cos(enemy.yaw);
          if (distance(enemy, player) <= enemy.attackRange && facing > Math.cos(enemy.attackHalfAngle)
            && visible(enemy, player)) hurtPlayer(boss ? 2 : 1, enemy);
        }
      } else if (enemy.attackPhase === 'strike' && context.time - enemy.phaseSince >= (enemy.attackStyle === 'charge' ? CHARGE.duration : 0.16)) {
        enemy.attackPhase = 'recover'; enemy.phaseSince = context.time;
      } else if (enemy.attackPhase === 'recover' && context.time - enemy.phaseSince >= (enemy.attackStyle === 'charge' ? CHARGE.recovery : boss ? 1.05 : 0.85)) {
        enemy.attackPhase = 'idle'; enemy.phaseSince = context.time;
      }
      if (enemy.attackStyle === 'charge' && enemy.attackPhase === 'strike') {
        const from = { x: enemy.x, y: enemy.y, z: enemy.z };
        const requested = Math.min(CHARGE.distance - enemy.chargeTravelled, CHARGE.distance / CHARGE.duration * TICK);
        Object.assign(enemy, physics.moveActor(enemy.id, Math.sin(enemy.yaw) * requested, Math.cos(enemy.yaw) * requested, { slide: false }));
        const moved = planarDistance(from, enemy);
        enemy.chargeTravelled += moved;
        if (!enemy.chargeContact && distanceToSegment(player, from, enemy) <= CHARGE.contactRadius && visible(enemy, player)) {
          enemy.chargeContact = true;
          hurtPlayer(2, enemy);
        }
        if (moved < requested - 0.001 || enemy.chargeTravelled >= CHARGE.distance - 0.001) {
          enemy.attackPhase = 'recover'; enemy.phaseSince = context.time;
        }
      }
      const strikeDuration = enemy.attackStyle === 'charge' ? CHARGE.duration : 0.16;
      const recovery = enemy.attackStyle === 'charge' ? CHARGE.recovery : boss ? 1.05 : 0.85;
      enemy.attackProgress = Math.min(1, (context.time - enemy.phaseSince) / (enemy.attackPhase === 'windup' ? windup : enemy.attackPhase === 'strike' ? strikeDuration : recovery));
    }
  };
  const afterCombat = () => {
    if (inflow && arrival) {
      // Damage and resolution precede admission, including the boss's last-hit
      // frame. A visible spawn or an occupied capsule never consumes a slot.
      inflow.update({ resolved: enemies.find((enemy) => enemy.kind === 'boss')!.hp === 0 });
      const inGallery = Math.abs(player.x - arrival.floor.x) <= arrival.floor.width / 2
        && Math.abs(player.z - arrival.floor.z) <= arrival.floor.depth / 2;
      const id = inflow.read().pending[0];
      const enemy = id ? enemies.find((candidate) => candidate.id === id) : undefined;
      if (enemy && player.hp > 0 && !inGallery && distance(player, arrival.spawn) > 2.5
        && !visible(player, arrival.spawn)) {
        const radius = enemy.kind === 'boss' ? .5 : .32;
        const occupants = [player, ...context.enemies.filter((candidate) => candidate.hp > 0 && !candidate.dormant)];
        const clear = physics.canStand(arrival.spawn, radius + .035)
          && occupants.every((other) => {
            const otherRadius = 'kind' in other && other.kind === 'boss' ? .5 : .32;
            return !bodiesOverlapVertically(arrival.spawn, radius, other, otherRadius)
              || planarDistance(arrival.spawn, other) >= radius + otherRadius + .12;
          });
        if (clear && inflow.commitEntry(enemy.id)) {
          Object.assign(enemy, arrival.spawn, { dormant: false, active: true, entering: true, arrivalIndex: 0 });
          Object.assign(enemy, physics.addActor(enemy.id, arrival.spawn, radius));
        }
      }
    }
    const exit = source.doors.find((door) => door.id === 'next-area')!;
    if (!resolved && player.hp > 0 && (adventure ? echoCollected : context.equipment.kitCollected && enemies.find((enemy) => enemy.kind === 'boss')!.hp === 0) && distance(player, exit) < 0.8) {
      completed = true;
    }
  };
  const readProgress = (): Hyosan3DSnapshot['progress'] => {
      const bossDefeated = enemies.find((enemy) => enemy.kind === 'boss')!.hp === 0;
      const bossDormant = enemies.find((enemy) => enemy.kind === 'boss')!.dormant;
      const bow = hyosan3DBow(context.equipment.kitCollected, context.equipment.supplyCollected, context.equipment.piercingCollected);
      const room = roomAt(player);
      const encounter = inflow?.read();
      const bossApproaching = encounter?.phase === 'climax'
        && enemies.some((enemy) => enemy.kind === 'boss' && enemy.hp > 0 && (enemy.dormant || enemy.entering));
      return { areaResolved: resolved, room, discoveredRooms: [...discoveredRooms], upgraded: context.equipment.kitCollected, bossDefeated, completed,
          anchorReached, incidentTriggered, shortcutOpened, entranceOpen, inWater: waterMultiplier(player) < 1,
          activeWaterIds: water.activeIds(), incidentShortcutOpened: furniture.shortcutOpen(),
          bossApproaching,
          supplyCollected: context.equipment.supplyCollected, echoCollected, bowLevel: bow.level,
          objective: resolved ? 'explore_school' : completed ? 'completed' : adventure
            ? echoCollected ? 'reach_exit' : bossDefeated ? 'collect_echo' : !incidentTriggered ? 'reach_cafeteria' : bossDormant && encounter?.phase !== 'climax' ? 'explore_cafeteria' : 'defeat_boss'
            : !context.equipment.kitCollected ? 'find_upgrade' : bossDefeated ? 'reach_exit' : room === 'cafeteria' ? 'defeat_boss' : 'reach_cafeteria' };
  };
  return {
    id: 'cafeteria', enemies, reset, update, afterCombat, readProgress, interaction, exportSave,
    observePlayer() {
      if (waterNeedsReset) { water.reset(incidentTriggered, waterOccupants()); waterNeedsReset = false; }
      if (context.area === 'cafeteria' && enteredAt === null) enteredAt = context.time;
      const surfaceId = support.sample(player)?.surfaceId;
      const room = surfaceId ? supportRooms.get(surfaceId) : null;
      if (room && HYOSAN_3D_ROOMS.some((candidate) => candidate === room)) discoveredRooms.add(room);
    },
    markResolved() { resolved = true; completed = false; },
    respawnPoint() { return anchorReached && adventure ? adventure.checkpoint : source.spawn; },
    furniture: furniture.read,
    inflow: () => inflow?.read(),
    movementMultiplier(point, kind) { return kind === 'boss' ? 1 : waterMultiplier(point); },
    onHit(enemy) {
      const own = enemy as Enemy; own.arrivalIndex = undefined; own.entering = false;
    },
  };
}
