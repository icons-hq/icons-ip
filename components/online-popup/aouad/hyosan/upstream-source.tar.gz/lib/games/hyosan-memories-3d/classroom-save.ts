import layout from '@/docs/games/hyosan-memories-3d/world-layout.json';
import { HYOSAN_CLASSROOM_ROOMS } from './types';

export type HyosanClassroomRoom = typeof HYOSAN_CLASSROOM_ROOMS[number];
export interface ClassroomSaveDTO {
  version: 1; worldVersion: string;
  barricadeReleased: boolean; shortcutOpened: boolean; anchorReached: boolean; piercingCollected: boolean;
  discoveredRooms: readonly HyosanClassroomRoom[];
}
const flags = ['barricadeReleased', 'shortcutOpened', 'anchorReached', 'piercingCollected'] as const;
const fields = ['version', 'worldVersion', 'discoveredRooms', ...flags];

/** S3 starts with world v7; combat, echo and region completion belong to the live attempt/campaign. */
export function parseHyosanClassroomSave(raw: unknown): ClassroomSaveDTO | null {
  try {
    const value: unknown = typeof raw === 'string' ? JSON.parse(raw) : raw;
    if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
    const candidate = value as Record<string, unknown>;
    if (Object.keys(candidate).length !== fields.length || Object.keys(candidate).some((key) => !fields.includes(key))) return null;
    const supportedWorld = candidate.worldVersion === layout.version || layout.version === 'hyosan-3d-school-v12'
      && ['hyosan-3d-school-v7', 'hyosan-3d-school-v8', 'hyosan-3d-school-v9', 'hyosan-3d-school-v10', 'hyosan-3d-school-v11'].includes(candidate.worldVersion as string);
    if (candidate.version !== 1 || !supportedWorld || flags.some((key) => typeof candidate[key] !== 'boolean')) return null;
    const rooms = candidate.discoveredRooms;
    if (!Array.isArray(rooms) || !rooms.length || rooms.length > HYOSAN_CLASSROOM_ROOMS.length || new Set(rooms).size !== rooms.length
      || Array.from(rooms).some((room) => !HYOSAN_CLASSROOM_ROOMS.includes(room))) return null;
    return { version: 1, worldVersion: layout.version, barricadeReleased: candidate.barricadeReleased as boolean,
      shortcutOpened: candidate.shortcutOpened as boolean, anchorReached: candidate.anchorReached as boolean,
      piercingCollected: candidate.piercingCollected as boolean, discoveredRooms: HYOSAN_CLASSROOM_ROOMS.filter((room) => rooms.includes(room)) };
  } catch { return null; }
}

export function serializeHyosanClassroomSave(save: ClassroomSaveDTO): string {
  const validated = parseHyosanClassroomSave(save);
  if (!validated) throw new TypeError('Invalid Hyosan classroom exploration save');
  return JSON.stringify(validated);
}
