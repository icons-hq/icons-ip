import layout from '@/docs/games/hyosan-memories-3d/world-layout.json';
import { HYOSAN_3D_ROOMS, type Hyosan3DBow, type Hyosan3DSave } from './types';

export const HYOSAN_3D_SAVE_KEY = 'hyosan-memories-3d-adventure-v1';
const flags = ['kitCollected', 'supplyCollected', 'incidentTriggered', 'shortcutOpened', 'anchorReached'] as const;
const fields = ['version', 'worldVersion', 'discoveredRooms', ...flags];

/** Validate untrusted storage before the explicit v2–v11 → v12 extension migration. */
export function parseHyosan3DSave(raw: unknown): Hyosan3DSave | null {
  try {
    const value: unknown = typeof raw === 'string' ? JSON.parse(raw) : raw;
    if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
    const candidate = value as Record<string, unknown>;
    if (Object.keys(candidate).length !== fields.length || Object.keys(candidate).some((key) => !fields.includes(key))) return null;
    // v12 appends the rooftop region; the existing six S2 rooms and flags are unchanged.
    // Future revisions must explicitly declare their own save compatibility.
    const supportedWorld = candidate.worldVersion === layout.version
      || (layout.version === 'hyosan-3d-school-v12'
        && ['hyosan-3d-school-v2', 'hyosan-3d-school-v3', 'hyosan-3d-school-v4', 'hyosan-3d-school-v5',
          'hyosan-3d-school-v6', 'hyosan-3d-school-v7', 'hyosan-3d-school-v8', 'hyosan-3d-school-v9', 'hyosan-3d-school-v10', 'hyosan-3d-school-v11'].includes(candidate.worldVersion as string));
    if (candidate.version !== 1 || !supportedWorld || flags.some((key) => typeof candidate[key] !== 'boolean')) return null;
    const rooms = candidate.discoveredRooms;
    if (!Array.isArray(rooms) || !rooms.length || rooms.length > HYOSAN_3D_ROOMS.length
      || new Set(rooms).size !== rooms.length || Array.from(rooms).some((room) => !HYOSAN_3D_ROOMS.includes(room))) return null;
    return { version: 1, worldVersion: layout.version, kitCollected: candidate.kitCollected as boolean,
      supplyCollected: candidate.supplyCollected as boolean, incidentTriggered: candidate.incidentTriggered as boolean,
      shortcutOpened: candidate.shortcutOpened as boolean, anchorReached: candidate.anchorReached as boolean,
      discoveredRooms: HYOSAN_3D_ROOMS.filter((room) => rooms.includes(room)) };
  } catch { return null; }
}

export function serializeHyosan3DSave(save: Hyosan3DSave): string {
  const validated = parseHyosan3DSave(save);
  if (!validated) throw new TypeError('Invalid Hyosan exploration save');
  return JSON.stringify(validated);
}

export function hyosan3DBow(kit: boolean, supply: boolean, piercing = false, stringReinforced = false, tipReinforced = false): Hyosan3DBow {
  const upgrades = Number(kit) + Number(supply);
  const penetration = Number(piercing) + Number(tipReinforced);
  return { level: (upgrades + Number(piercing) + 1) as Hyosan3DBow['level'], damage: upgrades ? 2 : 1,
    interval: upgrades === 2 ? 0.25 : 0.32, ...(penetration ? { penetration } : {}), ...(stringReinforced ? { projectileSpeed: 28 } : {}) };
}
