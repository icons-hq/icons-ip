import { createHyosanElevatedRouteGeometry, type HyosanElevatedRoute } from './elevated-routes';

import { HYOSAN_MAIN_LAYER } from './combat-layers';
export interface HyosanSupportPoint { x: number; z: number; y?: number; surfaceId?: string; currentLayerId?: string }
export interface HyosanSupportFloor {
  id: string; x: number; z: number; width: number; depth: number;
  y?: number; thickness?: number; currentLayerId?: string; roomId?: string; label?: string;
}
export interface HyosanSupportRamp {
  id: string; roomId: string; width: number;
  start: { x: number; y: number; z: number }; end: { x: number; y: number; z: number };
  fromFloorId: string; toFloorId: string;
}
export interface HyosanStair {
  id: string; roomId: string; width: number; steps: number;
  start: { x: number; y: number; z: number }; end: { x: number; y: number; z: number };
  fromFloorId: string; toFloorId: string;
}
/** Axis is the crossing normal; width spans the other horizontal axis. */
export interface HyosanLayerTransition {
  id: string; fromFloorId: string; toFloorId: string; fromLayerId: string; toLayerId: string;
  x: number; y: number; z: number; width: number; height: number; axis: string;
}
export interface HyosanSupportSample {
  height: number; slopeX: number; slopeZ: number; surfaceId: string; currentLayerId: string;
  kind: 'floor' | 'deck' | 'ramp' | 'stair'; stairId?: string; stepIndex?: number; rampId?: string;
}
export interface HyosanSupportSurface extends HyosanSupportSample {
  x: number; z: number; width: number; depth: number; roomId?: string; collisionId: string;
}
export interface HyosanSupportSource {
  floors: readonly HyosanSupportFloor[];
  elevatedRoutes?: readonly HyosanElevatedRoute[];
  stairs?: readonly HyosanStair[];
  supportRamps?: readonly HyosanSupportRamp[];
  layerTransitions?: readonly HyosanLayerTransition[];
}
const contains = (surface: { x: number; z: number; width: number; depth: number }, point: { x: number; z: number }) =>
  Math.abs(point.x - surface.x) <= surface.width / 2 + 1e-8 && Math.abs(point.z - surface.z) <= surface.depth / 2 + 1e-8;
const surfaceHeight = (surface: HyosanSupportSurface, point: { x: number; z: number }) =>
  surface.height + (point.x - surface.x) * surface.slopeX + (point.z - surface.z) * surface.slopeZ;

interface SupportBounds { minX: number; maxX: number; minZ: number; maxZ: number }
type SupportTree = SupportBounds & ({ indices: readonly number[] } | { left: SupportTree; right: SupportTree });

/** Immutable authored rectangles: space scales with surface count, not world area. */
function indexSupports(surfaces: readonly HyosanSupportSurface[]) {
  const bounds = surfaces.map((s): SupportBounds => {
    // Be conservative at both the contract epsilon and large-world rounding;
    // contains() remains the exact final acceptance test.
    const px = 1e-8 + Number.EPSILON * (Math.abs(s.x) + s.width) * 4;
    const pz = 1e-8 + Number.EPSILON * (Math.abs(s.z) + s.depth) * 4;
    return { minX: s.x - s.width / 2 - px, maxX: s.x + s.width / 2 + px,
      minZ: s.z - s.depth / 2 - pz, maxZ: s.z + s.depth / 2 + pz };
  });
  const build = (indices: number[]): SupportTree => {
    const box: SupportBounds = { minX: Infinity, maxX: -Infinity, minZ: Infinity, maxZ: -Infinity };
    for (const i of indices) {
      box.minX = Math.min(box.minX, bounds[i].minX); box.maxX = Math.max(box.maxX, bounds[i].maxX);
      box.minZ = Math.min(box.minZ, bounds[i].minZ); box.maxZ = Math.max(box.maxZ, bounds[i].maxZ);
    }
    if (indices.length <= 8) return { ...box, indices };
    const axis = box.maxX - box.minX >= box.maxZ - box.minZ ? 'x' : 'z';
    indices.sort((a, b) => surfaces[a][axis] - surfaces[b][axis]);
    const middle = Math.floor(indices.length / 2);
    return { ...box, left: build(indices.slice(0, middle)), right: build(indices.slice(middle)) };
  };
  const root = build(surfaces.map((_, index) => index));
  return (point: { x: number; z: number }) => {
    const found: number[] = [];
    const visit = (node: SupportTree) => {
      if (point.x < node.minX || point.x > node.maxX || point.z < node.minZ || point.z > node.maxZ) return;
      if ('indices' in node) {
        for (const index of node.indices) if (contains(surfaces[index], point)) found.push(index);
      } else { visit(node.left); visit(node.right); }
    };
    visit(root);
    // Candidate order breaks equal-height ties and is part of the old contract.
    return found.sort((a, b) => a - b).map((index) => surfaces[index]);
  };
}

/** Authored supports, exact stair treads and layer portals, independent of Rapier. */
export function createHyosanSupportGeometry(source: HyosanSupportSource) {
  const floors = structuredClone(source.floors);
  const elevated = createHyosanElevatedRouteGeometry(source);
  const ids = new Set<string>();
  const surfaces: HyosanSupportSurface[] = floors.map((floor) => {
    if (ids.has(floor.id) || ![floor.x, floor.z, floor.width, floor.depth, floor.y ?? 0, floor.thickness ?? .2].every(Number.isFinite)
      || floor.width <= 0 || floor.depth <= 0 || (floor.thickness ?? .2) <= 0) throw new Error('Invalid Hyosan support floor');
    ids.add(floor.id);
    return { ...floor, surfaceId: floor.id, collisionId: floor.id, kind: 'floor', height: floor.y ?? 0,
      slopeX: 0, slopeZ: 0, currentLayerId: floor.currentLayerId ?? HYOSAN_MAIN_LAYER };
  });
  for (const route of elevated.routes) surfaces.push({ ...route.deck, surfaceId: `${route.id}:deck`, collisionId: route.propId,
    roomId: route.roomId, kind: 'deck', slopeX: 0, slopeZ: 0, currentLayerId: HYOSAN_MAIN_LAYER });
  for (const ramp of elevated.ramps) surfaces.push({ ...ramp, height: ramp.height / 2, surfaceId: ramp.id, collisionId: ramp.id,
    kind: 'ramp', currentLayerId: HYOSAN_MAIN_LAYER });
  const ramps = structuredClone(source.supportRamps ?? []).map((ramp) => {
    const from = surfaces.find((floor) => floor.surfaceId === ramp.fromFloorId && floor.kind === 'floor');
    const to = surfaces.find((floor) => floor.surfaceId === ramp.toFloorId && floor.kind === 'floor');
    const dx = ramp.end.x - ramp.start.x; const dz = ramp.end.z - ramp.start.z;
    const run = Math.hypot(dx, dz); const rise = ramp.end.y - ramp.start.y;
    if (ids.has(ramp.id) || !from || !to || ![ramp.width, ...Object.values(ramp.start), ...Object.values(ramp.end)].every(Number.isFinite)
      || ramp.width <= 0 || run <= 0 || rise === 0 || (dx !== 0 && dz !== 0) || Math.abs(rise / run) > Math.tan(Math.PI * 35 / 180)
      || Math.abs(from.height - ramp.start.y) > 1e-8 || Math.abs(to.height - ramp.end.y) > 1e-8
      || from.currentLayerId !== to.currentLayerId) throw new Error(`Invalid Hyosan support ramp ${ramp.id}`);
    const axis = dx === 0 ? 'z' as const : 'x' as const; const across = axis === 'z' ? 'x' : 'z';
    const directionSign = Math.sign(axis === 'x' ? dx : dz);
    const fromEdge = from[axis] + directionSign * (axis === 'x' ? from.width : from.depth) / 2;
    const toEdge = to[axis] - directionSign * (axis === 'x' ? to.width : to.depth) / 2;
    if (Math.abs(fromEdge - ramp.start[axis]) > 1e-7 || Math.abs(toEdge - ramp.end[axis]) > 1e-7
      || [-1, 1].some((side) => !contains(from, { ...ramp.start, [across]: ramp.start[across] + side * ramp.width / 2 })
        || !contains(to, { ...ramp.end, [across]: ramp.end[across] + side * ramp.width / 2 }))) {
      throw new Error(`Disconnected Hyosan support ramp ${ramp.id}`);
    }
    ids.add(ramp.id);
    const slopeX = rise * dx / (run * run); const slopeZ = rise * dz / (run * run);
    const surface: HyosanSupportSurface = { surfaceId: ramp.id, collisionId: ramp.id, rampId: ramp.id,
      roomId: ramp.roomId, kind: 'ramp', x: (ramp.start.x + ramp.end.x) / 2, z: (ramp.start.z + ramp.end.z) / 2,
      width: axis === 'x' ? run : ramp.width, depth: axis === 'z' ? run : ramp.width,
      height: (ramp.start.y + ramp.end.y) / 2, slopeX, slopeZ, currentLayerId: from.currentLayerId };
    const baseY = Math.min(ramp.start.y, ramp.end.y) - .2;
    const vertices: number[] = [];
    for (const x of [-1, 1]) for (const z of [-1, 1]) {
      const point = { x: surface.x + x * surface.width / 2, z: surface.z + z * surface.depth / 2 };
      vertices.push(point.x, baseY, point.z, point.x, surfaceHeight(surface, point), point.z);
    }
    surfaces.push(surface);
    return { ...ramp, axis, run, rise, x: surface.x, z: surface.z, depth: surface.depth,
      // width/depth are world-X/Z bounds; pathWidth retains the authored cross-section.
      pathWidth: ramp.width, width: surface.width, height: surface.height, baseY, slopeX, slopeZ,
      currentLayerId: from.currentLayerId, vertices };
  });
  const stairs = structuredClone(source.stairs ?? []).map((stair) => {
    const from = surfaces.find((floor) => floor.surfaceId === stair.fromFloorId);
    const to = surfaces.find((floor) => floor.surfaceId === stair.toFloorId);
    const dx = stair.end.x - stair.start.x; const dz = stair.end.z - stair.start.z;
    const run = Math.hypot(dx, dz); const rise = stair.end.y - stair.start.y;
    if (ids.has(stair.id) || !from || !to || ![stair.width, ...Object.values(stair.start), ...Object.values(stair.end)].every(Number.isFinite)
      || stair.width <= 0 || !Number.isInteger(stair.steps) || stair.steps <= 0 || stair.steps > 100 || run <= 0
      || (dx !== 0 && dz !== 0) || rise === 0 || Math.abs(rise / run) > Math.tan(Math.PI * 35 / 180)
      || Math.abs(rise / stair.steps) > .2 || Math.abs(from.height - stair.start.y) > 1e-8 || Math.abs(to.height - stair.end.y) > 1e-8
      || !contains(from, stair.start) || !contains(to, stair.end) || from.currentLayerId !== to.currentLayerId) {
      throw new Error(`Invalid Hyosan stair ${stair.id}`);
    }
    ids.add(stair.id);
    const axis = dx === 0 ? 'z' as const : 'x' as const;
    const across = axis === 'z' ? 'x' : 'z';
    const directionSign = Math.sign(axis === 'x' ? dx : dz);
    const fromEdge = (axis === 'x' ? from.x : from.z) + directionSign * (axis === 'x' ? from.width : from.depth) / 2;
    const toEdge = (axis === 'x' ? to.x : to.z) - directionSign * (axis === 'x' ? to.width : to.depth) / 2;
    if (Math.abs(fromEdge - stair.start[axis]) > 1e-7 || Math.abs(toEdge - stair.end[axis]) > 1e-7
      || [-1, 1].some((side) => !contains(from, { ...stair.start, [across]: stair.start[across] + side * stair.width / 2 })
        || !contains(to, { ...stair.end, [across]: stair.end[across] + side * stair.width / 2 }))) throw new Error(`Disconnected Hyosan stair ${stair.id}`);
    const direction = { x: dx / run, z: dz / run };
    const treadDepth = run / stair.steps;
    const baseY = Math.min(stair.start.y, stair.end.y) - .2;
    const treads = Array.from({ length: stair.steps }, (_, index) => {
      const id = `${stair.id}:tread-${index}`;
      const x = stair.start.x + dx * (index + .5) / stair.steps;
      const z = stair.start.z + dz * (index + .5) / stair.steps;
      const height = stair.start.y + rise * (index + 1) / stair.steps;
      const surface: HyosanSupportSurface = { surfaceId: id, collisionId: id, stairId: stair.id, stepIndex: index,
        roomId: stair.roomId, kind: 'stair', x, z, width: axis === 'z' ? stair.width : treadDepth,
        depth: axis === 'z' ? treadDepth : stair.width, height, slopeX: 0, slopeZ: 0, currentLayerId: from.currentLayerId };
      surfaces.push(surface);
      return { ...surface, id, baseY, blockHeight: height - baseY };
    });
    return { ...stair, axis, run, rise, treadDepth, riserHeight: Math.abs(rise / stair.steps),
      currentLayerId: from.currentLayerId, direction, downhill: rise < 0 ? direction : { x: -direction.x, z: -direction.z },
      slopeX: rise * dx / (run * run), slopeZ: rise * dz / (run * run), treads };
  });
  const transitionPlanes = structuredClone(source.layerTransitions ?? []).map((transition) => {
    const from = surfaces.find((floor) => floor.surfaceId === transition.fromFloorId);
    const to = surfaces.find((floor) => floor.surfaceId === transition.toFloorId);
    if (!from || !to || ids.has(transition.id) || !['x', 'z'].includes(transition.axis)
      || ![transition.x, transition.y, transition.z, transition.width, transition.height].every(Number.isFinite)
      || transition.width <= 0 || transition.height <= 0 || from.currentLayerId !== transition.fromLayerId
      || to.currentLayerId !== transition.toLayerId || from.currentLayerId === to.currentLayerId
      || Math.abs(from.height - transition.y) > 1e-8 || Math.abs(to.height - transition.y) > 1e-8
      || !contains(from, transition) || !contains(to, transition)) throw new Error(`Invalid Hyosan layer transition ${transition.id}`);
    ids.add(transition.id);
    const axis = transition.axis as 'x' | 'z';
    const along = axis === 'x' ? transition.z : transition.x;
    const across = axis === 'x' ? 'z' : 'x';
    const coordinate = transition[axis];
    if (Math.abs(from[axis] + (axis === 'x' ? from.width : from.depth) / 2 - coordinate) > 1e-7
      || Math.abs(to[axis] - (axis === 'x' ? to.width : to.depth) / 2 - coordinate) > 1e-7
      || [-1, 1].some((side) => !contains(from, { ...transition, [across]: along + side * transition.width / 2 })
        || !contains(to, { ...transition, [across]: along + side * transition.width / 2 }))) throw new Error(`Disconnected Hyosan layer transition ${transition.id}`);
    return { ...transition, axis, coordinate: axis === 'x' ? transition.x : transition.z,
      min: along - transition.width / 2, max: along + transition.width / 2,
      yMin: transition.y - .2, yMax: transition.y + transition.height };
  });
  const nearbySupports = indexSupports(surfaces);
  const candidates = (point: { x: number; z: number }) => {
    if (![point.x, point.z].every(Number.isFinite)) return [];
    return nearbySupports(point).map((surface): HyosanSupportSample => ({
      height: surfaceHeight(surface, point), slopeX: surface.slopeX, slopeZ: surface.slopeZ,
      surfaceId: surface.surfaceId, currentLayerId: surface.currentLayerId, kind: surface.kind,
      ...(surface.stairId ? { stairId: surface.stairId, stepIndex: surface.stepIndex } : {}),
      ...(surface.rampId ? { rampId: surface.rampId } : {}),
    }));
  };
  const sample = (point: HyosanSupportPoint): HyosanSupportSample | null => {
    let options = candidates(point);
    if (point.surfaceId !== undefined) return options.find((surface) => surface.surfaceId === point.surfaceId) ?? null;
    if (point.currentLayerId !== undefined) options = options.filter((surface) => surface.currentLayerId === point.currentLayerId);
    if (point.y !== undefined) {
      if (!Number.isFinite(point.y)) return null;
      options.sort((a, b) => Math.abs(a.height - point.y!) - Math.abs(b.height - point.y!));
      return options[0] ?? null;
    }
    // Existing solid tabletop covers its underlying floor. Genuine stacked
    // floors require a physical height/layer hint instead of choosing the roof.
    const raised = options.filter((surface) => surface.kind !== 'floor');
    if (raised.length) options = raised;
    const unique = new Set(options.map((surface) => `${surface.currentLayerId}:${surface.height}`));
    if (unique.size > 1 && options.every((surface) => surface.kind === 'floor')) return null;
    return options.sort((a, b) => b.height - a.height || a.surfaceId.localeCompare(b.surfaceId))[0] ?? null;
  };
  return { surfaces: Object.freeze(surfaces.map((surface) => Object.freeze(surface))),
    ramps: Object.freeze(ramps.map((ramp) => Object.freeze({ ...ramp, start: Object.freeze(ramp.start), end: Object.freeze(ramp.end),
      vertices: Object.freeze(ramp.vertices) }))),
    stairs: Object.freeze(stairs.map((stair) => Object.freeze({ ...stair, start: Object.freeze(stair.start), end: Object.freeze(stair.end),
      treads: Object.freeze(stair.treads.map((tread) => Object.freeze(tread))) }))),
    transitionPlanes: Object.freeze(transitionPlanes.map((plane) => Object.freeze(plane))), candidates, sample };
}
