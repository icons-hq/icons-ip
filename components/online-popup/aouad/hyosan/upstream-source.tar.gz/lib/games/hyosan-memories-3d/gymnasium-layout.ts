import type { GroundPoint, Hyosan3DPropPose } from './physics';

type Point = GroundPoint & { y: number };
/** Physical anchors come from the authored world; the region owns encounter rules. */
export interface HyosanGymnasiumPlan {
  spawn: Point;
  entrySeam: Point & { axis: string; forward: number };
  checkpoint: Point & { radius: number };
  shortcut: Point & { id: string; hinge: Point; open: Hyosan3DPropPose; interactPoint: Point; duration: number };
  coverCart: { id: string; duration: number; stops: readonly (Hyosan3DPropPose & { y: number })[]; interactOffset: { x: number; z: number } };
  exitCart: { id: string; duration: number; stops: readonly (Hyosan3DPropPose & { y: number })[]; interactPoint: Point };
  escape: Point & { forward: number; width: number };
  exit: Point & { forward: number };
  echo: Point;
  hidden: Point;
  supply: Point;
  arrivalSources: readonly (Point & { id: string; via: readonly Point[] })[];
}
