import type { GroundPoint } from './physics';

/** Read-only, bounded route for a paused map. Never substitutes a straight line
 * when navigation fails, enters an unknown room, or crosses a forbidden hazard. */
export function traceHyosanNavigationRoute({ from, to, next, clear, allows, radius = .32 }: {
  from: GroundPoint; to: GroundPoint;
  radius?: number;
  next: (from: GroundPoint, to: GroundPoint, radius: number) => GroundPoint;
  clear: (from: GroundPoint, to: GroundPoint, radius: number) => boolean;
  allows: (point: GroundPoint) => boolean;
}): readonly GroundPoint[] {
  const valid = (p: GroundPoint) => [p.x, p.z, p.y ?? 0].every(Number.isFinite);
  if (!valid(from) || !valid(to) || !Number.isFinite(radius) || radius <= 0 || !allows(from)) return [];
  const segmentAllowed = (at: GroundPoint, point: GroundPoint) => {
    if (!valid(point) || !clear(at, point, radius)) return false;
    // Inspect interiors too: clipping a hidden detour in the drawing would
    // still leave a misleading broken line through an undiscovered room.
    const samples = Math.max(1, Math.ceil(Math.hypot(point.x - at.x, point.z - at.z) / .2));
    for (let step = 1; step <= samples; step++) {
      const fraction = step / samples;
      if (!allows({ x: at.x + (point.x - at.x) * fraction, z: at.z + (point.z - at.z) * fraction,
        y: (at.y ?? 0) + ((point.y ?? 0) - (at.y ?? 0)) * fraction })) return false;
    }
    return true;
  };
  if (segmentAllowed(from, to)) return [{ ...from }, { ...to }];
  // The navigation grid can miss a short, wide bend beside a bench. Try
  // exact, collision-checked flat bends before accepting its longer detour.
  if (Math.abs((from.y ?? 0) - (to.y ?? 0)) <= .05) {
    for (const bend of [{ x: to.x, z: from.z, y: from.y }, { x: from.x, z: to.z, y: from.y }]) {
      if (segmentAllowed(from, bend) && segmentAllowed(bend, to)) return [{ ...from }, bend, { ...to }];
    }
  }
  const points = [{ ...from }]; const visited = new Set<string>();
  for (let segment = 0; segment < 64; segment++) {
    const at = points[points.length - 1];
    if (Math.hypot(at.x - to.x, at.z - to.z, (at.y ?? 0) - (to.y ?? 0)) < .05) return points;
    const point = next(at, to, radius);
    if (!segmentAllowed(at, point)) return [];
    const key = `${point.x.toFixed(4)}:${(point.y ?? 0).toFixed(4)}:${point.z.toFixed(4)}`;
    const length = Math.hypot(point.x - at.x, point.z - at.z);
    if (length < .001 || visited.has(key)) return [];
    visited.add(key);
    points.push({ ...point });
  }
  return [];
}
