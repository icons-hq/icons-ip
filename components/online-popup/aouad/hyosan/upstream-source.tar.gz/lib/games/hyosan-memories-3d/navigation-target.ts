import type { GroundPoint } from './physics';

/** Authorizes only one authored transition beyond the discovered floor plan. */
export interface HyosanNavigationTarget extends GroundPoint {
  entrance?: { id: string; fromRoom: string };
  flight?: { id: string; exit: 'start' | 'end' };
}
