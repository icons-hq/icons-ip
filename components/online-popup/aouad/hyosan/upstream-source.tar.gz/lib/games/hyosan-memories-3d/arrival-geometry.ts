import type { Hyosan3DLayout } from './physics';

/** Resolve the authored entry route without introducing a second geometry map. */
export function hyosanArrivalGeometry(source: Hyosan3DLayout) {
  const inflow = source.adventure?.inflow;
  if (!inflow) return null;
  const floor = source.floors.find((entry) => entry.id === inflow.galleryFloorId);
  const threshold = source.doors.find((entry) => entry.id === inflow.thresholdId);
  const returnWall = source.walls.find((entry) => entry.id === inflow.returnWallId);
  const fixedGlass = source.walls.find((entry) => entry.id === inflow.fixedGlassWallId);
  if (!floor || !threshold || !returnWall || !fixedGlass) {
    throw new Error('Hyosan arrival route references missing authored geometry');
  }
  // Consumers receive their own description; changing a runtime plan cannot
  // move the canonical floor, canopy, spawn or finite encounter assignments.
  return structuredClone({ ...inflow, floor, threshold, returnWall, fixedGlass });
}

export type HyosanArrivalGeometry = NonNullable<ReturnType<typeof hyosanArrivalGeometry>>;
