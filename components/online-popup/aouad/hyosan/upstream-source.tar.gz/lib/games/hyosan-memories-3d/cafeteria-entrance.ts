import type { Hyosan3DLayout } from './physics';

export interface HyosanCafeteriaEntrance {
  x: number; z: number; width: number; height: number; depth: number;
  openingDuration: number; triggerRadius: number;
}

/** Dynamic glass leaves fit the existing doorway; no second map geometry. */
export function hyosanCafeteriaEntrance(source: Hyosan3DLayout): HyosanCafeteriaEntrance | null {
  const door = source.adventure && source.doors.find((entry) => entry.id === 'cafeteria-entry');
  return door ? { x: door.x, z: door.z, width: door.width, height: 2.2, depth: .08,
    openingDuration: .6, triggerRadius: 1.9 } : null;
}

export function hyosanCafeteriaDoorLeaves(entrance: HyosanCafeteriaEntrance, progress: number) {
  const angle = Math.max(0, Math.min(1, progress)) * Math.PI / 2;
  const halfLeaf = entrance.width / 4;
  return [-1, 1].map((side) => ({
    id: side < 0 ? 'cafeteria-glass-north' : 'cafeteria-glass-south',
    x: entrance.x + Math.sin(angle) * halfLeaf,
    z: entrance.z + side * (entrance.width / 2 - Math.cos(angle) * halfLeaf),
    // The centre seals overlap by 12 mm, avoiding a zero-width raycast seam.
    width: entrance.depth, depth: entrance.width / 2 + .012, height: entrance.height,
    rotation: -side * angle,
  }));
}
