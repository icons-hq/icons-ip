import type { GroundPoint, Hyosan3DLayout } from './physics';
import { hyosan3DRoomForFloor } from './rooms';
import type { Hyosan3DRoom } from './types';

interface Entrance extends GroundPoint {
  id: string; label: string; width: number; normal: 'x' | 'z';
  rooms: readonly Hyosan3DRoom[];
  sides: readonly { point: GroundPoint; room: Hyosan3DRoom | null }[];
}
export interface HyosanEntranceCrossing {
  from: GroundPoint; to: GroundPoint; fromRoom: string; toRoom: string;
  contains(point: GroundPoint): boolean;
}

/** Place arrival beyond the room boundary, with room for a body and stopping
 * tolerance. Door frames inside a connector use the actual floor seam. */
export function createHyosanNavigationEntrances(source: Pick<Hyosan3DLayout, 'floors' | 'doors'>) {
  const roomAt = (point: GroundPoint) => {
    const floor = source.floors.find((floor) => Math.abs(point.x - floor.x) <= floor.width / 2 + .01
      && Math.abs(point.z - floor.z) <= floor.depth / 2 + .01 && Math.abs((point.y ?? 0) - (floor.y ?? 0)) < .2);
    return floor ? hyosan3DRoomForFloor(floor) : null;
  };
  const seeds = source.doors.map((door) => {
    const neck = door.id === 'gym-equipment-shortcut-frame'
      ? source.floors.find((floor) => floor.id === 'gym-equipment-shortcut-neck') : undefined;
    return { id: door.id, label: door.label, x: door.x, y: 'y' in door ? door.y : 0,
      z: neck ? neck.z + neck.depth / 2 : door.z, width: door.width, normal: door.axis === 'x' ? 'z' as const : 'x' as const };
  });
  const neck = source.floors.find((floor) => floor.id === 'staffroom-breakroom-counselling-neck');
  if (neck) seeds.push({ id: 'staffroom-counselling-neck-entry', label: '직원 휴게실',
    x: neck.x - neck.width / 2, y: neck.y ?? 0, z: neck.z, width: neck.depth, normal: 'x' });
  const cart = source.floors.find((floor) => floor.id === 'gym-cartlane-west');
  if (cart) seeds.push({ id: 'gym-court-cartlane-edge', label: '카트 탈출로',
    x: cart.x, y: cart.y ?? 0, z: cart.z - cart.depth / 2, width: cart.width, normal: 'z' });
  if (source.floors.some((floor) => hyosan3DRoomForFloor(floor) === 'rooftop-court')) seeds.push(
    { id: 'rooftop-service-court-edge', label: '열린 옥상', x: 232, y: 3, z: -7, width: 2, normal: 'x' },
    { id: 'rooftop-court-memorial-edge', label: '모닥불 자리', x: 241.5, y: 3, z: -14, width: 2, normal: 'z' });
  const entrances: readonly Entrance[] = seeds.map((seed) => {
    const sides = [-1, 1].map((sign) => {
      const point = { x: seed.x + (seed.normal === 'x' ? sign * .8 : 0), y: seed.y,
        z: seed.z + (seed.normal === 'z' ? sign * .8 : 0) };
      return { point, room: roomAt(point) };
    });
    return { ...seed, sides, rooms: [...new Set(sides.flatMap((side) => side.room ? [side.room] : []))] };
  });
  const byId = new Map(entrances.map((entrance) => [entrance.id, entrance]));
  function crossing(id: string, fromRoom: string): HyosanEntranceCrossing | null {
    const entrance = byId.get(id);
    if (!entrance || entrance.rooms.length !== 2) return null;
    const from = entrance.sides.find((side) => side.room === fromRoom);
    const to = entrance.sides.find((side) => side.room && side.room !== fromRoom);
    if (!from || !to) return null;
    return { from: { ...from.point }, to: { ...to.point }, fromRoom, toRoom: to.room!,
      contains(point) {
        const along = entrance.normal; const across = along === 'x' ? 'z' : 'x';
        return Math.abs((point.y ?? 0) - (entrance.y ?? 0)) < .2
          && Math.abs(point[across] - entrance[across]) <= Math.min(.5, entrance.width / 2)
          && point[along] >= Math.min(from.point[along], to.point[along]) - .01
          && point[along] <= Math.max(from.point[along], to.point[along]) + .01;
      } };
  }
  return { entrances, crossing };
}
