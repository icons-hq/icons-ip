import type { Hyosan3DEnding, Hyosan3DPlayer } from './types';

/** Separate from the S8 incident: return to the Season 1 rooftop present. */
export const HYOSAN_REUNION = Object.freeze({
  fire: { x: 242, y: 3, z: -18.5 },
  approach: { x: 240.8, y: 3, z: -18.8 },
  namra: { x: 243.8, y: 3, z: -18.6 },
  radius: 1.05,
  returnDuration: 1.8,
});

/** Original game dialogue; no performance, voice, or quotation from the show. */
export const HYOSAN_REUNION_PAGES = [
  { speaker: '옥상 · 현재', title: '불빛이 남아 있는 곳', text: '소음이 멀어진다. 지나온 여덟 기억 너머, 모닥불 곁에 누군가 서 있다.' },
  { speaker: '남라', title: '혼자가 아니야', text: '아직 이곳에 남은 사람들이 있어. 나처럼, 너처럼. 그들을 찾아가려고 해.' },
  { speaker: '남라', title: '또 보자', text: '우리의 기억이 여기 남아 있으니까.' },
] as const;

export const reunionPlaying = (ending: Readonly<Hyosan3DEnding> | undefined) => ending?.phase === 'returning' || ending?.phase === 'reunion';
export const nearReunion = (player: Readonly<Hyosan3DPlayer>) => player.hp > 0
  && Math.abs(player.y - HYOSAN_REUNION.approach.y) < .2
  && Math.hypot(player.x - HYOSAN_REUNION.approach.x, player.z - HYOSAN_REUNION.approach.z) <= HYOSAN_REUNION.radius;
