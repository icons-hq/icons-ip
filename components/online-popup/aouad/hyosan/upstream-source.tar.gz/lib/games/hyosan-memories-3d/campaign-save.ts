import { parseHyosanRooftopSave, type RooftopSaveDTO } from './rooftop-save';
import layout from '@/docs/games/hyosan-memories-3d/world-layout.json';
import { parseHyosan3DSave } from './save';
import { parseHyosanScienceSave, type ScienceSaveDTO } from './science-save';
import { parseHyosanClassroomSave, type ClassroomSaveDTO } from './classroom-save';
import { parseHyosanBroadcastSave, type BroadcastSaveDTO } from './broadcast-save';
import { parseHyosanLibrarySave, type LibrarySaveDTO } from './library-save';
import { parseHyosanStaffroomSave, type StaffroomSaveDTO } from './staffroom-save';
import { parseHyosanGymnasiumSave, type GymnasiumSaveDTO } from './gymnasium-save';
import { HYOSAN_3D_AREAS, type Hyosan3DEquipment, type Hyosan3DSave } from './types';

export const HYOSAN_CAMPAIGN_SAVE_KEY = 'hyosan-memories-campaign-v1';
export interface HyosanCampaignSave {
  version: 9; introSeen: boolean; musicMemorySeen: boolean; endingSeen: boolean; worldVersion: string; activeArea: typeof HYOSAN_3D_AREAS[number];
  equipment: Hyosan3DEquipment;
  completedAreas: readonly typeof HYOSAN_3D_AREAS[number][];
  science: ScienceSaveDTO | null;
  cafeteria: Hyosan3DSave | null;
  classroom: ClassroomSaveDTO | null;
  broadcast: BroadcastSaveDTO | null;
  library: LibrarySaveDTO | null;
  staffroom: StaffroomSaveDTO | null;
  gymnasium: GymnasiumSaveDTO | null;
  rooftop: RooftopSaveDTO | null;
}
const baseFields = ['version', 'worldVersion', 'activeArea', 'equipment', 'completedAreas', 'science', 'cafeteria'];
const versions = [
  { version: 1, world: 'hyosan-3d-school-v6', count: 2, fields: baseFields, equipment: ['kitCollected', 'supplyCollected'] },
  { version: 2, world: 'hyosan-3d-school-v7', count: 3, fields: [...baseFields, 'classroom'], equipment: ['kitCollected', 'supplyCollected', 'piercingCollected'] },
  { version: 3, world: 'hyosan-3d-school-v8', count: 4, fields: [...baseFields, 'classroom', 'broadcast'], equipment: ['kitCollected', 'supplyCollected', 'piercingCollected'] },
  { version: 4, world: 'hyosan-3d-school-v9', count: 5, fields: [...baseFields, 'classroom', 'broadcast', 'library'], equipment: ['kitCollected', 'supplyCollected', 'piercingCollected', 'stringReinforced'] },
  { version: 5, world: 'hyosan-3d-school-v10', count: 6, fields: [...baseFields, 'classroom', 'broadcast', 'library', 'staffroom'], equipment: ['kitCollected', 'supplyCollected', 'piercingCollected', 'stringReinforced', 'tipReinforced'] },
  { version: 6, world: 'hyosan-3d-school-v11', count: 7, fields: [...baseFields, 'classroom', 'broadcast', 'library', 'staffroom', 'gymnasium'], equipment: ['kitCollected', 'supplyCollected', 'piercingCollected', 'stringReinforced', 'tipReinforced'] },
  { version: 7, world: 'hyosan-3d-school-v12', count: 8, fields: [...baseFields, 'classroom', 'broadcast', 'library', 'staffroom', 'gymnasium', 'rooftop'], equipment: ['kitCollected', 'supplyCollected', 'piercingCollected', 'stringReinforced', 'tipReinforced'] },
  { version: 8, world: 'hyosan-3d-school-v12', count: 8, fields: [...baseFields, 'classroom', 'broadcast', 'library', 'staffroom', 'gymnasium', 'rooftop', 'endingSeen'], equipment: ['kitCollected', 'supplyCollected', 'piercingCollected', 'stringReinforced', 'tipReinforced'] },
  { version: 9, world: 'hyosan-3d-school-v12', count: 8, fields: [...baseFields, 'classroom', 'broadcast', 'library', 'staffroom', 'gymnasium', 'rooftop', 'endingSeen', 'introSeen', 'musicMemorySeen'], equipment: ['kitCollected', 'supplyCollected', 'piercingCollected', 'stringReinforced', 'tipReinforced'] },
];

/** Strict, explicit extension migrations. Local saves never authorize rewards. */
export function parseHyosanCampaignSave(raw: unknown): HyosanCampaignSave | null {
  try {
    const value = typeof raw === 'string' ? JSON.parse(raw) : raw;
    if (!value || typeof value !== 'object' || Array.isArray(value) || layout.version !== 'hyosan-3d-school-v12') return null;
    const schema = versions.find((entry) => entry.version === value.version && entry.world === value.worldVersion);
    if (!schema || Object.keys(value).length !== schema.fields.length
      || Object.keys(value).some((key) => !schema.fields.includes(key))) return null;
    const allowedAreas = HYOSAN_3D_AREAS.slice(0, schema.count);
    if (!allowedAreas.includes(value.activeArea)
      || allowedAreas.some((area) => value[area] !== null && value[area]?.worldVersion !== value.worldVersion)) return null;
    const science = value.science === null ? null : parseHyosanScienceSave(value.science);
    const cafeteria = value.cafeteria === null ? null : parseHyosan3DSave(value.cafeteria);
    const classroom = schema.count < 3 || value.classroom === null ? null : parseHyosanClassroomSave(value.classroom);
    const broadcast = schema.count < 4 || value.broadcast === null ? null : parseHyosanBroadcastSave(value.broadcast);
    const library = schema.count < 5 || value.library === null ? null : parseHyosanLibrarySave(value.library);
    const staffroom = schema.count < 6 || value.staffroom === null ? null : parseHyosanStaffroomSave(value.staffroom);
    const gymnasium = schema.count < 7 || value.gymnasium === null ? null : parseHyosanGymnasiumSave(value.gymnasium);
    const rooftop = schema.count < 8 || value.rooftop === null ? null : parseHyosanRooftopSave(value.rooftop);
    const regions = { science, cafeteria, classroom, broadcast, library, staffroom, gymnasium, rooftop };
    if (allowedAreas.some((area) => value[area] !== null && !regions[area as keyof typeof regions]) || !regions[value.activeArea as keyof typeof regions]) return null;
    const equipment = value.equipment;
    if (!equipment || typeof equipment !== 'object' || Array.isArray(equipment)
      || Object.keys(equipment).length !== schema.equipment.length
      || schema.equipment.some((key) => typeof equipment[key] !== 'boolean')) return null;
    const gear: Required<Hyosan3DEquipment> = {
      kitCollected: Boolean(science?.kitCollected || cafeteria?.kitCollected),
      supplyCollected: Boolean(cafeteria?.supplyCollected),
      piercingCollected: Boolean(classroom?.piercingCollected), stringReinforced: Boolean(library?.stringReinforced),
      tipReinforced: Boolean(staffroom?.tipReinforced),
    };
    if (schema.equipment.some((key) => equipment[key] !== gear[key as keyof typeof gear])) return null;
    const completed = value.completedAreas;
    if (!Array.isArray(completed) || new Set(completed).size !== completed.length
      || Array.from(completed).some((area) => !allowedAreas.includes(area))) return null;
    if (completed.includes('science') && !science?.originInspected || completed.includes('cafeteria') && !cafeteria?.incidentTriggered
      || completed.includes('classroom') && !classroom?.discoveredRooms.includes('classroom-2-5')
      || completed.includes('broadcast') && (!broadcast?.consoleInspected || !broadcast.hoseSecured || !broadcast.discoveredRooms.includes('broadcast-lower'))
      || completed.includes('library') && (!library?.discoveredRooms.includes('library-crown') || !library.discoveredRooms.includes('library-workroom'))
      || completed.includes('staffroom') && (!staffroom?.discoveredRooms.includes('staffroom-records') || !staffroom.discoveredRooms.includes('staffroom-breakroom'))
      || completed.includes('gymnasium') && (!gymnasium?.escapeCartCleared || !gymnasium.discoveredRooms.includes('gym-exit'))
      || completed.includes('rooftop') && (!rooftop?.discoveredRooms.includes('rooftop-court') || !rooftop.discoveredRooms.includes('rooftop-memorial'))) return null;
    if (schema.version >= 8 && (typeof value.endingSeen !== 'boolean' || value.endingSeen && completed.length !== 8)) return null;
    if (schema.version === 9 && (typeof value.introSeen !== 'boolean' || typeof value.musicMemorySeen !== 'boolean'
      || value.musicMemorySeen && !completed.includes('library'))) return null;
    // Old campaigns already under way do not gain a surprise opening or a late combat interruption.
    const pastMusic = ['staffroom', 'gymnasium', 'rooftop'].includes(value.activeArea)
      || completed.some((area: string) => ['staffroom', 'gymnasium', 'rooftop'].includes(area));
    return { version: 9, introSeen: schema.version === 9 ? value.introSeen : true,
      musicMemorySeen: schema.version === 9 ? value.musicMemorySeen : completed.includes('library') && pastMusic,
      endingSeen: schema.version >= 8 && value.endingSeen, worldVersion: layout.version, activeArea: value.activeArea, equipment: gear,
      completedAreas: HYOSAN_3D_AREAS.filter((area) => completed.includes(area)), ...regions };
  } catch { return null; }
}
export function serializeHyosanCampaignSave(save: HyosanCampaignSave): string {
  const validated = parseHyosanCampaignSave(save);
  if (!validated) throw new TypeError('Invalid Hyosan campaign exploration save');
  return JSON.stringify(validated);
}
export function migrateHyosanCafeteriaSave(raw: unknown): HyosanCampaignSave | null {
  const cafeteria = parseHyosan3DSave(raw);
  return cafeteria ? { version: 9, introSeen: true, musicMemorySeen: false, endingSeen: false, worldVersion: layout.version, activeArea: 'cafeteria', science: null, cafeteria, classroom: null, broadcast: null, library: null, staffroom: null, gymnasium: null, rooftop: null,
    equipment: { kitCollected: cafeteria.kitCollected, supplyCollected: cafeteria.supplyCollected, piercingCollected: false, stringReinforced: false, tipReinforced: false }, completedAreas: [] } : null;
}
