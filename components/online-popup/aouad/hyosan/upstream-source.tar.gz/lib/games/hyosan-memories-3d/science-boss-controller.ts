export type HyosanScienceBossBeat = 'idle' | 'approach' | 'notice' | 'pursuit' | 'bite-windup' | 'bite' | 'recovery';
export const HYOSAN_SCIENCE_BOSS = { hp: 18, reach: 1.45, halfAngle: Math.PI / 3 } as const;
const duration = { notice: .65, pursuit: 1.2, 'bite-windup': .75, bite: .18, recovery: 1.05 };

/** Owns timing only; navigation, visible contact and player damage stay in simulation. */
export function createHyosanScienceBossController() {
  let beat: HyosanScienceBossBeat = 'idle';
  let since = 0; let yaw = 0; let lastTime = -1;
  const reset = () => { beat = 'idle'; since = 0; yaw = 0; lastTime = -1; };
  return {
    reset,
    advance(input: { time: number; x: number; z: number; targetX: number; targetZ: number; distance: number; visible: boolean }) {
      if (input.time < lastTime) reset();
      const changed = input.time !== lastTime;
      lastTime = input.time;
      let strike = false;
      const enter = (next: HyosanScienceBossBeat) => { beat = next; since = input.time; };
      if (changed) {
        if (beat === 'idle' || beat === 'approach') {
          if (input.visible && input.distance <= 4.5) {
            yaw = Math.atan2(input.targetX - input.x, input.targetZ - input.z); enter('notice');
          } else if (beat === 'idle') enter('approach');
        } else if (beat === 'notice' && input.time - since >= duration.notice - 1e-8) enter('pursuit');
        else if (beat === 'pursuit') {
          if (input.visible && input.distance <= 1.25) {
            yaw = Math.atan2(input.targetX - input.x, input.targetZ - input.z); enter('bite-windup');
          } else if (input.time - since >= duration.pursuit - 1e-8) enter('recovery');
        } else if (beat === 'bite-windup' && input.time - since >= duration['bite-windup'] - 1e-8) { enter('bite'); strike = true; }
        else if (beat === 'bite' && input.time - since >= duration.bite - 1e-8) enter('recovery');
        else if (beat === 'recovery' && input.time - since >= duration.recovery - 1e-8) enter('idle');
      }
      const current: HyosanScienceBossBeat = beat;
      return { beat: current, yaw, strike, speed: current === 'pursuit' ? 4.2 : current === 'approach' ? 3.8 : 0,
        attackPhase: current === 'notice' || current === 'bite-windup' ? 'windup' as const
          : current === 'bite' ? 'strike' as const : current === 'recovery' ? 'recover' as const : 'idle' as const,
        attackProgress: current === 'idle' || current === 'approach' ? 0 : Math.min(1, Math.max(0, (input.time - since) / duration[current])) };
    },
  };
}
