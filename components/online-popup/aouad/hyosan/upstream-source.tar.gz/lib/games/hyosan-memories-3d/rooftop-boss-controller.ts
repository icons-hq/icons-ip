export type HyosanRooftopBossBeat = 'stalk' | 'rush-windup' | 'rush' | 'sweep-windup' | 'sweep' | 'recovery' | 'resolve' | 'death';
export const HYOSAN_ROOFTOP_BOSS = {
  hp: 96,
  resolveDuration: 1.25,
  phases: [
    { speed: 2.45, recovery: 1.2, rush: { windup: .9, duration: .48, distance: 5.2, contactRange: 1.05, halfAngle: Math.PI / 5, damage: 2 },
      sweep: { windup: .8, duration: .2, contactRange: 1.55, halfAngle: Math.PI * 70 / 180, damage: 1 } },
    { speed: 2.8, recovery: 1.1, rush: { windup: .75, duration: .48, distance: 6.2, contactRange: 1.05, halfAngle: Math.PI / 5, damage: 2 },
      sweep: { windup: .7, duration: .2, contactRange: 1.65, halfAngle: Math.PI * 85 / 180, damage: 1 } },
  ],
} as const;
export interface HyosanRooftopBossInput {
  time: number; x: number; z: number; targetX: number; targetZ: number; distance: number;
  visible: boolean; sameLayer: boolean; canCharge: boolean; hpRatio: number; dead?: boolean;
}

/** A finite request schedule. The shared host accepts displacement through KCC,
 * checks the live contact cone/LOS, and deduplicates damage using attackId.
 * Aim and phase statistics freeze on commitment; no player input is predicted. */
export function createHyosanRooftopBossController() {
  let beat: HyosanRooftopBossBeat = 'stalk';
  let phase: 0 | 1 = 0; let committedPhase: 0 | 1 = 0;
  let since = 0; let lastTime = -1; let yaw = 0; let attackId = 0;
  let attack: 'rush' | 'sweep' = 'rush'; let requestedDistance = 0;
  let origin = { x: 0, z: 0 };
  const reset = () => {
    beat = 'stalk'; phase = 0; committedPhase = 0; since = 0; lastTime = -1; yaw = 0; attackId = 0;
    attack = 'rush'; requestedDistance = 0; origin = { x: 0, z: 0 };
  };
  return {
    reset,
    advance(input: HyosanRooftopBossInput) {
      if (input.time < lastTime) reset();
      const previousTime = lastTime; const changed = input.time !== lastTime; lastTime = input.time;
      let strike = false; let moveX = 0; let moveZ = 0;
      const enter = (next: HyosanRooftopBossBeat) => { beat = next; since = input.time; requestedDistance = 0; };
      const commit = (next: 'rush' | 'sweep') => {
        attack = next; committedPhase = phase; yaw = Math.atan2(input.targetX - input.x, input.targetZ - input.z);
        origin = { x: input.x, z: input.z }; attackId++;
        enter(next === 'rush' ? 'rush-windup' : 'sweep-windup');
      };
      const stats = () => HYOSAN_ROOFTOP_BOSS.phases[committedPhase];
      if (input.dead) { if (beat !== 'death') enter('death'); }
      else if (changed && beat !== 'death') {
        if (beat === 'stalk') {
          if (phase === 0 && input.hpRatio <= .5) { phase = 1; enter('resolve'); }
          else if (input.visible && input.sameLayer) {
            if (input.distance <= HYOSAN_ROOFTOP_BOSS.phases[phase].sweep.contactRange) commit('sweep');
            else if (input.canCharge && input.distance <= HYOSAN_ROOFTOP_BOSS.phases[phase].rush.distance + .65) commit('rush');
          }
        } else if (beat === 'resolve' && input.time - since >= HYOSAN_ROOFTOP_BOSS.resolveDuration - 1e-8) enter('stalk');
        else if ((beat === 'rush-windup' || beat === 'sweep-windup') && input.time - since >= stats()[attack].windup - 1e-8) {
          enter(attack); strike = true;
        } else if ((beat === 'rush' || beat === 'sweep') && input.time - since >= stats()[attack].duration - 1e-8) enter('recovery');
        else if (beat === 'recovery' && input.time - since >= stats().recovery - 1e-8) enter('stalk');
      }
      const current = beat as HyosanRooftopBossBeat;
      if (current === 'rush' && changed) {
        const { distance, duration } = stats().rush;
        const dt = previousTime < 0 ? 0 : Math.min(1 / 60, Math.max(0, input.time - previousTime));
        const amount = Math.min(distance - requestedDistance, distance * dt / duration);
        requestedDistance += amount; moveX = Math.sin(yaw) * amount; moveZ = Math.cos(yaw) * amount;
      }
      const windup = current === 'rush-windup' || current === 'sweep-windup';
      const contactBeat = current === 'rush' || current === 'sweep';
      const attackStats = stats()[attack];
      const duration = current === 'resolve' ? HYOSAN_ROOFTOP_BOSS.resolveDuration
        : windup ? attackStats.windup : contactBeat ? attackStats.duration : stats().recovery;
      return {
        beat: current, phase: phase + 1, committedPhase: committedPhase + 1, yaw, attackId, strike,
        contact: changed && contactBeat && input.sameLayer,
        attackPhase: windup ? 'windup' as const : contactBeat ? 'strike' as const
          : current === 'stalk' ? 'idle' as const : 'recover' as const,
        attackProgress: current === 'stalk' || current === 'death' ? 0 : Math.min(1, Math.max(0, (input.time - since) / duration)),
        damage: attackStats.damage, contactRange: attackStats.contactRange, halfAngle: attackStats.halfAngle,
        // World endpoints remain tied to commitment even when a wall rejects
        // requested displacement. The renderer must clip this corridor to geometry.
        telegraph: { origin: { ...origin }, end: { x: origin.x + Math.sin(yaw) * (attack === 'rush' ? stats().rush.distance : 0),
          z: origin.z + Math.cos(yaw) * (attack === 'rush' ? stats().rush.distance : 0) } },
        moveX, moveZ, speed: current === 'stalk' ? HYOSAN_ROOFTOP_BOSS.phases[phase].speed : 0,
      };
    },
  };
}
