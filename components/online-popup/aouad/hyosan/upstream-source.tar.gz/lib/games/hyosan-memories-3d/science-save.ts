import layout from '@/docs/games/hyosan-memories-3d/world-layout.json';

export const HYOSAN_SCIENCE_ROOMS = ['science-lab', 'science-prep', 'science-link'] as const;
export type HyosanScienceRoom = typeof HYOSAN_SCIENCE_ROOMS[number];
export interface ScienceSaveDTO {
  version: 1; worldVersion: string;
  originInspected: boolean; shortcutOpened: boolean; anchorReached: boolean; kitCollected: boolean;
  discoveredRooms: readonly HyosanScienceRoom[];
}
const flags = ['originInspected', 'shortcutOpened', 'anchorReached', 'kitCollected'] as const;
const fields = ['version', 'worldVersion', 'discoveredRooms', ...flags];

/** The v12 rooftop extension preserves v6–v11 S1 geometry and durable flags. */
export function parseHyosanScienceSave(raw: unknown): ScienceSaveDTO | null {
  try {
    const value: unknown = typeof raw === 'string' ? JSON.parse(raw) : raw;
    if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
    const candidate = value as Record<string, unknown>;
    if (Object.keys(candidate).length !== fields.length || Object.keys(candidate).some((key) => !fields.includes(key))) return null;
    const supportedWorld = candidate.worldVersion === layout.version || layout.version === 'hyosan-3d-school-v12'
      && ['hyosan-3d-school-v6', 'hyosan-3d-school-v7', 'hyosan-3d-school-v8', 'hyosan-3d-school-v9', 'hyosan-3d-school-v10', 'hyosan-3d-school-v11'].includes(candidate.worldVersion as string);
    if (candidate.version !== 1 || !supportedWorld || flags.some((key) => typeof candidate[key] !== 'boolean')) return null;
    const rooms = candidate.discoveredRooms;
    if (!Array.isArray(rooms) || !rooms.length || rooms.length > 3 || new Set(rooms).size !== rooms.length
      || Array.from(rooms).some((room) => !HYOSAN_SCIENCE_ROOMS.includes(room))) return null;
    return { version: 1, worldVersion: layout.version, originInspected: candidate.originInspected as boolean,
      shortcutOpened: candidate.shortcutOpened as boolean, anchorReached: candidate.anchorReached as boolean,
      kitCollected: candidate.kitCollected as boolean, discoveredRooms: HYOSAN_SCIENCE_ROOMS.filter((room) => rooms.includes(room)) };
  } catch { return null; }
}

export function serializeHyosanScienceSave(save: ScienceSaveDTO): string {
  const validated = parseHyosanScienceSave(save);
  if (!validated) throw new TypeError('Invalid Hyosan science exploration save');
  return JSON.stringify(validated);
}
