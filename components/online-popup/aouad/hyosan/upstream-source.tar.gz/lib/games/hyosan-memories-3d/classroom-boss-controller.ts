import type { Hyosan3DAttackPhase, Hyosan3DEnemy } from './types';

export const HYOSAN_CLASSROOM_BOSS = Object.freeze({ hp: 64, brace: .75, rush: .45, impact: .14,
  stagger: .35, recovery: 1.05, rushDistance: 2.2, contactRadius: .85, approachSpeed: 1.55, noticeRange: 3 });
type Beat = NonNullable<Hyosan3DEnemy['classroomBeat']> | 'idle';
interface Input { time: number; x: number; z: number; targetX: number; targetZ: number; visible: boolean; canStartRush?: boolean }
interface Frame { beat: Beat; yaw: number; attackPhase: Hyosan3DAttackPhase; attackProgress: number;
  attackRange: number; moveDistance: number }

/** A short, committed shoulder ram. Only actual terrain contact grants the extra stagger opening. */
export function createHyosanClassroomBossController() {
  let beat: Beat = 'idle'; let since = 0; let now = 0; let previous = -1; let yaw = 0;
  let travelled = 0; let requested = 0; let contacted = false;
  const enter = (next: Beat) => { beat = next; since = now; requested = 0; };
  const read = (): Frame => ({ beat, yaw, moveDistance: requested,
    attackPhase: beat === 'idle' ? 'idle' : beat === 'brace' ? 'windup' : beat === 'rush' ? 'strike' : 'recover',
    attackProgress: beat === 'idle' ? 0 : beat === 'rush' ? Math.min(1, travelled / HYOSAN_CLASSROOM_BOSS.rushDistance)
      : Math.min(1, (now - since) / HYOSAN_CLASSROOM_BOSS[beat]),
    attackRange: Math.max(0, HYOSAN_CLASSROOM_BOSS.rushDistance - travelled) + HYOSAN_CLASSROOM_BOSS.contactRadius });
  return {
    read,
    advance(input: Input): Frame {
      if (input.time <= previous) return read();
      const dt = previous < 0 ? 0 : Math.min(.1, input.time - previous);
      previous = now = input.time; requested = 0;
      if (beat === 'idle') {
        yaw = Math.atan2(input.targetX - input.x, input.targetZ - input.z);
        if (input.visible && input.canStartRush !== false && Math.hypot(input.targetX - input.x, input.targetZ - input.z) <= HYOSAN_CLASSROOM_BOSS.noticeRange) {
          travelled = 0; contacted = false; enter('brace');
        }
      } else if (beat === 'brace' && now - since + 1e-9 >= HYOSAN_CLASSROOM_BOSS.brace) enter('rush');
      else if (beat === 'rush') {
        requested = Math.min(HYOSAN_CLASSROOM_BOSS.rushDistance - travelled,
          HYOSAN_CLASSROOM_BOSS.rushDistance / HYOSAN_CLASSROOM_BOSS.rush * dt);
      } else if (beat === 'impact' && now - since + 1e-9 >= HYOSAN_CLASSROOM_BOSS.impact) enter('stagger');
      else if (beat === 'stagger' && now - since + 1e-9 >= HYOSAN_CLASSROOM_BOSS.stagger) enter('recovery');
      else if (beat === 'recovery' && now - since + 1e-9 >= HYOSAN_CLASSROOM_BOSS.recovery) enter('idle');
      return read();
    },
    resolveRush(feedback: { movedDistance: number; blocked: boolean; contact: boolean }): boolean {
      if (beat !== 'rush' || requested <= 0) return false;
      travelled += Math.max(0, Math.min(requested, feedback.movedDistance)); requested = 0;
      const hit = feedback.contact && !contacted; contacted ||= feedback.contact;
      if (feedback.blocked) enter('impact');
      else if (travelled >= HYOSAN_CLASSROOM_BOSS.rushDistance - .001) enter('recovery');
      return hit;
    },
    reset() { beat = 'idle'; since = now = yaw = travelled = requested = 0; previous = -1; contacted = false; },
  };
}
