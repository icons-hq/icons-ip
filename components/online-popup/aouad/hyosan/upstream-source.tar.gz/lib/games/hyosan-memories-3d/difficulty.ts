export type HyosanDifficulty = 'relaxed' | 'standard';

export const HYOSAN_DIFFICULTY = {
  relaxed: { damageGrace: 1.8, recoveryDelay: 5, recoveryInterval: 2 },
  standard: { damageGrace: .9, recoveryDelay: Infinity, recoveryInterval: Infinity },
} as const;

export const isHyosanDifficulty = (value: unknown): value is HyosanDifficulty => value === 'relaxed' || value === 'standard';
