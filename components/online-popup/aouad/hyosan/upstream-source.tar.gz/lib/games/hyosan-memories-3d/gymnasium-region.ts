import { HYOSAN_GYMNASIUM_ROOMS } from './types';
import { hyosan3DBow } from './save';
import { createHyosanFiniteInflow } from './finite-inflow';
import { createHyosanCartMovement } from './cart-movement';
import { distance, direction, planarDistance } from './combat-geometry';
import { sameHyosanCombatLayer } from './combat-layers';
import { createHyosanSupportGeometry } from './support-geometry';
import type { GroundPoint } from './physics';
import type { CombatEnemy, RegionModule, SharedCombatContext } from './region-module';
import type { GymnasiumSaveDTO, HyosanGymnasiumRoom } from './gymnasium-save';
import { parseHyosanGymnasiumSave } from './gymnasium-save';

const placedStudents = [
  { x: 190, y: -3, z: 3 }, { x: 196, y: -3, z: -2 },
  { x: 205, y: -3, z: 3 }, { x: 195, y: -3, z: 10 }, { x: 207, y: -3, z: 11 },
  { x: 182.5, y: 0, z: -6, currentLayerId: 'gym-gallery' },
  { x: 213.5, y: 0, z: -3, currentLayerId: 'gym-gallery' },
  { x: 199, y: 0, z: -9.5, currentLayerId: 'gym-gallery' },
] as const;
interface GymStudent extends CombatEnemy {
  since: number; arrivalSource?: number; arrivalStep?: number;
  navigationSlot: number; navigationWaypoint?: GroundPoint; navigationTarget?: GroundPoint; navigationLayer?: string;
}

/** A finite siege shares all bodies, damage and arrows with the school host. */
export function createHyosanGymnasiumRegion(ctx: SharedCombatContext): RegionModule<GymnasiumSaveDTO> {
  const { source, physics, player, equipment } = ctx;
  const plan = source.gymnasium;
  if (!plan || plan.arrivalSources.length !== 2) throw new Error('Hyosan gymnasium layout needs two physical arrival sources');
  const gate = source.props.find((prop) => prop.id === plan.shortcut.id);
  if (!gate) throw new Error('Hyosan gymnasium shortcut needs a physical gate');
  const supports = createHyosanSupportGeometry(source);
  const roomAt = (point: GroundPoint): HyosanGymnasiumRoom | undefined => {
    const sample = supports.sample(point);
    const room = supports.surfaces.find((surface) => surface.surfaceId === sample?.surfaceId)?.roomId;
    return HYOSAN_GYMNASIUM_ROOMS.find((candidate) => candidate === room);
  };
  const ids = (group: string) => Array.from({ length: 8 }, (_, index) => `gym-${group}-${index}`);
  const inflowPlan = { incidentIds: ids('court-arrival'), advanceIds: ids('gallery-arrival'), climaxIds: ids('exit-arrival') };
  const queuedIds = [...inflowPlan.incidentIds, ...inflowPlan.advanceIds, ...inflowPlan.climaxIds];
  const inflow = createHyosanFiniteInflow(inflowPlan, queuedIds);
  const enemies: GymStudent[] = [];
  const discovered = new Set<HyosanGymnasiumRoom>();
  let resolved = false;
  let escapeResolved = false;
  let echoCollected = false; let completed = false;
  let firstEnteredAt: number | null = null; let incidentTriggered = false;
  let shortcutOpened = false; let gateProgress = 0; let opening = false;
  let anchorReached = false; let keepsakeFound = false; let keepsakeSecured = false; let supplyTaken = false;
  const lastArrivalAt = [-Infinity, -Infinity];
  const exitCart = createHyosanCartMovement(plan.exitCart.stops, plan.exitCart.duration,
    (pose) => physics.trySetPropPose(plan.exitCart.id, pose));
  const coverCart = createHyosanCartMovement(plan.coverCart.stops, plan.coverCart.duration,
    (pose) => physics.trySetPropPose(plan.coverCart.id, pose));
  const coverHandle = () => ({ ...coverCart.read().pose,
    x: coverCart.read().pose.x + plan.coverCart.interactOffset.x, z: coverCart.read().pose.z + plan.coverCart.interactOffset.z });
  const cartCleared = () => exitCart.read().durableStop === plan.exitCart.stops.length - 1;
  const gatePose = (progress: number) => {
    if (progress === 1) return plan.shortcut.open;
    const rotation = gate.rotation + (plan.shortcut.open.rotation - gate.rotation) * progress;
    const delta = rotation - gate.rotation; const dx = gate.x - plan.shortcut.hinge.x; const dz = gate.z - plan.shortcut.hinge.z;
    return { x: plan.shortcut.hinge.x + dx * Math.cos(delta) + dz * Math.sin(delta), y: plan.shortcut.y,
      z: plan.shortcut.hinge.z - dx * Math.sin(delta) + dz * Math.cos(delta), rotation };
  };
  const interaction: RegionModule['interaction'] = () => {
    if (player.hp <= 0 || completed) return null;
    if (!resolved && escapeResolved && !echoCollected && distance(player, plan.echo) < 1.55 && physics.lineOfSight(player, plan.echo)) return 'echo';
    if (!keepsakeFound && roomAt(player) === 'gym-equipment' && distance(player, plan.hidden) < 1.55
      && physics.lineOfSight(player, plan.hidden)) return 'keepsake';
    if (!supplyTaken && player.hp < player.maxHp && roomAt(player) === 'gym-equipment'
      && distance(player, plan.supply) < 1.55 && physics.lineOfSight(player, plan.supply)) return 'supply';
    if (!shortcutOpened && !opening && roomAt(player) === 'gym-equipment' && distance(player, plan.shortcut.interactPoint) < 1.55
      && physics.lineOfSight(player, plan.shortcut.interactPoint, gate.id)) return 'shortcut';
    if (coverCart.read().durableStop < plan.coverCart.stops.length - 1 && coverCart.read().targetStop === null
      && distance(player, coverHandle()) < 1.55 && physics.lineOfSight(player, coverHandle(), plan.coverCart.id)) return 'cover-cart';
    return !cartCleared() && exitCart.read().targetStop === null && distance(player, plan.exitCart.interactPoint) < 1.55
      && physics.lineOfSight(player, plan.exitCart.interactPoint, plan.exitCart.id) ? 'exit-cart' : null;
  };
  const createEnemy = (id: string, at: GroundPoint, dormant: boolean, arrivalSource?: number): GymStudent => {
    if (!physics.canStand(at, .32)) throw new Error(`Gym student is outside a supported clear floor: ${id}`);
    const placed = dormant ? { ...at, y: at.y ?? -3 } : physics.addActor(id, at, .32);
    return { ...placed, id, ownerArea: 'gymnasium', yaw: 0, hp: 2, maxHp: 2, kind: 'student',
      active: false, dormant, attackStyle: 'melee', attackRange: 1.25, attackHalfAngle: Math.acos(.35),
      attackPhase: 'idle', attackProgress: 0, defeatedAt: null, since: 0, arrivalSource, navigationSlot: enemies.length % 12 };
  };
  const visible = (a: GroundPoint, b: GroundPoint) => sameHyosanCombatLayer(a, b) && physics.lineOfSight(a, b);
  const walk = (enemy: GymStudent, to: GroundPoint, speed: number) => {
    // Each student refreshes its route every .2s on a different fixed-tick slot.
    // Targets/landings change immediately; Rapier still validates every move,
    // including contact with a cart that moved since the route was calculated.
    if (!enemy.navigationWaypoint || enemy.navigationTarget !== to || enemy.navigationLayer !== enemy.currentLayerId
      || planarDistance(enemy, enemy.navigationWaypoint) < .12 || Math.round(ctx.time * 60) % 12 === enemy.navigationSlot) {
      enemy.navigationWaypoint = { ...ctx.navigate(enemy, to, .32, .32) };
      enemy.navigationTarget = to; enemy.navigationLayer = enemy.currentLayerId;
    }
    const waypoint = enemy.navigationWaypoint;
    const aim = direction(waypoint.x - enemy.x, waypoint.z - enemy.z);
    if (aim.x || aim.z) enemy.yaw = Math.atan2(aim.x, aim.z);
    const step = Math.min(planarDistance(enemy, waypoint), speed * ctx.dt * ctx.movementMultiplier(enemy, 'student'));
    Object.assign(enemy, physics.moveActor(enemy.id, aim.x * step, aim.z * step));
  };
  const updateStudents = () => {
    const graceOver = firstEnteredAt !== null && ctx.time - firstEnteredAt >= 2.5;
    for (const enemy of enemies) {
      if (player.hp <= 0) break;
      if (enemy.hp <= 0 || enemy.dormant) continue;
      enemy.active ||= graceOver && distance(enemy, player) < 14 && visible(enemy, player);
      if (!enemy.active) continue;
      if (enemy.arrivalStep !== undefined && enemy.arrivalSource !== undefined) {
        const target = plan.arrivalSources[enemy.arrivalSource].via[enemy.arrivalStep];
        if (!target || distance(enemy, player) < 2.2 && visible(enemy, player)) { enemy.arrivalStep = undefined; enemy.entering = false; }
        else { if (distance(enemy, target) < .18) enemy.arrivalStep++; else walk(enemy, target, 1.35); continue; }
      }
      if (enemy.attackPhase === 'idle') {
        if (distance(enemy, player) <= 1.05 && visible(enemy, player)) {
          enemy.yaw = Math.atan2(player.x - enemy.x, player.z - enemy.z); enemy.attackPhase = 'windup'; enemy.since = ctx.time;
        } else walk(enemy, player, 1.15);
      } else if (enemy.attackPhase === 'windup' && ctx.time - enemy.since >= .6) {
        enemy.attackPhase = 'strike'; enemy.since = ctx.time;
        const aim = direction(player.x - enemy.x, player.z - enemy.z);
        if (distance(enemy, player) <= enemy.attackRange && visible(enemy, player)
          && aim.x * Math.sin(enemy.yaw) + aim.z * Math.cos(enemy.yaw) > Math.cos(enemy.attackHalfAngle)) ctx.hurtPlayer(1, enemy);
      } else if (enemy.attackPhase === 'strike' && ctx.time - enemy.since >= .16) { enemy.attackPhase = 'recover'; enemy.since = ctx.time; }
      else if (enemy.attackPhase === 'recover' && ctx.time - enemy.since >= .85) { enemy.attackPhase = 'idle'; enemy.since = ctx.time; }
      enemy.attackProgress = enemy.attackPhase === 'idle' ? 0 : Math.min(1,
        (ctx.time - enemy.since) / (enemy.attackPhase === 'windup' ? .6 : enemy.attackPhase === 'strike' ? .16 : .85));
    }
  };
  const admitStudents = () => {
    if (player.hp <= 0 || escapeResolved || firstEnteredAt === null || ctx.time - firstEnteredAt < 2.5) return;
    for (const id of inflow.read().pending) {
      const enemy = enemies.find((candidate) => candidate.id === id)!;
      const sourceIndex = enemy.arrivalSource!; const spawn = plan.arrivalSources[sourceIndex];
      if (ctx.time - lastArrivalAt[sourceIndex] < .8 || distance(player, spawn) < 2.5 || physics.lineOfSight(player, spawn)) continue;
      const occupants = [player, ...ctx.enemies.filter((actor) => actor.hp > 0 && !actor.dormant)];
      if (!physics.canStand(spawn, .355) || occupants.some((actor) => {
        const radius = 'kind' in actor && actor.kind === 'boss' ? .5 : .32;
        const overlap = spawn.y < actor.y + 1.1 + radius * 2 && actor.y < spawn.y + 1.74;
        return overlap && planarDistance(spawn, actor) < .32 + radius + .12;
      })) continue;
      const placed = physics.addActor(id, spawn, .32);
      if (!inflow.commitEntry(id)) { physics.removeActor(id); continue; }
      Object.assign(enemy, placed, { dormant: false, active: true, entering: true, arrivalStep: 0 });
      lastArrivalAt[sourceIndex] = ctx.time;
    }
  };
  return {
    id: 'gymnasium', enemies,
    reset(raw, isResolved) {
      const saved = parseHyosanGymnasiumSave(raw);
      resolved = isResolved; discovered.clear(); inflow.reset(); enemies.length = 0;
      for (const room of saved?.discoveredRooms ?? []) discovered.add(room);
      firstEnteredAt = null; incidentTriggered = saved?.incidentTriggered === true; lastArrivalAt.fill(-Infinity);
      anchorReached = saved?.anchorReached === true; keepsakeSecured = saved?.keepsakeSecured === true; keepsakeFound = keepsakeSecured;
      supplyTaken = saved?.supplyTaken === true;
      shortcutOpened = saved?.shortcutOpened === true; gateProgress = shortcutOpened ? 1 : 0; opening = false;
      if (!physics.trySetPropPose(gate.id, gatePose(gateProgress))) throw new Error('Cannot restore the physical gym shortcut');
      escapeResolved = resolved;
      echoCollected = resolved; completed = false;
      if (!exitCart.reset(saved?.escapeCartCleared ? plan.exitCart.stops.length - 1 : 0)) throw new Error('Cannot restore the physical gym exit cart');
      if (!coverCart.reset(saved?.coverCartStop ?? 0)) throw new Error('Cannot restore the physical gym cover cart');
      if (!resolved) {
        placedStudents.forEach((at, index) => enemies.push(createEnemy(`gym-placed-${index}`, at, false)));
        queuedIds.forEach((id, index) => enemies.push(createEnemy(id, plan.arrivalSources[index % 2], true, index % 2)));
      } else inflow.update({ resolved: true });
    },
    observePlayer() {
      const room = roomAt(player); if (room) discovered.add(room);
      if (ctx.area === 'gymnasium' && firstEnteredAt === null) firstEnteredAt = ctx.time;
    },
    update({ interactPressed }) {
      if (player.hp <= 0) return;
      if (roomAt(player) === 'gym-equipment' && distance(player, plan.checkpoint) <= plan.checkpoint.radius
        && physics.lineOfSight(player, plan.checkpoint)) {
        if (!anchorReached) { anchorReached = true; ctx.checkpoint(plan.checkpoint); }
        if (keepsakeFound && !keepsakeSecured) { keepsakeSecured = true; ctx.effect('upgrade', plan.checkpoint, 1.2); }
      }
      const action = interactPressed ? interaction() : null;
      if (action === 'exit-cart') exitCart.requestNext();
      if (action === 'cover-cart') coverCart.requestNext();
      if (action === 'echo') { echoCollected = true; ctx.effect('upgrade', plan.echo, 1.2); }
      if (action === 'keepsake') { keepsakeFound = true; ctx.effect('upgrade', plan.hidden, 1.2); }
      if (action === 'supply') { supplyTaken = true; player.hp = Math.min(player.maxHp, player.hp + 2); ctx.effect('upgrade', plan.supply, 1.2); }
      if (action === 'shortcut') { opening = true; ctx.effect('door', plan.shortcut, .7); }
      exitCart.step(ctx.dt);
      coverCart.step(ctx.dt);
      if (opening) {
        const next = Math.min(1, gateProgress + ctx.dt / plan.shortcut.duration);
        if (physics.trySetPropPose(gate.id, gatePose(next))) gateProgress = next;
        if (gateProgress === 1) { shortcutOpened = true; opening = false; }
      }
      updateStudents();
    },
    afterCombat() {
      if (player.hp > 0 && cartCleared() && roomAt(player) === 'gym-exit'
        && Math.abs(player.y - plan.escape.y) < .25 && (player.x - plan.escape.x) * plan.escape.forward >= 0
        && Math.abs(player.z - plan.escape.z) < plan.escape.width / 2) {
        escapeResolved = true; inflow.update({ resolved: true });
      }
      if (!resolved && escapeResolved && echoCollected && player.hp > 0 && roomAt(player) === 'gym-exit'
        && Math.abs(player.y - plan.exit.y) < .25 && (player.x - plan.exit.x) * plan.exit.forward >= 0
        && Math.abs(player.z - plan.exit.z) < 1.2) { completed = true; keepsakeSecured ||= keepsakeFound; }
      const room = roomAt(player);
      if (player.hp <= 0) { inflow.update({ resolved: true }); return; }
      const court = room === 'gym-court'; const gallery = room === 'gym-gallery'; const cartlane = room === 'gym-cartlane';
      incidentTriggered ||= court || gallery || cartlane;
      inflow.update({ incident: incidentTriggered && (court || gallery || cartlane),
        advanced: gallery || court && player.x >= 198, climax: cartlane, resolved: escapeResolved });
      admitStudents();
    },
    markResolved() { resolved = true; escapeResolved = true; completed = false; inflow.update({ resolved: true }); },
    interaction,
    readProgress() {
      const bow = hyosan3DBow(equipment.kitCollected, equipment.supplyCollected, equipment.piercingCollected, equipment.stringReinforced, equipment.tipReinforced);
      return { room: roomAt(player) ?? 'gym-entry', discoveredRooms: [...discovered],
        areaResolved: resolved, escapeResolved, escapeCartCleared: cartCleared(), coverCartStop: coverCart.read().durableStop,
        keepsakeFound, keepsakeSecured, supplyTaken,
        objective: completed ? 'completed' : resolved ? 'explore_school' : echoCollected ? 'reach_exit' : escapeResolved ? 'collect_echo' : incidentTriggered ? 'escape_gym' : 'explore_gym',
        upgraded: equipment.kitCollected, supplyCollected: equipment.supplyCollected, piercingCollected: equipment.piercingCollected,
        bowLevel: bow.level, bossDefeated: false, completed, echoCollected, anchorReached,
        shortcutOpened, incidentTriggered, entranceOpen: 1, inWater: false, activeWaterIds: [], incidentShortcutOpened: false };
    },
    exportSave: () => ({ version: 1, worldVersion: source.version, discoveredRooms: [...discovered],
      anchorReached, incidentTriggered, shortcutOpened, escapeCartCleared: cartCleared(),
      coverCartStop: coverCart.read().durableStop, supplyTaken, keepsakeSecured }),
    respawnPoint: () => anchorReached ? plan.checkpoint : plan.spawn,
    furniture: () => [{ id: plan.exitCart.id, ...exitCart.read().pose, progress: exitCart.read().progress },
      { id: plan.coverCart.id, ...coverCart.read().pose, progress: coverCart.read().progress },
      { id: gate.id, ...gatePose(gateProgress), progress: gateProgress }],
    inflow: () => inflow.read(),
    onHit(enemy) { const own = enemy as GymStudent; own.arrivalStep = undefined; own.entering = false; },
  };
}
