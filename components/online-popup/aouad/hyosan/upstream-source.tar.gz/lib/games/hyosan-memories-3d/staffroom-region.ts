import layout from '@/docs/games/hyosan-memories-3d/world-layout.json';
import { HYOSAN_STAFFROOM_ROOMS } from './types';
import { hyosan3DBow } from './save';
import { parseHyosanStaffroomSave, type StaffroomSaveDTO, type HyosanStaffroomRoom } from './staffroom-save';
import { createHyosanStaffroomBossController, HYOSAN_STAFFROOM_BOSS } from './staffroom-boss-controller';
import { createHyosanStaffroomFire, type HyosanStaffroomFireActor } from './staffroom-fire';
import { createHyosanSupportGeometry } from './support-geometry';
import { direction, distance } from './combat-geometry';
import { sameHyosanCombatLayer, HYOSAN_MAIN_LAYER } from './combat-layers';
import type { GroundPoint } from './physics';
import type { CombatEnemy, RegionModule, SharedCombatContext } from './region-module';

interface StaffroomEnemy extends CombatEnemy { since: number }
const STUDENT = { windup: .55, strike: .16, recovery: .85 };

/** Encounter, finite paper fire and durable exploration share the school combat world. */
export function createHyosanStaffroomRegion(ctx: SharedCombatContext): RegionModule<StaffroomSaveDTO> {
  const { source, physics, navigate, player, equipment } = ctx;
  const plan = source.staffroom;
  if (!plan) throw new Error('Hyosan staffroom layout is required');
  const gate = source.props.find((prop) => prop.id === plan.shortcut.id);
  if (!gate) throw new Error('Hyosan staffroom shortcut has no physical prop');
  const support = createHyosanSupportGeometry(source);
  const roomsBySurface = new Map(support.surfaces.map((surface) => [surface.surfaceId, surface.roomId ?? surface.surfaceId]));
  const ownRoomAt = (point: GroundPoint): HyosanStaffroomRoom | undefined => {
    const sample = support.sample(point);
    return HYOSAN_STAFFROOM_ROOMS.find((room) => room === (sample && roomsBySurface.get(sample.surfaceId)));
  };
  const enemies: StaffroomEnemy[] = [];
  const bossController = createHyosanStaffroomBossController(plan.boss);
  const fire = createHyosanStaffroomFire(plan.fire);
  const lastBurnAt = new Map<string, number>();
  const discovered = new Set<HyosanStaffroomRoom>();
  let firstEnteredAt: number | null = null; let bossHit = false;
  let incidentTriggered = false; let fireStarted = false;
  let resolved = false; let completed = false; let echoCollected = false;
  let shortcutOpened = false; let anchorReached = false; let tipReinforced = false;
  let keepsakeFound = false; let keepsakeSecured = false;
  let gateProgress = 0; let opening = false;
  const gatePose = (progress: number) => {
    if (progress === 1) return plan.shortcut.open;
    const rotation = gate.rotation + (plan.shortcut.open.rotation - gate.rotation) * progress;
    const delta = rotation - gate.rotation;
    const dx = gate.x - plan.shortcut.hinge.x; const dz = gate.z - plan.shortcut.hinge.z;
    return { x: plan.shortcut.hinge.x + dx * Math.cos(delta) + dz * Math.sin(delta), y: plan.shortcut.y,
      z: plan.shortcut.hinge.z - dx * Math.sin(delta) + dz * Math.cos(delta), rotation };
  };
  const boss = () => enemies.find((enemy) => enemy.kind === 'boss');
  const nearby = (point: GroundPoint, ignore?: string) => distance(player, point) < 1.5 && physics.lineOfSight(player, point, ignore);
  const interaction: RegionModule['interaction'] = () => {
    if (player.hp <= 0 || completed) return null;
    if (!resolved && boss()?.hp === 0 && !echoCollected && nearby(plan.echo)) return 'echo';
    if (!tipReinforced && nearby(plan.upgrade, plan.upgrade.propId)) return 'arrowtip';
    if (!keepsakeFound && ownRoomAt(player) === 'staffroom-breakroom' && nearby(plan.hidden, plan.hidden.propId)) return 'keepsake';
    if (!shortcutOpened && !opening && player.x > gate.x + .2 && nearby(plan.shortcut.interactPoint, gate.id)) return 'shortcut';
    return null;
  };
  const createEnemy = (id: string, at: GroundPoint, isBoss = false): StaffroomEnemy => {
    const hp = isBoss ? HYOSAN_STAFFROOM_BOSS.hp : 2;
    return { id, ...physics.addActor(id, at, isBoss ? .5 : .32), yaw: 0, hp, maxHp: hp,
      ownerArea: 'staffroom', kind: isBoss ? 'boss' : 'student', ...(isBoss ? { profile: 'eunji' as const } : {}),
      active: false, dormant: false, since: 0,
      attackPhase: 'idle', attackStyle: 'melee', attackProgress: 0,
      attackRange: isBoss ? HYOSAN_STAFFROOM_BOSS.grab.range : 1.25,
      attackHalfAngle: isBoss ? HYOSAN_STAFFROOM_BOSS.grab.halfAngle : Math.acos(.35), defeatedAt: null };
  };
  const hitsPlayer = (enemy: StaffroomEnemy, reach = enemy.attackRange) => {
    const aim = direction(player.x - enemy.x, player.z - enemy.z);
    return sameHyosanCombatLayer(enemy, player) && distance(enemy, player) <= reach
      && aim.x * Math.sin(enemy.yaw) + aim.z * Math.cos(enemy.yaw) > Math.cos(enemy.attackHalfAngle)
      && physics.lineOfSight(enemy, player);
  };
  const walk = (enemy: StaffroomEnemy, aim: { x: number; z: number }, speed: number) => {
    if (aim.x || aim.z) enemy.yaw = Math.atan2(aim.x, aim.z);
    const step = speed * ctx.dt * ctx.movementMultiplier(enemy, enemy.kind);
    Object.assign(enemy, physics.moveActor(enemy.id, aim.x * step, aim.z * step));
  };
  const updateEnemies = () => {
    for (const enemy of enemies) {
      if (player.hp <= 0) break;
      if (enemy.hp <= 0 || enemy.dormant) continue;
      const sameLayer = sameHyosanCombatLayer(enemy, player);
      const visible = sameLayer && distance(enemy, player) < HYOSAN_STAFFROOM_BOSS.noticeRange && physics.lineOfSight(enemy, player);
      const graceOver = firstEnteredAt !== null && ctx.time - firstEnteredAt >= 2.2;
      if (enemy.kind === 'boss') {
        // The controller receives only a witnessed target. Hidden coordinates never feed navigation.
        const seen = visible && (graceOver || enemy.active || bossHit);
        const unlit = new Set(fire.read().filter((zone) => zone.phase === 'unlit').map((zone) => zone.id));
        const igniteZone = !resolved && plan.fire.zones.filter((zone) => unlit.has(zone.id))
          .map((zone) => ({ id: zone.id, x: zone.visualPoint.x, y: zone.y, z: zone.visualPoint.z, currentLayerId: zone.layerId }))
          .filter((point) => sameHyosanCombatLayer(enemy, point) && distance(enemy, point) <= HYOSAN_STAFFROOM_BOSS.ignite.range
            && physics.lineOfSight(enemy, point))
          .sort((a, b) => distance(enemy, a) - distance(enemy, b))[0];
        const frame = bossController.advance({ time: ctx.time, x: enemy.x, y: enemy.y, z: enemy.z,
          targetX: seen ? player.x : enemy.x, targetY: seen ? player.y : enemy.y, targetZ: seen ? player.z : enemy.z,
          distance: seen ? distance(enemy, player) : Infinity, visible: seen, sameLayer,
          canAttack: seen && (distance(enemy, player) <= HYOSAN_STAFFROOM_BOSS.grab.contactRange
            || physics.clearGround(enemy, player, .5)), hit: bossHit, igniteZone: igniteZone || undefined });
        bossHit = false;
        if (frame.beat !== 'death') enemy.staffroomBeat = frame.beat;
        enemy.active ||= frame.beat !== 'idle';
        enemy.attackPhase = frame.attackPhase; enemy.attackProgress = frame.attackProgress;
        enemy.attackRange = frame.range; enemy.attackHalfAngle = frame.halfAngle; enemy.yaw = frame.yaw;
        if (frame.speed > 0 && frame.navigationTarget) {
          const target = { ...frame.navigationTarget, currentLayerId: enemy.currentLayerId };
          const waypoint = navigate(enemy, target, .5, .32);
          walk(enemy, direction(waypoint.x - enemy.x, waypoint.z - enemy.z), frame.speed);
        }
        if (frame.beat === 'grab') {
          const before = { x: enemy.x, z: enemy.z };
          if (frame.moveDistance > 0) Object.assign(enemy, physics.moveActor(enemy.id,
            Math.sin(frame.yaw) * frame.moveDistance, Math.cos(frame.yaw) * frame.moveDistance));
          const movedDistance = Math.hypot(enemy.x - before.x, enemy.z - before.z);
          if (bossController.resolveGrab({ movedDistance, blocked: frame.moveDistance > .001 && movedDistance < frame.moveDistance * .25,
            contact: frame.contact && hitsPlayer(enemy, frame.contactRange) })) ctx.hurtPlayer(frame.damage, enemy);
        }
        if (frame.igniteZoneId && fire.ignite(frame.igniteZoneId, ctx.time)) { incidentTriggered = true; fireStarted = true; }
      } else {
        enemy.active ||= graceOver && visible;
        if (!enemy.active) continue;
        const waypoint = navigate(enemy, player, .32, .32);
        const aim = direction(waypoint.x - enemy.x, waypoint.z - enemy.z);
        if (enemy.attackPhase === 'idle') {
          if (sameHyosanCombatLayer(enemy, player) && distance(enemy, player) <= 1.05 && physics.lineOfSight(enemy, player)) {
            enemy.yaw = Math.atan2(player.x - enemy.x, player.z - enemy.z); enemy.attackPhase = 'windup'; enemy.since = ctx.time;
          } else walk(enemy, aim, 1.1);
        } else if (enemy.attackPhase === 'windup' && ctx.time - enemy.since >= STUDENT.windup) {
          enemy.attackPhase = 'strike'; enemy.since = ctx.time; if (hitsPlayer(enemy)) ctx.hurtPlayer(1, enemy);
        } else if (enemy.attackPhase === 'strike' && ctx.time - enemy.since >= STUDENT.strike) { enemy.attackPhase = 'recover'; enemy.since = ctx.time; }
        else if (enemy.attackPhase === 'recover' && ctx.time - enemy.since >= STUDENT.recovery) { enemy.attackPhase = 'idle'; enemy.since = ctx.time; }
        if (enemy.kind === 'student') enemy.attackProgress = enemy.attackPhase === 'idle' ? 0 : Math.min(1,
          (ctx.time - enemy.since) / (enemy.attackPhase === 'windup' ? STUDENT.windup : enemy.attackPhase === 'strike' ? STUDENT.strike : STUDENT.recovery));
      }
    }
  };
  const fireActors = (): HyosanStaffroomFireActor[] => [
    { ...player, id: 'player', radius: .32, currentLayerId: player.currentLayerId ?? HYOSAN_MAIN_LAYER },
    ...ctx.enemies.filter((enemy) => !enemy.dormant).map((enemy) => ({ ...enemy, radius: enemy.kind === 'boss' ? .5 : .32, currentLayerId: enemy.currentLayerId ?? HYOSAN_MAIN_LAYER })),
  ];
  const updateFire = () => {
    const actors = fireActors();
    fire.advance({ time: ctx.time, actors, shortcutOpened, bossDefeated: resolved || boss()?.hp === 0 });
    for (const id of fire.exposedActors(actors)) {
      if (ctx.time - (lastBurnAt.get(id) ?? -Infinity) < 1) continue;
      lastBurnAt.set(id, ctx.time);
      if (id === 'player') ctx.hurtPlayer(1);
      else ctx.hurtEnemy(id, 1);
    }
  };
  return {
    id: 'staffroom', enemies,
    reset(raw, isResolved) {
      const saved = parseHyosanStaffroomSave(raw);
      resolved = isResolved; completed = false; echoCollected = false;
      firstEnteredAt = null; bossHit = false; bossController.reset();
      fire.reset({ resolved }); lastBurnAt.clear(); fireStarted = false; incidentTriggered = saved?.incidentTriggered === true;
      shortcutOpened = saved?.shortcutOpened === true; anchorReached = saved?.anchorReached === true;
      tipReinforced = saved?.tipReinforced === true; equipment.tipReinforced ||= tipReinforced;
      keepsakeSecured = saved?.keepsakeSecured === true; keepsakeFound = keepsakeSecured;
      discovered.clear(); for (const room of saved?.discoveredRooms ?? []) discovered.add(room);
      gateProgress = shortcutOpened ? 1 : 0; opening = false;
      physics.trySetPropPose(gate.id, gatePose(gateProgress));
      enemies.length = 0;
      if (!resolved) {
        for (const group of plan.encounters) for (let index = 0; index < group.count; index++) {
          enemies.push(createEnemy(`${group.id}-${index}`, { ...group, x: group.x + index % 2 * .95, z: group.z + Math.floor(index / 2) * .95 }));
        }
        enemies.push(createEnemy(plan.boss.id, plan.boss, true));
      }
    },
    observePlayer() {
      const room = ownRoomAt(player); if (room) discovered.add(room);
      if (ctx.area === 'staffroom' && firstEnteredAt === null) firstEnteredAt = ctx.time;
    },
    update({ interactPressed }) {
      if (player.hp <= 0) return;
      if (distance(player, plan.checkpoint) <= plan.checkpoint.radius && nearby(plan.checkpoint)) {
        if (!anchorReached) { anchorReached = true; ctx.checkpoint(plan.checkpoint); }
        if (keepsakeFound && !keepsakeSecured) { keepsakeSecured = true; ctx.effect('upgrade', plan.checkpoint, 1.2); }
      }
      if (interactPressed) {
        const action = interaction();
        if (action === 'arrowtip') { tipReinforced = true; equipment.tipReinforced = true; }
        if (action === 'keepsake') keepsakeFound = true;
        if (action === 'shortcut') opening = true;
        if (action === 'echo') echoCollected = true;
        if (action) ctx.effect(action === 'shortcut' ? 'door' : 'upgrade', player, .7);
      }
      if (opening) {
        const next = Math.min(1, gateProgress + ctx.dt / plan.shortcut.duration);
        if (physics.trySetPropPose(gate.id, gatePose(next))) gateProgress = next;
        if (gateProgress === 1) { shortcutOpened = true; opening = false; }
      }
      if (!resolved && boss()?.hp !== 0 && firstEnteredAt !== null && !fireStarted
        && (incidentTriggered || distance(player, plan.fire.trigger) <= plan.fire.trigger.radius && nearby(plan.fire.trigger))) {
        incidentTriggered = true; fireStarted = true; fire.ignite(plan.fire.seedId, ctx.time);
      }
      updateEnemies();
      if (player.hp > 0) updateFire();
    },
    afterCombat() {
      // Arrow death stops pending ignition this same tick; existing flames finish their lifetime.
      if (boss()?.hp === 0) fire.advance({ time: ctx.time, actors: fireActors(), shortcutOpened, bossDefeated: true });
      if (!resolved && player.hp > 0 && boss()?.hp === 0 && echoCollected
        && Math.abs(player.y - plan.exit.y) < .25 && (player.x - plan.exit.x) * plan.exit.forward >= 0
        && Math.abs(player.z - plan.exit.z) <= 1.2) {
        completed = true; keepsakeSecured ||= keepsakeFound;
      }
    },
    interaction,
    markResolved() { resolved = true; completed = false; },
    readProgress() {
      const bow = hyosan3DBow(equipment.kitCollected, equipment.supplyCollected, equipment.piercingCollected, equipment.stringReinforced, equipment.tipReinforced);
      return { room: ownRoomAt(player) ?? 'staffroom-entry', discoveredRooms: [...discovered], tipReinforced, keepsakeFound, keepsakeSecured,
        areaResolved: resolved, objective: completed ? 'completed' : resolved ? 'explore_school'
          : boss()?.active && boss()!.hp > 0 ? 'defeat_boss' : boss()?.hp !== 0
            ? anchorReached ? 'inspect_records' : 'explore_staffroom' : !echoCollected ? 'collect_echo' : 'reach_exit',
        upgraded: equipment.kitCollected, supplyCollected: equipment.supplyCollected, piercingCollected: equipment.piercingCollected,
        bowLevel: bow.level, bossDefeated: resolved || boss()?.hp === 0, completed, echoCollected, anchorReached, shortcutOpened,
        incidentTriggered, inFire: fire.hazardous({ ...player, currentLayerId: player.currentLayerId ?? HYOSAN_MAIN_LAYER }, .32), entranceOpen: 1, inWater: ctx.movementMultiplier(player, 'player') < 1,
        activeWaterIds: [], incidentShortcutOpened: false };
    },
    exportSave: () => ({ version: 1, worldVersion: layout.version, shortcutOpened, anchorReached, incidentTriggered, tipReinforced, keepsakeSecured,
      discoveredRooms: HYOSAN_STAFFROOM_ROOMS.filter((room) => discovered.has(room)) }),
    respawnPoint: () => anchorReached ? plan.checkpoint : plan.spawn,
    fires: () => fire.read(),
    onHit(enemy) { if (enemy.kind === 'boss' && enemy.hp > 0) bossHit = true; },
    furniture: () => [{ id: gate.id, ...gatePose(gateProgress), progress: gateProgress }],
  };
}
