import type { GroundPoint, Hyosan3DPropPose } from './physics';

type Point = GroundPoint & { y: number };
export interface HyosanRooftopPlan {
  spawn: Point;
  entrySeam: Point & { axis: string; forward: number };
  checkpoint: Point & { radius: number };
  shortcut: Point & { id: string; hinge: Point; open: Hyosan3DPropPose; interactPoint: Point; duration: number };
  boss: Point & { id: string };
  encounters: readonly (Point & { id: string })[];
  echo: Point;
  exit: Point & { axis: string; forward: number };
  hidden: Point;
  supply: Point;
  campfire: Point;
  namra: Point;
}
