export interface HyosanInflowPlan {
  incidentIds: readonly string[];
  advanceIds: readonly string[];
  climaxIds: readonly string[];
}
export type HyosanEncounterPhase = 'approach' | 'pressure' | 'advance' | 'climax' | 'resolved';

/** A finite authored roster, requested by space and admitted by the physical world. */
export function createHyosanFiniteInflow(plan: HyosanInflowPlan, roster: readonly string[]) {
  const configured = [...plan.incidentIds, ...plan.advanceIds, ...plan.climaxIds];
  if (new Set(configured).size !== configured.length) throw new Error('Duplicate Hyosan inflow actor ID');
  const available = new Set(roster);
  const ids = configured.filter((id) => available.has(id));
  const eligible = new Set(ids);
  const requested = new Set<string>();
  const admitted = new Set<string>();
  const cancelled = new Set<string>();
  let stage = 0;
  const phases: readonly HyosanEncounterPhase[] = ['approach', 'pressure', 'advance', 'climax', 'resolved'];
  const queue = () => {
    // Spatially reaching the climax requests its fixed group immediately. A
    // safe entrance slot, not an earlier wave's kills/admissions, is the gate.
    const priority = stage === 3 ? [...plan.climaxIds, ...ids] : ids;
    return [...new Set(priority)].filter((id) => requested.has(id) && !admitted.has(id) && !cancelled.has(id));
  };
  return {
    includes(id: string) { return eligible.has(id); },
    update(signals: { incident?: boolean; advanced?: boolean; climax?: boolean; resolved?: boolean }) {
      if (stage === 4) return;
      if (signals.resolved) {
        stage = 4;
        for (const id of ids) if (!admitted.has(id)) cancelled.add(id);
        return;
      }
      stage = Math.max(stage, signals.climax ? 3 : signals.advanced ? 2 : signals.incident ? 1 : 0);
      const groups = [plan.incidentIds, plan.advanceIds, plan.climaxIds];
      for (let index = 0; index < stage; index++) {
        for (const id of groups[index]) if (eligible.has(id)) requested.add(id);
      }
    },
    /** Call only after damage resolves and the same tick's physical slot is safe. */
    commitEntry(id: string) {
      if (stage === 4 || !requested.has(id) || admitted.has(id) || cancelled.has(id)) return false;
      admitted.add(id);
      return true;
    },
    read() {
      return { phase: phases[stage], pending: queue(),
        admitted: ids.filter((id) => admitted.has(id)), cancelled: ids.filter((id) => cancelled.has(id)) };
    },
    reset() { stage = 0; requested.clear(); admitted.clear(); cancelled.clear(); },
  };
}
