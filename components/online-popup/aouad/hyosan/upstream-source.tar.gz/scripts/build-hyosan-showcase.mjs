import { createHash } from 'node:crypto';
import { copyFile, lstat, mkdir, readFile, readdir, realpath, rm, writeFile } from 'node:fs/promises';
import { dirname, isAbsolute, join, relative, resolve, sep } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { brotliCompress, brotliDecompress, constants, gzip, gunzip } from 'node:zlib';
import { promisify } from 'node:util';
import * as ts from 'typescript';
import { build as viteBuild } from 'vite';

const compressBrotli = promisify(brotliCompress);
const compressGzip = promisify(gzip);
const decompressBrotli = promisify(brotliDecompress);
const decompressGzip = promisify(gunzip);

const scriptDirectory = dirname(fileURLToPath(import.meta.url));
const repositoryRoot = resolve(scriptDirectory, '..');
const showcaseRoot = join(repositoryRoot, 'showcase/hyosan');
const routeSourcePath = join(
  repositoryRoot,
  'components/games/hyosan-memories-3d/asset-route.server.ts',
);
const assetSourceRoot = join(repositoryRoot, 'docs/games/hyosan-memories-3d/assets');
const outputRoot = join(repositoryRoot, 'output/hyosan-showcase/site');
const outputAssetRoot = join(outputRoot, 'api/dev/hyosan-3d');
const encodedRoot = join(outputRoot, '__encoded');
const manifestPath = join(outputRoot, 'hyosan-showcase-manifest.json');
const inputPaths = Object.freeze([
  'showcase/hyosan/index.html',
  'showcase/hyosan/main.tsx',
  'showcase/hyosan/styles.css',
  'showcase/hyosan/vite.config.ts',
  'components/games/hyosan-memories-3d/Hyosan3DGame.client.tsx',
  'components/games/hyosan-memories-3d/Hyosan3DOverlay.tsx',
  'components/games/hyosan-memories-3d/Hyosan3D.module.css',
  'lib/games/hyosan-memories-3d/campaign-storage.ts',
  'components/games/hyosan-memories-3d/campaign-writer-lease.ts',
  'scripts/build-hyosan-showcase.mjs',
  'components/games/hyosan-memories-3d/asset-route.server.ts',
]);

function portableRelative(from, to) {
  return relative(from, to).split(sep).join('/');
}

function assertSafeAssetName(name) {
  if (name.length === 0 || name === '.' || name === '..'
    || name.includes('/') || name.includes('\\') || name.includes('\0')) {
    throw new Error(`Hyosan showcase asset name is unsafe: ${name}`);
  }
}

function assertSafeAssetPath(assetPath) {
  if (assetPath.length === 0 || isAbsolute(assetPath) || assetPath.includes('\\')
    || assetPath.includes('\0')
    || assetPath.split('/').some((segment) => segment.length === 0 || segment === '.' || segment === '..')) {
    throw new Error(`Hyosan showcase source path is unsafe: ${assetPath}`);
  }
  const protectedSegments = new Set([
    'qa',
    'reference',
    'references',
    'old',
    'oldunusedassets',
    'old-unused-assets',
    'unused',
    'unused-assets',
  ]);
  if (assetPath.split('/').some((segment) => protectedSegments.has(segment.toLowerCase()))) {
    throw new Error(`Hyosan showcase source path is protected: ${assetPath}`);
  }
}

/**
 * Read only the string-literal object used by asset-route.server.ts.
 * Computed properties, spreads, expressions, and duplicate keys fail closed.
 */
export function extractHyosanAssetAllowlist(source, sourcePath = routeSourcePath) {
  const sourceFile = ts.createSourceFile(
    sourcePath,
    source,
    ts.ScriptTarget.Latest,
    true,
    ts.ScriptKind.TS,
  );
  const declarations = [];
  const visit = (node) => {
    if (ts.isVariableDeclaration(node)
      && ts.isIdentifier(node.name)
      && node.name.text === 'assets') declarations.push(node);
    ts.forEachChild(node, visit);
  };
  visit(sourceFile);
  if (declarations.length !== 1) {
    throw new Error('Hyosan asset route must contain exactly one assets declaration');
  }

  let initializer = declarations[0].initializer;
  if (initializer && ts.isAsExpression(initializer)
    && ts.isTypeReferenceNode(initializer.type)
    && ts.isIdentifier(initializer.type.typeName)
    && initializer.type.typeName.text === 'const') {
    initializer = initializer.expression;
  }
  if (!initializer || !ts.isObjectLiteralExpression(initializer)) {
    throw new Error('Hyosan asset allowlist must be a const object literal');
  }

  const entries = [];
  const names = new Set();
  for (const property of initializer.properties) {
    if (!ts.isPropertyAssignment(property)
      || !ts.isStringLiteral(property.name)
      || !ts.isStringLiteral(property.initializer)) {
      throw new Error('Hyosan asset allowlist accepts only string-literal properties and values');
    }
    const name = property.name.text;
    const assetPath = property.initializer.text;
    assertSafeAssetName(name);
    assertSafeAssetPath(assetPath);
    if (names.has(name)) throw new Error(`Hyosan asset allowlist duplicates ${name}`);
    names.add(name);
    entries.push(Object.freeze({ name, source: assetPath }));
  }
  if (entries.length === 0) throw new Error('Hyosan asset allowlist must not be empty');
  return Object.freeze(entries);
}

async function assertRegularFile(path, label) {
  const stats = await lstat(path);
  if (!stats.isFile()) throw new Error(`${label} must be a regular file: ${path}`);
}

export async function resolveHyosanAssetSource(assetPath, sourceRoot = assetSourceRoot) {
  assertSafeAssetPath(assetPath);
  const canonicalRoot = await realpath(sourceRoot);
  const lexicalSource = resolve(sourceRoot, assetPath);
  const lexicalRelative = portableRelative(sourceRoot, lexicalSource);
  if (lexicalRelative !== assetPath || lexicalRelative.startsWith(`..${sep}`) || isAbsolute(lexicalRelative)) {
    throw new Error(`Hyosan asset escaped the canonical source root: ${assetPath}`);
  }
  const source = await realpath(lexicalSource);
  const sourceRelative = portableRelative(canonicalRoot, source);
  if (sourceRelative !== assetPath || sourceRelative.startsWith(`..${sep}`) || isAbsolute(sourceRelative)) {
    throw new Error(`Hyosan asset realpath escaped the canonical source root: ${assetPath}`);
  }
  await assertRegularFile(source, 'Hyosan canonical asset');
  return source;
}

async function copyAllowlistedAssets(allowlist) {
  await rm(join(outputRoot, 'api'), { recursive: true, force: true });
  await rm(encodedRoot, { recursive: true, force: true });
  await mkdir(outputAssetRoot, { recursive: true });
  await mkdir(join(encodedRoot, 'br'), { recursive: true });
  await mkdir(join(encodedRoot, 'gzip'), { recursive: true });

  const assets = [];
  for (const entry of allowlist) {
    const sourcePath = await resolveHyosanAssetSource(entry.source);
    const bytes = await readFile(sourcePath);
    const originalPath = join(outputAssetRoot, entry.name);
    await copyFile(sourcePath, originalPath);

    const original = {
      path: `api/dev/hyosan-3d/${entry.name}`,
      bytes: bytes.byteLength,
      sha256: createHash('sha256').update(bytes).digest('hex'),
    };
    const encodings = {};
    if (entry.name.toLowerCase().endsWith('.glb')) {
      const variants = {
        br: await compressBrotli(bytes, {
          params: { [constants.BROTLI_PARAM_QUALITY]: 6 },
        }),
        gzip: await compressGzip(bytes),
      };
      for (const [encoding, encoded] of Object.entries(variants)) {
        const encodedPath = join(encodedRoot, encoding, entry.name);
        await writeFile(encodedPath, encoded);
        encodings[encoding] = {
          path: `__encoded/${encoding}/${entry.name}`,
          bytes: encoded.byteLength,
          sha256: createHash('sha256').update(encoded).digest('hex'),
        };
      }
    }
    assets.push(Object.freeze({
      name: entry.name,
      source: `docs/games/hyosan-memories-3d/assets/${entry.source}`,
      original,
      encodings: Object.freeze(encodings),
    }));
  }
  return Object.freeze(assets);
}

async function regularFiles(root) {
  const stats = await lstat(root);
  if (stats.isSymbolicLink()) throw new Error(`Showcase output must not contain symlinks: ${root}`);
  if (stats.isFile()) return [root];
  if (!stats.isDirectory()) throw new Error(`Showcase output entry is not a file or directory: ${root}`);
  const entries = await readdir(root, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    const path = join(root, entry.name);
    if (entry.isSymbolicLink()) throw new Error(`Showcase output must not contain symlinks: ${path}`);
    if (entry.isDirectory()) files.push(...await regularFiles(path));
    else if (entry.isFile()) files.push(path);
    else throw new Error(`Showcase output contains an unsupported entry: ${path}`);
  }
  return files;
}

async function describeFile(path, relativePath, label) {
  await assertRegularFile(path, label);
  const bytes = await readFile(path);
  return Object.freeze({
    path: relativePath,
    bytes: bytes.byteLength,
    sha256: createHash('sha256').update(bytes).digest('hex'),
  });
}

async function describeInputs() {
  return Object.freeze(await Promise.all(inputPaths.map((relativePath) => describeFile(
    resolve(repositoryRoot, relativePath),
    relativePath,
    'Hyosan showcase input',
  ))));
}

function isAllowedBuiltOutput(relativePath) {
  if (relativePath === 'index.html') return true;
  const lowerPath = relativePath.toLowerCase();
  if (!relativePath.startsWith('assets/') || lowerPath.endsWith('.map') || lowerPath.endsWith('.env')) return false;
  const basename = relativePath.slice('assets/'.length);
  return basename.length > 0 && !basename.includes('/') && /\.(?:js|css)$/i.test(basename);
}

export function assertNoHyosanShowcaseQaTokens(bytes, relativePath) {
  for (const token of ['__HYOSAN_3D_QA__', 'NEXT_PUBLIC_HYOSAN_TEST_DRIVER', 'process.env.NEXT_PUBLIC_HYOSAN_TEST_DRIVER']) {
    if (bytes.includes(Buffer.from(token))) {
      throw new Error(`Showcase bundle contains forbidden QA driver token ${token}: ${relativePath}`);
    }
  }
}

async function describeBuiltOutputs(files) {
  const outputFiles = files
    .map((path) => portableRelative(outputRoot, path))
    .filter(isAllowedBuiltOutput)
    .sort();
  return Object.freeze(await Promise.all(outputFiles.map((relativePath) => (
    describeFile(resolve(outputRoot, relativePath), relativePath, 'Hyosan showcase build output')
  ))));
}

async function verifyShowcaseOutput(allowlist, assets, inputs) {
  const files = await regularFiles(outputRoot);
  const relativeFiles = files.map((path) => portableRelative(outputRoot, path));
  const expectedOriginals = new Set(allowlist.map(({ name }) => `api/dev/hyosan-3d/${name}`));
  const expectedEncoded = new Set(
    allowlist
      .filter(({ name }) => name.toLowerCase().endsWith('.glb'))
      .flatMap(({ name }) => [`__encoded/br/${name}`, `__encoded/gzip/${name}`]),
  );
  const expectedBuilt = new Set(relativeFiles.filter(isAllowedBuiltOutput));
  if (!relativeFiles.includes('index.html')) throw new Error('Showcase build output is missing index.html');
  if (expectedBuilt.size === 0) throw new Error('Showcase build output is missing assets/* JavaScript or CSS');
  if (relativeFiles.some((path) => !expectedOriginals.has(path)
    && !expectedEncoded.has(path)
    && path !== 'index.html'
    && path !== 'hyosan-showcase-manifest.json'
    && !isAllowedBuiltOutput(path))) {
    const unexpected = relativeFiles.find((path) => !expectedOriginals.has(path)
      && !expectedEncoded.has(path)
      && path !== 'index.html'
      && path !== 'hyosan-showcase-manifest.json'
      && !isAllowedBuiltOutput(path));
    throw new Error(`Unexpected showcase output file: ${unexpected}`);
  }
  for (const path of expectedOriginals) if (!relativeFiles.includes(path)) throw new Error(`Missing showcase asset: ${path}`);
  for (const path of expectedEncoded) if (!relativeFiles.includes(path)) throw new Error(`Missing showcase encoding: ${path}`);

  const manifest = {
    version: 1,
    source: 'components/games/hyosan-memories-3d/asset-route.server.ts',
    inputs,
    outputFiles: await describeBuiltOutputs(files),
    assets,
  };
  await writeFile(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`);

  for (const asset of assets) {
    const originalBytes = await readFile(join(outputRoot, asset.original.path));
    const originalSha256 = createHash('sha256').update(originalBytes).digest('hex');
    if (originalBytes.byteLength !== asset.original.bytes || originalSha256 !== asset.original.sha256) {
      throw new Error(`Showcase asset manifest drifted for ${asset.original.path}`);
    }
    for (const [encoding, descriptor] of Object.entries(asset.encodings)) {
      const bytes = await readFile(join(outputRoot, descriptor.path));
      const sha256 = createHash('sha256').update(bytes).digest('hex');
      if (bytes.byteLength !== descriptor.bytes || sha256 !== descriptor.sha256) {
        throw new Error(`Showcase asset manifest drifted for ${descriptor.path}`);
      }
      const decoded = encoding === 'br' ? await decompressBrotli(bytes) : await decompressGzip(bytes);
      if (!decoded.equals(originalBytes)) throw new Error(`Showcase ${encoding} encoding drifted for ${asset.name}`);
    }
  }

  for (const path of files) {
    const relativePath = portableRelative(outputRoot, path);
    if (!isAllowedBuiltOutput(relativePath)) continue;
    assertNoHyosanShowcaseQaTokens(await readFile(path), relativePath);
  }
  const finalFiles = await regularFiles(outputRoot);
  const finalRelativeFiles = finalFiles.map((path) => portableRelative(outputRoot, path));
  const expectedFinalFiles = new Set([
    ...expectedOriginals,
    ...expectedEncoded,
    'index.html',
    'hyosan-showcase-manifest.json',
    ...expectedBuilt,
  ]);
  const unexpectedFinal = finalRelativeFiles.find((path) => !expectedFinalFiles.has(path));
  if (unexpectedFinal) throw new Error(`Unexpected showcase output file: ${unexpectedFinal}`);
  if (finalRelativeFiles.length !== expectedFinalFiles.size) {
    throw new Error('Showcase output file set does not match the allowlist');
  }
  return Object.freeze({ files: finalFiles.length, assets: allowlist.length, manifest: manifestPath });
}

export async function buildHyosanShowcase({
  root = repositoryRoot,
  routeSource = routeSourcePath,
  configFile = join(showcaseRoot, 'vite.config.ts'),
  output = outputRoot,
} = {}) {
  if (root !== repositoryRoot || routeSource !== routeSourcePath || configFile !== join(showcaseRoot, 'vite.config.ts') || output !== outputRoot) {
    throw new Error('Hyosan showcase build paths are fixed to the repository-owned output contract');
  }
  const routeSourceText = await readFile(routeSource, 'utf8');
  const allowlist = extractHyosanAssetAllowlist(routeSourceText, routeSource);
  const inputSnapshot = await describeInputs();

  await rm(outputRoot, { recursive: true, force: true });
  await viteBuild({ configFile, mode: 'production' });
  const currentInputs = await describeInputs();
  if (JSON.stringify(inputSnapshot) !== JSON.stringify(currentInputs)) {
    throw new Error('Hyosan showcase inputs changed during the build');
  }
  const assets = await copyAllowlistedAssets(allowlist);
  return verifyShowcaseOutput(allowlist, assets, currentInputs);
}

if (process.argv[1] && pathToFileURL(process.argv[1]).href === import.meta.url) {
  buildHyosanShowcase().then((result) => {
    console.log(`Hyosan showcase build passed (${result.files} files, ${result.assets} canonical assets)`);
    console.log(`Manifest: ${result.manifest}`);
  }).catch((error) => {
    console.error(error instanceof Error ? error.message : error);
    process.exitCode = 1;
  });
}
